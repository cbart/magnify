/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset;

/**
 * Sometimes user want to construct {@link AS0ResultsetBinder} but is working
 * in remote environment where he doesn't have nametranslator available
 * (know the name as String, but doesn't name the nameId yet).
 * 
 * So he should construct {@link AS0ResultsetBinderExtTemp} and some
 * processing layer (where nametranslator is available) should finish 
 * initialization of this value (so call {@link #initNameIdAs(int)}).
 * 
 * After that operation ({@link #initNameIdAs(int)} the value 
 * is fully equivalent to {@link AS0ResultsetBinder}.
 * 
 * Before {@link #initNameIdAs(int)} calculation of {@link #hashCode()} can be not possible
 * (hashcode is based on nameId)
 * 
 * @author ptab
 */
public interface AS0ResultsetBinderExtTemp extends AS0ResultsetBinder{

  public void initNameIdAs(int nameId);
  
  /**
   * {@inheritDoc}
   * 
   * @throws IllegalStateException before initNameIdAs has been called. 
   */
  public int getNameId();
  
  public boolean isInitialized();
}