/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.model.as0.api.ro;

import java.util.Map;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

public interface AS0ComplexObjectRO extends AS0ObjectRO/*, Iterable<Long>*/{
//  /**
//   * Count of subobjects.
//   *
//   * @return count of subobjects.
//   */
//  long getSize();
//
  /**
   * Get subobject Ids iterator.
   *
   * Instance of iterator through all the subobjects OIDs.
   */
  public ClosableIterator<AbstractOid> iterator() throws ModelException;

  /**
   * Get subobject Ids iterator.
   *
   * Instance of iterator through the subobjects OIDs, that has given name.
   */
  public ClosableIterator<AbstractOid> getIteratorBySubobjectNameId(int name_id) throws ModelException;

  /**
   * Returns map name_id into iterator of oids
   * @return
   * @throws ModelException
   */
  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap() throws ModelException;
}
