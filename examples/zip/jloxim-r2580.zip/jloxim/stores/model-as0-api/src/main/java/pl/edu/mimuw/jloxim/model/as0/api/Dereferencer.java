/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

public interface Dereferencer {

  /**
   * <ul>
   *  <li>Dereference reference into: 
   *     <ul>
   *        <li>If atomic found - returns it's value</li>
   *        <li>If pointer found - try to recursivly derefence it. 
   *        <li>If complex found - throw an exception</li> 
   *     <ul>  
   * </ul>
   * @param t - transaction
   * @param r
   * @return
   * @throws ExecutionException
   */
  public abstract AtomicValue toAtomicValue(AbstractOid oid) throws ModelException;

  /**
   * Converts:
   * <ul>
   *   <li>Atomic object into it's value itself</li>
   *  <li>Recursively interprets objects inside bag/sequence/struct of size 1</li>
   *  <li>Dereferences  references (not blocked). 
   *     <ul>
   *        <li>If atomic found - returns it's value</li>
   *        <li>If pointer found - try to recursivly derefence it. 
   *        <li>If complex found - throw an exception</li> 
   *     <ul>  
   *  <li>In other cases it throws an exception</li>  
   * </ul>
   * @param t
   * @param r
   * @return
   * @throws ExecutionException
   */
  public abstract AtomicValue toAtomicValue(AS0Resultset r) throws ModelException;

  /**
   * Converts:
   * <ul>  
   *  <li>Reference to atomic object into the atomic value</li>
   *  <li>Reference to pointer object into the pointer destination</li>
   *  <li>deep=true: Reference to complex object into struct of binders to dereferenced subobjects</li>
   *  <li>deep=false: Reference to complex object into struct of binders to references to subobjects</li>   *    
   * </ul>
   * 
   * 
   * @param t
   * @param r
   * @return
   * @throws ExecutionException
   */

  public abstract AS0Resultset dereference(AbstractOid oid, boolean deep) throws ModelException;

  /**
   * Converts:
   * <ul>  
   *  <li>If force=false and reference have blocked dereferencing the method returns the reference itself (unchanged)</li> 
   *  <li>Reference to atomic object into the atomic value</li>
   *  <li>Reference to pointer object into the pointer destination</li>
   *  <li>deep=true: Reference to complex object into struct of binders to dereferenced subobjects</li>
   *  <li>deep=false: Reference to complex object into struct of binders to references to subobjects</li>
   *   <li>Sequence/Bag/Struct of references into Sequence/Bag/Struct of recursivly dereferenced objects</li>   
   *  <li>Other objects </li> 
   * </ul>
   * 
   * 
   * @param t
   * @param r
   * @return
   * @throws ExecutionException
   */
  public abstract AS0Resultset dereference(AS0Resultset r, boolean deep, boolean force) throws ModelException;

}