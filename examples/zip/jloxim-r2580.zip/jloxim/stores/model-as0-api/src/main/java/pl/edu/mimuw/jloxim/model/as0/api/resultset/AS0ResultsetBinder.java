/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset;

/**
 * <p>All binders have to contain nameId and binded value.<p>
 * <p>Some binders (#hasName) also knows what's translated name of the nameId</p>
 * <p>There could be also binders in temporary form: </p>  
 * 
 * <p>{@link #hashCode()} and {@link #equals(Object)} depends only on {@link #getValue()} and {@link #getNameId()}).
 * In particular it does not depend on {@link #getName()}. {@link #getName()} is only a cache and should be derived from the {@link #getNameId()}.</p></p> 
 * 
 * @version $Id: AS0ResultsetBinder.java 2066 2010-09-17 16:24:55Z ptab $
 */
public interface AS0ResultsetBinder extends AS0Resultset {

  AS0Resultset getValue();
  
  int getNameId();  
  
  boolean hasName();
  
  String getName();
  
  /**
   * Stored by this method name works like cache. It doesn't affect {@link #hashCode()} or {@link #equals(Object)} of resultsets
   * 
   * @param newName
   */
  void setName(String newName);
}
