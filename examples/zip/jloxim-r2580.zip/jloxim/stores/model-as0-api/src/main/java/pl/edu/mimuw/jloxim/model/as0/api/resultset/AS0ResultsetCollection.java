/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.api.resultset;

public interface AS0ResultsetCollection extends AS0Resultset, Iterable<AS0Resultset> {
  
  interface Builder {
     /**
      * Add items to the collection. 
      */
     public Builder add(AS0Resultset r);
     
     /** 
      * @return this
      */
     public Builder addAll(Iterable<AS0Resultset> r);
     
     /**
      * Works the same as {@link #addAll(Iterable)} but support flow interface (returns 'this')
      * @param r
      * @return true if the builder has been modified in the result of the operation
      */
     public boolean addAllCheckChanges(Iterable<AS0Resultset> r);
   
     /**
      * If the collection is itself 'singleton' the single item is returned itself
      * @return
      */
     public AS0Resultset build(); 
  }
  
  public boolean contains(AS0Resultset r);
  public int size();
  public boolean isEmpty();
}
