/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.api.resultset;

import java.io.Serializable;
import java.lang.annotation.Inherited;

public interface AS0Resultset extends Serializable {

  /**
   * If the resultset is {@link AS0ResultsetBag} or {@link AS0ResultsetSequence} it is returned 
   * as is. In other cases it is created a 'degenerated' bug that contains this single item.
   * 
   * The method should be only used to unificate bag's and simple values treatment by the algorithms
   * 
   * Be careful - struct is returned as bag of struct (so it is really wrapped)
   * */
  public AS0ResultsetBag wrapAsBag();
  
  /**
   * Calculates hashcode of the whole subtree using nameIds in case of binders. 
   *    
   * @throws IllegalStateException if the nameId is not set for any binder 
   */
  public long hashCodeInternal();
  
  /**
   * Calculates hashcode of the whole subtree using name (String) in case of binders.
   * 
   * Respects model criteria (for example order of items in bug is not significant)
   * 
   * @throws IllegalStateException if the name is not set for any binder 
   */
  public long hashCodeExternal();

  /**
   * Compares this resultset with given resultset. In case of binders uses nameId.
   * 
   * @throws IllegalStateException if the nameId is not set for any binder  
   */
  public boolean equalsUsingInternal(AS0Resultset r2);
  
  /**
   * Compares this resultset with given resultset. In case of binders uses name.
   * 
   * @throws IllegalStateException if the name is not set for any binder
   */
  public boolean equalsUsingExternal(AS0Resultset r2);
  
  /**
   * {@link Inherited}
   * 
   * Works like {@link #equalsUsingInternal(AS0Resultset)}
   * 
   * @throws IllegalStateException if the nameId is not set for any binder 
   */
  @Override
  public int hashCode();
  
  /**
   * {@link Inherited}
   * 
   * Works like {@link #equalsUsingInternal(AS0Resultset)}
   * 
   * @throws IllegalStateException if the nameId is not set for any binder 
   */
  @Override
  public boolean equals(Object obj);  
}
