/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;

/**
 * 
 * @author ptab@mimuw.edu.pl
 */
public interface ResultCollector extends WarningSink{
  
  /** 
   * <p>Use this instead response collector.</p>
   *    
   * <p>Do not use this {@link AS0ResultsetFactory} to create intermediate results in the executor. 
   * It's possible that some implementation of this interface, the created objects are eagerly send
   * to the client (streamed through network). It's pointless to send to the client intermediate results</p>  
   *   
   * @return resultsetFactory that should be used to create FINAL {@link AS0Resultset}
   */
  AS0ResultsetFactory getFinalAs0ResultsetFactory();

  /**
   * If you created resultset using other resultset then this provided by {@link #getFinalAs0ResultsetFactory()}
   * and you want to use it in a final result, you should call this method on the resultset and use returned resultset
   * instead. 
   * 
   * <p>This method could for example queue the resultset to be sent to the user.</p>
   * 
   * <p>You don't have to adoptResultset created using the {@link #getFinalAs0ResultsetFactory()}. 
   *   
   * @param resultset
   * @return
   */
  AS0Resultset adoptResultset(AS0Resultset resultset);
  
  /**
   * Set's a result of the query. 
   * 
   * <p>You MUST NOT call that method twice </p>
   * 
   * <p>It's allowed (but not recommended) that {@link AS0Resultset} set by this method
   * has been created (totally or partially) using other {@link AS0ResultsetFactory} then
   * the one provided by {@link #getFinalAs0ResultsetFactory()}. </p>
   * 
   * @param result
   */
  void provideQueryResponse(AS0Resultset result); 
  
  /**
   * Optional method to inform user how big part of query-processing process has been finished. 
   * 
   * It can be used for informational purposes only.
   * 
   * @param value between 0.0 and 100.0
   */
  void setPercentCompleted(double completion);
}
