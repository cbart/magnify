/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset;

import javax.annotation.Nullable;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection.Builder;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

import com.google.common.base.Function;

public interface AS0ResultsetFactory {
  public AS0ResultsetAtomic createAtomic(AtomicValue value);

  public Builder createStructBuilder();

  public Builder createSequenceBuilder();

  public Builder createBagBuilder();
  
  /**
   * If origin is sequence - create sequence or bag otherwise
   */
  public Builder createBagOrSequenceBuilderAsOrigin(AS0ResultsetBag origin);

  public AS0ResultsetRef createRef(AbstractOid oid);

  public AS0ResultsetBinder createBinder(AS0Resultset createRef, Integer nameId);

  public AS0ResultsetBinder createBinder(AS0Resultset createRef, Integer nameId, @Nullable String name);
  
  public AS0ResultsetBinderExtTemp createBinder(AS0Resultset createRef, String name);
  
  public AS0ResultsetMethod createMethod(Function<AS0Resultset[], AS0Resultset> method);
}
