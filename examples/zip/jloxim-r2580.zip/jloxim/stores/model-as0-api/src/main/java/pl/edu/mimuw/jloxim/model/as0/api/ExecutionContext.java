/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api;

import java.util.LinkedList;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

public interface ExecutionContext extends Dereferencer, WarningSink{     
   public AS0ResultsetFactory getResultsetFactory();

   /**
    * Gets the {@link AtomicValueFactory} object which should be used to create {@link AtomicValue} objects.
    *  
    * @return An instance of the {@link AtomicValueFactory} object.
    */
   public AtomicValueFactory  getAtomicValueFactory();   

   /**
    * Gets the {@link AS0ObjectsFactory} object which can be used to create 
    * AS0 objects.
    * 
    * @return An instance of the {@link AS0ObjectsFactory} class which can be used to create 
    * AS0 objects.
    */
   public AS0ObjectsFactory getAs0ObjectsFactory();

   /**
  * Gets underlying {@link Transaction} for this.
  * @return the transaction
  */
   public Transaction getTransaction();
   
  public ExecutionContext createNestedContext(AS0Resultset resultset);
  //@Deprecated - when we will create real nested context
  public void unnestContext();
 
  public AS0Resultset bindName(int nameId);

  public AbstractOid addSubobject(AbstractOid refOID,
      AS0ObjectEditable buildAS0ObjectNode);

  public void setAtomicObjectValue(AbstractOid refOID, AtomicValue value);

  public void setNewPointerObjectDestination(AbstractOid refOID, AbstractOid refOID2);

  public void removeObject(AbstractOid refOID);

  public void removeObjects(AbstractOid[] oids);

  public void setNewComplexObjectValue(AbstractOid refOID,
      LinkedList<AS0ObjectEditable> subObjects);
}
