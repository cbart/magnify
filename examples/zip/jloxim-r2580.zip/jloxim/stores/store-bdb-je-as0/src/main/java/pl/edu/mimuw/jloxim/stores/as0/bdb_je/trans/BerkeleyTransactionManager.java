/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.trans;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;

import com.google.common.collect.Sets;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.TransactionConfig;

public class BerkeleyTransactionManager implements TransactionManager {
  private static final Logger logger = Logger.getLogger(BerkeleyTransactionManager.class);
  private final LinkedHashSet<BerkeleyTransaction> active_transactions = Sets.newLinkedHashSet();
  private final Environment environment;
  private final Map<TransactionIsolationLevel, TransactionConfig> txcConfsMap;
    
  public BerkeleyTransactionManager(Environment environment,
        Map<TransactionIsolationLevel, TransactionConfig> txcConfsMap) {
    logger.info("Created BerkeleyTransactionManager (" + this + ") " +
    		"that uses environment: " + environment);
    this.environment = environment;
    this.txcConfsMap = txcConfsMap;
  }

  public List<Transaction> getAllActiveTransactions() {
    //TODO: Can be provided faster (without copying) solution.
    return new LinkedList<Transaction>(active_transactions);
  }

  public Transaction newTransaction(TransactionIsolationLevel isolationLevel) throws TransactionManagerException {
    logger.info(this + " is creating new transaction");
    TransactionConfig transConfig=getConfForIsolationLevel(isolationLevel);
    if (transConfig!=null)
    {
      BerkeleyTransaction bt;
      try {
        bt = new BerkeleyTransaction(environment, transConfig, isolationLevel, this);
      } catch (DatabaseException e) {
        throw new TransactionManagerException(e);
      }
      active_transactions.add(bt);
      return bt;
    }else{
      throw new TransactionManagerException("Isolation level: "+isolationLevel+" not supported");
    }
  }

  private TransactionConfig getConfForIsolationLevel(
      TransactionIsolationLevel isolationLevel) {
    return txcConfsMap.get(isolationLevel);
  }

  public void removeActiveTransaction(BerkeleyTransaction berkeleyTransaction) {
    active_transactions.remove(berkeleyTransaction);    
  }
}
