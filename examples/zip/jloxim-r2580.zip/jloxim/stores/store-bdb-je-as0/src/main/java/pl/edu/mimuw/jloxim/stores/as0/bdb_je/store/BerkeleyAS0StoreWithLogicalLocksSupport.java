/*
 * Copyright 2011 Faculty of Mathematics Informatics and Mechanics at the University of Warsaw.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store;

import com.google.common.collect.Sets;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.CursorConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.SortedSet;
import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.lock_mgrs.api.LockTypeEnum;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0WithLogicalLocksSupport;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.callbacks.Callback;

/**
 *
 * @author mlenart
 * @version $Id: BerkeleyAS0StoreWithLogicalLocksSupport.java 2522 2011-09-29 23:49:08Z mlenart $
 */
public class BerkeleyAS0StoreWithLogicalLocksSupport
		extends BerkeleyAs0Store
		implements StoreAS0WithLogicalLocksSupport {
	
	@SuppressWarnings("unused")
	private final static Logger logger = Logger.getLogger(BerkeleyAS0StoreWithLogicalLocksSupport.class);

	@Override
	public void getLogicalLock(Transaction t, AbstractOid OID, LockTypeEnum type)
			throws StoreException {
		if (!getSuperRootOid().equals(OID)
				&& !getConfigRootOid().equals(OID)
				&& type != LockTypeEnum.NONE_LOCK) {
			doGetLogicalLock(t, OID, type);
		}
	}

	private void doGetLogicalLock(Transaction t, AbstractOid OID, LockTypeEnum type)
			throws StoreException {
		long oid = interpreteAbstractOid(OID);
		com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
		try {
			Cursor cursor = getAs0store().openCursor(realTrans, CursorConfig.DEFAULT);
			addCloseCursorCallbacks(t, cursor);
			OperationStatus os = cursor.getSearchKey(
					long2key(oid),
					new DatabaseEntry(),
					getBDBLockMode(type));
			if (os != OperationStatus.SUCCESS) {
				
				if (os == OperationStatus.NOTFOUND) {
					throw new ObjectNotFoundStoreException(
							getStoreId(),
							"Cannot find object with OID=" + oid);
				}
				else {
					throw new StoreException(
							getStoreId(),
							"Unexpected operation status:" + os);
				}
			}
		}
		catch (DatabaseException e) {
			throw new StoreException(getStoreId(),
					"Cannot proceed getObjectByOID(..., " + oid + ")", e);
		}
	}

	@Override
	public void getLogicalLocks(Transaction t, AbstractOid[] OIDs, LockTypeEnum type)
			throws StoreException {
		SortedSet<AbstractOid> oidsSet = Sets.newTreeSet(Arrays.asList(OIDs));
		oidsSet.remove(getSuperRootOid());
		oidsSet.remove(getConfigRootOid());
		if (type != LockTypeEnum.NONE_LOCK) {
			for (AbstractOid oid : oidsSet) {
				doGetLogicalLock(t, oid, type);
			}
		}
	}

	private void addCloseCursorCallbacks(Transaction t, Cursor cursor) {
		t.getBeforeCommitCallbacksManager().addCallback(new CloseCursorCallback(cursor));
		t.getBeforeRollbackCallbacksManager().addCallback(new CloseCursorCallback(cursor));
	}

	private LockMode getBDBLockMode(LockTypeEnum lockType) {
		if (EnumSet.of(LockTypeEnum.CONCURRENT_READ, LockTypeEnum.CONCURRENT_WRITE).contains(lockType)) {
			return LockMode.DEFAULT;
		}
		else {
			return LockMode.RMW;
		}
	}

	private static class CloseCursorCallback implements Callback<Transaction, TransactionException> {

		private final Cursor cursor;

		public CloseCursorCallback(Cursor cursor) {
			this.cursor = cursor;
		}

		@Override
		public void process(Transaction t) throws TransactionException {
			try {
//				logger.error("CLOSE CURSOR");
				cursor.close();
			}
			catch (Throwable ex) {}
		}
	}
}
