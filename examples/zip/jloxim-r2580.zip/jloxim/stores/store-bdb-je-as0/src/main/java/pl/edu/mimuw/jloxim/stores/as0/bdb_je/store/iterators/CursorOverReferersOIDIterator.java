/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.iterators;

import pl.edu.mimuw.jloxim.stores.as0.bdb_je.CursorBerkeleyIterator;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;

public class CursorOverReferersOIDIterator extends CursorBerkeleyIterator<Long> {
  private long OID;
  private final TupleBinding<Long> longTupleBinding=TupleBinding.getPrimitiveBinding(Long.class);
  
  
  public CursorOverReferersOIDIterator(Cursor c, long POID) {
    super(c);
    OID=POID;
  }

  /**
   * pkey - Parent_OID, Child_name<br/>
   * key -> OID 
   */
  @Override
  protected Long parseData(DatabaseEntry key, DatabaseEntry pkey, DatabaseEntry data) {
    return longTupleBinding.entryToObject(pkey);
  }

  @Override
  protected void positionCursorAtFirst(Cursor cursor) {
    DatabaseEntry firstKey=new DatabaseEntry();
    longTupleBinding.objectToEntry(OID, firstKey);
    try {
      OperationStatus os=cursor.getSearchKey(firstKey, new DatabaseEntry(), LockMode.DEFAULT);
      if (os==OperationStatus.NOTFOUND){
        setCursorEOF();
      }
    } catch (DatabaseException e) {
      setCorrupted();
    }
    setWish(WishEnum.NEXT_DUP);
  }
}
