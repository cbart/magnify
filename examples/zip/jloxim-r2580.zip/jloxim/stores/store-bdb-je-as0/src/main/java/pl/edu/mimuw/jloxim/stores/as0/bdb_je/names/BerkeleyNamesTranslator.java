/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.names;

import java.util.Map.Entry;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundNameTranslatorException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.CursorConfig;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.SecondaryConfig;
import com.sleepycat.je.SecondaryDatabase;
import com.sleepycat.je.Sequence;
import com.sleepycat.je.SequenceConfig;

public class BerkeleyNamesTranslator implements NamesTranslator {
  private Logger logger = Logger.getLogger(BerkeleyNamesTranslator.class);
  // ======================= Injected environment ==========================
  private Environment environment;
  private DatabaseConfig dbConfig;

  public Environment getEnvironment() {
    return environment;
  }

  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  public void setDbConfig(DatabaseConfig dbConfig) {
    this.dbConfig = dbConfig;
  }

  public DatabaseConfig getDbConfig() {
    return dbConfig;
  }

  // ======================== Laizy generated environment ===================
  private static final TupleBinding<Integer> integerBinding = TupleBinding
      .getPrimitiveBinding(Integer.class);
  private static final TupleBinding<String> stringBinding = TupleBinding
      .getPrimitiveBinding(String.class);
  private static final String MAGIC_SEQUENCE_KEY = "";

  private Database namesDatabase;
  private SecondaryDatabase namesIndex;
  private Sequence sequence;

  private Database getNamesDatabase() {
    return namesDatabase;
  }

  private Integer getNextSequenceValue() throws DatabaseException {
    return ((Long) sequence.get(null, 1)).intValue();
  }

  // ====================== Operations ======================================
  public void init() throws DatabaseException {
    namesDatabase = environment.openDatabase(null, "nameTranslatorDB",
        dbConfig);

    SecondaryConfig indexDbConfig = new SecondaryConfig();
    indexDbConfig.setKeyCreator(new CopyValueSecondaryKeyCreator());
    indexDbConfig.setAllowCreate(dbConfig.getAllowCreate());
    indexDbConfig.setDeferredWrite(dbConfig.getDeferredWrite());
    indexDbConfig.setAllowPopulate(true);
    namesIndex = environment.openSecondaryDatabase(null,
        "nameTranslatorDBindex", namesDatabase, indexDbConfig);

    SequenceConfig sc = new SequenceConfig();
    sc.setAllowCreate(true);
    sc.setCacheSize(100);
    sc.setInitialValue(SUPERROOT + 1);
    DatabaseEntry sequence_key = new DatabaseEntry();
    stringBinding.objectToEntry(MAGIC_SEQUENCE_KEY, sequence_key);
    sequence = namesDatabase.openSequence(null, sequence_key, sc);
    putValue(namesDatabase, SUPERROOT, "/");
  }

  /**
   * @return true - if ADDED, false if key already EXISTS, exception otherwise.
   */
  private boolean putValue(Database db, int value, String name) {
    DatabaseEntry theNameEntry = new DatabaseEntry();
    DatabaseEntry theValueEntry = new DatabaseEntry();
    integerBinding.objectToEntry(value, theValueEntry);
    stringBinding.objectToEntry(name, theNameEntry);
    OperationStatus put_res = db.put(null, theNameEntry, theValueEntry);
    if (put_res == OperationStatus.SUCCESS) {
      return true;
    } else if (put_res == OperationStatus.KEYEXIST) {
      /* race condition occured */
      return false;
    } else {
      throw new NameTranslatorException("Cannot add namesTranslator:" + name);
    }
  }
  
  public int getOrRegisterName(String name) throws NameTranslatorException {
    try {
      Database db = getNamesDatabase();
      DatabaseEntry theNameEntry = new DatabaseEntry();
      DatabaseEntry theValueEntry = new DatabaseEntry();
      stringBinding.objectToEntry(name, theNameEntry);
      OperationStatus os = db.get(null, theNameEntry, theValueEntry,
          LockMode.READ_UNCOMMITTED);
      if (os == OperationStatus.SUCCESS) {
        return integerBinding.entryToObject(theValueEntry);
      } else if (os == OperationStatus.NOTFOUND) {
        int value = getNextSequenceValue();
        if (putValue(db, value, name)) {
          return value;
        } else {
          /* race condition occured */
          return getNameIdByName(name);
        }
      } else {
        throw new NameTranslatorException(
            "Unexpected operational status during getting the (" + name + ") name:" + os);
      }
    } catch (DatabaseException e) {
      throw new NameTranslatorException("Error in getOrRegisterName()", e);
    }
  }

  public ClosableIterator<? extends Entry<Integer, String>> getAllEntries()
      throws NameTranslatorException {
    try {
      Database db = getNamesDatabase();
      CursorConfig cursorConfig = new CursorConfig();
      cursorConfig.setReadUncommitted(true);
      Cursor cursor = db.openCursor(null, cursorConfig);
      logger.info("Opened names translator cursor: " + cursor);
      /* Skipping first entry = the sequence */
      cursor.getFirst(new DatabaseEntry(), new DatabaseEntry(),
          LockMode.DEFAULT);
      return new NamesTranslatorIterator(cursor);
    } catch (DatabaseException e) {
      throw new NameTranslatorException(e);
    }
  }

  public String getNameByNameId(int name_id) throws NameTranslatorException {
    try {
      SecondaryDatabase index = getNamesIndex();
      DatabaseEntry theNameEntry = new DatabaseEntry();
      DatabaseEntry theNameIdEntry = new DatabaseEntry();
      DatabaseEntry theValueEntry = new DatabaseEntry();

      integerBinding.objectToEntry(name_id, theNameIdEntry);
      OperationStatus os = index.get(null, theNameIdEntry, theNameEntry,
          theValueEntry, LockMode.READ_UNCOMMITTED);
      if (os == OperationStatus.SUCCESS) {
        return stringBinding.entryToObject(theNameEntry);
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundNameTranslatorException(
            "Cannot find name_id: " + name_id);
      } else {
        throw new NameTranslatorException(
            "Problem with getting name_id: " + name_id);
      }
    } catch (DatabaseException e) {
      throw new NameTranslatorException(e);
    }
  }

  private SecondaryDatabase getNamesIndex() throws DatabaseException {
    if (namesIndex == null) {
      getNamesDatabase();
      assert namesIndex != null;
    }
    return namesIndex;
  }

  public int getNameIdByName(String name) throws NameTranslatorException {
    try {
      Database db = getNamesDatabase();
      DatabaseEntry theNameEntry = new DatabaseEntry();
      DatabaseEntry theValueEntry = new DatabaseEntry();
      stringBinding.objectToEntry(name, theNameEntry);
      OperationStatus os = db.get(null, theNameEntry, theValueEntry,
          LockMode.READ_UNCOMMITTED);
      if (os == OperationStatus.SUCCESS) {
        return integerBinding.entryToObject(theValueEntry);
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundNameTranslatorException(
            "Cannot find name: " + name);
      } else {
        throw new NameTranslatorException("Problem with getting name: "
            + name);
      }
    } catch (DatabaseException e) {
      throw new NameTranslatorException(e);
    }
  }

  public void removeName(String name) throws NameTranslatorException {
    DatabaseEntry theNameEntry = new DatabaseEntry();
    stringBinding.objectToEntry(name, theNameEntry);
    try {
      OperationStatus os = getNamesDatabase().delete(null, theNameEntry);
      if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundNameTranslatorException(
            "Cannot find for removal item key=" + name);
      } else if (os != OperationStatus.SUCCESS) {
        throw new NameTranslatorException("Cannot remove item name="
            + name + "; Unexpected operation status" + os);
      }
    } catch (DatabaseException e) {
      throw new NameTranslatorException("Cannot remove the entry");
    }

  }

  public void removeNameId(int name_id) throws NameTranslatorException {
    DatabaseEntry theNameIdEntry = new DatabaseEntry();
    integerBinding.objectToEntry(name_id, theNameIdEntry);
    try {
      SecondaryDatabase index = getNamesIndex();
      OperationStatus os = index.delete(null, theNameIdEntry);
      if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundNameTranslatorException(
            "Cannot find for removal item key=" + name_id);
      } else if (os != OperationStatus.SUCCESS) {
        throw new NameTranslatorException("Cannot remove item name="
            + name_id + "; Unexpected operation status" + os);
      }
    } catch (DatabaseException e) {
      throw new NameTranslatorException("Cannot remove the entry");
    }
  }

  public void sync() throws NameTranslatorException {
    try {
      if ((namesDatabase != null)
          && (namesDatabase.getConfig().getDeferredWrite()))
        namesDatabase.sync();
      if ((namesIndex != null)
          && (namesIndex.getConfig().getDeferredWrite()))
        namesIndex.sync();
    } catch (DatabaseException e) {
      throw new NameTranslatorException("Cannot sync namesDatabase", e);
    }
  }

  public void close() throws NameTranslatorException {
    try {
      sync();
      if (sequence != null)
        sequence.close();
      if (namesIndex != null)
        namesIndex.close();
      if (namesDatabase != null)
        namesDatabase.close();
    } catch (DatabaseException e) {
      throw new NameTranslatorException(e);
    }
  }

}
