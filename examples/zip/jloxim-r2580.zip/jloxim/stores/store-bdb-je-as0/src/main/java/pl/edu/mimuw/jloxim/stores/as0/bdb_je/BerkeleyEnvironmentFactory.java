/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.EnvironmentLockedException;

public class BerkeleyEnvironmentFactory implements DisposableBean{
  private static final Logger logger=Logger.getLogger(BerkeleyEnvironmentFactory.class);
  private static final File temp_dir = new File(System.getProperty("java.io.tmpdir"), "jloxim_test_data");
  private final static Random random=new Random();
  private EnvironmentConfig envConfig;
  private Set<File>      temporaryDirs=new LinkedHashSet<File>();
  
  private File getUniqTempDir() {
    File f = new File(temp_dir, Long.toString(random.nextLong()));
    if (!f.mkdirs()){
      throw new IllegalStateException("Cannot create temporary directory:"+f.getAbsolutePath());
    }
    return f;
  }
  
  public EnvironmentConfig getEnvConfig() {
    return envConfig;
  }
  
  public void setEnvConfig(EnvironmentConfig envConfig) {
    this.envConfig = envConfig;
  }
  
  public Environment newTemporaryEnvironment() throws EnvironmentLockedException, DatabaseException
  {
    File f= getUniqTempDir();
    temporaryDirs.add(f);
    return new Environment(f, envConfig);
  }
  
  public void destroy() throws Exception {
    removeTemporaryDirs();
  }

  private void removeTemporaryDirs() {
    for (File f:temporaryDirs)
    {
      logger.info("Removing temporary directory with Berkeley DB:"+f);
      deleteDir(f);
    }
    
  }
  
  private static boolean deleteDir(File dir) {
    if (dir.isDirectory()) {
      String[] children = dir.list();
      for (int i = 0; i < children.length; i++) {
        boolean success = deleteDir(new File(dir, children[i]));
        if (!success) {
          return false;
        }
      }
    }
    return dir.delete();
  }
  
}
