/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry;

import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.ChildIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.ChildIndexKeyTupleBinding;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.SecondaryDatabase;
import com.sleepycat.je.SecondaryKeyCreator;

public class StoreEntryChildKeyCreator implements SecondaryKeyCreator{
//  private static final TupleBinding<Integer> integerTupleBinding=TupleBinding.getPrimitiveBinding(Integer.class)
  
  //TODO: Można zastosować jakiś uproszczony - który nie deserializuje wartości
  private TupleBinding<StoreEntry> storeEntryTupleBinding=null;
  private final ChildIndexKeyTupleBinding childIndexKeyTupleBinding=new ChildIndexKeyTupleBinding();
  
  public TupleBinding<StoreEntry> getStoreEntryTupleBinding() {
    return storeEntryTupleBinding;
  }
  
  public void setStoreEntryTupleBinding(
      TupleBinding<StoreEntry> storeEntryTupleBinding) {
    this.storeEntryTupleBinding = storeEntryTupleBinding;
  }
  
  public boolean createSecondaryKey(SecondaryDatabase secondary,
      DatabaseEntry key, DatabaseEntry data, DatabaseEntry result)
      throws DatabaseException {
    StoreEntry entry=storeEntryTupleBinding.entryToObject(data);
    childIndexKeyTupleBinding.objectToEntry(new ChildIndexKey(entry.getParent_oid(), entry.getObject_name_id()), result);
    return true;
  }

}
