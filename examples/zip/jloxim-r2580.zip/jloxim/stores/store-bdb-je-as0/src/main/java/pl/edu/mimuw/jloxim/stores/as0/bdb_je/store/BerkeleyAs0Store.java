/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.impl.ro.AS0AtomicObjectROImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.ro.AS0ObjectROImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.ro.AS0PointerObjectROImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntry;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryAtomic;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryComposite;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryPointer;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryTupleBinding;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.iterators.CursorOverChildsIndexOIDIterator;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.iterators.CursorOverChildsIndexOIDNameIterator;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.iterators.CursorOverReferersOIDIterator;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.iterators.Long2AbstractOidCursorConverter;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.trans.BerkeleyTransaction;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableAndSizeAwareIterator;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.api.callbacks.CallbackWithReturnValue;
import pl.edu.mimuw.jloxim.utils.impl.LazyMap;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.SecondaryConfig;
import com.sleepycat.je.SecondaryCursor;
import com.sleepycat.je.SecondaryDatabase;
import com.sleepycat.je.Sequence;
import com.sleepycat.je.SequenceConfig;

public class BerkeleyAs0Store implements StoreAS0 {
  private final static Logger logger=Logger.getLogger(BerkeleyAs0Store.class);
  private String storeId;

  private Database as0store;
  private Database as0store_sequences;
  private Sequence oidSequence;
  private SecondaryDatabase childsIndex;
  private SecondaryDatabase referersIndex;
  private Environment environment;
  private DatabaseConfig dbConfig;
  private SecondaryConfig childIndexDbConfig;
  private SecondaryConfig refererIndexDbConfig;
  private SequenceConfig sequenceConfig;

  private StoreEntryTupleBinding storeEntryTupleBinding;
  private final TupleBinding<Long> longTupleBinding = TupleBinding.getPrimitiveBinding(Long.class);
  private final TupleBinding<ChildIndexKey> childTupleBinding = new ChildIndexKeyTupleBinding();

  protected Database getAs0store(){
    return as0store;
  }

  public synchronized void init() throws DatabaseException  {
    as0store = environment.openDatabase(null, getDBName("as0store"), dbConfig);
    // TODO: Pewnie sekwencje powinny mieć natywna konfiguracje
    as0store_sequences = environment.openDatabase(null,
        getDBName("as0store_sequences"), dbConfig);

    DatabaseEntry oidSequenceEntry = new DatabaseEntry();
    oidSequenceEntry.setData("oid".getBytes());
    sequenceConfig.setInitialValue(10);
    oidSequence = as0store_sequences.openSequence(null,
        oidSequenceEntry, sequenceConfig);

    childsIndex = environment.openSecondaryDatabase(null,
        getDBName("as0store_childs"), as0store, childIndexDbConfig);
    referersIndex = environment.openSecondaryDatabase(null,
        getDBName("as0store_referers"), as0store, refererIndexDbConfig);

    com.sleepycat.je.Transaction trans = environment.beginTransaction(null, null);
    try{
     as0store.put(trans, long2key(0),
       storeEntry2data(new StoreEntryComposite(NamesTranslator.SUPERROOT, 0/*TODO(ptab): Why 0*/)));
     trans.commit();
    } finally {
      if (trans.isValid()) trans.abort();
    }

  }

  private String getDBName(String name) {
    return name+"_"+getStoreId();
  }

  public Environment getEnvironment() {
    return environment;
  }

  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  public DatabaseConfig getDbConfig() {
    return dbConfig;
  }

  public void setDbConfig(DatabaseConfig dbConfig) {
    this.dbConfig = dbConfig;
  }

  public void setChildIndexDbConfig(SecondaryConfig childIndexDbConfig) {
    this.childIndexDbConfig = childIndexDbConfig;
  }

  public SecondaryConfig getChildIndexDbConfig() {
    return childIndexDbConfig;
  }

  public void setRefererIndexDbConfig(SecondaryConfig refererIndexDbConfig) {
    this.refererIndexDbConfig = refererIndexDbConfig;
  }

  public SecondaryConfig getRefererIndexDbConfig() {
    return refererIndexDbConfig;
  }

  public StoreEntryTupleBinding getStoreEntryTupleBinding() {
    return storeEntryTupleBinding;
  }

  public String getStoreId() {
    return storeId;
  }

  public void setStoreId(String storeId) {
    this.storeId = storeId;
  }

  public void setStoreEntryTupleBinding(
      StoreEntryTupleBinding storeEntryTupleBinding) {
    this.storeEntryTupleBinding = storeEntryTupleBinding;
  }

  public SequenceConfig getSequenceDbConfig() {
    return sequenceConfig;
  }

  public void setSequenceDbConfig(SequenceConfig sequenceDbConfig) {
    this.sequenceConfig = sequenceDbConfig;
  }

  // =========================== helpers ================================

  protected BerkeleyTransaction getBerkeleyTransFromTransaction(
      Transaction transaction) {
    return (BerkeleyTransaction) transaction;
  }

  protected com.sleepycat.je.Transaction getRealBerkeleyTransFromTransaction(
      Transaction transaction) {
    return getBerkeleyTransFromTransaction(transaction)
        .getRealTransaction();
  }

  private long generateInternalOid(){
    getAs0store();
    return oidSequence.get(null, 1);
  }

//  private AbstractOid generateOID() throws DatabaseException {
//    return new LongOid(generateInternalOid());
//  }

  protected DatabaseEntry long2key(long l) {
    DatabaseEntry de = new DatabaseEntry();
    longTupleBinding.objectToEntry(l, de);
    return de;
  }

  // =========================== data edit =================================

  public AbstractOid addSubobject(Transaction t, AbstractOid parent_OID,
      AS0ObjectEditable object) throws StoreException {
    // TODO: Nested transaction ??
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    try {
      if (!getSuperRootOid().equals(parent_OID)
          && !getConfigRootOid().equals(parent_OID)){
        assertOidIsComplexObject(realTrans, parent_OID);
      }
      return new LongOid( addSubobject(realTrans, interpreteAbstractOid(parent_OID), object));
    } catch (ModelException e) {
      throw new StoreException(getStoreId(), e);
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    }
  }

  private void assertOidIsComplexObject(com.sleepycat.je.Transaction realTrans, AbstractOid parentOID) throws StoreException{
    StoreEntry storeEntry=getStoreEntryByOid(realTrans, interpreteAbstractOid(parentOID));
    if (!(storeEntry instanceof StoreEntryComposite)){
      throw new ObjectNotFoundStoreException("Object with oid:"+parentOID+" required to be complex object, but it is: "+storeEntry.getClass().getSimpleName());
    }
  }

  /**
   * Does not verify parent's type
   *
   * @param realTrans
   * @param parent_OID
   * @param object
   * @return returns internal oid of created object
   * @throws DatabaseException
   * @throws ModelException
   */
  private long addSubobject(com.sleepycat.je.Transaction realTrans, long parent_OID,
      AS0ObjectEditable object) throws DatabaseException, ModelException {
    long oid=generateInternalOid();
    addSubobjectOid(oid, realTrans, parent_OID, object);
    return oid;
  }

  private void addSubobjectOid(long new_oid,
      com.sleepycat.je.Transaction realTrans, long parent_OID,
      AS0ObjectEditable object) throws DatabaseException, ModelException {
    if (object instanceof AS0AtomicObjectEditable) {
      AS0AtomicObjectEditable aoro = (AS0AtomicObjectEditable) object;
      as0store.put(realTrans, long2key(new_oid),
          storeEntry2data(new StoreEntryAtomic(parent_OID, aoro.getNameId(), aoro.getValue())));
    } else if (object instanceof AS0PointerObjectEditable) {
      AS0PointerObjectEditable poro = (AS0PointerObjectEditable) object;
      as0store.put(realTrans, long2key(new_oid),
          storeEntry2data(new StoreEntryPointer(parent_OID, poro
              .getNameId(), poro.getDestinationOID())));
    } else if (object instanceof AS0ComplexObjectEditable) {
      AS0ComplexObjectEditable coro = (AS0ComplexObjectEditable) object;
      as0store.put(realTrans, long2key(new_oid),
          storeEntry2data(new StoreEntryComposite(parent_OID, coro.getNameId())));
      for (AS0ObjectEditable subobject : coro.getSubobjects()) {
        addSubobject(realTrans, new_oid, subobject);
      }
    } else {
      throw new IllegalArgumentException(
          "Unexpected AS0ObjectEditable class type:"
              + object.getClass().getCanonicalName());
    }
    object.setOID(internal2externalOid(new_oid));
    object.setParentOID(internal2externalOid(parent_OID));
  }

  private AbstractOid internal2externalOid(long newOid) {
    return new LongOid(newOid);
  }

  public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid OID)
      throws StoreException {
    long oid=interpreteAbstractOid(OID);
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    return storeEntry2ObjectRO(OID, getStoreEntryByOid(realTrans, oid), t);
  }

  private StoreEntry getStoreEntryByOid(com.sleepycat.je.Transaction realTrans,
      long oid) throws ObjectNotFoundStoreException, StoreException {
    DatabaseEntry data = new DatabaseEntry();
    // TODO(ptab): Check the LockMode (It might depend on isolation level). 
    try {
      OperationStatus os = getAs0store().get(realTrans, long2key(oid), data, LockMode.DEFAULT);
      if (os == OperationStatus.SUCCESS) {
        return storeEntryTupleBinding.entryToObject(data);
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundStoreException(getStoreId(),
            "Cannot find object with OID=" + oid);
      } else {
        throw new StoreException(getStoreId(),
            "Unexpected operation status:" + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(),
          "Cannot proceed getObjectByOID(..., " + oid + ")", e);
    }
  }

//  private StoreEntry createSuperrootEntry(com.sleepycat.je.Transaction realTrans) {
//    AS0ComplexObjectROImpl
//    return null;
//  }

  private AS0ObjectRO storeEntry2ObjectRO(AbstractOid oid, StoreEntry entry,
      Transaction transaction) {
    if (entry instanceof StoreEntryAtomic) {
      StoreEntryAtomic entryAtomic = (StoreEntryAtomic) entry;
      return new AS0AtomicObjectROImpl(oid,
          entryAtomic.getObject_name_id(),
          internal2externalOid(entryAtomic.getParent_oid()),
          entryAtomic.getValue());
    } else if (entry instanceof StoreEntryPointer) {
      return new AS0PointerObjectROImpl(oid, entry.getObject_name_id(),
          internal2externalOid(entry.getParent_oid()),
          ((StoreEntryPointer) entry).getDestination_oid());
    } else if (entry instanceof StoreEntryComposite) {
      return new AS0ComplexObjectROImpl(oid,
          entry.getObject_name_id(),
          internal2externalOid(entry.getParent_oid()),
          transaction);
    } else {
      throw new IllegalArgumentException("Unexpected argument type: "
          + entry.getClass().getName());
    }
  }

  public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    DatabaseEntry data = new DatabaseEntry();
    try {
      /*
       * TODO: upewnić się co do LockMode (czy nie uzależnić od
       * IsolationLevel)
       */

      OperationStatus os=getAs0store().get(realTrans, long2key(interpreteAbstractOid(oid)), data, LockMode.DEFAULT);
      if (os==OperationStatus.NOTFOUND){
        if (oid.equals(getConfigRootOid())) {
          return getSuperRootOid();
        } else {
          throw new ObjectNotFoundStoreException(getStoreId(), "Cannot find object with OID:"+oid);
        }
      }
      // TODO: Szybsza wersja, która nie parsuje danych
      return internal2externalOid(storeEntryTupleBinding.entryToObject(data).getParent_oid());
    } catch (DatabaseException e) {
      throw new StoreException("Cannot proceed getObjectByOID(..., " + oid
          + ")", e);
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(
      Transaction t) throws StoreException {
    return getSubobjectOIDsMap(t, new LongOid(0L));
  }

  public ClosableAndSizeAwareIterator<AbstractOid> getRoots(Transaction t)
      throws StoreException {
    return getSubobjectOIDs(t, new LongOid(0L));
  }

  public ClosableAndSizeAwareIterator<AbstractOid> getRootsByName(Transaction t,
      int name_id) throws StoreException {
    return getSubobjectOIDsByNameOID(t, new LongOid(0L), name_id);
  }

  public ClosableAndSizeAwareIterator<AbstractOid> getSubobjectOIDs(Transaction t,
      AbstractOid OID) throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    return new Long2AbstractOidCursorConverter(getSubobjectOIDs(realTrans, interpreteAbstractOid(OID)));
  }

  protected ClosableAndSizeAwareIterator<Long> getSubobjectOIDs(com.sleepycat.je.Transaction realTrans,
       long OID) throws StoreException {
    try {
      SecondaryCursor cursor = childsIndex.openCursor(realTrans, null);
      return new CursorOverChildsIndexOIDIterator(cursor, OID);
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    }
  }

  protected Set<Integer> getChildsNames(com.sleepycat.je.Transaction t,
      long OID) throws StoreException {
    Set<Integer> res = new LinkedHashSet<Integer>();
    SecondaryCursor cursor = null;
    try {
      cursor = childsIndex.openCursor(t, null);
      if (logger.isTraceEnabled()) {
        logger.trace("GetChildsNames(" + OID + ") created cursor:" + cursor);
      }

      DatabaseEntry key = new DatabaseEntry();
      childTupleBinding.objectToEntry(new ChildIndexKey(OID, 0), key);

      DatabaseEntry pkey = new DatabaseEntry();
      DatabaseEntry data = new DatabaseEntry();
      OperationStatus os = cursor.getSearchKeyRange(key, pkey, data,
          LockMode.DEFAULT);
      ChildIndexKey decodedKey = childTupleBinding.entryToObject(key);
      while (os == OperationStatus.SUCCESS
          && decodedKey.getParent_oid()==OID) {
        res.add(decodedKey.getChild_name_id());
        os = cursor.getNextNoDup(key, pkey, data, LockMode.DEFAULT);
        decodedKey = childTupleBinding.entryToObject(key);
      }

      if (os != OperationStatus.NOTFOUND && os != OperationStatus.SUCCESS) {
        throw new StoreException(getStoreId(),
            "Unexpected operation status: " + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    } finally {
      if (cursor != null) {
        try {
          cursor.close();
        } catch (DatabaseException e) {
          throw new StoreException(getStoreId(), e);
        }
      }
    }
    return res;
  }

  class LazyCreateCursorOverChildsIndexOIDNameIterator implements
      CallbackWithReturnValue<ClosableIterator<AbstractOid>, Integer, RuntimeException> {

    private com.sleepycat.je.Transaction transaction;
    private long OID;

    public LazyCreateCursorOverChildsIndexOIDNameIterator(
        com.sleepycat.je.Transaction t, long oid) {
      this.OID = oid;
      this.transaction = t;
    }

    public ClosableAndSizeAwareIterator<AbstractOid> process(Integer name_id)
        throws RuntimeException {
      try {
    	  Cursor cursor = childsIndex.openCursor(transaction, null);
    	  if (logger.isTraceEnabled()) {
    	    logger.trace("LazyCreateCursorOverChildsIndexOIDNameIterator::process() " + cursor);
    	  }
        return new Long2AbstractOidCursorConverter(new CursorOverChildsIndexOIDNameIterator(cursor, OID, name_id));
      } catch (DatabaseException e) {
        throw new RuntimeException("Cannot open the cursor", e);
      }
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(
      Transaction t, AbstractOid OID) throws StoreException {
    Long oid= interpreteAbstractOid(OID);
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    Set<Integer> names_ids = getChildsNames(realTrans, oid);
    return new LazyMap<Integer, ClosableIterator<AbstractOid>>(
        new LinkedHashMap<Integer, ClosableIterator<AbstractOid>>(),
        new LazyCreateCursorOverChildsIndexOIDNameIterator(realTrans,
            oid), names_ids);
  }

  public ClosableAndSizeAwareIterator<AbstractOid> getSubobjectOIDsByNameOID(
      Transaction t, AbstractOid OID, int nameID) throws StoreException {
    long oid=interpreteAbstractOid(OID);
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    try {
      SecondaryCursor cursor = childsIndex.openCursor(realTrans, null);
      if (logger.isTraceEnabled()) {
        logger.info("getSubobjectOIDsByNameOID " + cursor);
      }
      return new Long2AbstractOidCursorConverter( new CursorOverChildsIndexOIDNameIterator(cursor, oid, nameID));
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    }
  }

  public void moveObject(Transaction t, AbstractOid OID, AbstractOid abstract_new_parent_oid)
      throws StoreException {
    long oid=interpreteAbstractOid(OID);
    if (oid == 0) throw new StoreException(getStoreId(), "Cannot move superroot object.");
    long new_parent_oid=interpreteAbstractOid(abstract_new_parent_oid);
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    DatabaseEntry data = new DatabaseEntry();
    // TODO: upewnić się co do LockMode (czy nie uzależnić od IsolationLevel)
    try {
      DatabaseEntry key=long2key(oid);
      OperationStatus os = getAs0store().get(realTrans, key, data, LockMode.DEFAULT);
      if (os == OperationStatus.SUCCESS) {
        StoreEntry se=storeEntryTupleBinding.entryToObject(data);
        se.setParent_oid(new_parent_oid);
        storeEntryTupleBinding.objectToEntry(se, data);
        getAs0store().put(realTrans, key , data);
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundStoreException(getStoreId(),
            "Cannot find object with OID=" + OID);
      } else {
        throw new StoreException(getStoreId(),
            "Unexpected operation status:" + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(),
          "Cannot proceed getObjectByOID(..., " + OID + ")", e);
    }
  }

  public void removeObject(Transaction t, AbstractOid OID) throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    removeObjectWithSubobjectAndReferers(realTrans, interpreteAbstractOid(OID));
  }

  /**
   * Removes object given by OID. If it's composite object all subobjects are also removed. If there are referrers to the
   * object - the referring object is also removed.
   *
   * @param realTrans
   * @param OID
   * @throws ObjectNotFoundStoreException - One of objects that should be removed has not been found
   * @throws StoreException - other problem occured.
   */
  private void removeObjectWithSubobjectAndReferers(com.sleepycat.je.Transaction realTrans, long OID) throws StoreException
  {
    try {
      removeObjectWithReferers(realTrans, OID);
      removeSubobjectsWithReferersRecursivly(realTrans, OID);
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), "Cannot remove entry with oid=" + OID, e);
    }
  }

  /**
   * Removes object given by OID. If there are referrers to the
   * object - the referring object is also removed. There is no try to remove subobjects - so the method
   * should not be called in most cases for complex objects.
   *
   * @param realTrans
   * @param OID
   * @throws ObjectNotFoundStoreException - One of objects that should be removed has not been found
   * @throws StoreException - other problem occured.
   */
  private void removeObjectWithReferers(com.sleepycat.je.Transaction realTrans, long OID) throws StoreException
  {
    try {
      removeObjectItself(realTrans, OID);
      removeReferersToObjectById(realTrans, OID);
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), "Cannot remove entry with oid=" + OID, e);
    }
  }

  private void removeReferersToObjectById(com.sleepycat.je.Transaction realTrans, long OID) throws StoreException {
    /*removing referers to the object*/
    ClosableAndSizeAwareIterator<Long> iter=getReferers(realTrans, OID);
    try{
      while(iter.hasNext())
      {
        removeObjectWithSubobjectAndReferers(realTrans, iter.next());
      }
    }finally{
      iter.close();
    }
  }

  /**
   * Removes subobjects and referers refering to the subobjects.
   * In case of not composite object - does nothing.
   *
   * @param realTrans
   * @param OID
   * @throws StoreException
   */
  private void removeSubobjectsWithReferersRecursivly(
      com.sleepycat.je.Transaction realTrans, long OID)
      throws StoreException {
    /*removing subobjects*/
    ClosableAndSizeAwareIterator<Long> iter=getSubobjectOIDs(realTrans, OID);
    try{
      while(iter.hasNext())
      {
        removeObjectWithSubobjectAndReferers(realTrans, iter.next());
      }
    }finally{
      iter.close();
    }
  }

  private void removeObjectItself(com.sleepycat.je.Transaction realTrans,  long OID) throws ObjectNotFoundStoreException, StoreException {
    logger.debug("Removing object with OID:" + OID);
    if (OID == 0) throw new StoreException(getStoreId(), "Cannot remove superroot object.");
    OperationStatus os=getAs0store().delete(realTrans, long2key(OID));
    if (os==OperationStatus.NOTFOUND)
    {
      throw new ObjectNotFoundStoreException(getStoreId(), "Cannot find object with OID="+OID+" to remove");
    }else if (os!=OperationStatus.SUCCESS){
      throw new StoreException("Cannot remove object with OID:"+OID+" unexpected operation status:"+os);
    }
  }

  public void removeObjects(Transaction t, AbstractOid[] OIDs) throws StoreException {
    // TODO: Maybe nested transaction ???
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    for (AbstractOid oid : OIDs) {
      removeObjectWithSubobjectAndReferers(realTrans, interpreteAbstractOid(oid));
    }

  }

  public void setAtomicObjectValue(Transaction t, AbstractOid OID, AtomicValue value)
      throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    long oid=interpreteAbstractOid(OID);
    DatabaseEntry oidAsKey=long2key(oid);
    DatabaseEntry data = new DatabaseEntry();
    // TODO: upewnić się co do LockMode (czy nie uzależnić od IsolationLevel)
    try {
      OperationStatus os = as0store.get(realTrans, oidAsKey,
          data, LockMode.DEFAULT);
      if (os == OperationStatus.SUCCESS) {
        StoreEntry se=storeEntryTupleBinding.entryToObject(data);
        if (se instanceof StoreEntryComposite)
        {
          removeSubobjectsWithReferersRecursivly(realTrans, oid);
        }
        as0store.put(realTrans, oidAsKey,
            storeEntry2data(new StoreEntryAtomic(se.getParent_oid(), se.getObject_name_id(), value)));
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundStoreException(getStoreId(),
            "Cannot find object with OID=" + OID);
      } else {
        throw new StoreException(getStoreId(),
            "Unexpected operation status:" + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(),
          "Cannot proceed getObjectByOID(..., " + OID + ")", e);
    }
  }

  public void setNewPointerObjectDestination(Transaction t, AbstractOid OID,
      AbstractOid destination_OID) throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    long oid=interpreteAbstractOid(OID);
    DatabaseEntry data = new DatabaseEntry();
    // TODO: upewnić się co do LockMode (czy nie uzależnić od IsolationLevel)
    try {
      OperationStatus os = as0store.get(realTrans, long2key(oid),  data, LockMode.DEFAULT);
      if (os == OperationStatus.SUCCESS) {
        StoreEntry se=storeEntryTupleBinding.entryToObject(data);
        if (se instanceof StoreEntryComposite)
        {
          removeSubobjectsWithReferersRecursivly(realTrans, oid);
        }
        as0store.put(realTrans, long2key(oid),
            storeEntry2data(new StoreEntryPointer(se.getParent_oid(), se.getObject_name_id(), destination_OID)));
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundStoreException(getStoreId(),
            "Cannot find object with OID=" + OID);
      } else {
        throw new StoreException(getStoreId(),
            "Unexpected operation status:" + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(),
          "Cannot proceed getObjectByOID(..., " + OID + ")", e);
    }
  }

  public void setNewComplexObjectValue(Transaction t, AbstractOid OID,
      Collection<AS0ObjectEditable> subobjects)
    throws StoreException
  {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    long oid=interpreteAbstractOid(OID);
    DatabaseEntry keyentry=long2key(oid);
    try {
      DatabaseEntry data = new DatabaseEntry();
      OperationStatus os = as0store.get(realTrans, long2key(oid),  data, LockMode.DEFAULT);
      if (os == OperationStatus.SUCCESS) {
        StoreEntry se=storeEntryTupleBinding.entryToObject(data);
        if (se instanceof StoreEntryComposite){
          removeSubobjectsWithReferersRecursivly(realTrans, oid);
        }else{
          as0store.put(realTrans, keyentry, storeEntry2data(new StoreEntryComposite(se.getParent_oid(), se.getObject_name_id())));
        }
        for (AS0ObjectEditable subobject:subobjects){
          addSubobject(realTrans, oid, subobject);
        }
      } else if (os == OperationStatus.NOTFOUND) {
        throw new ObjectNotFoundStoreException(getStoreId(),
            "Cannot find object with OID=" + OID);
      } else {
        throw new StoreException(getStoreId(),
            "Unexpected operation status:" + os);
      }
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(),  "Cannot proceed getObjectByOID(..., " + OID + ")", e);
    } catch (ModelException e) {
      throw new StoreException(getStoreId(), e);
    }
  }


  // ===========================================================================

  private DatabaseEntry storeEntry2data(StoreEntry storeEntry) {
    DatabaseEntry de = new DatabaseEntry();
    storeEntryTupleBinding.objectToEntry(storeEntry, de);
    return de;
  }

  public class AS0ComplexObjectROImpl extends AS0ObjectROImpl implements
      AS0ComplexObjectRO {
    private Transaction transaction;

    public AS0ComplexObjectROImpl(AbstractOid oid, int name_id, AbstractOid parent,
        Transaction t) {
      super(oid, name_id, parent);
      this.transaction = t;
    }

    public ClosableAndSizeAwareIterator<AbstractOid> getIteratorBySubobjectNameId(
        int name_id) throws ModelException {
      try {
        return getSubobjectOIDsByNameOID(transaction, getOID(), name_id);
      } catch (StoreException e) {
        throw new ModelException(
            "Cannot create iterator over object with oid="
                + getOID(), e);
      }
    }

    public ClosableAndSizeAwareIterator<AbstractOid> iterator()
        throws ModelException {
      try {
        return getSubobjectOIDs(transaction, getOID());
      } catch (StoreException e) {
        throw new ModelException(
            "Cannot create iterator over object with oid="
                + getOID(), e);
      }
    }

    public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap() throws ModelException
    {
      try {
        return BerkeleyAs0Store.this.getSubobjectOIDsMap(transaction, getOID());
      } catch (StoreException e) {
        throw new ModelException(
            "Cannot create iterator over object with oid="
                + getOID(), e);
      }
    }
  }
  
//  public class AS0SuperrootComplexObjectROImpl 
//      extends AS0ObjectROImpl 
//      implements AS0ComplexObjectRO {
//    private Transaction transaction;
//    
//    @Override
//    public ClosableIterator<AbstractOid> getIteratorBySubobjectNameId(
//        int name_id) throws ModelException {
//      return getRootsByName(transaction, name_id);
//    }
//    
//    @Override
//    public int getNameId() {
//      return 0;
//    }
//  }

  synchronized public void close() throws StoreException {
    try {
      if (oidSequence != null)
        oidSequence.close();
      if (as0store_sequences != null)
        as0store_sequences.close();
      if (childsIndex != null)
        childsIndex.close();
      if (referersIndex != null)
        referersIndex.close();
      if (as0store != null)
        as0store.close();
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    }
  }

  public ClosableAndSizeAwareIterator<AbstractOid> getReferrers(Transaction t, AbstractOid OID) throws StoreException {
    com.sleepycat.je.Transaction realTrans = getRealBerkeleyTransFromTransaction(t);
    return new Long2AbstractOidCursorConverter(getReferers(realTrans, interpreteAbstractOid(OID)));
  }

  protected long interpreteAbstractOid(AbstractOid OID) {
    return ((LongOid)OID).getValue();
  }

  private ClosableAndSizeAwareIterator<Long> getReferers(com.sleepycat.je.Transaction realTrans, long OID) throws StoreException {
    try {
      SecondaryCursor cursor = referersIndex.openCursor(realTrans, null);
      if (logger.isTraceEnabled()) {
        logger.trace("Get referers: " + cursor);
      }
      return new CursorOverReferersOIDIterator(cursor, OID);
    } catch (DatabaseException e) {
      throw new StoreException(getStoreId(), e);
    }
  }


  // ======================================================================
  // TODO: Prefetch not implemented (ignored) for now

  public void prefetchDeepObject(AbstractOid OID) {
  }

  public void prefetchDeepObjects(AbstractOid[] OIDs) {
  }

  public void prefetchObject(AbstractOid OID) {
  }

  public void prefetchObjects(AbstractOid[] OIDs) {
  }

  public void prefetchSubobjectsByParentIDandName(AbstractOid parentId, int nameId) {
  }

  public AbstractOid getSuperRootOid() {
    return LongOid.ZERO;
  }

  public AbstractOid getConfigRootOid() {
    return LongOid.ONE;
  }

}
