/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

/**
 * 
 */
package pl.edu.mimuw.jloxim.stores.as0.bdb_je;

import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.utils.api.ClosableAndSizeAwareIterator;

import com.sleepycat.je.Cursor;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.je.SecondaryCursor;

abstract public class CursorBerkeleyIterator<T> implements ClosableAndSizeAwareIterator<T> {
  
  private static final Logger log = Logger.getLogger(CursorBerkeleyIterator.class);

  //private static final TupleBinding<Integer> integerBinding = TupleBinding.getPrimitiveBinding(Integer.class);
  //private static final TupleBinding<String> stringBinding = TupleBinding.getPrimitiveBinding(String.class);

  private Cursor cursor;
  private boolean cursor_used=false;

  private final LinkedList<T> next_items=new LinkedList<T>();
  private boolean cursorEOF = false;
  
  private AtomicBoolean corrupted=new AtomicBoolean(false);

  private Long availableItemsCnt=null;
  
  static protected enum WishEnum{
    NEXT,
    NEXT_DUP,
    NEXT_NONDUP
  }
  
  private WishEnum wish;
  
  public CursorBerkeleyIterator(Cursor c) {
    cursor = c;
    cursor_used=false;
    wish=WishEnum.NEXT;
  }

  //TODO: Ugly that no exception is propagated
  public synchronized void close() {
    try {
      if (log.isTraceEnabled()) {
        log.trace("Closing: " + cursor);
      }
      cursor.close();
    } catch (DatabaseException e) {
      log.error("Cannot close iterator", e);
      corrupted.set(true);
    }

  }

  //TODO: Ugly that no exception is propagated
  public synchronized boolean hasNext() {
    if (!cursor_used) initCursor();
    if (!next_items.isEmpty()){
      return true;
    } else if (cursorEOF) {
      return false;
    } else {
      assert next_items.isEmpty() && !cursorEOF;
      tryToReadMoreItems();
      return !(next_items.isEmpty());
    }

  }
  
  public synchronized boolean isEOF()
  {
    return !hasNext();
  }
  
  private synchronized void initCursor() {
    cursor_used=true;
    positionCursorAtFirst(cursor);
    if (!corrupted.get() && !cursorEOF)
    {
      DatabaseEntry data=new DatabaseEntry();
      DatabaseEntry key=new DatabaseEntry();
      DatabaseEntry pkey=null;
      try {
        OperationStatus os=null;
        if (cursor instanceof SecondaryCursor)
        {
          pkey=new DatabaseEntry();        
          os=((SecondaryCursor)cursor).getCurrent(key, pkey, data, LockMode.DEFAULT);
        }else{
          os=cursor.getCurrent(key, data, LockMode.DEFAULT);
        }
        
        if (os==OperationStatus.SUCCESS){
          interpreteNewData(key, pkey, data);
        }else if (os==OperationStatus.NOTFOUND){
           cursorEOF=true;
        }else{
          cursorEOF=true;
          corrupted.set(true);
          log.error("Unexpocted cursor's operation status:"+os);
        }
      } catch (DatabaseException e) {
        log.error(e);
        cursorEOF=true;
        corrupted.set(true);
      }
    }
  }

  protected void interpreteNewData(DatabaseEntry key, DatabaseEntry pkey, DatabaseEntry data) {
    T new_position=parseData(key, pkey, data);
    if (new_position!=null)
    {
      next_items.addLast(new_position);
    }
  }
  
  protected abstract T parseData(DatabaseEntry key, DatabaseEntry pkey, DatabaseEntry data);

  synchronized public void setCursorEOF()
  {
    cursorEOF=true;
  }
  
  synchronized public void setCorrupted()
  {
    corrupted.set(true);
  }
  
  public boolean isCorrupted() {
    return corrupted.get();
  }
  
  public synchronized boolean isCursorEOF() {
    return cursorEOF;
  }
  
  protected abstract void positionCursorAtFirst(Cursor cursor);

  private void tryToReadMoreItems() {
    try {
      DatabaseEntry data=new DatabaseEntry();
      DatabaseEntry key=new DatabaseEntry();
      DatabaseEntry pkey=null;
      
      OperationStatus os=null;
      if (cursor instanceof SecondaryCursor)
      {
        pkey=new DatabaseEntry();
        switch (wish) {
        case NEXT:
          os=((SecondaryCursor)cursor).getNext(key, pkey, data, LockMode.DEFAULT);
          break;
        case NEXT_DUP:
          os=((SecondaryCursor)cursor).getNextDup(key, pkey, data, LockMode.DEFAULT);          
          break;
        case NEXT_NONDUP:
          os=((SecondaryCursor)cursor).getNextNoDup(key, pkey, data, LockMode.DEFAULT);
          break;
        default:
          throw new IllegalStateException("Unexpected enum (WithEnum) value : "+wish);
        }
      }else{
        switch (wish) {
        case NEXT:
          os=(cursor).getNext(key, data, LockMode.DEFAULT);
          break;
        case NEXT_DUP:
          os=(cursor).getNextDup(key, data, LockMode.DEFAULT);          
          break;
        case NEXT_NONDUP:
          os=(cursor).getNextNoDup(key, data, LockMode.DEFAULT);
          break;
        default:
          throw new IllegalStateException("Unexpected enum (WithEnum) value : "+wish);
        }
      }
      if (os == OperationStatus.SUCCESS) {
        interpreteNewData(key, pkey, data);
      } else if (os == OperationStatus.NOTFOUND)
      {
        cursorEOF=true;
      }else{
        log.error("hasNext() failes - unexpected cursor operation status");
        cursorEOF=true;
        corrupted.set(true);
      }
    } catch (DatabaseException e) {
      log.error("hasNext() failed:", e);
      cursorEOF=true;
      corrupted.set(true);
    }
  }

  public T next() {
    if (!hasNext())
      throw new NoSuchElementException("The cursor have no more items");
    assert (next_items.size()>0);
    if (availableItemsCnt!=null) 
      availableItemsCnt--;
    return next_items.poll();
  }
  
  public synchronized long availableItemsCnt()
  {
    if (!cursor_used) initCursor();
    if (availableItemsCnt==null)
    {
      recountItems();
    }
    return availableItemsCnt;
  }

  protected synchronized void recountItems() {
    while(!cursorEOF && !corrupted.get())
    {
      tryToReadMoreItems();
    }
    availableItemsCnt=(long)next_items.size();
  }
  
  protected void setWish(WishEnum w)
  {
    wish=w;
  }

  /**
   * Unsupported operation for the iterator
   */
  public void remove() {
    throw new UnsupportedOperationException();
  }

}