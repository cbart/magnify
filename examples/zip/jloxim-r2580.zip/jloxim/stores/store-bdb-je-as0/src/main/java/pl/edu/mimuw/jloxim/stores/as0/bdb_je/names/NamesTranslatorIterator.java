/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

/**
 * 
 */
package pl.edu.mimuw.jloxim.stores.as0.bdb_je.names;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.stores.as0.bdb_je.CursorBerkeleyIterator;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;

class NamesTranslatorIterator extends CursorBerkeleyIterator<NameEntry>
{
  private static final Logger log = Logger.getLogger(NamesTranslatorIterator.class);
  private static final TupleBinding<Integer> integerBinding = TupleBinding.getPrimitiveBinding(Integer.class);
  private static final TupleBinding<String> stringBinding = TupleBinding.getPrimitiveBinding(String.class);

  public NamesTranslatorIterator(Cursor c) {
    super(c);
  }
  
  @Override
  protected NameEntry parseData(DatabaseEntry key, DatabaseEntry pkey, DatabaseEntry data) {
    return new NameEntry(integerBinding.entryToObject(data), stringBinding.entryToObject(key));
  }


  @Override
  protected void positionCursorAtFirst(Cursor cursor) {
    try {
      //Skiping first - it is sequence
      if (cursor.getFirst(new DatabaseEntry(), new DatabaseEntry(), LockMode.DEFAULT)!=OperationStatus.SUCCESS)
      {
        setCursorEOF();
      }
      if (cursor.getNext(new DatabaseEntry(), new DatabaseEntry(), LockMode.DEFAULT)!=OperationStatus.SUCCESS)
      {
        setCursorEOF();
      }
    } catch (DatabaseException e) {
      log.error(e);
      setCorrupted();
    }    
  }
}