/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.trans;

import java.sql.Date;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionStatus;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.utils.api.callbacks.CallbackManager;
import pl.edu.mimuw.jloxim.utils.impl.CallbackManagerImpl;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.TransactionConfig;

public class BerkeleyTransaction implements Transaction {
  private final static Logger logger = Logger.getLogger(BerkeleyTransaction.class);

  private CallbackManager<Transaction, TransactionException> afterCommitCallbacksManager;
  private CallbackManager<Transaction, TransactionException> beforeCommitCallbacksManager;
  private CallbackManager<Transaction, TransactionException> afterRollbackCallbacksManager;
  private CallbackManager<Transaction, TransactionException> beforeRollbackCallbacksManager;
  private CallbackManager<Transaction, TransactionException> onTransactionInterruptedCallbacksManager;
  private CallbackManager<Transaction, TransactionException> onTransactionVictimCallbackManager;

  private final com.sleepycat.je.Transaction berkeleyTransaction;
  private final TransactionIsolationLevel isolationLevel;
  private final BerkeleyTransactionManager transactionManager;
  private final int transactionId;
  private final Date transactionStartedAt;
  private TransactionStatus transactionStatus;

  BerkeleyTransaction(Environment env, TransactionConfig txnConfig,
    TransactionIsolationLevel transactionIsolationLevel,
    BerkeleyTransactionManager transManager) throws DatabaseException {
    logger.info("Running transaction using environment: " + env);
    berkeleyTransaction = env.beginTransaction(null, txnConfig);
    
    // TODO: Ugly conversion
    transactionId = (int)berkeleyTransaction.getId();
    transactionStartedAt = new Date(System.currentTimeMillis());
    transactionManager = transManager;
    transactionStatus = TransactionStatus.ACTIVE;
    isolationLevel=transactionIsolationLevel;
  }

  public TransactionIsolationLevel getIsolationLevel() {
    return isolationLevel;
  }

  public long getTransactionId() {
    return transactionId;
  }

  public double getTransactionPriority() {
    return 0;
  }

  public Date getTransactionStarted() {
    return transactionStartedAt;
  }

  public TransactionStatus getTransactionStatus() {
    return transactionStatus;
  }
  
  @Override
  public boolean isActive() {
    return getTransactionStatus() == TransactionStatus.ACTIVE;
  }

  public long createSavepoint() throws TransactionException {
    throw new UnsupportedOperationException();
  }

  public void partialRollbackToSavePoint(long savepointId)
      throws TransactionException {
    throw new UnsupportedOperationException();
  }

  public void interrupt(String reason) throws TransactionException {
    transactionStatus = TransactionStatus.ROLLBACKING_INTERRUPTED;
    transactionManager.removeActiveTransaction(this);
    try {
      if (onTransactionInterruptedCallbacksManager != null) {
        onTransactionInterruptedCallbacksManager.fire(this);
      }
      if (beforeRollbackCallbacksManager != null) {
        beforeRollbackCallbacksManager.fire(this);
      }
      berkeleyTransaction.abort();
      transactionStatus = TransactionStatus.ROLLBACKED_INTERRUPTED;
      if (afterRollbackCallbacksManager != null) {
        afterRollbackCallbacksManager.fire(this);
      }
    } catch (DatabaseException e) {
      throw new TransactionException(getTransactionId(), e);
    }

  }

  public void commit() throws TransactionException {
    transactionStatus = TransactionStatus.COMMITING;
    transactionManager.removeActiveTransaction(this);
    try {
      if (beforeCommitCallbacksManager != null) {
        beforeCommitCallbacksManager.fire(this);
      }
      berkeleyTransaction.commit();
      transactionStatus = TransactionStatus.COMMITED;
      if (afterCommitCallbacksManager != null) {
        afterCommitCallbacksManager.fire(this);
      }
    } catch (DatabaseException e) {
      throw new TransactionException(getTransactionId(), e);
    }
  }

  public void rollback() throws TransactionException {
    transactionStatus = TransactionStatus.ROLLBACKING_INTERRUPTED;
    transactionManager.removeActiveTransaction(this);
    try {
      if (beforeRollbackCallbacksManager != null) {
        beforeRollbackCallbacksManager.fire(this);
      }
      berkeleyTransaction.abort();
      transactionStatus = TransactionStatus.ROLLBACKED_INTERRUPTED;
      if (afterRollbackCallbacksManager != null) {
        afterRollbackCallbacksManager.fire(this);
      }
    } catch (DatabaseException e) {
      throw new TransactionException(getTransactionId(), e);
    }
  }

  // =============================== Callbacks =============================

  public CallbackManager<Transaction, TransactionException> getAfterCommitCallbacksManager() {
    if (afterCommitCallbacksManager == null) {
      afterCommitCallbacksManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return afterCommitCallbacksManager;
  }

  public CallbackManager<Transaction, TransactionException> getAfterRollbackCallbacksManager() {
    if (afterRollbackCallbacksManager == null) {
      afterRollbackCallbacksManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return afterRollbackCallbacksManager;
  }

  public CallbackManager<Transaction, TransactionException> getBeforeCommitCallbacksManager() {
    if (beforeCommitCallbacksManager == null) {
      beforeCommitCallbacksManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return beforeCommitCallbacksManager;
  }

  public CallbackManager<Transaction, TransactionException> getBeforeRollbackCallbacksManager() {
    if (beforeRollbackCallbacksManager == null) {
      beforeRollbackCallbacksManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return beforeRollbackCallbacksManager;
  }

  public CallbackManager<Transaction, TransactionException> getOnTransactionInterrupted() {
    if (onTransactionInterruptedCallbacksManager == null) {
      onTransactionInterruptedCallbacksManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return onTransactionInterruptedCallbacksManager;
  }

  public CallbackManager<Transaction, TransactionException> getOnTransactionVictimCallbackManager() {
    if (onTransactionVictimCallbackManager == null) {
      onTransactionVictimCallbackManager = new CallbackManagerImpl<Transaction, TransactionException>();
    }
    return onTransactionVictimCallbackManager;
  }

  public com.sleepycat.je.Transaction getRealTransaction() {
    return berkeleyTransaction;
  }

}
