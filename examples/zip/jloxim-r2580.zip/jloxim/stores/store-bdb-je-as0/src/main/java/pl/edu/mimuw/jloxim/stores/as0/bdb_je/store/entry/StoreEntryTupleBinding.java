/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry;

import java.util.Date;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BooleanAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.bind.tuple.TupleInput;
import com.sleepycat.bind.tuple.TupleOutput;

public class StoreEntryTupleBinding extends TupleBinding<StoreEntry>{
  private static final int OBJECT_TYPE_COMPOSITE=0;
  private static final int OBJECT_TYPE_POINTER  =1;
  private static final int OBJECT_TYPE_INT      =2;
  private static final int OBJECT_TYPE_BOOL     =3;
  private static final int OBJECT_TYPE_LONG     =4;
  private static final int OBJECT_TYPE_DOUBLE   =5;
  private static final int OBJECT_TYPE_STRING   =6;
  private static final int OBJECT_TYPE_BINARY   =7;
  private static final int OBJECT_TYPE_DATE    =8;
  
  private AtomicValueFactory atomicValueFactory=null;
  
  public AtomicValueFactory getAtomicValueFactory() {
    return atomicValueFactory;
  }
  
  public void setAtomicValueFactory(AtomicValueFactory atomicValueFactory) {
    this.atomicValueFactory = atomicValueFactory;
  }
  
  @Override
  public StoreEntry entryToObject(TupleInput input) {
        long parent_oid = input.readLong();
    int   object_name_id=input.readPackedInt();
    int   object_type=input.readPackedInt();
    if (object_type==OBJECT_TYPE_COMPOSITE)
    {
      return new StoreEntryComposite(parent_oid, object_name_id);
    }else if (object_type==OBJECT_TYPE_POINTER){
      long object_destination_id= input.readLong();
      //TODO: Should support object_destination_id in any format - not only 'Long's'
      return new StoreEntryPointer(parent_oid, object_name_id, new LongOid(object_destination_id));
    }else{
      AtomicValue av=readAtomicValue(object_type, input);
      return new StoreEntryAtomic(parent_oid, object_name_id, av);
    }
  }
 
  private AtomicValue readAtomicValue(int object_type, TupleInput input) {
    switch (object_type) {
      case OBJECT_TYPE_INT:    return atomicValueFactory.newAtomicValue(input.readInt());
      case OBJECT_TYPE_BOOL:   return atomicValueFactory.newAtomicValue(input.readBoolean());
      case OBJECT_TYPE_STRING: return atomicValueFactory.newAtomicValue(input.readString());
      case OBJECT_TYPE_BINARY: 
        {
          int size=input.readPackedInt();
          byte[] res=new byte[size];
          int pos=0;
          int r=0;
          while ((r=input.readFast(res, pos, size-pos))>0)
          {
            pos+=r;
          }
          return atomicValueFactory.newAtomicValue(res);
        }
      case OBJECT_TYPE_LONG:   return atomicValueFactory.newAtomicValue(input.readLong());
      case OBJECT_TYPE_DOUBLE: return atomicValueFactory.newAtomicValue(input.readDouble());      
      case OBJECT_TYPE_DATE:   return atomicValueFactory.newAtomicValue(new Date(input.readLong()));
    default:
      return null;
    }
  }

  @Override
  public void objectToEntry(StoreEntry object, TupleOutput output) {
    output.writeLong(object.getParent_oid());
    output.writePackedInt(object.getObject_name_id());
    if (object instanceof StoreEntryComposite)
    {
      output.writePackedInt(OBJECT_TYPE_COMPOSITE);
    }else if (object instanceof StoreEntryAtomic){
      writeAtomicValue(((StoreEntryAtomic)object).getValue(), output);      
    }else if (object instanceof StoreEntryPointer){
      output.writePackedInt(OBJECT_TYPE_POINTER);
      //TODO: Should support object_destination_id in any format - not only 'Long's'
      output.writeLong(((LongOid)(((StoreEntryPointer)object).getDestination_oid())).getValue());
    }    
  }

  private void writeAtomicValue(AtomicValue object, TupleOutput output) {
    if (object instanceof DateAtomicValue){
      output.writePackedInt(OBJECT_TYPE_DATE);
      output.writeLong(((DateAtomicValue)object).getValue().getTimeInMillis());
    }else if (object instanceof BooleanAtomicValue){
      output.writePackedInt(OBJECT_TYPE_BOOL);
      output.writeBoolean(((BooleanAtomicValue)object).getValue());
    }else if (object instanceof IntegerAtomicValue){  
      output.writePackedInt(OBJECT_TYPE_INT);
      output.writeInt(((IntegerAtomicValue)object).getValue());
    }else if (object instanceof DoubleAtomicValue){
      output.writePackedInt(OBJECT_TYPE_DOUBLE);
      output.writeDouble(((DoubleAtomicValue)object).getValue());
    }else if (object instanceof TextAtomicValue){
      output.writePackedInt(OBJECT_TYPE_STRING);
      //TODO: Zamienić na przepisywanie strumeni (wydajność i zajętość pamięci)
      output.writeString(((TextAtomicValue)object).getValue());
    }else if (object instanceof BinaryAtomicValue){
      output.writePackedInt(OBJECT_TYPE_BINARY);
      output.writePackedInt(((BinaryAtomicValue)object).getValue().length);
      //TODO: Zamienić na przepisywanie strumeni (wydajność i zajętość pamięci)
      output.writeFast(((BinaryAtomicValue)object).getValue());
    }else if (object instanceof LongAtomicValue){
      output.writePackedInt(OBJECT_TYPE_LONG);
      output.writeLong(((LongAtomicValue)object).getValue());
    }else{
      throw new IllegalArgumentException("Unknown type of AtomicValue:"+object.getClass().getCanonicalName());
    }
  }

    
}
