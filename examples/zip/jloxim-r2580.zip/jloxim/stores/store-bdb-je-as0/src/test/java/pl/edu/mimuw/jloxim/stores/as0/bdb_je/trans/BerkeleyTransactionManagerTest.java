/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.trans;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionStatus;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;



public class BerkeleyTransactionManagerTest {
  
  TransactionManager getTransactionManager()
  {
    ApplicationContext context=new ClassPathXmlApplicationContext("BerkeleyTransactionManagerTest-context.xml");
    TransactionManager transactionManager=(TransactionManager)context.getBean("transactionManager", TransactionManager.class);
    Assert.assertNotNull(transactionManager);
    return transactionManager;
  }
  
  @Test
  public void startCommitTransaction() throws TransactionManagerException, TransactionException
  {
    TransactionManager transactionManager=getTransactionManager();
  
    Transaction trans=transactionManager.newTransaction(TransactionIsolationLevel.SERIALIZABLE);
    
    Assert.assertEquals(TransactionIsolationLevel.SERIALIZABLE, trans.getIsolationLevel());
    Assert.assertEquals(TransactionStatus.ACTIVE, trans.getTransactionStatus());
    Assert.assertArrayEquals(new Object[]{trans}, transactionManager.getAllActiveTransactions().toArray());
    
    trans.commit();
    Assert.assertEquals(TransactionStatus.COMMITED, trans.getTransactionStatus());
    
    Assert.assertArrayEquals(new Object[]{}, transactionManager.getAllActiveTransactions().toArray());
  }
  
  @Test(timeout=10000)
  public void startCommitTransactionx1000() throws TransactionManagerException, TransactionException
  {
    TransactionManager transactionManager=getTransactionManager();
    for (int i=0; i<1000; i++)
    {      
      Transaction trans=transactionManager.newTransaction(TransactionIsolationLevel.SERIALIZABLE);
      
      Assert.assertEquals(TransactionIsolationLevel.SERIALIZABLE, trans.getIsolationLevel());
      Assert.assertEquals(TransactionStatus.ACTIVE, trans.getTransactionStatus());
      Assert.assertArrayEquals(new Object[]{trans}, transactionManager.getAllActiveTransactions().toArray());
      
      trans.commit();
      Assert.assertEquals(TransactionStatus.COMMITED, trans.getTransactionStatus());
      
      Assert.assertArrayEquals(new Object[]{}, transactionManager.getAllActiveTransactions().toArray());

    }
  }
  
  @Test
  public void startRollbackTransaction() throws TransactionManagerException, TransactionException
  {
    TransactionManager transactionManager=getTransactionManager();
    Transaction trans=transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
    
    Assert.assertEquals(TransactionIsolationLevel.READ_UNCOMMITED, trans.getIsolationLevel());
    Assert.assertEquals(TransactionStatus.ACTIVE, trans.getTransactionStatus());
    Assert.assertArrayEquals(new Object[]{trans}, transactionManager.getAllActiveTransactions().toArray());
    
    trans.rollback();
    Assert.assertEquals(TransactionStatus.ROLLBACKED_INTERRUPTED, trans.getTransactionStatus());
    
    Assert.assertArrayEquals(new Object[]{}, transactionManager.getAllActiveTransactions().toArray());
  }  
  @Test
  public void startIterruptTransaction() throws TransactionManagerException, TransactionException
  {
    TransactionManager transactionManager=getTransactionManager();
    Transaction trans=transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    
    Assert.assertEquals(TransactionIsolationLevel.READ_COMMITED, trans.getIsolationLevel());
    Assert.assertEquals(TransactionStatus.ACTIVE, trans.getTransactionStatus());
    Assert.assertArrayEquals(new Object[]{trans}, transactionManager.getAllActiveTransactions().toArray());
    
    trans.interrupt("testing interruption");
    Assert.assertEquals(TransactionStatus.ROLLBACKED_INTERRUPTED, trans.getTransactionStatus());
    
    Assert.assertArrayEquals(new Object[]{}, transactionManager.getAllActiveTransactions().toArray());
  }  
}
