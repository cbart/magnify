/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.bdb_je;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.Test;

import pl.edu.mimuw.jloxim.utils.impl.FileUtil;

import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.LockTimeoutException;
import com.sleepycat.je.Transaction;

public class BerkeleyDbBehaviourTest {
  private static final Logger logger=Logger.getLogger(BerkeleyDbBehaviourTest.class);
  
  /**
   * This test shows that BDB does not have 'real' deadlock detector. 
   * 
   * It wait's for lock some time, and if it doesn't acquire it - it interrupts the transaction 
   */
  @Test(expected=LockTimeoutException.class, timeout=3000)
  public void simulateDeadlock(){
      File dir=FileUtil.getInstance().getUniqTempDir("BerkeleyDbBehaviourTest");
      dir.mkdirs();
      Transaction t2a=null, t2b=null;
      Database db=null;
      Environment env=new Environment(dir,
          new EnvironmentConfig()
              .setTransactional(true)
              .setLocking(true)
              .setLockTimeout(1, TimeUnit.SECONDS)
              .setAllowCreate(true));
      try{
        Transaction t1=env.beginTransaction(null, null);
        db=env.openDatabase(t1, "db1", 
            new DatabaseConfig().setAllowCreate(true).setTransactional(true)
        );
        
        for (int i=0; i<100; i++){
          DatabaseEntry e=new DatabaseEntry(String.valueOf(i).getBytes());
          DatabaseEntry e2=new DatabaseEntry(String.valueOf(i).getBytes());
          db.put(t1, e, e2);
        }
        t1.commit();
        
        t2a=env.beginTransaction(null, null);
        t2b=env.beginTransaction(null, null);
        
        DatabaseEntry e1=new DatabaseEntry("7".getBytes());
        DatabaseEntry v1=new DatabaseEntry();
        
        DatabaseEntry e2=new DatabaseEntry("7".getBytes());
        DatabaseEntry v2=new DatabaseEntry();
        
        db.get(t2a, e1, v1, LockMode.RMW);
        db.get(t2b, e2, v2, LockMode.RMW);
                
        //db.
//        lo
        
                
      }catch (RuntimeException e){
         logger.error(e);
         throw e;
      }finally{
        t2a.abort();
        t2b.abort();
        db.close();
        env.close();
        FileUtil.getInstance().deleteDir(dir);
      }
      
  }
  
}
