/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.tests.NamesTranslatorTest;

/**
 * Test are inherited from common tests for all NamesTranslators
 * 
 * @author piotr.tabor@gmail.com
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations={"/BerkeleyAs0NamesTranslatorTest-context.xml"})
public class BerkeleyAs0NamesTranslatorTest extends NamesTranslatorTest {
  private Logger logger=Logger.getLogger(BerkeleyAs0NamesTranslatorTest.class);
  
//  @Autowired
  private NamesTranslator namesTranslator;
  
//  @Autowired
  private ConfigurableApplicationContext context;

  @Override
  public NamesTranslator getNamesTranslator() {
    return namesTranslator;
  }
  
  @Before
  public void before()
  {    
    try{
      logger.info("Closing context");
      context=new ClassPathXmlApplicationContext("/BerkeleyAs0NamesTranslatorTest-context.xml");
      namesTranslator=(NamesTranslator) context.getBean("namesTranslator", NamesTranslator.class);
    }catch (RuntimeException e) {
      logger.error(e.getMessage(), e);
      throw e;
    }
  }
  
  @After
  public void after()
  {    
    logger.info("Closing context");
    context.close();
  }

}
