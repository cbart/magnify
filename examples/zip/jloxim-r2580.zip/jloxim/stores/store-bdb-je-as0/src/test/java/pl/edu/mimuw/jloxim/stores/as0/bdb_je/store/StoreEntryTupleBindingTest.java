/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntry;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryAtomic;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryComposite;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryPointer;
import pl.edu.mimuw.jloxim.stores.as0.bdb_je.store.entry.StoreEntryTupleBinding;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import com.sleepycat.je.DatabaseEntry;

public class StoreEntryTupleBindingTest {
  AtomicValueFactory atomicFactory=new AtomicValueFactoryImpl();
  
  public StoreEntryTupleBinding getBinding() {
    StoreEntryTupleBinding binding=new StoreEntryTupleBinding();
    binding.setAtomicValueFactory(atomicFactory);
    Assert.assertNotNull(binding.getAtomicValueFactory());
    return binding;
  }
  
  private List<StoreEntry> getTestsObjects() throws UnsupportedEncodingException
  {
    List<StoreEntry> res=new LinkedList<StoreEntry>();
    res.add(new StoreEntryAtomic(17L, 13, atomicFactory.newAtomicValue(true)));
    res.add(new StoreEntryAtomic(Long.MAX_VALUE, 13, atomicFactory.newAtomicValue(false)));
    res.add(new StoreEntryAtomic(0L, 13, atomicFactory.newAtomicValue("abdf³¼½²ðđŋęą".getBytes("UTF-8"))));
    res.add(new StoreEntryAtomic(18L, Integer.MAX_VALUE, atomicFactory.newAtomicValue(new Date())));
    res.add(new StoreEntryAtomic(19L, Integer.MIN_VALUE, atomicFactory.newAtomicValue(Integer.MIN_VALUE)));
    res.add(new StoreEntryAtomic((20L), 13, atomicFactory.newAtomicValue(Integer.MAX_VALUE)));
    res.add(new StoreEntryAtomic((21L), 13, atomicFactory.newAtomicValue(Long.MIN_VALUE)));
    res.add(new StoreEntryAtomic((22L), 13, atomicFactory.newAtomicValue(Long.MAX_VALUE)));
    res.add(new StoreEntryAtomic((23L), 13, atomicFactory.newAtomicValue("abdf³¼½²ðđŋęą")));
    res.add(new StoreEntryAtomic((24L), 14, atomicFactory.newAtomicValue(1234.8765)));
    
    res.add(new StoreEntryPointer(24L, 14, new LongOid(Long.MAX_VALUE)));
    res.add(new StoreEntryComposite(25L, 15));
    
    return res;
  }
  
  @Test
  public void testObjectToEntry() throws UnsupportedEncodingException {
    for (StoreEntry se:getTestsObjects())
    {
      DatabaseEntry de=new DatabaseEntry();
      getBinding().objectToEntry(se, de);
    }
  }
  
  @Test
  public void testObjectToEntryAndBack() throws UnsupportedEncodingException {
    for (StoreEntry se:getTestsObjects())
    {
      DatabaseEntry de=new DatabaseEntry();
      getBinding().objectToEntry(se, de);
      StoreEntry res=getBinding().entryToObject(de);
      Assert.assertEquals("Problem for equal for object with parent oid: "+se.getParent_oid(), se, res);
    }
  }
}
