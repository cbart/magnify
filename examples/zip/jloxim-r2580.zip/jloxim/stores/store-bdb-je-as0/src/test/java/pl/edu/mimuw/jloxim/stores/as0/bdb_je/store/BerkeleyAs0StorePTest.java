/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0.bdb_je.store;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.tests.StoreAs0PTest;


@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/BerkeleyAs0StoreTest-context.xml"})
public class BerkeleyAs0StorePTest extends StoreAs0PTest{
  @Autowired StoreAS0 store;
  @Autowired TransactionManager transactionManager;
  @Autowired AS0ObjectsFactory as0ObjectsFactory;
  @Autowired AtomicValueFactory atomicValueFactory;
  
  @Override
  public AtomicValueFactory getAtomicValueFactory() {
    return atomicValueFactory;
  }
  
  @Override
  public StoreAS0 getStore() {  
    return store;
  }
  
  @Override
  public TransactionManager getTM() {
    return transactionManager;
  }
  
  @Override
  public AS0ObjectsFactory getAS0ObjectsFactory() {
    return as0ObjectsFactory;
  }
  

//  public static void main(String[] args) throws InterruptedException {
//    BerkeleyAs0StorePTest ins=new BerkeleyAs0StorePTest();
//    try{
//      ins.performanceTest1();
//    }finally{
//      ins.cleanContext();
//    }
//  }
}
