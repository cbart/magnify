/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.model.as0.api.values.*;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.*;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;

/**
 * @author kadamczyk
 * @version $Id: EntryValueBindingTest.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
//@Ignore
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"/StoreBtreeAs0SpringTest-context.xml"})
public class EntryValueBindingTest {

    private static final Logger logger = Logger.getLogger(EntryValueBindingTest.class);

    private AtomicValueFactory atomicValueFactory = new AtomicValueFactoryImpl();
    private EntryValueBinding binding;

    @Rule public TestName testName = new TestName();
    private AbstractApplicationContext applicationContext;

    protected synchronized ApplicationContext getApplicationContext() {
        if (applicationContext == null)
        {
            applicationContext = new ClassPathXmlApplicationContext("/StoreBtreeAs0SpringTest-context.xml");
        }
        return applicationContext;
    }
    
    @Before
    public void init() {
        this.binding = getApplicationContext().getBean("entryValueBinding", EntryValueBinding.class);
    }

    @After
    public void afterTest()
    {
        logger.error("finished " + testName.getMethodName());
        if (applicationContext != null) {
            applicationContext.close();
        }
    }
    
    @Test
    public void testComplexValue() {
        /*
            private static final byte OBJECT_TYPE_COMPOSITE = 0;
        */

        final int COUNT = 5000;

        // Complex

        for (int i = 0; i < COUNT; ++i) {
            int rInt = new Random().nextInt();
            EntryComplexValue entry = new EntryComplexValue(new LongOid(i), rInt);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryComplexValue);
            Assert.assertTrue(entry.compareTo((EntryComplexValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }
    }

    @Test
    public void testPointerValue() {
        /*
        private static final byte OBJECT_TYPE_POINTER = 1;
        */

        final int COUNT = 5000;

        // Pointer

        for (int i = 0; i < COUNT; ++i) {
            int rInt = new Random().nextInt();
            EntryPointerValue entry = new EntryPointerValue(new LongOid(i), i, new LongOid(rInt));
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryPointerValue);
            Assert.assertTrue(entry.compareTo((EntryPointerValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }
    }

    @Test
    public void testAtomicValue() {
        /*
            private static final byte OBJECT_TYPE_INT = 2;
            private static final byte OBJECT_TYPE_LONG = 3;
            private static final byte OBJECT_TYPE_DOUBLE = 4;
            private static final byte OBJECT_TYPE_BOOLEAN = 5;
            private static final byte OBJECT_TYPE_STRING = 6;
            private static final byte OBJECT_TYPE_BINARY = 7;
            private static final byte OBJECT_TYPE_DATE = 8;
        */

        final int COUNT = 5000;

        // Integer

        for (int i = 0; i < COUNT; ++i) {
            int rInt = new Random().nextInt();
            IntegerAtomicValue value = atomicValueFactory.newAtomicValue(rInt);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(rInt), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // Long

        for (int i = 0; i < COUNT; ++i) {
            long rLong = new Random().nextLong();
            LongAtomicValue value = atomicValueFactory.newAtomicValue(rLong);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(rLong), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // Double

        for (int i = 0; i < COUNT; ++i) {
            double rDouble = new Random().nextDouble();
            DoubleAtomicValue value = atomicValueFactory.newAtomicValue(rDouble);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // Boolean

        for (int i = 0; i < 2; ++i) {
            boolean rBool = i > 0;
            BooleanAtomicValue value = atomicValueFactory.newAtomicValue(rBool);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // String

        for (int i = 0; i < COUNT; ++i) {
            String rString = "name_" + new Random().nextDouble();
            TextAtomicValue value = atomicValueFactory.newAtomicValue(rString);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        for (int i = 0; i < COUNT; ++i) {
            String rString = new LongOid(i).toReadableString();
            TextAtomicValue value = atomicValueFactory.newAtomicValue(rString);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        for (int i = 0; i < COUNT; ++i) {
            String rString = new LongOid(new Random().nextLong()).toString();
            TextAtomicValue value = atomicValueFactory.newAtomicValue(rString);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // Binary

        for (int i = 0; i < COUNT; ++i) {
            byte[] rByte = new LongOid(new Random().nextLong()).toString().getBytes();
            BinaryAtomicValue value = atomicValueFactory.newAtomicValue(rByte);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            if (logger.isDebugEnabled()) {
                String debug = new String(((BinaryAtomicValue) ((EntryAtomicValue) entry).getValue()).getValue());
                logger.info("input: " + debug);
                String debug0 = new String(rawValue.getData());
                logger.info("rawValue: " + debug);
                String debug2 = new String(((BinaryAtomicValue) ((EntryAtomicValue) entry2).getValue()).getValue());
                logger.info("output: " + debug2);
            }

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        for (int i = 0; i < COUNT; ++i) {
            byte[] rByte = new LongOid(new Random().nextLong()).toReadableString().getBytes();
            BinaryAtomicValue value = atomicValueFactory.newAtomicValue(rByte);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

        // Data

        for (int i = 0; i < COUNT; ++i) {
            Date rDate = new Date();
            rDate.setTime(new Random().nextInt());
            Calendar rCalendar = Calendar.getInstance();
            rCalendar.setTime(rDate);

            if (logger.isDebugEnabled()) {
                logger.info("date: " + rDate.toString());
                logger.info("calendar: " + rCalendar.toString());
            }

            DateAtomicValue value = atomicValueFactory.newAtomicValue(rCalendar);
            EntryAtomicValue entry = new EntryAtomicValue(new LongOid(i), i, value);
            TransBtreeValue rawValue = new TransBtreeValueImpl();
            binding.objectToRawValue(entry, rawValue);
            EntryValue entry2 = binding.rawValueToObject(rawValue);

            Assert.assertTrue(entry2 instanceof EntryAtomicValue);
            Assert.assertTrue(entry.compareTo((EntryAtomicValue) entry2) == 0);
            Assert.assertTrue(entry.compareTo(entry2) == 0);
        }

    }


}
