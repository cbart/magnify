/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree;

import com.google.common.collect.Collections2;
import java.util.Calendar;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.annotation.ExpectedException;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.StoreBtreeAS0;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexValue;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.TransBtreeImpl;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author kadamczyk
 * @version $Id: BasicTest.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
//@Ignore
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"/StoreBtreeAs0SpringTest-context.xml"})
public class StoreBtreeAs0SpecTest {
    
    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(StoreBtreeAs0SpecTest.class);

    @Rule public TestName testName = new TestName();
    private AbstractApplicationContext applicationContext;

    private AS0ObjectsFactory as0ObjectsFactory = new AS0ObjectsFactoryImpl();
    private AtomicValueFactory atomicValueFactory = new AtomicValueFactoryImpl();

    protected synchronized ApplicationContext getApplicationContext() {
        if (applicationContext == null)
        {
            applicationContext = new ClassPathXmlApplicationContext("/StoreBtreeAs0SpringTest-context.xml");
        }
        return applicationContext;
    }

    @After
    public void afterTest()
    {
        logger.error("finished " + testName.getMethodName());
        if (applicationContext != null) {
            applicationContext.close();
        }
    }

    public StoreAS0 getStore() {
        return getApplicationContext().getBean("storeAS0", StoreAS0.class);
    }

    public TransactionManager getTM() {
        return getApplicationContext().getBean("transactionManager", TransactionManager.class);
    }


    public AS0ObjectsFactory getAS0ObjectsFactory() {
        return as0ObjectsFactory;
    }

    public AtomicValueFactory getAtomicValueFactory() {
        return atomicValueFactory;
    }
      @Test(expected=ObjectNotFoundStoreException.class)
    public void setAtomicObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setAtomicObjectValue(t, newOid, getAtomicValueFactory().newAtomicValue(7));
      } finally {
        t.commit();
      }
    }
    
    @Test(expected=ObjectNotFoundStoreException.class)
    public void setNewComplexObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setNewComplexObjectValue(t, newOid, Collections.EMPTY_LIST);      
      } finally {
        t.commit();
      }
    }
    
    @Test(expected=ObjectNotFoundStoreException.class)
    public void setNewPointerObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setNewPointerObjectDestination(t, newOid, store.getSuperRootOid());
      } finally {
        t.commit();
      }
    }
    
  @Test
  public void basicUseCase() {       
    StoreAS0 storeAS0 = getStore();
    StoreBtreeAS0 storeAS0Impl = (StoreBtreeAS0) storeAS0;        
        
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

    //printDebug();
    AbstractOid oId = storeAS0.addSubobject(t, storeAS0.getSuperRootOid(), 
        getAS0ObjectsFactory().newAtomicObject(13, 
            getAtomicValueFactory().newAtomicValue(7)));
    //printDebug();
    AbstractOid oId2 = storeAS0.addSubobject(t, storeAS0.getSuperRootOid(), 
        getAS0ObjectsFactory().newAtomicObject(14, 
            getAtomicValueFactory().newAtomicValue(true)));
    //printDebug();
    AbstractOid oId3 = storeAS0.addSubobject(t, storeAS0.getSuperRootOid(), 
        getAS0ObjectsFactory().newAtomicObject(15, 
            getAtomicValueFactory().newAtomicValue("test")));
    //printDebug();

    AS0ObjectRO o = storeAS0.getObjectByOID(t, oId);
    AS0ObjectRO o2 = storeAS0.getObjectByOID(t, oId2);
    AS0ObjectRO o3 = storeAS0.getObjectByOID(t, oId3);

    Assert.assertTrue(o instanceof AS0AtomicObjectRO);
    Assert.assertTrue(o2 instanceof AS0AtomicObjectRO);
    Assert.assertTrue(o3 instanceof AS0AtomicObjectRO);

    AS0AtomicObjectRO ao = (AS0AtomicObjectRO) o;
    AS0AtomicObjectRO ao2 = (AS0AtomicObjectRO) o2;
    AS0AtomicObjectRO ao3 = (AS0AtomicObjectRO) o3;

    Assert.assertEquals(ao.getValue(), 
            getAtomicValueFactory().newAtomicValue(7));
    Assert.assertEquals(ao2.getValue(), 
            getAtomicValueFactory().newAtomicValue(true));
    Assert.assertEquals(ao3.getValue(), 
            getAtomicValueFactory().newAtomicValue("test"));

    ((TransBtreeImpl)storeAS0Impl.getBasicTree()).printDebug(t);
    ((TransBtreeImpl)storeAS0Impl.getParentIndex()).printDebug(t);
    ((TransBtreeImpl)storeAS0Impl.getReferrerIndex()).printDebug(t);

    ParentIndexKey parentIndexKey = new ParentIndexKey(
            new LongOid(0L), 0, new LongOid(0L));
    ParentIndexValue parentIndexValue = storeAS0Impl.getParentIndex().get(
            t, parentIndexKey);
    Assert.assertNull(parentIndexValue);
    ClosableIterator<? extends Entry<ParentIndexKey, ParentIndexValue>> 
            parentIndexIter = storeAS0Impl.getParentIndex().find(
            t, parentIndexKey);
    Assert.assertTrue(parentIndexIter.hasNext());

    ClosableIterator<AbstractOid> allIter = storeAS0.getRoots(t);
    Assert.assertTrue(allIter.hasNext());
    Assert.assertTrue(allIter.hasNext());
    Assert.assertTrue(allIter.hasNext());

    ClosableIterator<AbstractOid> iter = storeAS0.getRootsByName(t, 13);
    Assert.assertTrue(iter.hasNext());
    Assert.assertEquals(iter.next(), oId);

    ClosableIterator<AbstractOid> iter2 = storeAS0.getRootsByName(t, 14);
    Assert.assertTrue(iter2.hasNext());
    Assert.assertEquals(iter2.next(), oId2);

    ClosableIterator<AbstractOid> iter3 = storeAS0.getRootsByName(t, 15);
    Assert.assertTrue(iter3.hasNext());
    Assert.assertEquals(iter3.next(), oId3);

    Map<Integer, ClosableIterator<AbstractOid>> map = storeAS0.getRootsMap(t);
    Assert.assertEquals(3, map.size());

    Assert.assertTrue(map.get(13).hasNext());
    Assert.assertEquals(map.get(13).next(), oId);

    Assert.assertTrue(map.get(14).hasNext());
    Assert.assertEquals(map.get(14).next(), oId2);

    Assert.assertTrue(map.get(15).hasNext());
    Assert.assertEquals(map.get(15).next(), oId3);

    AbstractOid oId4 = storeAS0.addSubobject(t, storeAS0.getSuperRootOid(), 
            getAS0ObjectsFactory().newPointerObject(16, oId));
    //printDebug();
    ClosableIterator<AbstractOid> referrers = storeAS0.getReferrers(t, oId);
    Assert.assertTrue(referrers.hasNext());

    storeAS0.removeObject(t, oId);
    ClosableIterator<AbstractOid> iter4 = storeAS0.getRootsByName(t, 13);
    Assert.assertFalse(iter2.hasNext());

    t.commit();

    Assert.assertTrue(storeAS0.getSuperRootOid().compareTo(new LongOid(0L)) == 0);
    }
    
  @Test
  public void longNameIdsList() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);     
    StoreAS0 storeAS0 = getStore();
        
    final int COUNT = 10000;
    for (int i = 0; i < COUNT; ++i) {
      AbstractOid oId = storeAS0.addSubobject(t, storeAS0.getSuperRootOid(), 
          getAS0ObjectsFactory().newAtomicObject(i, 
              getAtomicValueFactory().newAtomicValue(7)));
    }
  }

}
