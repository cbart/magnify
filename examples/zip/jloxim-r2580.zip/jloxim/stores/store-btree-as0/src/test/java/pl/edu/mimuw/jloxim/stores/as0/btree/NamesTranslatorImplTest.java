/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.btree.names.NamesTranslatorImpl;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.tests.NamesTranslatorTest;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.TransBtreeImpl;

/**
 * Test are inherited from common tests
 *
 * @author kadamczyk
 * @version $Id: NamesTranslatorImplTest.java 2524 2011-10-13 21:37:55Z ptab $
 */
//@Ignore
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"/StoreBtreeAs0SpringTest-context.xml"})
public class NamesTranslatorImplTest extends NamesTranslatorTest {

    private static final Logger logger = Logger.getLogger(NamesTranslatorImplTest.class);

    @Rule public TestName testName = new TestName();
    private AbstractApplicationContext applicationContext;
    
    protected synchronized ApplicationContext getApplicationContext() {
        if (applicationContext == null)
        {
            applicationContext = new ClassPathXmlApplicationContext("/StoreBtreeAs0SpringTest-context.xml");
        }
        return applicationContext;
    }
        
    @After
    public void afterTest()
    {
        logger.info("finished " + testName.getMethodName());
        if (applicationContext != null) {
            applicationContext.close();
        }
    }
    
    @Override
    public NamesTranslator getNamesTranslator() {
        return getApplicationContext().getBean("namesTranslator", NamesTranslator.class);
    }
    
    public TransactionManager getTM() {
        return getApplicationContext().getBean("transactionManager", TransactionManager.class);
    }

    public void printDebug() throws NameTranslatorException, TransactionManagerException, TransactionException {
        if (logger.getLevel() == Level.DEBUG) {
            logger.debug("printing trans btree..");

            Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
            ((TransBtreeImpl<?, ?>)((NamesTranslatorImpl)getNamesTranslator()).getTransBtree()).printDebug(t);
            ((TransBtreeImpl<?, ?>)((NamesTranslatorImpl)getNamesTranslator()).getRewTransBtree()).printDebug(t);
            t.commit();
        }
    }


    //@Ignore
    @Test
    public void registerAndCheck5k() throws NameTranslatorException, TransactionManagerException, TransactionException {

        getNamesTranslator().getOrRegisterName("test0");
        printDebug();

        final int COUNT = 5000;
        for (int i = 0; i < COUNT; ++i) {
            Assert.assertEquals("name_" + i, getNamesTranslator().getNameByNameId(getNamesTranslator().getOrRegisterName("name_" + i)));
        }
    }

    /*
    @Before
    public void initTransBtree() throws TransactionException, TransBufferspaceException, TransactionManagerException {

        namesTranslatorImpl = (NamesTranslatorImpl) namesTranslator;

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

        logger.info("init trans bree: begin");
        RootNode rootNode = nodeManager.newRootNode(t);
        rootNode.write();
        namesTranslatorImpl.getTransBtree().setRootPageId(rootNode.getId());
        logger.info("init trans bree: end");

        logger.info("init rew trans bree: begin");
        RootNode rootNode2 = nodeManager.newRootNode(t);
        rootNode2.write();
        namesTranslatorImpl.getRewTransBtree().setRootPageId(rootNode2.getId());
        logger.info("init rew trans bree: end");

        t.commit();
        //printDebug();
         
    }
    //*/
}
