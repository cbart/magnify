/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairIndexKey;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.nio.ByteBuffer;
import java.util.Random;

/**
 *
 * @author kadamczyk
 */
public class ReferrerIndexKeyTest {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(ReferrerIndexKeyTest.class);

    @Test
    public void serializeTest() {

        final int COUNT = 5000;
        for (int i = 0; i < COUNT; ++i) {
            AbstractOid oId = new LongOid(new Random().nextLong());
            AbstractOid referrerOId = new LongOid(new Random().nextLong());

            //logger.debug("test oId:" + oId  + " referrerOId:" + referrerOId);

            OidPairIndexKey key = new OidPairIndexKey(oId, referrerOId);

            byte[] byteArray = new byte[key.serializableLength()];
            ByteBuffer buffer = ByteBuffer.wrap(byteArray);

            key.serializeInto(buffer);

            OidPairIndexKey key2 = new OidPairIndexKey();
            buffer.rewind();
            key2.deserialize(buffer);

            Assert.assertTrue(key.compareTo(key2) == 0);
            Assert.assertEquals(referrerOId, key2.getSecondOid());
            Assert.assertEquals(oId, key2.getOid());
        }

    }

    
}
