/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.StoreBtreeAS0;
import pl.edu.mimuw.jloxim.stores.tests.StoreAs0Test;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.TransBtreeImpl;

/**
 * Test are inherited from common tests
 * @author kadamczyk
 * @version $Id: StoreBtreeAS0Test.java 2474 2011-09-16 23:12:48Z kadamczyk $
 */
//@Ignore
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"/StoreBtreeAs0SpringTest-context.xml"})
public class StoreBtreeAS0Test extends StoreAs0Test {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(StoreBtreeAS0Test.class);

    @Rule public TestName testName = new TestName();
    private AbstractApplicationContext applicationContext;

    private AS0ObjectsFactory as0ObjectsFactory = new AS0ObjectsFactoryImpl();
    private AtomicValueFactory atomicValueFactory = new AtomicValueFactoryImpl();
    
    protected synchronized ApplicationContext getApplicationContext() {
        if (applicationContext == null)
        {
            applicationContext = new ClassPathXmlApplicationContext("/StoreBtreeAs0SpringTest-context.xml");
        }
        return applicationContext;
    }

    @After
    public void afterTest()
    {
        logger.info("finished " + testName.getMethodName());
        if (applicationContext != null) {
            applicationContext.close();
        }
    }

    /*
    @Before
    public void init() {
        StoreBtreeAS0 storeAS0Impl = (StoreBtreeAS0) getStore();
        storeAS0Impl.init();
    }
    */
    
    public void printDebug() {
        if (logger.getLevel() == Level.DEBUG) {
            logger.debug("printing trans btree..");
       
            Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        
            StoreBtreeAS0 storeAS0Impl = (StoreBtreeAS0) getStore();
            ((TransBtreeImpl)storeAS0Impl.getBasicTree()).printDebug(t);
            ((TransBtreeImpl)storeAS0Impl.getParentIndex()).printDebug(t);
            ((TransBtreeImpl)storeAS0Impl.getReferrerIndex()).printDebug(t);

            t.commit();
        }
    }

    @Override
    public StoreAS0 getStore() {
        return getApplicationContext().getBean("storeAS0", StoreAS0.class);
    }

    @Override
    public TransactionManager getTM() {
        /*
        TransactionManager transactionManagerSpy = Mockito.spy(transactionManager);
        logger.info("Creating transactionManagerMock");
        Mockito.when(transactionManagerSpy.newTransaction(Mockito.any(TransactionIsolationLevel.class))).thenAnswer(
            new Answer<Transaction>() {
                public Transaction answer(InvocationOnMock invocation) throws Throwable {
                    logger.info("Creating transactions spy");
                    Transaction t = Mockito.spy(transactionManager.newTransaction((TransactionIsolationLevel) invocation.getArguments()[0]));
                    Mockito.doNothing().when(t).rollback();
                    return t;
                }
            }
        );
        return transactionManagerSpy;
        */
        return getApplicationContext().getBean("transactionManager", TransactionManager.class);
    }

    @Override
    public AS0ObjectsFactory getAS0ObjectsFactory() {
        return as0ObjectsFactory;
    }

    @Override
    public AtomicValueFactory getAtomicValueFactory() {
        return atomicValueFactory;
    }

    
    /*
    @Before
    public void init() {
        StoreBtreeAS0 storeAS0Impl = (StoreBtreeAS0) storeAS0;

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

        //  private TransBtree<AbstractOid, EntryValue> transBtree;
        RootNode transBtreeRootNode = nodeManager.newRootNode(t);
        transBtreeRootNode.write();
        storeAS0Impl.getTransBtree().setRootPageId(transBtreeRootNode.getId());

        //  private TransBtree<ParentIndexKey, ParentIndexValue> parentIndex;
        RootNode parentIndexRootNode = nodeManager.newRootNode(t);
        parentIndexRootNode.write();
        storeAS0Impl.getParentIndex().setRootPageId(parentIndexRootNode.getId());

        //  private TransBtree<ReferrerIndexKey, ReferrerIndexValue> referrerIndex;
        RootNode referrerIndexRootNode = nodeManager.newRootNode(t);
        referrerIndexRootNode.write();
        storeAS0Impl.getReferrerIndex().setRootPageId(referrerIndexRootNode.getId());

        storeAS0Impl.init(t);
        t.commit();        
    }
    */
}
