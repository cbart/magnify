/*
 * Copyright 2011 Faculty of Mathematics Informatics and Mechanics at the University of Warsaw.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store;

import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Component;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * Thread-safe unique long oIds provider
 * 
 * @author kadamczyk
 * @version $Id: LongOidSequence.java 2496 2011-09-24 00:33:50Z kadamczyk $
 */
@Component
public class LongOidSequence {

    private AtomicLong oIdSequence = new AtomicLong(2L);
    
    public LongOid get(long n) {
        return new LongOid(oIdSequence.addAndGet(n));
    }
            
    public void set(long s) {
        oIdSequence.set(s);
    }
}
