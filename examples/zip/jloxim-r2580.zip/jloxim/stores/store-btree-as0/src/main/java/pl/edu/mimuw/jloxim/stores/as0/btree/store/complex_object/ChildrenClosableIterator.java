/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.complex_object;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Map;
import java.util.NoSuchElementException;

/**
 * @author kadamczyk
 * @version $Id: ChildrenClosableAndSizeAwareIterator.java 2086 2010-09-22 21:18:25Z kadamczyk $
 */
public final class ChildrenClosableIterator implements ClosableIterator<AbstractOid> {

    private static final Logger logger = Logger.getLogger(ChildrenClosableIterator.class);

    private ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> realIterator;
    private AbstractOid parentOid;
    private int nameId;

    private AbstractOid nextOid;
    private boolean end;

    public ChildrenClosableIterator(ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> realIterator, AbstractOid parentOid) {
        this.realIterator = realIterator;
        this.parentOid = parentOid;
        this.nameId = 0;

        this.end = false;
        this.nextOid = null;
        //logger.info("iterator hasNext:" + this.hasNext());
    }

    public ChildrenClosableIterator(ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> realIterator, AbstractOid parentOid, int nameId) {
        this.realIterator = realIterator;
        this.parentOid = parentOid;
        this.nameId = nameId;

        this.end = false;
        this.nextOid = null;
        //logger.info("iterator by nameId hasNext:" + this.hasNext());
    }

    @Override
    public void close() {
        realIterator.close();
    }

    @Override
    public synchronized boolean hasNext() {
        if (end)
            return false;

        if (nextOid != null)
            return true;

        if (realIterator.hasNext()) {
            Map.Entry<ParentIndexKey, ParentIndexValue> nextRec = realIterator.next();
            //logger.info("parentOid:" + parentOid + " ?= nextRec.parentOid:" + nextRec.getKey().getParentOid());
            if (nextRec.getKey().getParentOid().compareTo(parentOid) == 0) {
                if (nameId != 0 && nextRec.getKey().getNameId() != nameId) {
                    end = true;
                    return false;
                }
                nextOid = nextRec.getKey().getOid();
                return true;
            }
        }

        end = true;
        return false;
    }

    @Override
    public synchronized AbstractOid next() {
        if (hasNext()) {
            AbstractOid ret = nextOid;
            nextOid = null;
            return ret;
        }
        throw new NoSuchElementException("The cursor have no more items.");
    }

    @Override
    public void remove() {
        realIterator.remove();
    }
}
