/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.complex_object;

import java.util.Map.Entry;
import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.EntryComplexValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.util.HashMap;
import java.util.Map;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.names_index.NamesIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.names_index.NamesIndexValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairClosableIterator;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairIndexValue;

/**
 * @author kadamczyk
 * @version $Id: AS0ComplexObjectROImpl.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
public class AS0ComplexObjectROImpl implements AS0ComplexObjectRO {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(AS0ComplexObjectROImpl.class);

    private LongOid oId;
    EntryComplexValue complexValue;

    private Transaction transaction;
    private TransBtree<NamesIndexKey, NamesIndexValue> namesIndex;
    private TransBtree<ParentIndexKey, ParentIndexValue> parentIndex;

    public AS0ComplexObjectROImpl(Transaction transaction, AbstractOid oId, EntryComplexValue complexValue, TransBtree<ParentIndexKey, ParentIndexValue> parentIndex, TransBtree<NamesIndexKey, NamesIndexValue> namesIndex) {
        this.oId = (LongOid) oId;
        this.complexValue = complexValue;

        this.transaction = transaction;
        this.parentIndex = parentIndex;
        this.namesIndex = namesIndex;
    }

    @Override
    public ClosableIterator<AbstractOid> iterator() throws ModelException {
        ParentIndexKey key = new ParentIndexKey(oId, 0, new LongOid(0L));
        ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> iter = parentIndex.find(transaction, key);
            
        //logger.info("iterator hasNext:" + iter.hasNext());
        return new ChildrenClosableIterator(iter, oId);
    }

    @Override
    public ClosableIterator<AbstractOid> getIteratorBySubobjectNameId(int nameId) throws ModelException {
        ParentIndexKey key = new ParentIndexKey(oId, nameId, new LongOid(0L));
        ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> iter = parentIndex.find(transaction, key);
            
        //logger.info("iterator by nameId hasNext:" + iter.hasNext());
        return new ChildrenClosableIterator(iter, oId, nameId);
    }

    @Override
    public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap() throws ModelException {
        Map<Integer, ClosableIterator<AbstractOid>> map = new HashMap<Integer, ClosableIterator<AbstractOid>>();
        
        NamesIndexKey namesKey = new NamesIndexKey(oId, 0);
        ClosableIterator<? extends Map.Entry<NamesIndexKey, NamesIndexValue>> namesIterator = null;        
        try {
            namesIterator = namesIndex.find(transaction, namesKey);            
            while (namesIterator.hasNext()) {
                Entry<NamesIndexKey, NamesIndexValue> next = namesIterator.next();
                if (oId.compareTo(next.getKey().getOid()) != 0)
                    break;
                
                int nameId = next.getKey().getNameId();
                ParentIndexKey key = new ParentIndexKey(oId, nameId, new LongOid(0L));
                ClosableIterator<? extends Map.Entry<ParentIndexKey, ParentIndexValue>> iter = parentIndex.find(transaction, key);
                
                if (iter.hasNext())
                    map.put(nameId, new ChildrenClosableIterator(iter, oId, nameId));
            }
        } finally {
            if (namesIterator != null)
                namesIterator.close();                   
        }
        
        return map;            
    }

    @Override
    public AbstractOid getOID() {
        return oId;
    }

    @Override
    public AbstractOid getParentOID() {
        return complexValue.getParentOid();
    }

    @Override
    public int getNameId() {
        return complexValue.getNameId();
    }
}
