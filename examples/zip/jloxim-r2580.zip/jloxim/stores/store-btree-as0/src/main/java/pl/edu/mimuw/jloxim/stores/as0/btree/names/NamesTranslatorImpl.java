/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.names;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundNameTranslatorException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Map.Entry;

import javax.security.auth.Destroyable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor;

/**
 * @author kadamczyk
 * @version $Id: NamesTranslatorImpl.java 2539 2011-12-02 00:24:35Z ptab $
 */
public class NamesTranslatorImpl implements NamesTranslator {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(NamesTranslatorImpl.class);
    
    @Autowired private TransactionManager transactionManager;
    @Autowired private IntegerSequence sequence;

    private TransBtree<Integer, String> transBtree;
    private TransBtree<String, Integer> rewTransBtree;   

    public TransBtree<Integer, String> getTransBtree() {
        return transBtree;
    }

    public void setTransBtree(TransBtree<Integer, String> transBtree) {
        this.transBtree = transBtree;
    }

    public TransBtree<String, Integer> getRewTransBtree() {
        return rewTransBtree;
    }

    public void setRewTransBtree(TransBtree<String, Integer> rewTransBtree) {
        this.rewTransBtree = rewTransBtree;
    }
    
    private int generateNameId() {
        return sequence.get(1);                
    }
    
    public void init() throws NameTranslatorException {
      Transaction t = null;
      try {
        t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Integer nameId = rewTransBtree.get(t, SUPERROOT_NAME);
        if (nameId == null) {
            transBtree.put(t, SUPERROOT, SUPERROOT_NAME);
            rewTransBtree.put(t, SUPERROOT_NAME, SUPERROOT);
        }
      } catch (TransactionException ex) {
          throw new NameTranslatorException(ex);
      } catch (TransBtreeException ex) {
          throw new NameTranslatorException(ex);
      } catch (TransactionManagerException ex) {
          throw new NameTranslatorException(ex);
      } finally {       
        if (t != null) t.commit();
      }
    }

    /**
     *
     * @param name to get or register
     * @return
     * @throws NameTranslatorException
     */
    @Override
    public synchronized int getOrRegisterName(String name) throws NameTranslatorException {
      try {
          // internal transaction
          Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
          Integer nameId = rewTransBtree.get(t, name);          
          if (nameId == null) {
              nameId = generateNameId();
              // two-way map
              transBtree.put(t, nameId, name);
              rewTransBtree.put(t, name, nameId);
          }
          t.commit();
          return nameId;
      } catch (TransactionException ex) {
          throw new NameTranslatorException(ex);
      } catch (TransBtreeException ex) {
          throw new NameTranslatorException(ex);
      } catch (TransactionManagerException ex) {
          throw new NameTranslatorException(ex);
      }
    }
    
    @Override
    public synchronized String getNameByNameId(int nameId) throws NameTranslatorException {
        try {
            // internal transaction
            Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            String name = transBtree.get(t, nameId);
            t.commit();

            if (name == null) {
                throw new ObjectNotFoundNameTranslatorException();
            }

            return name;

        } catch (TransactionException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransBtreeException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransactionManagerException ex) {
            throw new NameTranslatorException(ex);
        }
    }

    @Override
    public synchronized int getNameIdByName(String name) throws NameTranslatorException {
        try {
            // internal transaction
            Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            Integer nameId = rewTransBtree.get(t, name);
            t.commit();

            if (nameId == null) {
                throw new ObjectNotFoundNameTranslatorException();
            }

            return nameId;

        } catch (TransactionException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransBtreeException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransactionManagerException ex) {
            throw new NameTranslatorException(ex);
        }
    }

    @Override
    public ClosableIterator<? extends Entry<Integer, String>> getAllEntries() throws NameTranslatorException {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        // iterator close() method commits transaction
        return new NamesIterator(t, transBtree.iterator(t));
    }

    @Override
    synchronized public void removeName(String name) throws NameTranslatorException {
        try {
            // internal transaction
            Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            Integer nameId = getNameIdByName(name);
            transBtree.remove(t, nameId);
            rewTransBtree.remove(t, name);
            t.commit();

        } catch (TransactionException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransBtreeException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransactionManagerException ex) {
            throw new NameTranslatorException(ex);
        }
    }

    @Override
    public void removeNameId(int nameId) throws NameTranslatorException {
        try {
            // internal transaction
            Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            String name = getNameByNameId(nameId);
            transBtree.remove(t, nameId);
            rewTransBtree.remove(t, name);
            t.commit();

        } catch (TransactionException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransBtreeException ex) {
            throw new NameTranslatorException(ex);
        } catch (TransactionManagerException ex) {
            throw new NameTranslatorException(ex);
        }
    }

}
