/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.entry;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.model.as0.api.values.*;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.nio.ByteBuffer;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author kadamczyk
 * @version $Id: EntryValueBinding.java 2505 2011-09-26 06:05:41Z kadamczyk $
 */
public class EntryValueBinding implements TransBtreeValueBinding<EntryValue> {

    private static final Logger logger = Logger.getLogger(EntryValueBinding.class);
    private static final byte OBJECT_TYPE_COMPOSITE = 0;
    private static final byte OBJECT_TYPE_POINTER = 1;
    private static final byte OBJECT_TYPE_INT = 2;
    private static final byte OBJECT_TYPE_LONG = 3;
    private static final byte OBJECT_TYPE_DOUBLE = 4;
    private static final byte OBJECT_TYPE_BOOLEAN = 5;
    private static final byte OBJECT_TYPE_STRING = 6;
    private static final byte OBJECT_TYPE_BINARY = 7;
    private static final byte OBJECT_TYPE_DATE = 8;
    
    @Autowired private AtomicValueFactory atomicValueFactory;

    @Override
    public EntryValue rawValueToObject(TransBtreeValue entry) {

        ByteBuffer data = ByteBuffer.wrap(entry.getData());
        LongOid parentOid = new LongOid(data.getLong());
        int nameId = data.getInt();
        byte type = data.get();

        switch (type) {
            case OBJECT_TYPE_POINTER: {
                LongOid destinationOid = new LongOid(data.getLong());
                return new EntryPointerValue(parentOid, nameId, destinationOid);
            }
            case OBJECT_TYPE_INT: {
                int value = data.getInt();
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_LONG: {
                long value = data.getLong();
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_DOUBLE: {
                double value = data.getDouble();
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_BOOLEAN: {
                boolean value = data.get() != 0;
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_DATE: {
                Date value = new Date(data.getLong());
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_STRING: {
                int len = data.getInt();
                String value = new String(data.array(), data.position(), len);
                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_BINARY: {
                int size = data.getInt();
                byte[] value = new byte[size];
                for (int i = 0; i < size; ++i) {
                    value[i] = data.get();
                }
                //byte[] value = Arrays.copyOfRange(data.array(), data.arrayOffset(), data.arrayOffset() + size);

                if (logger.isDebugEnabled()) {
                    logger.debug("binding binary value size: " + size);
                    String debug = new String(value);
                    logger.debug("binding binary data: " + debug);
                }

                return new EntryAtomicValue(parentOid, nameId, atomicValueFactory.newAtomicValue(value));
            }
            case OBJECT_TYPE_COMPOSITE: {
                EntryComplexValue value = new EntryComplexValue(parentOid, nameId);
                return value;
            }
            default:
                throw new StoreException("EntryValue: Unknown object type.");
        }
    }

    @Override
    public void objectToRawValue(EntryValue object, TransBtreeValue rawValue) {

        int size = object.serializableLength();
        byte[] byteArray = new byte[size];
        ByteBuffer data = ByteBuffer.wrap(byteArray);

        data.putLong(((LongOid) object.getParentOid()).getValue());
        data.putInt(object.getNameId());

        if (object instanceof EntryAtomicValue) {
            AtomicValue atomicValue = ((EntryAtomicValue) object).getValue();
            if (atomicValue instanceof IntegerAtomicValue) {
                data.put(OBJECT_TYPE_INT);
                data.putInt((Integer) atomicValue.getValue());
            } else if (atomicValue instanceof LongAtomicValue) {
                data.put(OBJECT_TYPE_LONG);
                data.putLong((Long) atomicValue.getValue());
            } else if (atomicValue instanceof DoubleAtomicValue) {
                data.put(OBJECT_TYPE_DOUBLE);
                data.putDouble((Double) atomicValue.getValue());
            } else if (atomicValue instanceof BooleanAtomicValue) {
                data.put(OBJECT_TYPE_BOOLEAN);
                byte value = (byte) ((((Boolean) atomicValue.getValue())) ? 1 : 0);
                data.put(value);
            } else if (atomicValue instanceof TextAtomicValue) {
                data.put(OBJECT_TYPE_STRING);
                String value = (String) atomicValue.getValue();
                data.putInt(value.length());
                data.put(value.getBytes());
            } else if (atomicValue instanceof DateAtomicValue) {
                data.put(OBJECT_TYPE_DATE);
                data.putLong((((DateAtomicValue) atomicValue).getValue().getTimeInMillis()));
            } else if (atomicValue instanceof BinaryAtomicValue) {
                data.put(OBJECT_TYPE_BINARY);
                byte[] value = ((BinaryAtomicValue) atomicValue).getValue();
                data.putInt(value.length);
                data.put(value, 0, value.length);
            }
        } else if (object instanceof EntryPointerValue) {
            EntryPointerValue pointer = (EntryPointerValue) object;
            data.put(OBJECT_TYPE_POINTER);
            data.putLong(((LongOid) pointer.getDestinationOid()).getValue());
        } else if (object instanceof EntryComplexValue) {
            EntryComplexValue value = (EntryComplexValue) object;
            data.put(OBJECT_TYPE_COMPOSITE);
        } else {
            throw new StoreException("EntryValue: Unknown object type.");
        }

        rawValue.setData(byteArray, 0, size);
    }
}
