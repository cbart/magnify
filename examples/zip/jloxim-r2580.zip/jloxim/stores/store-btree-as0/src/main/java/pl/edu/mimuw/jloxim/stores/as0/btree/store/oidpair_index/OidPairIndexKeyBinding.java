/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index;

import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;

import java.nio.ByteBuffer;
import org.springframework.stereotype.Component;

/**
 * @author kadamczyk
 * @version $Id: OidPairIndexKeyBinding.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
@Component
public class OidPairIndexKeyBinding implements TransBtreeValueBinding<OidPairIndexKey> {
    @Override
    public OidPairIndexKey rawValueToObject(TransBtreeValue entry) {
        byte[] byteArray = entry.getData();
        ByteBuffer data = ByteBuffer.wrap(byteArray);

        OidPairIndexKey key = new OidPairIndexKey();
        key.deserialize(data);
        return key;
    }

    @Override
    public void objectToRawValue(OidPairIndexKey object, TransBtreeValue value) {
        byte[] byteArray = new byte[object.serializableLength()];
        ByteBuffer data = ByteBuffer.wrap(byteArray);
        object.serializeInto(data);
        value.setData(byteArray, 0, byteArray.length);
    }
}
