/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.complex_object.AS0ComplexObjectROImpl;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.EntryAtomicValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.EntryComplexValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.EntryPointerValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.entry.EntryValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.parent_index.ParentIndexValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairIndexValue;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index.OidPairClosableIterator;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import javax.annotation.PostConstruct;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.names_index.NamesIndexKey;
import pl.edu.mimuw.jloxim.stores.as0.btree.store.names_index.NamesIndexValue;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;

/**
 * Store based on transactional B+Tree implementation.
 * 
 * @author kdamczyk
 * @version $Id: StoreBtreeAS0.java 2539 2011-12-02 00:24:35Z ptab $
 */
public class StoreBtreeAS0 implements StoreAS0 {

    private static final Logger logger = Logger.getLogger(StoreBtreeAS0.class);
    private static final AbstractOid SUPER_ROOT_OID = LongOid.ZERO;
    private static final AbstractOid CONFIG_ROOT_OID = LongOid.ONE;
    private String storeId;

    @Autowired private AS0ObjectsFactory as0ObjectsFactory;
    @Autowired private TransactionManager transactionManager;
    @Autowired private LongOidSequence oIdSequence;
    
    /// main data storage
    private TransBtree<AbstractOid, EntryValue> basicTree;
    
    /// supplementary structures
    private TransBtree<ParentIndexKey, ParentIndexValue> parentIndex;
    private TransBtree<NamesIndexKey, NamesIndexValue> namesIndex;
    private TransBtree<OidPairIndexKey, OidPairIndexValue> referrerIndex;

    public void setTransactionManager(TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    public TransBtree<AbstractOid, EntryValue> getBasicTree() {
        return basicTree;
    }

    public void setBasicTree(TransBtree<AbstractOid, EntryValue> transBtree) {
        this.basicTree = transBtree;
    }

    public TransBtree<ParentIndexKey, ParentIndexValue> getParentIndex() {
        return parentIndex;
    }

    public void setParentIndex(TransBtree<ParentIndexKey, ParentIndexValue> parentIndex) {
        this.parentIndex = parentIndex;
    }

    public TransBtree<NamesIndexKey, NamesIndexValue> getNamesIndex() {
        return namesIndex;
    }

    public void setNamesIndex(TransBtree<NamesIndexKey, NamesIndexValue> namesIndex) {
        this.namesIndex = namesIndex;
    }    

    public TransBtree<OidPairIndexKey, OidPairIndexValue> getReferrerIndex() {
        return referrerIndex;
    }

    public void setReferrerIndex(TransBtree<OidPairIndexKey, OidPairIndexValue> referrerIndex) {
        this.referrerIndex = referrerIndex;
    }

    public void setAs0ObjectsFactory(AS0ObjectsFactory as0ObjectsFactory) {
        this.as0ObjectsFactory = as0ObjectsFactory;
    }

    @Override
    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    @Override
    public AbstractOid getSuperRootOid() {
        return SUPER_ROOT_OID;
    }

    @Override
    public AbstractOid getConfigRootOid() {
        return CONFIG_ROOT_OID;
    }

    /**
     * Creates special ROOT and CONFIG_ROOT objects
     * 
     */
    @PostConstruct
    public synchronized void init() {        
        Transaction transaction = transactionManager.newTransaction(
                TransactionIsolationLevel.SERIALIZABLE);
 
        // add super root
        AS0ComplexObjectEditable root = as0ObjectsFactory.newEmptyComplexObject(0);
        addSubobjectWithoutCheck(transaction, getSuperRootOid(), root, getSuperRootOid());

        // add config root
        AS0ComplexObjectEditable configRoot = as0ObjectsFactory.newEmptyComplexObject(0);
        addSubobjectWithoutCheck(transaction, getSuperRootOid(), configRoot, getConfigRootOid());        

        transaction.commit();
    }

    // get

    @Override
    public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException {
        try {
            EntryValue value = basicTree.get(t, oid);
            return value.getParentOid();
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getParentOID interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }        
    }

    @Override
    public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(Transaction t, AbstractOid OID) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(t, OID);
            if (object instanceof AS0ComplexObjectRO) {
                return ((AS0ComplexObjectRO) object).getSubobjectOIDsMap();
            }

            return Collections.<Integer, ClosableIterator<AbstractOid>>emptyMap();
        
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getSubobjectOIDsMap interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        } 
    }

    @Override
    public ClosableIterator<AbstractOid> getSubobjectOIDs(Transaction t, AbstractOid OID) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(t, OID);
            if (object instanceof AS0ComplexObjectRO) {
                return ((AS0ComplexObjectRO) object).iterator();
            }

            return new EmptyClosableIterator<AbstractOid>();
        
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getSubobjectOIDs interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }         
    }

    @Override
    public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(Transaction t, AbstractOid OID, int nameId) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(t, OID);
            if (object instanceof AS0ComplexObjectRO) {
                return ((AS0ComplexObjectRO) object).getIteratorBySubobjectNameId(nameId);
            }

            return new EmptyClosableIterator<AbstractOid>();
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getSubobjectOIDsByNameOID interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }        
    }

    @Override
    public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(Transaction t) throws StoreException {
        try {
            AS0ComplexObjectRO root = (AS0ComplexObjectRO) getObjectOrSuperRootByOID(t, getSuperRootOid());
            return root.getSubobjectOIDsMap();
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getRootsMap interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        } 
    }

    @Override
    public ClosableIterator<AbstractOid> getRoots(Transaction t) throws StoreException {
        try {
            AS0ComplexObjectRO root = (AS0ComplexObjectRO) getObjectOrSuperRootByOID(t, getSuperRootOid());
            return root.iterator();
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getRoots interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        } 
    }

    @Override
    public ClosableIterator<AbstractOid> getRootsByName(Transaction t, int nameId) throws StoreException {
        try {
            AS0ComplexObjectRO root = (AS0ComplexObjectRO) getObjectOrSuperRootByOID(t, getSuperRootOid());
            return root.getIteratorBySubobjectNameId(nameId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getRoots interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    @Override
    public AS0ObjectRO getObjectByOID(Transaction transaction, AbstractOid oId) throws StoreException {
        try {
            return getObjectOrSuperRootByOID(transaction, oId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getObjectByOID interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }  
    }

    public AS0ObjectRO getObjectOrSuperRootByOID(Transaction transaction, AbstractOid oId) throws StoreException {
        EntryValue value = basicTree.get(transaction, oId);
        if (value == null)
            throw new ObjectNotFoundStoreException(storeId);

        if (value instanceof EntryAtomicValue) {
            EntryAtomicValue atomicValue = (EntryAtomicValue) value;
            AS0ObjectEditable object = as0ObjectsFactory.newAtomicObject(value.getNameId(), atomicValue.getValue());
            object.setParentOID(value.getParentOid());
            object.setOID(oId);
            return object;
        } else if (value instanceof EntryPointerValue) {
            AS0ObjectEditable object = as0ObjectsFactory.newPointerObject(value.getNameId(), ((EntryPointerValue) value).getDestinationOid());
            object.setParentOID(value.getParentOid());
            object.setOID(oId);
            return object;
        } else if (value instanceof EntryComplexValue) {
            return new AS0ComplexObjectROImpl(transaction, oId, (EntryComplexValue) value, parentIndex, namesIndex);
        } else {
            throw new StoreException(storeId, "Unknown value type.");
        }
    }

    // set new value

    @Override
    public void setAtomicObjectValue(Transaction transaction, AbstractOid oId, AtomicValue value) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(transaction, oId);
            removeObjectWithoutCheck(transaction, object.getOID(), false /* withReferrers */);

            AS0AtomicObjectEditable atomicObject = as0ObjectsFactory.newAtomicObject(object.getNameId(), value);
            atomicObject.setOID(oId);
            atomicObject.setParentOID(object.getParentOID());
            addSubobjectWithoutCheck(transaction, object.getParentOID(), atomicObject, oId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "setAtomicObjectValue interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }        
    }

    @Override
    public void setNewPointerObjectDestination(Transaction transaction, AbstractOid oId, AbstractOid destinationOid) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(transaction, oId);
            removeObjectWithoutCheck(transaction, object.getOID(), false /* withReferrers */);

            AS0PointerObjectEditable pointerObject = as0ObjectsFactory.newPointerObject(object.getNameId(), destinationOid);
            pointerObject.setOID(oId);
            pointerObject.setParentOID(object.getParentOID());
            addSubobjectWithoutCheck(transaction, object.getParentOID(), pointerObject, oId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "setNewPointerObjectDestination interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    @Override
    public void setNewComplexObjectValue(Transaction transaction, AbstractOid oId, Collection<AS0ObjectEditable> subobjects) throws StoreException {
        try {
            AS0ObjectRO object = getObjectOrSuperRootByOID(transaction, oId);
            removeObjectWithoutCheck(transaction, object.getOID(), false /* withReferrers */);

            AS0ComplexObjectEditable complexObject = as0ObjectsFactory.newComplexObject(object.getNameId(), subobjects);
            complexObject.setOID(oId);
            complexObject.setParentOID(object.getParentOID());
            addSubobjectWithoutCheck(transaction, object.getParentOID(), complexObject, oId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "setNewComplexObjectValue interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    // add

    /**
     * Adds a subobject with a new unique identifier to the given complex object
     * 
     * @param transaction
     * @param parentOid complex object identifier, use 0 to create a root
     * @param object to add
     * @return
     * @throws StoreException
     * @throws ObjectNotFoundStoreException if the given parentOid 
     *     does not represent a valid complex object
     * @throws InterruptedStoreOperationException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
    @Override
    public AbstractOid addSubobject(Transaction transaction, AbstractOid parentOid, AS0ObjectEditable object) throws StoreException {        
        try {
            // assert parent is a complex object
            if (!parentOid.equals(SUPER_ROOT_OID)) {
                EntryValue value = basicTree.get(transaction, parentOid);
                if (!(value instanceof EntryComplexValue)) {
                    String unexpectedValueType = "null";
                    if (value != null)
                        unexpectedValueType = value.getClass().getSimpleName();
                    throw new ObjectNotFoundStoreException(storeId, "Object with OID:" + parentOid + " required to be complex object, but it is: " + unexpectedValueType);
                }
            }
            addSubobjectWithoutCheck(transaction, parentOid, object);
            return object.getOID();
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "addSubobject interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    /**
     * Adds a subobject with a new unique identifier, 
     * without verifying the existance of a parent object
     * 
     * @param transaction
     * @param parentOid parent object identifier, use 0 to create a root
     * @param object to add
     */
    private void addSubobjectWithoutCheck(Transaction transaction, AbstractOid parentOid, AS0ObjectEditable object) {
        addSubobjectWithoutCheck(transaction, parentOid, object, generateOid());
    }

    /**
     * Adds a subobject with the specified identifier, 
     * without verifying the existance of a parent object
     * 
     * @param transaction
     * @param parentOid 
     * @param object to add
     * @param newObjectOid
     */
    private void addSubobjectWithoutCheck(Transaction transaction, AbstractOid parentOid, AS0ObjectEditable object, AbstractOid newObjectOid) {
        object.setOID(newObjectOid);
        object.setParentOID(parentOid);
        EntryValue value = as0ObjectToEntryValue(object);

        if (logger.isDebugEnabled())
          logger.debug("add parentId:" + parentOid + " nameId:" + object.getNameId() + " oId:" + newObjectOid);
        
        basicTree.put(transaction, newObjectOid, value);

        if (!newObjectOid.equals(SUPER_ROOT_OID) && !newObjectOid.equals(CONFIG_ROOT_OID)) {
            ParentIndexKey parentIndexKey = new ParentIndexKey(parentOid, object.getNameId(), newObjectOid);
            parentIndex.put(transaction, parentIndexKey, ParentIndexValue.EMPTY);

            EntryComplexValue parentObject = (EntryComplexValue) basicTree.get(transaction, parentOid);
            if (parentObject != null) {
                NamesIndexKey namesIndexKey = new NamesIndexKey(parentOid, object.getNameId());
                namesIndex.put(transaction, namesIndexKey, NamesIndexValue.EMPTY);
                basicTree.put(transaction, parentOid, parentObject);
            }
        }

        if (object instanceof AS0ComplexObjectEditable) {
            AS0ComplexObjectEditable complexObject = (AS0ComplexObjectEditable) object;
            for (AS0ObjectEditable subobject : complexObject.getSubobjects()) {
                addSubobjectWithoutCheck(transaction, newObjectOid, subobject);
            }
        } else if (object instanceof AS0PointerObjectEditable) {
            AS0PointerObjectEditable pointer = (AS0PointerObjectEditable) object;
            OidPairIndexKey key = new OidPairIndexKey(pointer.getDestinationOID(), pointer.getOID());
            referrerIndex.put(transaction, key, OidPairIndexValue.EMPTY);
        }
    }

    /**
     * Converts AS0ObjectRO to the internal representation
     * 
     * @param object
     * @return 
     */
    private EntryValue as0ObjectToEntryValue(AS0ObjectRO object) {
        if (object instanceof AS0AtomicObjectRO) {
            AS0AtomicObjectRO atomicObject = (AS0AtomicObjectRO) object;
            return new EntryAtomicValue(atomicObject.getParentOID(), atomicObject.getNameId(), atomicObject.getValue());
        }
        if (object instanceof AS0PointerObjectRO) {
            AS0PointerObjectRO pointerObject = (AS0PointerObjectRO) object;
            return new EntryPointerValue(pointerObject.getParentOID(), pointerObject.getNameId(), pointerObject.getDestinationOID());
        }
        if (object instanceof AS0ComplexObjectRO) {
            AS0ComplexObjectRO complexObject = (AS0ComplexObjectRO) object;
            return new EntryComplexValue(complexObject.getParentOID(), complexObject.getNameId());
        } else {
            throw new StoreException(storeId, "Unknown object type");
        }
    }

    /**
     * Generates a unique object identifiers
     * 
     * @return unique LongOid identifier
     */
    private AbstractOid generateOid() {
        return oIdSequence.get(1L);
    }

    // remove

    @Override
    public void removeObject(Transaction transaction, AbstractOid oId) throws StoreException {
        try {
            if (oId.equals(SUPER_ROOT_OID)) {
                throw new StoreException(getStoreId(), "Cannot remove super root");
            }
            if (oId.equals(CONFIG_ROOT_OID)) {
                throw new StoreException(getStoreId(), "Cannot remove config root");
            }

            /// check whether a oId points to a valid object
            getObjectOrSuperRootByOID(transaction, oId);

            removeObjectWithoutCheck(transaction, oId, true /* withReferrers */);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "removeObject interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    @Override
    public void removeObjects(Transaction transaction, AbstractOid[] oIds) throws StoreException {
        for (AbstractOid oId : oIds) {
            removeObject(transaction, oId);
        }
    }

    private void removeObjectWithoutCheck(Transaction transaction, AbstractOid oId, boolean withReferrers) throws StoreException {

        AS0ObjectRO object;
        try {
           object = getObjectOrSuperRootByOID(transaction, oId);
        } catch (ObjectNotFoundStoreException ex) {
           return;
        }

        /* get subobjects iterator */
        ClosableIterator<AbstractOid> iter = getSubobjectOIDs(transaction, oId);

        /* remove object itself */
        basicTree.remove(transaction, oId);
        
        if (object instanceof AS0PointerObjectRO) {
            AS0PointerObjectRO pointerObject = (AS0PointerObjectRO) object;
            OidPairIndexKey referrerIndexKey = new OidPairIndexKey(pointerObject.getDestinationOID(), oId);
            referrerIndex.remove(transaction, referrerIndexKey);
        }
        
        //TODO clean-up unused nameIds

        /* removing subobjects */
        try {
            while (iter.hasNext()) {
                removeObjectWithoutCheck(transaction, iter.next(), true);
                ParentIndexKey parentIndexKey = new ParentIndexKey(object.getParentOID(), object.getNameId(), oId);
                parentIndex.remove(transaction, parentIndexKey);
            }
        } finally {
            iter.close();
        }

        /* removing referrers to the object */
        if (withReferrers) {
            iter = getReferrers(transaction, oId);
            try {
                while (iter.hasNext()) {
                    AbstractOid referrerOid = iter.next();
                    removeObjectWithoutCheck(transaction, referrerOid, true);
                    OidPairIndexKey referrerIndexKey = new OidPairIndexKey(oId, referrerOid);
                    referrerIndex.remove(transaction, referrerIndexKey);
                }
            } finally {
                iter.close();
            }
        }
    }

    // move - set new parentId

    @Override
    public void moveObject(Transaction transaction, AbstractOid oId, AbstractOid newParentOid) throws StoreException {
        try {
            if (oId.equals(SUPER_ROOT_OID))
                throw new ObjectNotFoundStoreException(storeId);

            EntryValue entryValue = basicTree.get(transaction, oId);

            if (entryValue == null)
                throw new ObjectNotFoundStoreException(storeId);

            if (entryValue.getParentOid().compareTo(newParentOid) == 0)
                return;

            AbstractOid oldParentOid = entryValue.getParentOid();
            entryValue.setParentOid(newParentOid);
            basicTree.put(transaction, oId, entryValue);

            EntryComplexValue oldParentObject = (EntryComplexValue) basicTree.get(transaction, oldParentOid);
            //TODO clean-up unused nameIds
            basicTree.put(transaction, oldParentOid, oldParentObject);

            EntryComplexValue newParentObject = (EntryComplexValue) basicTree.get(transaction, newParentOid);
            NamesIndexKey namesIndexKey = new NamesIndexKey(newParentOid, entryValue.getNameId());
            namesIndex.put(transaction, namesIndexKey, NamesIndexValue.EMPTY);
            basicTree.put(transaction, newParentOid, newParentObject);

            ParentIndexKey parentIndexKey = new ParentIndexKey(oldParentOid, entryValue.getNameId(), oId);
            parentIndex.remove(transaction, parentIndexKey);
            parentIndexKey.setParentOid(newParentOid);
            parentIndex.put(transaction, parentIndexKey, ParentIndexValue.EMPTY);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "moveObject interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }
    }

    // referrers

    @Override
    public ClosableIterator<AbstractOid> getReferrers(Transaction transaction, AbstractOid oId) throws StoreException {
        try {
            OidPairIndexKey key = new OidPairIndexKey(oId, new LongOid(0));
            ClosableIterator<? extends Entry<OidPairIndexKey, OidPairIndexValue>> iter = referrerIndex.find(transaction, key);

            return new OidPairClosableIterator(iter, oId);
        } catch (InterruptedOperationTransBtreeException ex) {
            throw new InterruptedStoreOperationException(storeId, "getReferrers interrupted", ex);
        } catch (TransBtreeException ex) {
            throw new StoreException(storeId, ex);
        }        
    }

    // prefetch

    @Override
    public void prefetchObject(AbstractOid OID) {
        return;
    }

    @Override
    public void prefetchObjects(AbstractOid[] OIDs) {
        return;
    }

    @Override
    public void prefetchDeepObject(AbstractOid OID) {
        return;
    }

    @Override
    public void prefetchDeepObjects(AbstractOid[] OIDs) {
        return;
    }

    @Override
    public void prefetchSubobjectsByParentIDandName(AbstractOid parentId, int nameId) {
        return;
    }
}
