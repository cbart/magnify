/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.SerializableIntoBuffer;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.nio.ByteBuffer;

/**
 * @author kadamczyk
 * @version $Id: OidPairIndexKey.java 2415 2011-07-15 22:40:00Z kadamczyk $
 */
public class OidPairIndexKey implements SerializableIntoBuffer, Comparable<OidPairIndexKey> {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(OidPairIndexKey.class);

    private AbstractOid oId;
    private AbstractOid secondOid;

    public OidPairIndexKey(AbstractOid oId, AbstractOid secondOid) {
        this.oId = oId;
        this.secondOid = secondOid;
    }

    public OidPairIndexKey() {
        oId = new LongOid(0L);
        secondOid = new LongOid(0L);
    }

    public AbstractOid getOid() {
        return oId;
    }

    public void setoId(AbstractOid oId) {
        this.oId = oId;
    }

    public AbstractOid getSecondOid() {
        return secondOid;
    }

    public void setSecondOid(AbstractOid secondOid) {
        this.secondOid = secondOid;
    }

    @Override
    public int serializeInto(ByteBuffer data) {
        //logger.error("ReferrerIndexKey oId:" + oId + " referrerOid:" + referrerOid);
        oId.serializeInto(data);
        secondOid.serializeInto(data);
        return serializableLength();
    }

    @Override
    public int deserialize(ByteBuffer data) {
        oId.deserialize(data);
        secondOid.deserialize(data);
        //logger.error("ReferrerIndexKey deserialize oId:" + oId + " referrerOid:" + referrerOid);
        return serializableLength();
    }

    @Override
    public int serializableLength() {
        return oId.serializableLength() + secondOid.serializableLength();
    }

    @Override
    public int compareTo(OidPairIndexKey key) {
        int ret = this.oId.compareTo(key.oId);
        if (ret != 0)
            return ret;

        return this.secondOid.compareTo(key.secondOid);
    }

    @Override
    public String toString() {
        return "oId:" + oId  + " referrerOid:" + secondOid;
    }

}
