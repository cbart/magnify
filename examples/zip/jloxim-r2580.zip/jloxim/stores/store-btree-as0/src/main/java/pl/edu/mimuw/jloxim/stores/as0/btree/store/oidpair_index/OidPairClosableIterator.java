/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.btree.store.oidpair_index;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Map;
import java.util.NoSuchElementException;

/**
 *
 * @author kadamczyk
 * @version $Id: OidPairClosableIterator.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
public class OidPairClosableIterator implements ClosableIterator<AbstractOid> {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(OidPairClosableIterator.class);
    private ClosableIterator<? extends Map.Entry<OidPairIndexKey, OidPairIndexValue>> realIterator;
    AbstractOid oId;
    private AbstractOid secondOid;
    private boolean end;

    public OidPairClosableIterator(ClosableIterator<? extends Map.Entry<OidPairIndexKey, OidPairIndexValue>> realIterator, AbstractOid oId) {
        this.realIterator = realIterator;
        this.oId = oId;
        this.end = false;
        //logger.info("iterator hasNext:" + this.hasNext());
    }


    @Override
    public void close() {
        realIterator.close();
    }

    @Override
    public boolean hasNext() {
        if (end == true) {
            return false;
        }

        if (secondOid != null)
            return true;

        if (realIterator.hasNext()) {
            Map.Entry<OidPairIndexKey, OidPairIndexValue> value = realIterator.next();
            if (value.getKey().getOid().compareTo(oId) == 0) {
                secondOid = value.getKey().getSecondOid();
                return true;
            }
        }

        end = true;
        return false;
    }

    @Override
    public AbstractOid next() {
        if (hasNext()) {
            AbstractOid ret = secondOid;
            secondOid = null;
            return ret;
        }
        throw new NoSuchElementException("The cursor have no more items.");
    }

    @Override
    public void remove() {
        realIterator.remove();
    }
    
}
