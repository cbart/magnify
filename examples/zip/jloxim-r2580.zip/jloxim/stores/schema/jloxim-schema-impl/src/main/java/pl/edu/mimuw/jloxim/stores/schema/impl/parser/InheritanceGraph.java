/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.parser;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParseResult;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 *
 * @author Paweł Mantur
 */
public class InheritanceGraph {

    private class InheritanceGraphNode {

        public InheritanceGraphNode(String n) {
            name = n;
            parents = new LinkedList<InheritanceGraphNode>();
        }

        String name;

        List<InheritanceGraphNode> parents;
    }

    Map<String, InheritanceGraphNode> classesMap;

    public InheritanceGraph() {
        classesMap = new HashMap<String, InheritanceGraphNode>();
    }

    public void addClasses(SchemaParseResult pr) {
        for (SchemaType t : pr.getTypes().values()) {
            if (t.getTypeKind() == TypeEnum.Class) {
                addClass((ClassType) t);
            }
        }
    }

    public boolean isSubclass(String name1, String name2) {
        InheritanceGraphNode n1 = classesMap.get(name1);
        InheritanceGraphNode n2 = classesMap.get(name2);
        return findParent(n2, name1) || findParent(n1, name2);
    }

    private boolean findParent(InheritanceGraphNode node, String classToFind) {
        for (InheritanceGraphNode parent : node.parents) {
            if (parent.name.compareTo(classToFind) == 0) {
                return true;
            }
            if (findParent(parent, classToFind)) {
                return true;
            }
        }
        return false;
    }

    private void addClass(ClassType cl) {
        InheritanceGraphNode node = null;
        if (classesMap.containsKey(cl.getName())) {
            node = classesMap.get(cl.getName());
        } else {
            node = new InheritanceGraphNode(cl.getName());
        }

        InheritanceGraphNode parent = null;
        for (String pn : cl.getExtendsList()) {
            if (classesMap.containsKey(pn)) {
                parent = classesMap.get(pn);
            } else {
                parent = new InheritanceGraphNode(pn);
            }
            node.parents.add(parent);
        }
    }

    /**
     * Checks if there is a cycle in the graph. If a cycle is found all its members are returned.
     * Otherwise null is returned
     * @return
     */
    public Set<String> isCyclic() {
        Set<String> searched = new java.util.HashSet<String>();
        Stack<InheritanceGraphNode> stack = new Stack<InheritanceGraphNode>();
        Set<String> onStack = new java.util.HashSet<String>();

        for (InheritanceGraphNode n : classesMap.values()) {
            if (!searched.contains(n.name)) {
                searched.add(n.name);
                stack.push(n);
                onStack.add(n.name);
                if (findCycle(stack, onStack, searched)) {
                    return onStack;
                }
            }
        }

        return null;
    }

    private boolean findCycle(Stack<InheritanceGraphNode> stack, Set<String> onStack, Set<String> searched) {
        if (stack.isEmpty()) {
            return false;
        }

        InheritanceGraphNode current = stack.peek();

        for (InheritanceGraphNode p : current.parents) {

            if (onStack.contains(p.name)) {
                return true;
            }

            stack.push(p);
            onStack.add(p.name);
            searched.add(p.name);

            if (findCycle(stack, onStack, searched)) {
                return true;
            }

            stack.pop();
            onStack.remove(p.name);
        }

        return false;
    }
}
