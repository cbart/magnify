/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.metabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseRO;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.CardinalityImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.ClassTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.DateRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.DoubleRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationConstantImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.LongRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.MethodImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.PointerTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.RestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.SchemaTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StringRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructMemberImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.TypeOidImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.VariantTypeImpl;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 *
 * @author Paweł Mantur
 */
public class MetabaseROImpl implements MetabaseRO {

    protected StoreAS0 backingStore;

    protected AS0ObjectsFactory objectsFactory;

    protected AtomicValueFactory atomicValFacory;

    protected NamesTranslator namesTransaltor;

    protected MetabaseNaming metabaseNaming;

    protected Logger logger = Logger.getLogger(MetabaseROImpl.class);


    /* ====================  getters and setters  ===================== */
    /**
     * Store where schema is physically located.
     * @return
     */
    public StoreAS0 getBackingStore() {
        return backingStore;
    }

    public void setBackingStore(StoreAS0 backingStore) {
        this.backingStore = backingStore;
    }

    public void setObjectsFactory(AS0ObjectsFactory factory) {
        this.objectsFactory = factory;
    }

    public AS0ObjectsFactory getObjectsFactory() {
        return objectsFactory;
    }

    public AtomicValueFactory getAtomicValFacory() {
        return atomicValFacory;
    }

    public void setAtomicValFacory(AtomicValueFactory atomicValFacory) {
        this.atomicValFacory = atomicValFacory;
    }

    public NamesTranslator getNamesTransaltor() {
        return namesTransaltor;
    }

    public void setNamesTransaltor(NamesTranslator namesTransaltor) {
        this.namesTransaltor = namesTransaltor;
    }

    protected MetabaseNaming getMetabaseNaming() {
        if (metabaseNaming == null) {
            metabaseNaming = new MetabaseNaming(namesTransaltor);
        }
        return metabaseNaming;
    }

    private Map<TypeOid, SchemaType> typeByOidMap = new HashMap<TypeOid, SchemaType>();

    private Map<String, SchemaType> typeByNameMap = new HashMap<String, SchemaType>();

    /* ====================  methods ===================== */
    public String getSchemaId(Transaction t) {
        MetabaseNaming n = getMetabaseNaming();
        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, n);
        if (schemaRootObj == null) {
            return null;
        }
        return getAtomicValue(t, schemaRootObj, n.getNameId(MetabaseNaming.SCHEMA_ID));
    }

    public TypeOid getRootTypeOid(Transaction t) {
        MetabaseNaming n = getMetabaseNaming();
        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, n);
        if (schemaRootObj == null) {
            return null;
        }
        return getPointerToType(t, schemaRootObj, n.getNameId(MetabaseNaming.ROOT_POINTER));
    }

    public SchemaType getTypeByName(Transaction t, String typeName) {

        MetabaseNaming n = getMetabaseNaming();

        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, n);
        if (schemaRootObj == null) {
            throw new SchemaProviderException("Metabase is empty");
        }

        typeByOidMap.clear();
        typeByNameMap.clear();

        String schemaId = getAtomicValue(t, schemaRootObj, n.getNameId(MetabaseNaming.SCHEMA_ID));

        Map<AbstractOid, String> typeNameByTypeOidMap = new HashMap<AbstractOid, String>();
        Map<String, AS0ComplexObjectRO> typeObjectByNameMap = readAllTypesSchallow(t, schemaRootObj.getOID(), getMetabaseNaming(), typeNameByTypeOidMap, null);

        AS0ComplexObjectRO typeObj = typeObjectByNameMap.get(typeName);
        if (typeObj == null) {
            throw new SchemaProviderException("Type named '" + typeName + "' not found in schema with id '" + schemaId + "'");
        }

        return storeObjectToSchemaType(t, typeObj, typeName, n, typeNameByTypeOidMap);
    }

    public Map<String, SchemaType> getTypesByNameMap(Transaction t) {
        typeByOidMap.clear();
        typeByNameMap.clear();
        readAllTypes(t, typeByOidMap, typeByNameMap);
        return typeByNameMap;
    }

    public SchemaType getTypeByOid(Transaction t, TypeOid typeOid) throws SchemaProviderException {

        MetabaseNaming n = getMetabaseNaming();

        // get metabse root object
        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, n);
        if (schemaRootObj == null) {
            throw new SchemaProviderException("Metabase is empty");
        }

        AS0ObjectRO obj = backingStore.getObjectByOID(t, typeOid);
        if (obj == null || !(obj instanceof AS0ComplexObjectRO)) {
            throw new SchemaProviderException("Type with id '" + typeOid.toReadableString() + "' not found");
        }

        typeByOidMap.clear();
        typeByNameMap.clear();

        Map<AbstractOid, String> typeNameByTypeOidMap = new HashMap<AbstractOid, String>();
        readAllTypesSchallow(t, schemaRootObj.getOID(), n, typeNameByTypeOidMap, null);

        AS0ComplexObjectRO typeObject = (AS0ComplexObjectRO) obj;
        return storeObjectToSchemaType(t, typeObject, getMetabaseNaming(), typeNameByTypeOidMap);
    }

    public Map<TypeOid, SchemaType> getTypesByOidMap(Transaction t) {
        typeByOidMap.clear();
        typeByNameMap.clear();
        readAllTypes(t, typeByOidMap, typeByNameMap);
        return typeByOidMap;
    }

    /* ========= private  methods =========== */
    private void readAllTypes(Transaction t, Map<TypeOid, SchemaType> typeByOidMap, Map<String, SchemaType> typeByNameMap) {

        MetabaseNaming naming = getMetabaseNaming();

        // get metabse root object
        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, naming);
        if (schemaRootObj == null) {
            throw new SchemaProviderException("Metabase is empty");
        }

        Map<AbstractOid, String> typeNameByTypeOidMap = new HashMap<AbstractOid, String>();
        Map<String, AS0ComplexObjectRO> typeObjectByNameMap = readAllTypesSchallow(t, schemaRootObj.getOID(), naming, typeNameByTypeOidMap, null);

        // read full information about types
        for (String typeName : typeObjectByNameMap.keySet()) {
            AS0ComplexObjectRO typeObj = typeObjectByNameMap.get(typeName);
            SchemaTypeImpl type = storeObjectToSchemaType(t, typeObj, getMetabaseNaming(), typeNameByTypeOidMap);
            typeByOidMap.put(type.getTypeOid(), type);
            typeByNameMap.put(type.getName(), type);
        }
    }

    protected AS0ComplexObjectRO getMetabaseRootObject(Transaction t, MetabaseNaming naming) {

        ClosableIterator<AbstractOid> iter = backingStore.getRootsByName(t, naming.getNameId(MetabaseNaming.METABASE_ROOT));
        if (!iter.hasNext()) {
            iter.close();
            return null;
        }

        AbstractOid schemaRootID = iter.next();
        iter.close();

        AS0ObjectRO schemaObj = backingStore.getObjectByOID(t, schemaRootID);
        if (!(schemaObj instanceof AS0ComplexObjectRO)) {
            throw new SchemaProviderException("Invalid metabase format. Root element of scherma is not a complex object");
        }

        return (AS0ComplexObjectRO) schemaObj;
    }

    protected Map<String, AS0ComplexObjectRO> readAllTypesSchallow(Transaction t, AbstractOid schemaRootID, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap, Integer typeNameId, Map<Integer, AbstractOid> groupObjectsOIDs) {

        Map<String, AS0ComplexObjectRO> res = new HashMap<String, AS0ComplexObjectRO>();
        ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, schemaRootID, typeNameId);
        while (iter.hasNext()) {
            AbstractOid groupOid = iter.next();
            if (groupObjectsOIDs != null) {
                groupObjectsOIDs.put(typeNameId, groupOid);
            }
            ClosableIterator<AbstractOid> typesIter = backingStore.getSubobjectOIDsByNameOID(t, groupOid, naming.getNameId(MetabaseNaming.TYPE));
            while (typesIter.hasNext()) {
                AS0ComplexObjectRO typeObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, typesIter.next());
                String name = getAtomicValue(t, typeObj, naming.getNameId(MetabaseNaming.NAME));
                res.put(name, typeObj);
                if (typeNameByTypeOidMap != null) {
                    typeNameByTypeOidMap.put(typeObj.getOID(), name);
                }
            }
            typesIter.close();
        }
        iter.close();
        return res;
    }

    protected Map<String, AS0ComplexObjectRO> readAllTypesSchallow(Transaction t, AbstractOid schemaRootID, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap, Map<Integer, AbstractOid> groupObjectsOIDs) {
        Map<String, AS0ComplexObjectRO> res = new HashMap<String, AS0ComplexObjectRO>();
        for (Integer typeNameID : naming.getTypeNameIds()) {
            res.putAll(readAllTypesSchallow(t, schemaRootID, naming, typeNameByTypeOidMap, typeNameID, groupObjectsOIDs));
        }
        return res;
    }

    protected SchemaType getTypeByOidShallow(Transaction t, AbstractOid typeOid, MetabaseNaming naming) {
        AS0ObjectRO obj = backingStore.getObjectByOID(t, typeOid);

        if (obj == null) {
            throw new SchemaProviderException("Type object not found in metabase, typeOid = " + typeOid);
        }

        if (!(obj instanceof AS0ComplexObjectRO)) {
            throw new SchemaProviderException("Type object not complex, typeOid = " + typeOid);
        }

        AS0ComplexObjectRO cObj = (AS0ComplexObjectRO) obj;
        return new SchemaTypeImpl(getName(t, cObj, naming), getKind(t, cObj, naming));
    }

    private String getName(Transaction t, AS0ComplexObjectRO parent, MetabaseNaming naming) {
        return (String) getAtomicValue(t, parent, naming.getNameId(MetabaseNaming.NAME));
    }

    private TypeEnum getKind(Transaction t, AS0ComplexObjectRO parent, MetabaseNaming naming) {
        String typeKindStr = getAtomicValue(t, parent, naming.getNameId(MetabaseNaming.KIND));
        return TypeEnum.valueOf(typeKindStr);
    }

    private SchemaTypeImpl storeObjectToSchemaType(Transaction t, AS0ComplexObjectRO obj, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {
        String typeName = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.NAME));
        return storeObjectToSchemaType(t, obj, typeName, naming, typeNameByTypeOidMap);
    }

    private SchemaTypeImpl storeObjectToSchemaType(Transaction t, AS0ComplexObjectRO obj, String typeName, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {

        String typeKindStr = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.KIND));
        TypeEnum typeKind = TypeEnum.valueOf(typeKindStr);

        SchemaTypeImpl res = null;

        switch (typeKind) {
            case Class:
                res = readClass(t, obj, typeName, naming, typeNameByTypeOidMap);
                break;
            case Struct:
                res = readStruct(t, obj, typeName, naming, typeNameByTypeOidMap);
                break;
            case Enum:
                res = readEnum(t, obj, typeName, naming);
                break;
            case Restriction:
                res = readRestriction(t, obj, typeName, naming);
                break;
            case AnyAtomic:
            case Binary:
            case Boolean:
            case Byte:
            case DateTime:
            case Double:
            case Integer:
            case Long:
            case Short:
            case String:
            case AnyType:
                res = new SchemaTypeImpl(typeName, typeKind);
                break;
            case Pointer:
                res = readPointerType(t, obj, typeName, typeNameByTypeOidMap);
                break;
            case Variant:
                res = readVariantType(t, obj, typeName, naming, typeNameByTypeOidMap);
                break;
            default:
                throw new SchemaProviderException("Unrecognized type in metabase: " + typeKind.toString() + " (type name: " + typeName + ", string: " + typeKindStr + ")");
        }

        res.setTypeOid(new TypeOidImpl(obj.getOID()));
        return res;
    }

    private StructTypeImpl readStruct(Transaction t, AS0ComplexObjectRO obj, String name, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {
        StructTypeImpl struct = new StructTypeImpl(name);
        struct.setTypeOid(new TypeOidImpl(obj.getOID()));

        // read fields
        ClosableIterator<AbstractOid> fieldsOids = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), naming.getNameId(MetabaseNaming.FIELD));
        while (fieldsOids.hasNext()) {

            AbstractOid id = fieldsOids.next();
            AS0ComplexObjectRO fieldObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, id);

            String memberName = getAtomicValue(t, fieldObj, naming.getNameId(MetabaseNaming.NAME));
            StructMemberImpl member = new StructMemberImpl(memberName);
            member.setStaticId(id);

            // object declaration
            readObjectDeclaration(t, fieldObj, member, naming, typeNameByTypeOidMap);

            struct.addMember(member);
        }
        fieldsOids.close();
        return struct;
    }

    private ClassTypeImpl readClass(Transaction t, AS0ComplexObjectRO obj, String name, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {
        ClassTypeImpl classType = new ClassTypeImpl(name);

        classType.setTypeOid(new TypeOidImpl(obj.getOID()));

        // read extends list
        ClosableIterator<AbstractOid> extOids = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), naming.getNameId(MetabaseNaming.EXTENDS));
        while (extOids.hasNext()) {
            AbstractOid extId = extOids.next();
            AS0PointerObjectRO ext = (AS0PointerObjectRO) backingStore.getObjectByOID(t, extId);
            classType.getExtendsListOid().add(new TypeOidImpl(ext.getDestinationOID()));
            classType.getExtendsList().add(typeNameByTypeOidMap.get(ext.getDestinationOID()));
        }
        extOids.close();

        // read role of
        TypeOid roleOfOid = getPointerToType(t, obj, naming.getNameId(MetabaseNaming.ROLEOF));
        classType.setRoleOfOid(roleOfOid);
        classType.setRoleOf(typeNameByTypeOidMap.get(roleOfOid));

        // read fields
        ClosableIterator<AbstractOid> fieldsOids = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), naming.getNameId(MetabaseNaming.FIELD));
        while (fieldsOids.hasNext()) {

            AbstractOid id = fieldsOids.next();
            AS0ComplexObjectRO fieldObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, id);

            String memberName = getAtomicValue(t, fieldObj, naming.getNameId(MetabaseNaming.NAME));
            StructMemberImpl member = new StructMemberImpl(memberName);
            member.setStaticId(id);

            // object declaration
            readObjectDeclaration(t, fieldObj, member, naming, typeNameByTypeOidMap);

            // scope
            String scoprStr = getAtomicValue(t, fieldObj, naming.getNameId(MetabaseNaming.SCOPE));
            member.setScope(ScopeEnum.valueOf(scoprStr));

            classType.addMember(member);
        }
        fieldsOids.close();

        // read methods
        ClosableIterator<AbstractOid> methodOids = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), naming.getNameId(MetabaseNaming.METHOD));
        while (methodOids.hasNext()) {
            AbstractOid id = methodOids.next();
            AS0ComplexObjectRO methodObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, id);

            // method name
            String methodName = getAtomicValue(t, methodObj, naming.getNameId(MetabaseNaming.NAME));
            MethodImpl method = new MethodImpl(methodName);


            // parameters
            ClosableIterator<AbstractOid> paramOids = backingStore.getSubobjectOIDsByNameOID(t, methodObj.getOID(), naming.getNameId(MetabaseNaming.PARAM));
            while (paramOids.hasNext()) {

                AbstractOid paramId = paramOids.next();
                AS0ComplexObjectRO paramObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, paramId);

                String paramName = getAtomicValue(t, paramObj, naming.getNameId(MetabaseNaming.NAME));
                StructMemberImpl param = new StructMemberImpl(paramName);
                param.setStaticId(paramId);

                readObjectDeclaration(t, paramObj, param, naming, typeNameByTypeOidMap);
                method.addParameter(param);
            }
            paramOids.close();

            // scope
            String scoprStr = getAtomicValue(t, methodObj, naming.getNameId(MetabaseNaming.SCOPE));
            method.setScope(ScopeEnum.valueOf(scoprStr));

            // result
            AbstractOid resId = getFirstSubobjectByName(t, id, naming.getNameId(MetabaseNaming.RESULT));
            if (resId != null) {
                AS0ComplexObjectRO resObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, resId);
                StructMemberImpl res = new StructMemberImpl(null);
                res.setStaticId(resId);
                readObjectDeclaration(t, resObj, res, naming, typeNameByTypeOidMap);
                method.setResultDeclaration(res);
            }

            // class name
            String className = getAtomicValue(t, methodObj, naming.getNameId(MetabaseNaming.CLASS_NAME));
            method.setClassName(className);

            classType.addMethod(method);
        }
        methodOids.close();

        return classType;
    }

    private void readObjectDeclaration(Transaction t, AS0ComplexObjectRO obj, StructMemberImpl decl, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {

        TypeOid dataTypeId = getPointerToType(t, obj, naming.getNameId(MetabaseNaming.TYPE));
        if (dataTypeId == null) {
            throw new SchemaProviderException("No type oid in object declaration, objId=" + obj.getOID().toReadableString());
        }

        SchemaType type = getTypeByOidShallow(t, dataTypeId, naming);
        if (type == null) {
            throw new SchemaProviderException("Failed to find referenced type by id = " + dataTypeId);
        }

        decl.setTypeKind(type.getTypeKind());
        decl.setTypeName(type.getName());
        decl.setTypeOid(dataTypeId);
        decl.setCardinality(readCardinality(t, obj.getOID(), naming));

        if (type.getTypeKind() == TypeEnum.Pointer) {
            AS0ComplexObjectRO pointerObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, dataTypeId);
            PointerType pnt = readPointerType(t, pointerObj, type.getName(), typeNameByTypeOidMap);
            decl.setReferencedTypeName(pnt.getReferencedObjectTypeName());
        }

        // default value
        Object defaultValue = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.DEFAULT));
        if (defaultValue != null) {
            decl.setDefaultValue(defaultValue);
            // is constant
            Boolean isConstsnt = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.IS_CONSTANT));
            decl.setIsConstant(isConstsnt);
        }
    }

    private Cardinality readCardinality(Transaction t, AbstractOid parentOid, MetabaseNaming naming) {
        AbstractOid cardObjId = getFirstSubobjectByName(t, parentOid, naming.getNameId(MetabaseNaming.CARD));
        AS0ComplexObjectRO cardObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, cardObjId);
        Long min = getAtomicValue(t, cardObj, naming.getNameId(MetabaseNaming.MIN));
        Long max = getAtomicValue(t, cardObj, naming.getNameId(MetabaseNaming.MAX));
        CardinalityImpl card = new CardinalityImpl(min, max == CardinalityImpl.INFINITY ? null : max);
        return card;
    }

    private EnumerationTypeImpl readEnum(Transaction t, AS0ComplexObjectRO obj, String name, MetabaseNaming naming) {
        EnumerationTypeImpl enumeration = new EnumerationTypeImpl(name);

        // allowed avalues
        ClosableIterator<AbstractOid> constantsOids = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), naming.getNameId(MetabaseNaming.ENUM_CONST));
        while (constantsOids.hasNext()) {
            AS0ComplexObjectRO enumConst = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, constantsOids.next());
            EnumerationConstantImpl con = new EnumerationConstantImpl();
            con.setName((String) getAtomicValue(t, enumConst, naming.getNameId(MetabaseNaming.NAME)));
            enumeration.getAllowedValues().add(con);
        }
        constantsOids.close();

        return enumeration;
    }

    private RestrictionTypeImpl readRestriction(Transaction t, AS0ComplexObjectRO restrictionObject, String name, MetabaseNaming naming) {

        RestrictionTypeImpl restr = null;
        TypeOid baseTypeOid = getPointerToType(t, restrictionObject, naming.getNameId(MetabaseNaming.BASETYPE));
        AS0ComplexObjectRO baseTypeObj = (AS0ComplexObjectRO) backingStore.getObjectByOID(t, baseTypeOid);
        TypeEnum baseTypeKind = getKind(t, baseTypeObj, naming);

        switch (baseTypeKind) {
            case String:
                restr = readStringRestriction(t, restrictionObject, naming, name);
                break;
            case Double:
                restr = readDoubleRestriction(t, restrictionObject, naming, name);
                break;
            case DateTime:
                restr = readDateRestriction(t, restrictionObject, naming, name);
                break;
            case Byte:
            case Integer:
            case Long:
            case Short:
                restr = readIntegerRestriction(t, restrictionObject, naming, name);
                break;
            default:
                throw new SchemaProviderException("Metabase constains restriction of type which cannot be restrictted, type name: " + baseTypeKind.toString());
        }

        restr.setTypeOid(new TypeOidImpl(restrictionObject.getOID()));

        restr.setBaseTypeKind(baseTypeKind);
        restr.setBaseTypeOid(baseTypeOid);

        return restr;
    }

    private StringRestrictionTypeImpl readStringRestriction(Transaction t, AS0ComplexObjectRO obj, MetabaseNaming naming, String restrictionName) {

        StringRestrictionTypeImpl restr = new StringRestrictionTypeImpl(restrictionName);

        Integer minLen = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MINLEN));
        Integer maxLen = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MAXLEN));
        String regex = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.REGEX));

        restr.setMaxLength(maxLen == -1 ? null : maxLen);
        restr.setMinLength(minLen == -1 ? null : minLen);
        restr.setRegex(regex);

        return restr;
    }

    private DateRestrictionTypeImpl readDateRestriction(Transaction t, AS0ComplexObjectRO obj, MetabaseNaming naming, String restrictionName) {
        DateRestrictionTypeImpl restr = new DateRestrictionTypeImpl(restrictionName);

        Calendar minVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MINVAL));
        Calendar maxVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MAXVAL));

        restr.setMinValue(minVal);
        restr.setMaxValue(maxVal);

        return restr;
    }

    private DoubleRestrictionTypeImpl readDoubleRestriction(Transaction t, AS0ComplexObjectRO obj, MetabaseNaming naming, String restrictionName) {
        DoubleRestrictionTypeImpl restr = new DoubleRestrictionTypeImpl(restrictionName);

        Double minVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MINVAL));
        Double maxVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MAXVAL));

        restr.setMinValue(minVal);
        restr.setMaxValue(maxVal);

        return restr;
    }

    private LongRestrictionTypeImpl readIntegerRestriction(Transaction t, AS0ComplexObjectRO obj, MetabaseNaming naming, String restrictionName) {
        LongRestrictionTypeImpl restr = new LongRestrictionTypeImpl(restrictionName);

        Long minVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MINVAL));
        Long maxVal = getAtomicValue(t, obj, naming.getNameId(MetabaseNaming.MAXVAL));

        restr.setMinValue(minVal);
        restr.setMaxValue(maxVal);

        return restr;
    }

    private PointerTypeImpl readPointerType(Transaction t, AS0ComplexObjectRO obj, String pointerName, Map<AbstractOid, String> typeNameByTypeOidMap) {
        PointerTypeImpl pt = new PointerTypeImpl(pointerName);
        TypeOid refTypeId = getPointerToType(t, obj, getMetabaseNaming().getNameId(MetabaseNaming.REFTYPE));
        pt.setReferencedTypeOid(refTypeId);
        pt.setReferencedTypeName(typeNameByTypeOidMap.get(refTypeId));
        pt.setReferencedFieldName((String) getAtomicValue(t, obj, getMetabaseNaming().getNameId(MetabaseNaming.REFERENCED_FIELD_NAME)));
        return pt;
    }

    private VariantTypeImpl readVariantType(Transaction t, AS0ComplexObjectRO obj, String variantName, MetabaseNaming naming, Map<AbstractOid, String> typeNameByTypeOidMap) {
        VariantTypeImpl variant = new VariantTypeImpl(variantName);
        ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, obj.getOID(), metabaseNaming.getNameId(MetabaseNaming.POSSIBLE_TYPE));
        while (iter.hasNext()) {
            AS0PointerObjectRO pnt = (AS0PointerObjectRO) backingStore.getObjectByOID(t, iter.next());
            variant.getPossibleTypesNames().add(typeNameByTypeOidMap.get(pnt.getDestinationOID()));
        }
        iter.close();
        return variant;
    }

    private <T> T getAtomicValue(Transaction t, AS0ComplexObjectRO obj, int nameId) {
        AbstractOid oid = getFirstSubobjectByName(t, obj.getOID(), nameId);
        if (oid == null) {
            return null;
        }
        AS0AtomicObjectRO o = (AS0AtomicObjectRO) backingStore.getObjectByOID(t, oid);
        return (T) o.getValue().getValue();
    }

    private TypeOid getPointerToType(Transaction t, AS0ComplexObjectRO obj, int nameId) {
        AbstractOid oid = getFirstSubobjectByName(t, obj.getOID(), nameId);
        if (oid == null) {
            return null;
        }
        AS0PointerObjectRO o = (AS0PointerObjectRO) backingStore.getObjectByOID(t, oid);
        return new TypeOidImpl(o.getDestinationOID());
    }

    protected AbstractOid getFirstSubobjectByName(Transaction t, AbstractOid parentOID, int nameId) {
        AbstractOid res = null;
        ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, parentOID, nameId);
        try {
            while (iter.hasNext()) {
                res = iter.next();
            }
            if (iter.hasNext()) {
                String childName = namesTransaltor.getNameByNameId(nameId);
                throw new SchemaProviderException(String.format("Only one child named %1$s was expected for object with id = %2$s", childName, parentOID.toReadableString()));
            }
        } finally {
            iter.close();
        }
        return res;
    }
}
