/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.metabase;

import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseEditable;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParseResult;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationConstant;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.RestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.CardinalityImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.SchemaTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.TypeOidImpl;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author Paweł Mantur
 */
public class MetabaseEditableImpl extends MetabaseROImpl implements MetabaseEditable {

    public void initFromParseResult(Transaction t, SchemaParseResult parseResult) {
        addTypes(t, parseResult.getTypes().values());
        setSchemaId(t, parseResult.getSchemaId());
        if (!parseResult.getRootType().getTypeKind().isUesrDefined()) {
            SchemaType st = getTypeByName(t, parseResult.getRootType().getName());
             ((SchemaTypeImpl)parseResult.getRootType()).setTypeOid(st.getTypeOid());
        }
        setRootType(t, parseResult.getRootType());
    }

    public void setSchemaId(Transaction t, String schemaId) {
        MetabaseNaming naming = getMetabaseNaming();
        AS0ComplexObjectRO schemaRoot = getMetabaseRootObject(t, naming);
        if (schemaRoot == null) {
            Map<Integer, AbstractOid> groupObjectsOIDs = new HashMap<Integer, AbstractOid>();
            schemaRoot = createEmptySchema(t, naming, null, groupObjectsOIDs);
        }

        AbstractOid oid = getFirstSubobjectByName(t, schemaRoot.getOID(), naming.getNameId(MetabaseNaming.SCHEMA_ID));
        TextAtomicValue atomicVal = atomicValFacory.newAtomicValue(schemaId);
        if (oid == null) {
            AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.SCHEMA_ID), atomicVal);
            backingStore.addSubobject(t, schemaRoot.getOID(), atomic);
        } else {
            backingStore.setAtomicObjectValue(t, oid, atomicVal);
        }
    }

    public void setRootType(Transaction t, SchemaType rootType) {

        if (rootType == null) {
            throw new SchemaProviderException("root type doesn't exist");
        }

        TypeOid rootTypeOid = rootType.getTypeOid();

        if (rootTypeOid == null){
            throw new SchemaProviderException("rootTypeOid is null");
        }

        MetabaseNaming naming = getMetabaseNaming();
        AS0ComplexObjectRO schemaRoot = getMetabaseRootObject(t, naming);
        if (schemaRoot == null) {
            Map<Integer, AbstractOid> groupObjectsOIDs = new HashMap<Integer, AbstractOid>();
            schemaRoot = createEmptySchema(t, naming, null, groupObjectsOIDs);
        }

        AbstractOid oid = getFirstSubobjectByName(t, schemaRoot.getOID(), naming.getNameId(MetabaseNaming.ROOT_POINTER));
        if (oid == null) {
            AS0PointerObjectEditable pointer = objectsFactory.newPointerObject(naming.getNameId(MetabaseNaming.ROOT_POINTER), rootTypeOid);
            backingStore.addSubobject(t, schemaRoot.getOID(), pointer);
        } else {
            backingStore.setNewPointerObjectDestination(t, oid, rootTypeOid);
        }
    }

    public void removeAllTypes(Transaction t) {
        MetabaseNaming naming = getMetabaseNaming();
        AS0ComplexObjectRO schemaRootObj = getMetabaseRootObject(t, naming);
        if (schemaRootObj == null) {
            // metabase is empty
            return;
        }

        for (Integer nameId : naming.getTypeNameIds()) {
            logger.info("removing " + namesTransaltor.getNameByNameId(nameId));
            ClosableIterator<AbstractOid> groups = backingStore.getSubobjectOIDsByNameOID(t, schemaRootObj.getOID(), nameId);
            while (groups.hasNext()) {
                AbstractOid groupOid = groups.next();
                ClosableIterator<AbstractOid> types = backingStore.getSubobjectOIDsByNameOID(t, groupOid, naming.getNameId(MetabaseNaming.TYPE));
                while (types.hasNext()) {
                    AbstractOid typeOid = types.next();
                    SchemaType typeToRemove = getTypeByOidShallow(t, typeOid, naming);
                    if (typeToRemove.getTypeKind().isUesrDefined()) {
                        backingStore.removeObject(t, typeOid);
                    }
                }
                types.close();
            }
            groups.close();
        }
    }

    public Map<String, TypeOid> addTypes(Transaction t, Collection<SchemaType> typesToAdd) {

        Map<String, TypeOid> types = new HashMap<String, TypeOid>();
        MetabaseNaming naming = new MetabaseNaming(getNamesTransaltor());

        ParamsAgreagator params = new ParamsAgreagator();
        params.types = types;
        params.naming = naming;
        params.transaction = t;

        try {

            Map<Integer, AbstractOid> groupObjectsOIDs = new HashMap<Integer, AbstractOid>();
            AS0ComplexObjectRO schemaRoot = getMetabaseRootObject(t, naming);
            if (schemaRoot == null) {
                // create empty schema with system types
                createEmptySchema(t, naming, types, groupObjectsOIDs).getOID();
            } else {
                // read already defined types to set references
                Map<String, AS0ComplexObjectRO> m = readAllTypesSchallow(t, schemaRoot.getOID(), naming, null, groupObjectsOIDs);
                for (String key : m.keySet()) {
                    types.put(key, new TypeOidImpl(m.get(key).getOID()));
                }
            }

            // for each type save an empty complex object to get typeOid
            for (SchemaType type : typesToAdd) {
                AS0ComplexObjectEditable obj = objectsFactory.newEmptyComplexObject(naming.getNameId(MetabaseNaming.TYPE));
                AbstractOid parentOid = groupObjectsOIDs.get(naming.getCollectionNameIdForType(type));
                backingStore.addSubobject(t, parentOid, obj);
                TypeOid toid = new TypeOidImpl(obj.getOID());
                types.put(type.getName(), toid);
                ((SchemaTypeImpl) type).setTypeOid(toid);
            }

            // now we have typeOids for all types, we can insert complete data
            for (SchemaType type : typesToAdd) {
                if (type instanceof ClassType) {
                    saveClassType(params, (ClassType) type);
                } else if (type instanceof StructType) {
                    saveStructType(params, (StructType) type);
                } else if (type instanceof EnumerationType) {
                    saveEnumerationType(params, (EnumerationType) type, naming);
                } else if (type instanceof RestrictionType) {
                    saveRestrictionType(params, (RestrictionType) type);
                } else if (type instanceof VariantType) {
                    saveVariantType(params, (VariantType) type);
                } else if (type instanceof PointerType) {
                    savePointerType(params, (PointerType) type);
                } else {
                    throw new Error("Unknown type of class " + type.getClass().getName());
                }
            }

        } catch (StoreException e) {
            throw new SchemaProviderException(e);
        }

        return types;
    }

    private AS0ComplexObjectRO createEmptySchema(Transaction t, MetabaseNaming naming, Map<String, TypeOid> types, Map<Integer, AbstractOid> groupParents) {

        // create 'sys' object
        AS0ComplexObjectEditable sys = objectsFactory.newEmptyComplexObject(naming.getNameId(MetabaseNaming.METABASE_ROOT));
        backingStore.addSubobject(t, new LongOid(0L), sys);

        // create group wrapper objects
        for (Integer typeNameID : naming.getTypeNameIds()) {
            AS0ComplexObjectEditable systemType = objectsFactory.newEmptyComplexObject(typeNameID);
            AbstractOid newOid = backingStore.addSubobject(t, sys.getOID(), systemType);
            groupParents.put(typeNameID, newOid);
        }

        // add predefined atomic types
        for (TypeEnum type : TypeEnum.values()) {
            if (type.isUesrDefined()) {
                continue;
            } else {

                int nameId = naming.getNameId(MetabaseNaming.SYSTEM_TYPES);
                AS0ComplexObjectEditable systemType = objectsFactory.newEmptyComplexObject(naming.getNameId(MetabaseNaming.TYPE));
                backingStore.addSubobject(t, groupParents.get(nameId), systemType);

                String typeKeyword = type.getSymbol();

                TypeOid systemTypeOid = new TypeOidImpl(systemType.getOID());
                if (types != null) {
                    types.put(typeKeyword, systemTypeOid);
                //logger.info("added system type: " + typeKeyword);
                }

                saveName(t, systemTypeOid, typeKeyword, naming);
                saveKind(t, systemTypeOid, type, naming);
            }
        }

        return sys;
    }

    private void saveName(Transaction t, AbstractOid parent, String name, MetabaseNaming naming) {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue(name);
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.NAME), atomicVal);
        backingStore.addSubobject(t, parent, atomic);
    }

    private void saveKind(Transaction t, AbstractOid parent, TypeEnum kind, MetabaseNaming naming) {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue(kind.toString());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.KIND), atomicVal);
        backingStore.addSubobject(t, parent, atomic);
    }

    private void saveReferencedFieldName(Transaction t, AbstractOid parent, String name) {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue(name);
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(getMetabaseNaming().getNameId(MetabaseNaming.REFERENCED_FIELD_NAME), atomicVal);
        backingStore.addSubobject(t, parent, atomic);
    }

    private void saveStructType(ParamsAgreagator p, StructType struct) throws StoreException {

        TypeOid structId = p.types.get(struct.getName());

        saveName(p.transaction, structId, struct.getName(), p.naming);
        saveKind(p.transaction, structId, TypeEnum.Struct, p.naming);

        for (Iterator<StructMember> iter = struct.getOwnMembersIterator(); iter.hasNext();) {
            saveField(p.transaction, iter.next(), structId, p.types, getMetabaseNaming().getNameId(MetabaseNaming.FIELD), false);
        }
    }

    private void saveField(Transaction t, StructMember field, AbstractOid parentOid, Map<String, TypeOid> types, int nameId, boolean isParam) {

        // wapper object 'field'
        AS0ComplexObjectEditable complex = objectsFactory.newEmptyComplexObject(nameId);
        backingStore.addSubobject(t, parentOid, complex);
        AbstractOid fieldId = complex.getOID();

        // saving data inherited from ObjectDeclaration
        saveStructMember(t, field, fieldId, types, getMetabaseNaming(), isParam);

    }

    private void saveClassType(ParamsAgreagator p, ClassType cl) throws StoreException {

        TypeOid classId = p.types.get(cl.getName());

        AtomicValue atomicVal;
        AS0AtomicObjectEditable atomic;
        AS0PointerObjectEditable pointer;
        AS0ComplexObjectEditable complex;

        // save name and kind
        saveName(p.transaction, classId, cl.getName(), p.naming);
        saveKind(p.transaction, classId, TypeEnum.Class, p.naming);

        // save extends list
        for (String parent : cl.getExtendsList()) {
            pointer = objectsFactory.newPointerObject(p.naming.getNameId(MetabaseNaming.EXTENDS), p.types.get(parent));
            backingStore.addSubobject(p.transaction, classId, pointer);
        }

        // save role of
        if (cl.getRoleOf() != null && !cl.getRoleOf().isEmpty()) {
            pointer = objectsFactory.newPointerObject(p.naming.getNameId(MetabaseNaming.ROLEOF), p.types.get(cl.getRoleOf()));
            backingStore.addSubobject(p.transaction, classId, pointer);
        }

        // save fields
        for (Iterator<StructMember> iter = cl.getOwnMembersIterator(); iter.hasNext();) {
            saveField(p.transaction, iter.next(), classId, p.types, getMetabaseNaming().getNameId(MetabaseNaming.FIELD), false);
        }

        // save methods
        for (Iterator<Method> iter = cl.getOwnMethodsIterator(); iter.hasNext();) {
            Method method = iter.next();
            // wapper object 'method'
            complex = objectsFactory.newEmptyComplexObject(p.naming.getNameId(MetabaseNaming.METHOD));
            backingStore.addSubobject(p.transaction, classId, complex);
            AbstractOid methodId = complex.getOID();

            // method name
            saveName(p.transaction, methodId, method.getName(), p.naming);

            // type kind
            saveKind(p.transaction, methodId, TypeEnum.Method, p.naming);

            // parameters
            for (StructMember param : method.getParameters()) {
                saveField(p.transaction, param, methodId, p.types, p.naming.getNameId(MetabaseNaming.PARAM), true);
            }

            // scope
            atomicVal = atomicValFacory.newAtomicValue(method.getScope().toString());
            atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.SCOPE), atomicVal);
            backingStore.addSubobject(p.transaction, methodId, atomic);

            // reult specification
            if (method.getResultDeclaration() != null) {

                // wapper object 'result'
                complex = objectsFactory.newEmptyComplexObject(p.naming.getNameId(MetabaseNaming.RESULT));
                backingStore.addSubobject(p.transaction, methodId, complex);
                AbstractOid resultId = complex.getOID();

                // cardinality
                saveCardinality(p.transaction, method.getResultDeclaration().getCardinality(), resultId, p.naming);

                // data type
                saveTypeSpecification(p.transaction, method.getResultDeclaration(), resultId, p.types, p.naming);
            }

            // class name
            atomicVal = atomicValFacory.newAtomicValue(method.getClassName());
            atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.CLASS_NAME), atomicVal);
            backingStore.addSubobject(p.transaction, methodId, atomic);

        }
    }

    private void saveStructMember(Transaction t, StructMember member, AbstractOid parentOid, Map<String, TypeOid> types, MetabaseNaming naming, boolean isParam) {

        // name
        AtomicValue atomicVal = atomicValFacory.newAtomicValue(member.getObjectName());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.NAME), atomicVal);
        backingStore.addSubobject(t, parentOid, atomic);

        // data type
        saveTypeSpecification(t, member, parentOid, types, naming);

        // cardinality
        saveCardinality(t, member.getCardinality(), parentOid, naming);

        if (!isParam) {
            // default or constant value
            if (member.getDefaultValue() != null) {

                // value
                atomicVal = literalToAtomicValue(member.getDefaultValue());
                atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.DEFAULT), atomicVal);
                backingStore.addSubobject(t, parentOid, atomic);

                // is constant
                atomicVal = atomicValFacory.newAtomicValue(member.isConstant());
                atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.IS_CONSTANT), atomicVal);
                backingStore.addSubobject(t, parentOid, atomic);
            }

            // scope
            atomicVal = atomicValFacory.newAtomicValue(member.getScope().toString());
            atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.SCOPE), atomicVal);
            backingStore.addSubobject(t, parentOid, atomic);
        }
    }

    private void saveTypeSpecification(Transaction t, StructMember obj, AbstractOid parentOid, Map<String, TypeOid> types, MetabaseNaming naming) {

        // type id
        TypeOid dataTypeId = types.get(obj.getObjectTypeName());
        if (dataTypeId == null) {
            throw new SchemaDefinitionException("Referenced type not present, type name: " + obj.getObjectTypeName());
        }

        AS0PointerObjectEditable pointer = objectsFactory.newPointerObject(naming.getNameId(MetabaseNaming.TYPE), dataTypeId);
        backingStore.addSubobject(t, parentOid, pointer);
    }

    private void saveCardinality(Transaction t, Cardinality card, AbstractOid parentOid, MetabaseNaming naming) {

        AtomicValue atomicVal;
        AS0AtomicObjectEditable atomic;

        AS0ComplexObjectEditable cardinlaityObj = objectsFactory.newEmptyComplexObject(naming.getNameId(MetabaseNaming.CARD));
        backingStore.addSubobject(t, parentOid, cardinlaityObj);

        atomicVal = atomicValFacory.newAtomicValue(card.getMinOccurences());
        atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.MIN), atomicVal);
        backingStore.addSubobject(t, cardinlaityObj.getOID(), atomic);

        atomicVal = atomicValFacory.newAtomicValue(card.getMaxOccurences() == null ? CardinalityImpl.INFINITY : card.getMaxOccurences());
        atomic = objectsFactory.newAtomicObject(naming.getNameId(MetabaseNaming.MAX), atomicVal);
        backingStore.addSubobject(t, cardinlaityObj.getOID(), atomic);
    }

    private void saveEnumerationType(ParamsAgreagator p, EnumerationType enumeration, MetabaseNaming naming) throws StoreException {

        TypeOid enumId = p.types.get(enumeration.getName());

        // save type and kind
        saveName(p.transaction, enumId, enumeration.getName(), p.naming);
        saveKind(p.transaction, enumId, TypeEnum.Enum, p.naming);

        // save constants
        for (EnumerationConstant c : enumeration.getAllowedValues()) {

            AS0ComplexObjectEditable obj = objectsFactory.newEmptyComplexObject(naming.getNameId(MetabaseNaming.ENUM_CONST));
            backingStore.addSubobject(p.transaction, enumId, obj);

            // name
            AtomicValue atomicVal = atomicValFacory.newAtomicValue(c.getName());
            AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.NAME), atomicVal);
            backingStore.addSubobject(p.transaction, obj.getOID(), atomic);
        }
    }

    private void saveRestrictionType(ParamsAgreagator p, RestrictionType restr) throws StoreException {
        TypeOid restrId = p.types.get(restr.getName());

        // save type and kind
        saveName(p.transaction, restrId, restr.getName(), p.naming);
        saveKind(p.transaction, restrId, TypeEnum.Restriction, p.naming);

        // save base type (base type is atomic)
        TypeOid baseTypeId = p.types.get(restr.getBaseTypeKind().getSymbol());
        if (baseTypeId == null) {
            throw new SchemaProviderException("Base type for restriction not found, base type kind: " + restr.getBaseTypeKind());
        }
        AS0PointerObjectEditable pointer = objectsFactory.newPointerObject(p.naming.getNameId(MetabaseNaming.BASETYPE), baseTypeId);
        backingStore.addSubobject(p.transaction, restrId, pointer);

        if (restr instanceof StringRestrictionType) {
            saveStringRestrictionType(p, restrId, (StringRestrictionType) restr);
        } else if (restr instanceof DateRestrictionType) {
            saveDateRestrictionType(p, restrId, (DateRestrictionType) restr);
        } else if (restr instanceof DoubleRestrictionType) {
            saveDoubleRestrictionType(p, restrId, (DoubleRestrictionType) restr);
        } else if (restr instanceof LongRestrictionType) {
            saveIntegerRestrictionType(p, restrId, (LongRestrictionType) restr);
        }
    }

    private void saveStringRestrictionType(ParamsAgreagator p, AbstractOid parent, StringRestrictionType sr) throws StoreException {

        AtomicValue atomicVal = atomicValFacory.newAtomicValue(sr.getMinLength() == null ? -1 : sr.getMinLength().intValue());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MINLEN), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);

        atomicVal = atomicValFacory.newAtomicValue(sr.getMaxLength() == null ? -1 : sr.getMaxLength().intValue());
        atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MAXLEN), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);

        atomicVal = atomicValFacory.newAtomicValue(sr.getRegex());
        atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.REGEX), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);
    }

    private void saveDateRestrictionType(ParamsAgreagator p, AbstractOid parent, DateRestrictionType rr) throws StoreException {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue((Calendar) rr.getMinValue());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MINVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);

        atomicVal = atomicValFacory.newAtomicValue((Calendar) rr.getMaxValue());
        atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MAXVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);
    }

    private void saveDoubleRestrictionType(ParamsAgreagator p, AbstractOid parent, DoubleRestrictionType rr) throws StoreException {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue((Double) rr.getMinValue());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MINVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);

        atomicVal = atomicValFacory.newAtomicValue((Double) rr.getMaxValue());
        atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MAXVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);
    }

    private void saveIntegerRestrictionType(ParamsAgreagator p, AbstractOid parent, LongRestrictionType rr) throws StoreException {
        AtomicValue atomicVal = atomicValFacory.newAtomicValue((Long) rr.getMinValue());
        AS0AtomicObjectEditable atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MINVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);

        atomicVal = atomicValFacory.newAtomicValue((Long) rr.getMaxValue());
        atomic = objectsFactory.newAtomicObject(p.naming.getNameId(MetabaseNaming.MAXVAL), atomicVal);
        backingStore.addSubobject(p.transaction, parent, atomic);
    }

    private void savePointerType(ParamsAgreagator p, PointerType pointer) throws StoreException {
        TypeOid pointerId = p.types.get(pointer.getName());
        saveName(p.transaction, pointerId, pointer.getName(), p.naming);
        saveKind(p.transaction, pointerId, TypeEnum.Pointer, p.naming);

        // referenced type id
        TypeOid referencedTypeId = p.types.get(pointer.getReferencedObjectTypeName());
        if (referencedTypeId == null) {
            throw new SchemaDefinitionException("Type referenced by pointer not present, type name: " + pointer.getReferencedObjectTypeName());
        }

        if (pointer.getReferencedObjectName() == null) {
            throw new SchemaDefinitionException("Referenced field name not present for pointer, type name: " + pointer.getReferencedObjectTypeName());
        }
        saveReferencedFieldName(p.transaction, pointerId, pointer.getReferencedObjectName());

        AS0PointerObjectEditable pointerToRefType = objectsFactory.newPointerObject(p.naming.getNameId(MetabaseNaming.REFTYPE), referencedTypeId);
        backingStore.addSubobject(p.transaction, pointerId, pointerToRefType);
    }

    private void saveVariantType(ParamsAgreagator p, VariantType variant) throws StoreException {
        TypeOid variantID = p.types.get(variant.getName());
        saveName(p.transaction, variantID, variant.getName(), p.naming);
        saveKind(p.transaction, variantID, TypeEnum.Variant, p.naming);
        for (String n : variant.getPossibleTypesNames()) {
            AS0PointerObjectEditable pointer = objectsFactory.newPointerObject(p.naming.getNameId(MetabaseNaming.POSSIBLE_TYPE), p.types.get(n));
            backingStore.addSubobject(p.transaction, variantID, pointer);
        }
    }

    private AtomicValue literalToAtomicValue(Object val) {
        return atomicValFacory.newAtomicValue(val);
    }

    class ParamsAgreagator {

        Transaction transaction;

        Map<String, TypeOid> types;

        MetabaseNaming naming;
    }
}
