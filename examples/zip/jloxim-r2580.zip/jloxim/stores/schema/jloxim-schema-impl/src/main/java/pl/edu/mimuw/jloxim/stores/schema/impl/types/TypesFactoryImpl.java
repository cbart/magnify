/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import java.util.Calendar;
import java.util.List;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationConstant;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypesFactory;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.InvalidTypeException;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;

/**
 *
 * @author Paweł Mantur
 */
public class TypesFactoryImpl implements TypesFactory {

    public Cardinality newCardinality(Long minOccurences, Long maxOccurences) {
        return new CardinalityImpl(minOccurences, maxOccurences);
    }

    public ClassType newClassType(String className, List<StructMember> members, List<Method> methods, List<String> superclasses, ClassKindEnum kind, String roleOfClassName, Cardinality roleOfCardinality) {
        ClassTypeImpl c = new ClassTypeImpl(className);
        c.setAbstract(kind == ClassKindEnum.Abstract);
        if (methods != null) {
            for (Method m : methods) {
                c.addMethod(m);
            }
        }
        if (superclasses != null) {
            for (String parntClassName : superclasses) {
                c.addToExtendsList(parntClassName);
            }
        }
        c.setRoleOf(roleOfClassName);
        c.setRoleOfCardinality(roleOfCardinality);
        if (members != null) {
            for (StructMember m : members) {
                c.addMember(m);
            }
        }
        c.setSealed(kind == ClassKindEnum.Selaed);
        return c;
    }

    public DateRestrictionType newDateRestrictionType(String name, Calendar minValue, Calendar maxValue) {
        DateRestrictionTypeImpl drt = new DateRestrictionTypeImpl(name);
        drt.setMinValue(minValue);
        drt.setMaxValue(maxValue);
        return drt;
    }

    public DoubleRestrictionType newDoubleRestrictionType(String name, Double minValue, Double maxValue) {
        DoubleRestrictionTypeImpl drt = new DoubleRestrictionTypeImpl(name);
        drt.setMinValue(minValue);
        drt.setMaxValue(maxValue);
        return drt;
    }

    public EnumerationConstant newEnumerationConstant(String name) {
        EnumerationConstantImpl ec = new EnumerationConstantImpl();
        ec.setName(name);
        return ec;
    }

    public EnumerationType newEnumerationType(String name, List<EnumerationConstant> constants) {
        EnumerationTypeImpl et = new EnumerationTypeImpl(name);
        if (constants != null) {
            for (EnumerationConstant c : constants) {
                et.getAllowedValues().add(c);
            }
        }
        return et;
    }

    public LongRestrictionType newLongRestrictionType(String name, Long minValue, Long maxValue) {
        LongRestrictionTypeImpl ir = new LongRestrictionTypeImpl(name);
        ir.setMaxValue(maxValue);
        ir.setMinValue(minValue);
        return ir;
    }

    public Method newMethod(String name, List<StructMember> parematers, StructMember resultDecl, ScopeEnum scope) {
        MethodImpl m = new MethodImpl(name);
        if (parematers != null) {
            m.getParameters().addAll(parematers);
        }
        m.setScope(scope);
        m.setResultDeclaration(resultDecl);
        return m;
    }

    public PointerType newPointerType(String name, String referencedTypeName, String referencedFieldName) {
        PointerTypeImpl pt = new PointerTypeImpl(name);
        pt.setReferencedTypeName(referencedTypeName);
        pt.setReferencedFieldName(referencedFieldName);
        return pt;
    }

    public StringRestrictionType newStringRestrictionType(String name, Integer minLen, Integer maxLen, String regex) {
        StringRestrictionTypeImpl sr = new StringRestrictionTypeImpl(name);
        sr.setMaxLength(maxLen);
        sr.setMinLength(minLen);
        sr.setRegex(regex);
        return sr;
    }

    public StructMember newStructMember(String name, Cardinality cardinality, Object defaultValue, boolean isConstant, ScopeEnum scope, SchemaType type) {
        StructMemberImpl sm = new StructMemberImpl(name);
        sm.setCardinality(cardinality);
        sm.setDefaultValue(defaultValue);
        sm.setScope(scope);
        sm.setTypeKind(type.getTypeKind());
        sm.setTypeName(type.getName());
        sm.setTypeOid(type.getTypeOid());
        sm.setIsConstant(isConstant);
        return sm;
    }

    public StructType newStructType(String name, List<StructMember> members) {
        StructTypeImpl st = new StructTypeImpl(name);
        if (members != null) {
            for (StructMember m : members) {
                st.addMember(m);
            }
        }
        return st;
    }

    public SchemaType newSystemType(TypeEnum typeKind) {
        if (typeKind.isUesrDefined()) {
            throw new InvalidTypeException("System type was expected. Given type is " + typeKind.toString());
        }

        SchemaTypeImpl typeImpl = new SchemaTypeImpl(typeKind);
        return typeImpl;
    }

    public SchemaType newSchemaType(TypeEnum typeKind, String typeName) {
        if (!typeKind.isUesrDefined()) {
            if (typeKind.getSymbol().compareTo(typeName) != 0) {
                throw new JLoximException(String.format("Proper name for '%1$s' system type kind is '%2$s'", typeKind.toString(), typeKind.getSymbol()));
            }
        }

        SchemaTypeImpl typeImpl = new ClassTypeImpl(typeName);
        typeImpl.setTypeKind(typeKind);
        return typeImpl;
    }
}
