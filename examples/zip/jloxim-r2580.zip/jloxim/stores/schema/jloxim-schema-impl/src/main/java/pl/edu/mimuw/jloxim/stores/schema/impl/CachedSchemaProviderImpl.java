/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseRO;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructMemberImpl;

/**
 * Implementation of <code>SchemaProvider</code> which
 * exposes the content of metabase as cached schema model.
 *
 * @author Paweł Mantur
 */
public class CachedSchemaProviderImpl implements SchemaProvider {

    private MetabaseRO persistentSchema;

    private String schemaId;

    private TypeOid rootTypeId;

    private Map<String, SchemaType> typesByName;

    private Map<TypeOid, SchemaType> typesById;

    private TransactionManager transactionManager;

    private NamesTranslator namesTransalator;

    public CachedSchemaProviderImpl() {
    }

    public NamesTranslator getNamesTransalator() {
        return namesTransalator;
    }

    public void setNamesTransalator(NamesTranslator namesTransalator) {
        this.namesTransalator = namesTransalator;
    }

    public MetabaseRO getPersistentSchema() {
        return persistentSchema;
    }

    public void setPersistentSchema(MetabaseRO persistentSchema) {
        this.persistentSchema = persistentSchema;
    }

    public TransactionManager getTransactionManager() {
        return transactionManager;
    }

    public void setTransactionManager(TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    public void refresh() {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        this.typesByName = persistentSchema.getTypesByNameMap(t);
        this.typesById = persistentSchema.getTypesByOidMap(t);
        this.rootTypeId = persistentSchema.getRootTypeOid(t);
        this.schemaId = persistentSchema.getSchemaId(t);
        t.commit();
    }

    private TypeOid getTypeOidByPathNames(List<String> objectLocationPath, StructType parent, String path) {

        String name = objectLocationPath.get(0);
        if (path.length() > 1) {
            path += "." + name;
        } else {
            path += name;
        }
        StructMemberImpl cm = (StructMemberImpl) parent.getMemberByName(name, this, MembersSetType.OwnAndInherited, ScopeEnum.Private);
        if (cm == null) {
            throw new SchemaProviderException(String.format("Path %3$s is not allowed by schema. No member named '%1$s' in class '%2$s'", name, parent.getName(), path));
        }
        if (objectLocationPath.size() == 1) {
            return cm.getObjectTypeOid();
        }

        SchemaType type = getTypeByOid(cm.getObjectTypeOid());
        if (type.getTypeKind().isComplex()) {
            return getTypeOidByPathNames(objectLocationPath.subList(1, objectLocationPath.size()), (StructType) type, path);
        } else if (type.getTypeKind() == TypeEnum.AnyType){
            return getTypeByName(TypeEnum.AnyType.getSymbol()).getTypeOid();
        } else if (type.getTypeKind() == TypeEnum.Variant) {
            // TODO: till object doesn't know exact type, matched path can be ambigous
            VariantType vt = (VariantType) type;
            for (String vName : vt.getPossibleTypesNames()) {
                SchemaType st = getTypeByName(vName);
                if (st.getTypeKind().isComplex()) {
                    try {
                        return getTypeOidByPathNames(objectLocationPath.subList(1, objectLocationPath.size()), (StructType) st, path);
                    } catch (SchemaProviderException e) {
                        continue;
                    }
                }
            }
            throw new SchemaProviderException(String.format("Path %1$s is not allowed by schema", path));
        } else {
            throw new SchemaProviderException(String.format("Path %2$s is not allowed by schema. Object '%1$s' is not complex", cm.getObjectName(), path));
        }
    }

    public TypeOid getTypeOidByPath(List<Integer> objectLocationPath) {

        if (objectLocationPath == null || objectLocationPath.isEmpty()) {
            return this.getRootTypeOid();
        }

        TypeOid rootTypeOid = this.getRootTypeOid();
        SchemaType rootType = getTypeByOid(rootTypeOid);
        if (rootType.getTypeKind() == TypeEnum.AnyType) {
            return getTypeByName(TypeEnum.AnyType.getSymbol()).getTypeOid();
        }

        StructType classType = (StructType) rootType;

        List<String> getTypeOidByPathNames = new LinkedList<String>();
        for (Integer nameId : objectLocationPath) {
            String name = namesTransalator.getNameByNameId(nameId);
            getTypeOidByPathNames.add(name);
        }

        return getTypeOidByPathNames(getTypeOidByPathNames, classType, "/");
    }

    public SchemaType getTypeByName(String typeName) {
        return typesByName.get(typeName);
    }

    public Map<String, SchemaType> getTypesByNameMap() {
        return typesByName;
    }

    public SchemaType getTypeByOid(TypeOid id) throws SchemaProviderException {
        return typesById.get(id);
    }

    public Map<TypeOid, SchemaType> getTypesByOidMap() {
        return typesById;
    }

    public String getSchemaId() {
        return schemaId;
    }

    public TypeOid getRootTypeOid() {
        return rootTypeId;
    }

    public SchemaType getRootType() {
        return getTypeByOid(rootTypeId);
    }

    public Map<String, SchemaType> getTypesByTypeKindMap(TypeEnum typeKind) {
        Map<String, SchemaType> res = new HashMap<String, SchemaType>();
        for (SchemaType t : getTypesByOidMap().values()) {
            if (t.getTypeKind() == typeKind) {
                res.put(t.getName(), t);
            }
        }
        return res;
    }
}
