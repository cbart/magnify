/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.parser;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParseResult;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.impl.metabase.MetabaseNaming;

/**
 * This class agregates all types found in schema definition file
 *
 * @author Paweł Mantur
 */
public class SchemaParseResultImpl implements SchemaParseResult {

    private String schemaId;

    private SchemaType rootType;

    private int rootClassLineNumber;

    private List<String> referencedTypesNames;

    private List<String> imports;

    private Map<String, SchemaType> types;

    public Map<String, SchemaType> getTypes() {
        return types;
    }

    public SchemaParseResultImpl(String schemaId) {
        this.schemaId = schemaId;
        this.types = new HashMap<String, SchemaType>();
        this.referencedTypesNames = new LinkedList<String>();
        this.imports = new LinkedList<String>();
    }

    public void addType(SchemaType type) {
        if (types.containsKey(type.getName())) {
            throw new SchemaDefinitionException(String.format("Type '%1$s' is already defined", type.getName()));
        }
        types.put(type.getName(), type);
    }

    public void addReferencedTypeName(String typeName) {
        if (!referencedTypesNames.contains(typeName)) {
            referencedTypesNames.add(typeName);
        }
    }

    public List<String> getReferencedTypesNames() {
        return referencedTypesNames;
    }

    public SchemaType getType(String name) {
        return types.get(name);
    }

    public String getSchemaId() {
        return schemaId;
    }

    public int getRootClassLineNumber() {
        return rootClassLineNumber;
    }

    public void setRootClassLineNumber(int rootClassLineNumber) {
        this.rootClassLineNumber = rootClassLineNumber;
    }

    public List<String> getImports() {
        return imports;
    }

    private int anonymousStructCounter;

    public String getAnonymousStructName() {
        if (getSchemaId() == null) {
            throw new SchemaDefinitionException("Schema name not present while parsing anonympus type");
        }
        anonymousStructCounter++;
        return getSchemaId() + MetabaseNaming.ANONYMOUS_STRUCT_NAME_PREFIX + anonymousStructCounter;
    }

    private int anonymousVariantCounter;

    public String getAnonymousVariantName() {
        if (getSchemaId() == null) {
            throw new SchemaDefinitionException("Schema name not present while parsing anonympus type");
        }
        anonymousVariantCounter++;
        return getSchemaId() + MetabaseNaming.ANONYMOUS_VARIANT_NAME_PREFIX + anonymousVariantCounter;
    }

    public SchemaType getRootType() {
        return rootType;
    }

    public void setRootType(SchemaType rootClass) {
        this.rootType = rootClass;
    }

    public void addTypes(SchemaParseResult parseRes) {
        // add types
        for (SchemaType typeToAdd : parseRes.getTypes().values()) {
            if (this.types.containsKey(typeToAdd.getName())) {
                throw new SchemaDefinitionException(String.format("Type '%1$s' imported from schema '%2$s' is already defined in schema '%3$s'", typeToAdd.getName(), parseRes.getSchemaId(), this.getSchemaId()));
            }
            this.addType(typeToAdd);
        }

        // ad referenced types names (necessary for verification)
        for (String tname : parseRes.getReferencedTypesNames()) {
            this.addReferencedTypeName(tname);
        }
    }

    public void verify() throws SchemaDefinitionException {
        SchemaVerifier verifier = new SchemaVerifier();
        verifier.verifySchema(this);
    }
}
