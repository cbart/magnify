/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.signatures;

import pl.edu.mimuw.jloxim.stores.schema.api.signatures.AtomicValueSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.CollectionKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.Signature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.RestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 *
 * @author Paweł Mantur
 */
public class AtomicValueSignatureImpl extends SignatureImpl implements AtomicValueSignature {

    private Object value;

    private SchemaType type;

    public AtomicValueSignatureImpl(SignaturesEnum signatureKind) {
        checkSigKind(signatureKind);
    }

    public AtomicValueSignatureImpl(SchemaType type, Object value) {
        if (type.getTypeKind() == TypeEnum.Restriction) {
            this.signatureKind = this.typeKindToSignatureKind(((RestrictionType) type).getBaseTypeKind());
        } else {
            this.signatureKind = this.typeKindToSignatureKind(type.getTypeKind());
        }

        if (type.getTypeKind() == TypeEnum.Enum)
            this.typeName = type.getName();
        
        this.type = type;
        this.value = value;
    }

    private void checkSigKind(SignaturesEnum type) {
        switch (type) {
            case Binder:
            case Reference:
            case Struct:
            case Unknown:
            case Method:
            case Void:
            case Variant:
                throw new Error(String.format("Type %1$s cannot be converted to AtomicValueSignature"));
            default:
                this.signatureKind = type;
        }
    }

    public AtomicValueSignatureImpl(Object value, TypeEnum typeKind, String typeName, Cardinality cardinality, CollectionKindEnum collectionKind) {
        super(cardinality, collectionKind);
        this.value = value;
        this.signatureKind = typeKindToSignatureKind(typeKind);
        this.typeName = typeName;
    }

    public AtomicValueSignatureImpl(Object value, TypeEnum typeKind, Cardinality cardinality, CollectionKindEnum collectionKind, String typeName) {
        super(cardinality, collectionKind);
        this.value = value;
        this.signatureKind = typeKindToSignatureKind(typeKind);
        this.typeName = typeName;
    }

    public AtomicValueSignatureImpl(SignaturesEnum signatureKind, Cardinality cardinality, CollectionKindEnum collectionKind, Object value, String typeName) {
        super(cardinality, collectionKind);
        this.value = value;
        this.signatureKind = signatureKind;
        this.typeName = typeName;
    }

    private SignaturesEnum typeKindToSignatureKind(TypeEnum typeKind) {

        switch (typeKind) {
            case Binary:
                return SignaturesEnum.Binary;
            case Boolean:
                return SignaturesEnum.Boolean;
            case Byte:
                return SignaturesEnum.Byte;
            case DateTime:
                return SignaturesEnum.DateTime;
            case Double:
                return SignaturesEnum.Double;
            case Integer:
                return SignaturesEnum.Integer;
            case Long:
                return SignaturesEnum.Long;
            case Short:
                return SignaturesEnum.Short;
            case Enum:
            case String:
                return SignaturesEnum.String;
            case AnyAtomic:
                return SignaturesEnum.AnyAtomic;
            default:
                throw new Error(String.format("Type %s cannot be converted to AtomicValueSignature", typeKind.toString()));
        }
    }

    public Object getValue() {
        return value;
    }

    public Signature copy() {
        AtomicValueSignatureImpl res = new AtomicValueSignatureImpl(signatureKind, cardinality, collectionKind, value, typeName);
        res.setType(this.type);
        this.copyTo(res);
        return res;
    }

    @Override
    public String toString() {
        if (getTypeName() != null) {
            return getTypeName();
        }
        return this.getSignatureKind().toString();
    }

    public SchemaType getType() {
        return this.type;
    }

    public void setType(SchemaType t) {
        this.type = t;
    }
}
