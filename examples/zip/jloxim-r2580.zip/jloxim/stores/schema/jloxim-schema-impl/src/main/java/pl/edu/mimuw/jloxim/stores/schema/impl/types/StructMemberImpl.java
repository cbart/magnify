/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author Paweł Mantur
 */
public class StructMemberImpl implements StructMember {

    protected String name;

    protected TypeOid typeOid;

    protected Cardinality cardinality;

    protected TypeEnum typeKind;

    protected String typeName;

    private Object defaultValue;

    private boolean isConstant;

    private ScopeEnum scope;

    private AbstractOid staticId;

    public StructMemberImpl(String name) {
        this.cardinality = new CardinalityImpl(1L, 1L);
        this.name = name;
        this.scope = ScopeEnum.Public;
    }

    public Cardinality getCardinality() {
        return cardinality;
    }

    public void setCardinality(Cardinality cardinality) {
        this.cardinality = cardinality;
    }

    public String getObjectName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TypeOid getObjectTypeOid() {
        return typeOid;
    }

    public void setTypeOid(TypeOid typeOid) {
        this.typeOid = typeOid;
    }

    public TypeEnum getObjectTypeKind() {
        return typeKind;
    }

    public void setTypeKind(TypeEnum typeKind) {
        this.typeKind = typeKind;
    }

    public String getObjectTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public boolean isConstant() {
        return isConstant;
    }

    public void setIsConstant(boolean constant) {
        this.isConstant = constant;
    }

    public Object getDefaultValue() {
        return this.defaultValue;
    }

    public void setDefaultValue(Object defaultValue) {
        this.defaultValue = defaultValue;
    }

    private int line;

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public void setScope(ScopeEnum scope) {
        this.scope = scope;
    }

    public ScopeEnum getScope() {
        return this.scope;
    }

    public AbstractOid getStaticId() {
        return staticId;
    }

    public void setStaticId(AbstractOid staticId) {
        this.staticId = staticId;
    }

    private String referencedTypeName;

    public String getReferencedTypeName() {
        return referencedTypeName;
    }

    public void setReferencedTypeName(String referencedTypeName) {
        this.referencedTypeName = referencedTypeName;
    }
}
