/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import java.util.LinkedList;
import java.util.List;

import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 *
 * @author Paweł Mantur
 */
public class MethodImpl extends SchemaTypeImpl implements Method {

    private ScopeEnum scope;

    private StructMember resultDeclaration;

    private List<StructMember> parameters;

    private String className;

    public MethodImpl(String name) {
        super(name, TypeEnum.Method);
        this.parameters = new LinkedList();
        this.scope = ScopeEnum.Public;
    }

    public void setScope(ScopeEnum scope) {
        this.scope = scope;
    }

    public ScopeEnum getScope() {
        return this.scope;
    }

    public StructMember getParameterByName(String paramName) {
        for (StructMember param : parameters) {
            if (param.getObjectName().compareTo(paramName) == 0) {
                return param;
            }
        }
        return null;
    }

    public void addParameter(StructMember param) {
        parameters.add(param);
    }

    public List<StructMember> getParameters() {
        return parameters;
    }

    public StructMember getResultDeclaration() {
        return resultDeclaration;
    }

    public void setResultDeclaration(StructMember resultDecl) {
        resultDeclaration = resultDecl;
    }

    public String getSignature() {
        String res = this.getName() + "(";
        int paramsCnt = this.getParameters().size();
        StructMemberImpl param;

        for (int i = 0; i < paramsCnt; i++) {

            if (i > 0) {
                res += ", ";
            }

            param = (StructMemberImpl) this.getParameters().get(i);
            if (param.getObjectTypeKind() == TypeEnum.Pointer) {
                res += "&" + param.getReferencedTypeName();
            } else {
                res += param.getObjectTypeName();
            }
        }

        return res + ")";
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}
