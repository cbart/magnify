/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.signatures;

import java.util.LinkedList;
import java.util.List;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.CollectionKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.Signature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.StructureSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;

/**
 *
 * @author Paweł Mantur
 */
public class StructureSignatureImpl extends SignatureImpl implements StructureSignature {

    private List<Signature> membersSignatures;

    public StructureSignatureImpl() {
        this.membersSignatures = new LinkedList<Signature>();
        this.signatureKind = SignaturesEnum.Struct;
    }

    public StructureSignatureImpl(Cardinality cardinality, CollectionKindEnum collectionKind) {
        super(cardinality, collectionKind);
        this.membersSignatures = new LinkedList<Signature>();
        this.signatureKind = SignaturesEnum.Struct;
    }

    public List<Signature> getMembersSignatures() {
        return membersSignatures;
    }

    public Signature copy() {
        StructureSignatureImpl res = new StructureSignatureImpl(cardinality, collectionKind);
        for (Signature s : membersSignatures) {
            res.membersSignatures.add(s.copy());
        }

        return res;
    }

    @Override
    public String toString() {
        String res = "struct(";
        int i = 0;
        for (Signature s : getMembersSignatures()) {
            res += s.toString();
            if (i++ < getMembersSignatures().size() - 1) {
                res += ",";
            }
        }
        return res + ")";
    }
}
