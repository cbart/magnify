/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;

/**
 *
 * @author Paweł Mantur
 */
public class PointerTypeImpl extends SchemaTypeImpl implements PointerType {

    private TypeOid referencedTypeOid;

    private String referencedTypeName;

    private String referencedFieldName;

    public PointerTypeImpl(String name) {
        super(name, TypeEnum.Pointer);
    }

    public TypeOid getReferencedObjectTypeOid() {
        return this.referencedTypeOid;
    }

    public String getReferencedObjectTypeName() {
        return this.referencedTypeName;
    }

    public void setReferencedTypeName(String refeencedTypeName) {
        this.referencedTypeName = refeencedTypeName;
    }

    public void setReferencedTypeOid(TypeOid referencedTypeOid) {
        this.referencedTypeOid = referencedTypeOid;
    }

    public String getReferencedObjectName() {
        return referencedFieldName;
    }

    public void setReferencedFieldName(String referencedFieldName) {
        this.referencedFieldName = referencedFieldName;
    }
}
