/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.metabase;

import java.util.LinkedList;
import java.util.List;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;

/**
 * Provides names for metabase objects;
 *
 * @author Paweł Mantur
 */
public class MetabaseNaming {

    public static final String METABASE_ROOT = "sys";

    public static final String ENUMS = "enumerations";

    public static final String CLASSES = "classes";

    public static final String STRUTCS = "structs";

    public static final String RESTRICTIONS_STRING = "stringRestrictions";

    public static final String RESTRICTIONS_INT = "integerRestrictions";

    public static final String RESTRICTIONS_DATE = "dateRestrictions";

    public static final String RESTRICTIONS_DOUBLE = "doubleRestrictions";

    public static final String POINTERS = "pointerTypes";

    public static final String VARIANTS = "variantTypes";

    public static final String SYSTEM_TYPES = "systemTypes";

    public static final String EXTENDS = "extends";

    public static final String ROLEOF = "roleOf";

    public static final String FIELD = "field";

    public static final String METHOD = "method";

    public static final String NAME = "name";

    public static final String KIND = "kind";

    public static final String POSSIBLE_TYPE = "possibleType";

    public static final String SCHEMA_ID = "schemaId";

    public static final String TYPE = "type";

    public static final String ROOT_POINTER = "rootType";

    public static final String SCOPE = "scope";

    public static final String DEFAULT = "defaultValue";

    public static final String CARD = "cardinality";

    public static final String MIN = "min";

    public static final String MAX = "max";

    public static final String MINVAL = "minValue";

    public static final String MAXVAL = "maxValue";

    public static final String REGEX = "regex";

    public static final String MINLEN = "minLength";

    public static final String MAXLEN = "maxLength";

    public static final String PARAM = "parameters";

    public static final String RESULT = "result";

    public static final String IS_CONSTANT = "isConstant";

    public static final String VALUE = "value";

    public static final String ENUM_CONST = "enumConstant";

    public static final String BASETYPE = "baseType";

    public static final String REFTYPE = "referencedType";

    public static final String ROOT_CLASS_NAME = "Root";

    public static final String REFERENCED_FIELD_NAME = "referencedFieldName";

    public static final String ANONYMOUS_STRUCT_NAME_PREFIX = "AnonymousStruct#";

    public static final String ANONYMOUS_VARIANT_NAME_PREFIX = "AnonymousVariant#";

    public static final String CLASS_NAME = "className";

    private NamesTranslator namesTransaltor;

    public MetabaseNaming(NamesTranslator namesTransaltor) {
        this.namesTransaltor = namesTransaltor;
    }

    public Integer getNameId(String name) {
        return namesTransaltor.getOrRegisterName(name);
    }

    public Integer getCollectionNameIdForType(SchemaType type) {
        if (type instanceof ClassType) {
            return getNameId(CLASSES);
        } else if (type instanceof StructType) {
            return getNameId(STRUTCS);
        } else if (type instanceof EnumerationType) {
            return getNameId(ENUMS);
        } else if (type instanceof StringRestrictionType) {
            return getNameId(RESTRICTIONS_STRING);
        } else if (type instanceof LongRestrictionType) {
            return getNameId(RESTRICTIONS_INT);
        } else if (type instanceof DateRestrictionType) {
            return getNameId(RESTRICTIONS_DATE);
        } else if (type instanceof DoubleRestrictionType) {
            return getNameId(RESTRICTIONS_DOUBLE);
        } else if (type instanceof PointerType) {
            return getNameId(POINTERS);
        } else if (type instanceof VariantType) {
            return getNameId(VARIANTS);
        } else if (type instanceof SchemaType) {
            return getNameId(SYSTEM_TYPES);
        } else {
            throw new Error("Unknown type of class " + type.getClass().getName());
        }
    }

    private List<Integer> typeNameIds = null;

    public List<Integer> getTypeNameIds() {
        if (typeNameIds == null) {
            typeNameIds = new LinkedList<Integer>();
            typeNameIds.add(getNameId(CLASSES));
            typeNameIds.add(getNameId(STRUTCS));
            typeNameIds.add(getNameId(ENUMS));
            typeNameIds.add(getNameId(RESTRICTIONS_DATE));
            typeNameIds.add(getNameId(RESTRICTIONS_DOUBLE));
            typeNameIds.add(getNameId(RESTRICTIONS_INT));
            typeNameIds.add(getNameId(RESTRICTIONS_STRING));
            typeNameIds.add(getNameId(POINTERS));
            typeNameIds.add(getNameId(VARIANTS));
            typeNameIds.add(getNameId(SYSTEM_TYPES));
        }
        return typeNameIds;
    }
}
