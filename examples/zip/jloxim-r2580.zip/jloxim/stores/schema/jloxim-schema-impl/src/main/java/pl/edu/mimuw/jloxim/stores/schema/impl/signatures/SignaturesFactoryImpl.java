/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.signatures;

import pl.edu.mimuw.jloxim.stores.schema.api.signatures.AtomicValueSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.BinderSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.CollectionKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.MethodSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.ReferenceSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.Signature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesFactory;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.StructureSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.UnknownSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.VariantSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.VoidSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 *
 * @author Paweł Mantur
 */
public class SignaturesFactoryImpl implements SignaturesFactory {

    public AtomicValueSignature newAtomicValueSignature(SignaturesEnum sigKind) {
        return new AtomicValueSignatureImpl(sigKind);
    }

    public AtomicValueSignature newAtomicValueSignature(SchemaType type, Object value) {
        return new AtomicValueSignatureImpl(type, value);
    }

    public AtomicValueSignature newAtomicValueSignature(Object value, TypeEnum typeKind, String typeName, Cardinality cardinality, CollectionKindEnum collectionKind) {
        return new AtomicValueSignatureImpl(value, typeKind, typeName, cardinality, collectionKind);
    }

    public BinderSignature newBinderSignature(String name, Signature signature) {
        return new BinderSignatureImpl(name, signature);
    }

    public ReferenceSignature newReferenceSignature(String destinationFieldName, SchemaType destinationType) {
        return new ReferenceSignatureImpl(destinationFieldName, destinationType);
    }

    public ReferenceSignature newReferenceSignature(String destinationFieldName, SchemaType destinationType, Cardinality cardinality, CollectionKindEnum collectionKind) {
        return new ReferenceSignatureImpl(destinationFieldName, destinationType, cardinality, collectionKind);
    }

    public ReferenceSignature newReferenceSignature(String destinationFieldName, SchemaType destinationType, Cardinality cardinality, CollectionKindEnum collectionKind, boolean isConstant) {
        return new ReferenceSignatureImpl(destinationFieldName, destinationType, cardinality, collectionKind, isConstant);
    }

    public StructureSignature newStructureSignature() {
        return new StructureSignatureImpl();
    }

    public StructureSignature newStructureSignature(Cardinality cardinality, CollectionKindEnum collectionKind) {
        return new StructureSignatureImpl(cardinality, collectionKind);
    }

    public VariantSignature newVariantSignature() {
        return new VariantSignatureImpl();
    }

    public VariantSignature newVariantSignature(Cardinality cardinality, CollectionKindEnum collectionKind) {
        return new VariantSignatureImpl(cardinality, collectionKind);
    }

    public UnknownSignature newUnknownSignature() {
        return new UnknownSignatureImpl();
    }

    public MethodSignature newMethodSignature(Method m) {
        return new MethodSignatureImpl(m);
    }

    public VoidSignature newVoidSignaure(String methodName) {
        return new VoidSignatureImpl(methodName);
    }
}
