/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Calendar;
import java.util.regex.Pattern;

import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.RestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.RangeRestriction;

/**
 *
 * @author Paweł Mantur
 */
public class ValuesAgainstTypesChecker {

    public void checkRestriction(RestrictionType restriction, Object value, String storeID) {

        if (value instanceof Calendar) {
            if (restriction instanceof DateRestrictionType) {
                checkRangeRestriction((RangeRestriction) restriction, value, storeID);
                return;
            }
        } else if (value instanceof Double) {
            if (restriction instanceof DoubleRestrictionType) {
                checkRangeRestriction((RangeRestriction) restriction, value, storeID);
                return;
            }
        } else if ((value instanceof Integer || value instanceof Long)) {
            if (restriction instanceof LongRestrictionType) {
                checkRangeRestriction((RangeRestriction) restriction, value, storeID);
                return;
            }
        } else if (value instanceof String) {
            if (restriction instanceof StringRestrictionType) {
                checkStringRestriction((StringRestrictionType) restriction, (String) value, storeID);
                return;
            }
        } else {
            throw new SchemaViolationStoreException("Unknwown class of atomic value: " + value.getClass());
        }

        throw new SchemaViolationStoreException(String.format("Restriction of kind '%1$s' is not compatible with value '%3$s' of type '%2$s'", restriction.getBaseTypeKind(), value.getClass(), value.toString()));
    }

    public void checkRangeRestriction(RangeRestriction restriction, Object value, String storeID) {
        if (restriction.getMinValue() != null && restriction.getMinValue().compareTo(value) > 0) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Value is less than allowed by restriction '%1$s'", restriction.getName()), SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MINVAL);
        }
        if (restriction.getMaxValue() != null && restriction.getMaxValue().compareTo(value) < 0) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Value is greater than allowed by restriction '%1$s'", restriction.getName()), SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MAXVAL);
        }
    }

    public void checkStringRestriction(StringRestrictionType stringRestr, String val, String storeID) {
        if (stringRestr.getRegex() != null && !Pattern.matches(stringRestr.getRegex(), val)) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Given value doesn't match pattern '%2$s' defined in restriction '%1$s'", stringRestr.getName(), stringRestr.getRegex()), SchemaViolationStoreException.ERR_STRING_RESTRICTION_REGEX);
        }

        if (stringRestr.getMinLength() != null && stringRestr.getMinLength() > val.length()) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Minimum string length required by restriction '%1$s' is %2$d", stringRestr.getName(), stringRestr.getMinLength()), SchemaViolationStoreException.ERR_STRING_RESTRICTION_MINLEN);
        }

        if (stringRestr.getMaxLength() != null && stringRestr.getMaxLength() < val.length()) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Maximum string length allowed by restriction '%1$s' is %2$d", stringRestr.getName(), stringRestr.getMaxLength()), SchemaViolationStoreException.ERR_STRING_RESTRICTION_MAXLEN);
        }
    }

    public void checkNumericValue(Number val, TypeEnum te, String storeID) {

        if (!(val instanceof Long) && !(val instanceof Integer)) {
            throw new Error("Expected instance of Long or Integer as atomic value");
        }

        long min, max;

        switch (te) {
            case Long:
                min = Long.MIN_VALUE;
                max = Long.MAX_VALUE;
                break;

            case Integer:
                min = (long) Integer.MIN_VALUE;
                max = (long) Integer.MAX_VALUE;
                break;

            case Short:
                min = (long) Short.MIN_VALUE;
                max = (long) Short.MAX_VALUE;
                break;

            case Byte:
                min = (long) Byte.MIN_VALUE;
                max = (long) Byte.MAX_VALUE;
                break;

            default:
                throw new Error("Expected numeric TypeKind");
        }

        long nuumber = val.longValue();
        if (nuumber < min) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Atomic value exceedes allowed range of %1$s type (value %2$d is too small)", te.toString(), nuumber));
        }

        if (nuumber > max) {
            throw new SchemaViolationStoreException(storeID, 
                    String.format("Atomic value exceedes allowed range of %1$s type (value %2$d is too large)", te.toString(), nuumber));
        }
    }
}
