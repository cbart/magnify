/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.SchemaTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.TypeOidImpl;

import com.google.common.collect.ImmutableMap;

/**
 * Implementation of <code>SchemaProvider</code> which
 * types everything as Any. Used in semistructural mode.
 *
 * @author Piotr Tabor
 */
public class AnySchemaProvider implements SchemaProvider {
    private static TypeOid ROOT_OID = new TypeOidImpl(1);
    private static SchemaType ANY_TYPE = new SchemaTypeImpl(TypeEnum.AnyType);

    public AnySchemaProvider() {
    }

    public void refresh() {}

    public TypeOid getTypeOidByPath(List<Integer> objectLocationPath) {
        return getRootTypeOid();
    }

    //TODO(ptab): NoSuchTypeException ?
    public SchemaType getTypeByName(String typeName) {
      return getTypesByNameMap().get(typeName);
    }

    public Map<String, SchemaType> getTypesByNameMap() {
        return ImmutableMap.of(ANY_TYPE.getName(), ANY_TYPE);
    }

    public SchemaType getTypeByOid(TypeOid id) throws SchemaProviderException {
        return id == getRootTypeOid() ?
            new SchemaTypeImpl(TypeEnum.AnyType)
        :   null;
    }

    public Map<TypeOid, SchemaType> getTypesByOidMap() {
      return ImmutableMap.of(ROOT_OID, ANY_TYPE);
    }

    public String getSchemaId() {
        return "any";
    }

    public TypeOid getRootTypeOid() {
        return ROOT_OID;
    }

    public SchemaType getRootType() {
        return ANY_TYPE;
    }

    public Map<String, SchemaType> getTypesByTypeKindMap(TypeEnum typeKind) {
        Map<String, SchemaType> res = new HashMap<String, SchemaType>();
        for (SchemaType t : getTypesByOidMap().values()) {
            if (t.getTypeKind() == typeKind) {
                res.put(t.getName(), t);
            }
        }
        return res;
    }
}