/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *ROOT_CLASS_NAME
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.parser.antlr;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.Tree;

import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypesFactory;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.impl.metabase.MetabaseNaming;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.SchemaParseResultImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.CardinalityImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.ClassTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.DateRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.DoubleRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumReference;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationConstantImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.LongRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.MethodImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.PointerTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.RestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.SchemaTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StringRestrictionTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructMemberImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructTypeImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.TypesFactoryImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.VariantTypeImpl;

/**
 * This class builds schema definition AST from tree returned by parser.
 *
 * @author Paweł Mantur
 */
public class AntlrTreeTranslator {

    //private final static Logger logger = Logger.getLogger(CustomJLoximSchemaParser.class);
    private final static String duplicateMemberMsgFmt = "Wrong schema syntax (line %1$d): class %2$s already defines '%3$s' member";

    private final static String duplicateMemberMethodMsgFmt = "Wrong schema syntax (line %1$d): cannot add member '%3$s' to class %2$s because its name is in conflict with method '%4$s' signature";

    private final static String duplicateMemberInAnonymousTypeMsgFmt = "Wrong schema syntax (line %1$d): anonymous type already defines '%2$s' member";

    private final static String duplicateEnumMsgFmt = "Wrong schema syntax (line %1$d): enum %2$s already defines '%3$s' value";

    private final static String generalMsgFmt = "Wrong schema syntax (line %1$d)";

    private final static String duplicateParamMsgFmt = "Wrong schema syntax (line %1$d): method %2$s already contains parametr named '%3$s'";

    private final static String duplicateMethodMsgFmt = "Wrong schema syntax (line %1$d): class %2$s already contains method with signature '%3$s'";

    private TypesFactory typesFactory;

    public AntlrTreeTranslator() {
        this.typesFactory = new TypesFactoryImpl();
    }

    public SchemaParseResultImpl translateTree(CommonTree treeNode, boolean isImported, boolean isAlreadyImorted) throws SchemaDefinitionException {

        validateNodeType(treeNode, JLoximSchemaLexer.SCHEMA);

        SchemaParseResultImpl parseRes = new SchemaParseResultImpl(stripQuotes(treeNode.getText()));

        int childrenCnt = treeNode.getChildCount();

        for (int i = 0; i < childrenCnt; i++) {

            Tree schemaChild = treeNode.getChild(i);

            switch (schemaChild.getType()) {

                case JLoximSchemaLexer.CLASS:
                    if (!isAlreadyImorted) {
                        parseRes.addType(translateClass(schemaChild, parseRes));
                    }
                    break;

                case JLoximSchemaLexer.RESTRICTION:
                    if (!isAlreadyImorted) {
                        parseRes.addType(translateRestriction(schemaChild, parseRes));
                    }
                    break;

                case JLoximSchemaLexer.ENUM:
                    if (!isAlreadyImorted) {
                        parseRes.addType(translateEnum(schemaChild));
                    }
                    break;

                case JLoximSchemaLexer.POINTER:
                    if (!isAlreadyImorted) {
                        parseRes.addType(translatePointerType(schemaChild, parseRes));
                    }
                    break;

                case JLoximSchemaLexer.IMPORT:
                    parseRes.getImports().add(schemaChild.getText());
                    break;

                case JLoximSchemaLexer.VARIANT:
                    if (!isAlreadyImorted) {
                        parseRes.addType(translateVariantType(schemaChild, parseRes, false));
                    }
                    break;

                case JLoximSchemaLexer.ROOT:
                    if (isImported) {
                        continue;
                    }
                    translateRoot(schemaChild, parseRes);
                    break;

                default:
                    throw new RuntimeException("Invalid node type '" + treeNode.getType() + "'!");
            }
        }

        return parseRes;
    }

    private void translateRoot(Tree classNode, SchemaParseResultImpl parseRes) throws SchemaDefinitionException {
        validateNodeType(classNode, JLoximSchemaLexer.ROOT);
        SchemaType root = null;
        if (classNode.getChildCount() == 1 && classNode.getChild(0).getType() != JLoximSchemaLexer.CLASS_MEMBER) {
            TypeInfo ti = translateType(classNode.getChild(0), parseRes);
            root =  new SchemaTypeImpl(ti.getTypeName(), ti.getTypeKind());
        } else {
            root = new ClassTypeImpl(parseRes.getSchemaId() + "#" + MetabaseNaming.ROOT_CLASS_NAME);
            if (parseRes.getRootType() != null) {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): root type is already defined. First definiton was in line %2$d", classNode.getLine(), parseRes.getRootClassLineNumber()));
            }
            translateMembers((ClassTypeImpl) root, classNode, parseRes, true);
            parseRes.addType(root);
        }
        
        parseRes.setRootClassLineNumber(classNode.getLine());
        parseRes.setRootType(root);
    }

    private void translateMembers(ClassTypeImpl clazz, Tree classNode, SchemaParseResultImpl parseRes, boolean isRoot) throws SchemaDefinitionException {

        StructMember tmpMember;
        for (int i = 0; i < classNode.getChildCount(); i++) {

            Tree classNodeChild = classNode.getChild(i);

            switch (classNodeChild.getType()) {

                case JLoximSchemaLexer.CLASS_MEMBER:
                    StructMemberImpl member = translateClassMember(classNodeChild, parseRes);
                    tmpMember = clazz.getOwnMemberByName(member.getObjectName());
                    if (tmpMember != null) {
                        throw new SchemaDefinitionException(String.format(duplicateMemberMsgFmt, classNodeChild.getLine(), stripQuotes(classNode.getText()), member.getObjectName()));
                    }
                    Method met = clazz.getOwnMethodBySignature(member.getObjectName());
                    if (met != null) {
                        throw new SchemaDefinitionException(String.format(duplicateMemberMethodMsgFmt, classNodeChild.getLine(), stripQuotes(classNode.getText()), member.getObjectName(), met.getName()));
                    }
                    clazz.addMember(member);
                    break;

                case JLoximSchemaLexer.METHOD:
                    MethodImpl m = translateMethod(classNodeChild, parseRes);
                    if (!clazz.addMethod(m)) {
                        throw new SchemaDefinitionException(String.format(duplicateMethodMsgFmt, classNodeChild.getLine(), stripQuotes(classNode.getText()), m.getName()));
                    }
                    tmpMember = clazz.getOwnMemberByName(m.getSignature());
                    if (tmpMember != null) {
                        throw new SchemaDefinitionException(String.format(duplicateMemberMethodMsgFmt, classNodeChild.getLine(), stripQuotes(classNode.getText()), tmpMember.getObjectName(), m.getName()));
                    }
                    m.setClassName(clazz.getName());

                    break;

                default:
                    if (isRoot) {
                        throw new RuntimeException("Invalid node type '" + classNodeChild.getType() + "'!");
                    } else {
                        continue;
                    }
            }
        }
    }

    private void validateTypeName(String name, int line) {
        if (name == null) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Type name cannot be null", line));
        }
        if (name.trim().length() == 0) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Type name cannot be empty", line));
        }
        if (name.startsWith("PoinerTo")) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Type name cannot begin with prefix 'PointerTo...'", line));
        }
        if (name.equals("#any#")){
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Type name '#any#' is forbiden (this name is reserved for system purposes)", line));
        }
    }

    private ClassType translateClass(Tree classNode, SchemaParseResultImpl parseRes) throws SchemaDefinitionException {

        validateNodeType(classNode, JLoximSchemaLexer.CLASS);
        ClassTypeImpl resultClass = new ClassTypeImpl(stripQuotes(classNode.getText()));
        validateTypeName(resultClass.getName(), classNode.getLine());

        translateMembers(resultClass, classNode, parseRes, false);

        for (int i = 0; i < classNode.getChildCount(); i++) {

            Tree classNodeChild = classNode.getChild(i);

            switch (classNodeChild.getType()) {

                case JLoximSchemaLexer.EXTENDS:
                    for (int j = 0; j < classNodeChild.getChildCount(); j++) {
                        Tree superclassNameNode = classNodeChild.getChild(j);
                        resultClass.addToExtendsList(stripQuotes(superclassNameNode.getText()));
                        parseRes.addReferencedTypeName(stripQuotes(superclassNameNode.getText()));
                    }
                    break;

                case JLoximSchemaLexer.ROLEOF:
                    resultClass.setRoleOf(stripQuotes(classNodeChild.getText()));
                    resultClass.setRoleOfCardinality(translateRoleOfCardinality(classNodeChild));
                    parseRes.addReferencedTypeName(stripQuotes(classNodeChild.getText()));
                    break;

                case JLoximSchemaLexer.CLASS_KIND:
                    resultClass.setClassKind(translateClassKindEnum(classNodeChild));
                    break;

                case JLoximSchemaLexer.METHOD:
                case JLoximSchemaLexer.CLASS_MEMBER:
                    // it was translated by 'translateMembers' method
                    continue;

                default:
                    throw new RuntimeException("Invalid node type '" + classNodeChild.getType() + "'!");
            }
        }

        return resultClass;
    }

    private StructMemberImpl translateClassMember(Tree classMemberNode, SchemaParseResultImpl parseRes) {
        validateNodeType(classMemberNode, JLoximSchemaLexer.CLASS_MEMBER);
        StructMemberImpl member = null;
        ScopeEnum scope = ScopeEnum.Public;

        for (int i = 0; i < classMemberNode.getChildCount(); i++) {
            Tree classNodeChild = classMemberNode.getChild(i);

            switch (classNodeChild.getType()) {

                case JLoximSchemaLexer.SCOPE:
                    scope = translateScope(classNodeChild);
                    break;
                case JLoximSchemaLexer.STRUCT_MEMBER:
                    member = translateStructMember(classNodeChild, parseRes, false);
                    break;
                default:
                    throw new Error("Unexpected node type : " + classNodeChild.getType());
            }
        }

        member.setScope(scope);
        member.setLine(classMemberNode.getLine());
        return member;
    }

    private Object parseDefaultOrConst(Tree defaultOrConstNode) {

        if (defaultOrConstNode.getType() != JLoximSchemaLexer.DEFAULT && defaultOrConstNode.getType() != JLoximSchemaLexer.CONST) {
            throw new RuntimeException("wrong node type: expected DEFAULT or CONST, was " + defaultOrConstNode.getType());
        }

        if (defaultOrConstNode.getChildCount() != 1) {
            throw new RuntimeException("Default value or constant node is expectd to have one child");
        }

        Tree valueNode = defaultOrConstNode.getChild(0);

        if (valueNode.getType() == JLoximSchemaLexer.LITERAL) {
            return parseLiteral(valueNode);
        } else if (valueNode.getType() == JLoximSchemaLexer.ENUM_REF) {
            return parseEnumeReference(valueNode);
        } else {
            throw new RuntimeException("wrong node type: expected LITERAL or ENUM_REF, was " + valueNode.getType());
        }
    }

    private EnumReference parseEnumeReference(Tree enumRefNode) {
        validateNodeType(enumRefNode, JLoximSchemaLexer.ENUM_REF);
        EnumReference ref = new EnumReference();
        ref.setEnumName(stripQuotes(enumRefNode.getText()));
        ref.setEnumConstName(stripQuotes(enumRefNode.getChild(0).getText()));
        return ref;
    }

    private DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    private Object parseLiteral(Tree literalNode) {

        validateNodeType(literalNode, JLoximSchemaLexer.LITERAL);
        validateChildrenCount(literalNode, 1);

        Tree litValue = literalNode.getChild(0);
        String literal = litValue.getText();

        try {
            switch (litValue.getType()) {
                case JLoximSchemaLexer.STRING:
                    return literal.substring(1, literal.length() - 1);
                case JLoximSchemaLexer.INT:
                    return Long.valueOf(literal);
                case JLoximSchemaLexer.FLOAT:
                    return Double.valueOf(literal);
                case JLoximSchemaLexer.DATETIME_CONST:
                    Date d = formatter.parse(literal);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(d);
                    return cal;
                case JLoximSchemaLexer.TRUE:
                case JLoximSchemaLexer.FALSE:
                    return Boolean.valueOf(literal);
                default:
                    throw new RuntimeException("wrong node type: " + litValue.getType());
            }
        } catch (ParseException e) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): failed to parse literal of type %2$s", litValue.getLine(), litValue.getType()), e);
        }
    }

    private StructMemberImpl translateStructMember(Tree structMemberNode, SchemaParseResultImpl parseRes, boolean isParameter) {
        if (isParameter) {
            validateNodeType(structMemberNode, JLoximSchemaLexer.PARAMETER);
        } else {
            validateNodeType(structMemberNode, JLoximSchemaLexer.STRUCT_MEMBER);
        }
        StructMemberImpl member = new StructMemberImpl(stripQuotes(structMemberNode.getText()));
        int cnt = structMemberNode.getChildCount();
        StructTypeImpl anonymousType = null;
        TypeInfo ti = null;
        VariantType anonymousVariant = null;
        Tree defaultNode = null;
        boolean isReference = false;
        String referencedFieldName = null;

        for (int i = 0; i < cnt; i++) {
            Tree child = structMemberNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.ANONYMOUS_TYPE:
                    anonymousType = transalteAnonymousType(child, parseRes);
                    break;
                case JLoximSchemaLexer.VARIANT:
                    anonymousVariant = translateVariantType(child, parseRes, true);
                    member.setTypeName(anonymousVariant.getName());
                    member.setTypeKind(TypeEnum.Variant);
                    parseRes.addType(anonymousVariant);
                    break;
                case JLoximSchemaLexer.TYPE:
                    ti = translateType(child, parseRes);
                    member.setTypeName(ti.typeName);
                    member.setTypeKind(ti.typeKind);
                    break;
                case JLoximSchemaLexer.REF:
                    isReference = true;
                    break;
                case JLoximSchemaLexer.CARD:
                    member.setCardinality(translateCardinality(child));
                    break;

                case JLoximSchemaLexer.DEFAULT:
                    if (isParameter) {
                        throw new Error("Parameters cannot have default values");
                    }
                    defaultNode = child;
                    break;

                case JLoximSchemaLexer.CONST:
                    if (isParameter) {
                        throw new Error("Parameters cannot have const values");
                    }
                    member.setIsConstant(true);
                    defaultNode = child;
                    break;

                case JLoximSchemaLexer.POINTER_DEST:
                    referencedFieldName = stripQuotes(child.getText());
                    break;

                default:
                    throw new Error("wrong node type: " + child.getType());
            }
        }

        validatePointer(isReference, referencedFieldName, structMemberNode.getLine());

        if (anonymousType != null) {
            if (ti != null || isReference || defaultNode != null) {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Both anonymous type and normal type or reference flag or default/constant is present!", structMemberNode.getLine()));
            }
            member.setTypeName(anonymousType.getName());
            member.setTypeKind(TypeEnum.Class);
        }

        if (defaultNode != null) {

            if (isReference) {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): reference type cannot have default value", defaultNode.getLine()));
            }

            Object dv = parseDefaultOrConst(defaultNode);
            member.setDefaultValue(dv);
        }

        if (isReference) {
            PointerType pt = getPredefinedPointer(ti.typeName, referencedFieldName, parseRes);
            member.setTypeName(pt.getName());
            member.setTypeKind(TypeEnum.Pointer);
            member.setReferencedTypeName(ti.typeName);
        }

        return member;
    }

    private PointerType getPredefinedPointer(String typeName, String referencedFieldName, SchemaParseResultImpl parseRes) {

        String name = "PointerTo";
        name += typeName.substring(0, 1).toUpperCase() + typeName.substring(1);
        name += "As";
        name += referencedFieldName.substring(0, 1).toUpperCase() + referencedFieldName.substring(1);

        PointerType pt = null;
        if (!parseRes.getTypes().containsKey(name)) {
            pt = typesFactory.newPointerType(name, typeName, referencedFieldName);
            parseRes.addType(pt);
        } else {
            pt = (PointerType) parseRes.getType(name);
        }

        return pt;
    }

    private StructTypeImpl transalteAnonymousType(Tree anonymousTypeNode, SchemaParseResultImpl parseRes) {
        validateNodeType(anonymousTypeNode, JLoximSchemaLexer.ANONYMOUS_TYPE);
        StructTypeImpl struct = new StructTypeImpl(parseRes.getAnonymousStructName());
        for (int i = 0; i < anonymousTypeNode.getChildCount(); i++) {
            Tree structMemberNode = anonymousTypeNode.getChild(i);
            StructMemberImpl structMember = translateStructMember(structMemberNode, parseRes, false);
            if (struct.getOwnMemberByName(structMember.getObjectName()) != null) {
                throw new SchemaDefinitionException(String.format(duplicateMemberInAnonymousTypeMsgFmt, structMemberNode.getLine(), stripQuotes(structMemberNode.getText())));
            }
            struct.addMember(structMember);
        }
        parseRes.addType(struct);
        return struct;
    }

    private MethodImpl translateMethod(Tree methodNode, SchemaParseResultImpl parseRes) {
        validateNodeType(methodNode, JLoximSchemaLexer.METHOD);
        MethodImpl method = new MethodImpl(stripQuotes(methodNode.getText()));

        int cnt = methodNode.getChildCount();

        for (int i = 0; i < cnt; i++) {
            Tree methodChild = methodNode.getChild(i);
            switch (methodChild.getType()) {
                case JLoximSchemaLexer.SCOPE:
                    method.setScope(translateScope(methodChild));
                    break;
                case JLoximSchemaLexer.RETURN:
                    method.setResultDeclaration(translateMethodResult(methodChild, parseRes));
                    break;
                case JLoximSchemaLexer.PARAMETER:
                    StructMemberImpl param = translateStructMember(methodChild, parseRes, true);
                    if (method.getParameterByName(param.getObjectName()) != null) {
                        throw new SchemaDefinitionException(String.format(duplicateParamMsgFmt, methodChild.getLine(), stripQuotes(methodNode.getText()), param.getObjectName()));
                    }
                    method.addParameter(param);
                    break;

                default:
                    throw new RuntimeException("wrong node type: " + methodChild.getType());
            }
        }

        return method;
    }

    private StructMember translateMethodResult(Tree treeNode, SchemaParseResultImpl parseRes) {
        StructMemberImpl res = new StructMemberImpl("");
        int cnt = treeNode.getChildCount();
        boolean isReference = false;
        String referencedFieldName = null;
        TypeInfo ti = null;
        for (int i = 0; i < cnt; i++) {
            Tree child = treeNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.CARD:
                    res.setCardinality(translateCardinality(child));
                    break;
                case JLoximSchemaLexer.REF:
                    isReference = true;
                    break;
                case JLoximSchemaLexer.POINTER_DEST:
                    referencedFieldName = stripQuotes(child.getText());
                    break;
                case JLoximSchemaLexer.TYPE:
                    ti = translateType(child, parseRes);
                    res.setTypeName(ti.typeName);
                    res.setTypeKind(ti.typeKind);
                    break;
                case JLoximSchemaLexer.VOID:
                    return null;
                default:
                    throw new RuntimeException("wrong node type: " + child.getType());
            }
        }

        validatePointer(isReference, referencedFieldName, treeNode.getLine());

        if (isReference) {
            PointerType pt = getPredefinedPointer(ti.typeName, referencedFieldName, parseRes);
            res.setTypeName(pt.getName());
            res.setTypeKind(TypeEnum.Pointer);
        }

        return res;
    }

    private void validatePointer(boolean isReference, String referencedFieldName, int line) {
        if (!isReference && referencedFieldName != null) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): referenced field name is allowed only when field declaration is a pointer and uses 'ref' keyword", line));
        }
        if (isReference && referencedFieldName == null) {
            throw new SchemaDefinitionException(String.format("Schema error (line %1$d): reference field have to declare destination field name. Example: fieldName : ref Type as destFieldName;", line));
        }
    }

    private TypeInfo translateType(Tree typeNode, SchemaParseResultImpl parseRes) {

        validateNodeType(typeNode, JLoximSchemaLexer.TYPE);
        TypeInfo tinfo = new TypeInfo();

        int childrenCnt = typeNode.getChildCount();
        if (childrenCnt != 1) {
            throw new SchemaDefinitionException(String.format(generalMsgFmt + "type node is expected to have 1 child", typeNode.getLine()));
        }

        Tree typeKindNode = typeNode.getChild(0);
        switch (typeKindNode.getType()) {
            case JLoximSchemaLexer.ID:
                tinfo.setTypeName(stripQuotes(typeKindNode.getText()));
                parseRes.addReferencedTypeName(tinfo.getTypeName());
                break;
            case JLoximSchemaLexer.TATOMIC:
                tinfo.setTypeKind(TypeEnum.AnyAtomic);
                break;
            case JLoximSchemaLexer.TBINARY:
                tinfo.setTypeKind(TypeEnum.Binary);
                break;
            case JLoximSchemaLexer.TBOOL:
                tinfo.setTypeKind(TypeEnum.Boolean);
                break;
            case JLoximSchemaLexer.TBYTE:
                tinfo.setTypeKind(TypeEnum.Byte);
                break;
            case JLoximSchemaLexer.TDATETIME:
                tinfo.setTypeKind(TypeEnum.DateTime);
                break;
            case JLoximSchemaLexer.TDOUBLE:
                tinfo.setTypeKind(TypeEnum.Double);
                break;
            case JLoximSchemaLexer.TINT:
                tinfo.setTypeKind(TypeEnum.Integer);
                break;
            case JLoximSchemaLexer.TLONG:
                tinfo.setTypeKind(TypeEnum.Long);
                break;
            case JLoximSchemaLexer.TSHORT:
                tinfo.setTypeKind(TypeEnum.Short);
                break;
            case JLoximSchemaLexer.TSTRING:
                tinfo.setTypeKind(TypeEnum.String);
                break;
            case JLoximSchemaLexer.TANY:
                tinfo.setTypeKind(TypeEnum.AnyType);
                break;
            default:
                throw new RuntimeException("unrecognized type kind: " + typeKindNode.getType());
        }

        return tinfo;
    }

    private Cardinality translateCardinality(Tree treeNode) {

        validateNodeType(treeNode, JLoximSchemaLexer.CARD);

        Long min, max;
        int childCnt = treeNode.getChildCount();

        if (childCnt == 1) {
            Tree minNode = treeNode.getChild(0);
            switch (minNode.getType()) {
                case JLoximSchemaLexer.INT:
                    min = Long.parseLong(minNode.getText());
                    max = Long.valueOf(min);
                    break;
                case JLoximSchemaLexer.ASTERISK:
                    min = 0L;
                    max = null;
                    break;
                case JLoximSchemaLexer.QUES:
                    min = 0L;
                    max = 1L;
                    break;
                case JLoximSchemaLexer.PLUS:
                    min = 1L;
                    max = null;
                    break;

                default:
                    throw new RuntimeException("Invalid node type '" + treeNode.getType() + "'!");
            }

        } else if (childCnt == 2) {
            Tree minNode = treeNode.getChild(0);
            if (minNode.getType() != JLoximSchemaLexer.INT) {
                throw new RuntimeException("Invalid node type '" + treeNode.getType() + "'! Expected INT");
            }
            min = Long.parseLong(minNode.getText());
            if (min < 0) {
                throw new SchemaDefinitionException(treeNode.getLine(), "wrong cardinality, max value cannot be less than 0");
            }

            Tree maxNode = treeNode.getChild(1);
            if (maxNode.getType() == JLoximSchemaLexer.INT) {
                max = Long.parseLong(maxNode.getText());
                if (min > max) {
                    throw new SchemaDefinitionException(treeNode.getLine(), "wrong cardinality, min value exceeds max value");
                }
                if (max < 1) {
                    throw new SchemaDefinitionException(treeNode.getLine(), "wrong cardinality, max value cannot be less than 1");
                }
            } else if (maxNode.getType() == JLoximSchemaLexer.ASTERISK) {
                max = null;
            } else {
                throw new RuntimeException("Invalid node type '" + treeNode.getType() + "'! Expected INT OR ASTERISK");
            }

        } else {
            throw new RuntimeException("Cardinality node is expected to have 1 or 2 children");
        }

        return new CardinalityImpl(min, max);
    }

    private ScopeEnum translateScope(Tree treeNode) {

        validateNodeType(treeNode, JLoximSchemaLexer.SCOPE);
        validateChildrenCount(treeNode, 1);

        Tree child = treeNode.getChild(0);
        switch (child.getType()) {
            case JLoximSchemaLexer.PUBLIC:
                return ScopeEnum.Public;
            case JLoximSchemaLexer.PROTECTED:
                return ScopeEnum.Protected;
            case JLoximSchemaLexer.PRIVATE:
                return ScopeEnum.Private;
            default:
                throw new RuntimeException("root node of schema definition tree was expected to be SHEMA");
        }
    }

    private Cardinality translateRoleOfCardinality(Tree treeNode) {
        validateNodeType(treeNode, JLoximSchemaLexer.ROLEOF);
        if (treeNode.getChildCount() == 1) {
            return translateCardinality(treeNode.getChild(0));
        }
        return new CardinalityImpl(1L, 1L);
    }

    private EnumerationType translateEnum(Tree enumNode) throws SchemaDefinitionException {
        validateNodeType(enumNode, JLoximSchemaLexer.ENUM);

        EnumerationTypeImpl enumType = new EnumerationTypeImpl(stripQuotes(enumNode.getText()));
        validateTypeName(enumType.getName(), enumNode.getLine());

        int cnt = enumNode.getChildCount();

        for (int i = 0; i < cnt; i++) {
            Tree child = enumNode.getChild(i);
            String name = stripQuotes(child.getText());
            if (enumType.getAllowedValues().contains(name)) {
                throw new SchemaDefinitionException(String.format(duplicateEnumMsgFmt, child.getLine(), enumType.getName(), name));
            }

            EnumerationConstantImpl con = new EnumerationConstantImpl();
            con.setName(name);
            enumType.getAllowedValues().add(con);
        }

        return enumType;
    }

    private SchemaType translateRestriction(Tree restrictionNode, SchemaParseResultImpl parseRes) {
        validateNodeType(restrictionNode, JLoximSchemaLexer.RESTRICTION);

        Tree baseTypeNode = restrictionNode.getChild(0);
        TypeInfo baseType = translateType(baseTypeNode, parseRes);
        RestrictionTypeImpl restr;

        switch (baseType.getTypeKind()) {
            case String:
                restr = translateStringRestriction(restrictionNode);
                break;
            case DateTime:
                restr = translateDateRestriction(restrictionNode);
                break;
            case Double:
                restr = translateDoubleRestriction(restrictionNode);
                break;
            case Byte:
            case Integer:
            case Long:
            case Short:
                restr = translateIntegerRestriction(restrictionNode);
                break;
            default:
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): type %2$s cannot be restricted", baseTypeNode.getLine(), baseType.getTypeKind().toString()));
        }

        validateTypeName(restr.getName(), baseTypeNode.getLine());

        restr.setBaseTypeKind(baseType.getTypeKind());
        return restr;
    }

    private StringRestrictionTypeImpl translateStringRestriction(Tree restrictionNode) {
        StringRestrictionTypeImpl res = new StringRestrictionTypeImpl(stripQuotes(restrictionNode.getText()));
        int cnt = restrictionNode.getChildCount();
        for (int i = 0; i < cnt; i++) {
            Tree child = restrictionNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.TYPE:
                    TypeInfo ti = translateType(child, null);
                    res.setBaseTypeKind(ti.getTypeKind());
                    break;
                case JLoximSchemaLexer.REGEX:
                    String regex = child.getText();
                    if (regex == null || regex.length() <= 2) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): Regex cannot be empty", child.getLine()));
                    }
                    res.setRegex(regex.substring(1, regex.length() - 1));
                    break;
                case JLoximSchemaLexer.MINLEN:
                    res.setMinLength(Integer.valueOf(child.getText()));
                    break;
                case JLoximSchemaLexer.MAXLEN:
                    res.setMaxLength(Integer.valueOf(child.getText()));
                    break;
                default:
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): not supported property of restriction", child.getLine()));
            }
        }
        return res;
    }

    private DateRestrictionTypeImpl translateDateRestriction(Tree restrictionNode) {
        DateRestrictionTypeImpl res = new DateRestrictionTypeImpl(stripQuotes(restrictionNode.getText()));
        int cnt = restrictionNode.getChildCount();
        for (int i = 0; i < cnt; i++) {
            Tree child = restrictionNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.TYPE:
                    TypeInfo ti = translateType(child, null);
                    res.setBaseTypeKind(ti.getTypeKind());
                    break;
                case JLoximSchemaLexer.MINVAL:
                    res.setMinValue((Calendar) parseLiteral(child.getChild(0)));
                    break;
                case JLoximSchemaLexer.MAXVAL:
                    res.setMaxValue((Calendar) parseLiteral(child.getChild(0)));
                    break;
                default:
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): not supported restriction property '%2$s'", child.getLine(), child.getText()));
            }
        }
        return res;
    }

    private DoubleRestrictionTypeImpl translateDoubleRestriction(Tree restrictionNode) {
        DoubleRestrictionTypeImpl res = new DoubleRestrictionTypeImpl(stripQuotes(restrictionNode.getText()));
        int cnt = restrictionNode.getChildCount();
        for (int i = 0; i < cnt; i++) {
            Tree child = restrictionNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.TYPE:
                    TypeInfo ti = translateType(child, null);
                    res.setBaseTypeKind(ti.getTypeKind());
                    break;
                case JLoximSchemaLexer.MINVAL:
                    res.setMinValue((Double) parseLiteral(child.getChild(0)));
                    break;
                case JLoximSchemaLexer.MAXVAL:
                    res.setMaxValue((Double) parseLiteral(child.getChild(0)));
                    break;
                default:
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): not supported restriction property '%2$s'", child.getLine(), child.getText()));
            }
        }
        return res;
    }

    private LongRestrictionTypeImpl translateIntegerRestriction(Tree restrictionNode) {
        LongRestrictionTypeImpl res = new LongRestrictionTypeImpl(stripQuotes(restrictionNode.getText()));
        int cnt = restrictionNode.getChildCount();
        for (int i = 0; i < cnt; i++) {
            Tree child = restrictionNode.getChild(i);
            switch (child.getType()) {
                case JLoximSchemaLexer.TYPE:
                    TypeInfo ti = translateType(child, null);
                    res.setBaseTypeKind(ti.getTypeKind());
                    break;
                case JLoximSchemaLexer.MINVAL:
                    res.setMinValue((Long) parseLiteral(child.getChild(0)));
                    break;
                case JLoximSchemaLexer.MAXVAL:
                    res.setMaxValue((Long) parseLiteral(child.getChild(0)));
                    break;
                default:
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): not supported restriction property '%2$s'", child.getLine(), child.getText()));
            }
        }
        return res;
    }

    private PointerType translatePointerType(Tree pointerNode, SchemaParseResultImpl parseRes) {
        PointerTypeImpl pointer = new PointerTypeImpl(stripQuotes(pointerNode.getText()));
        validateTypeName(pointer.getName(), pointerNode.getLine());
        validateChildrenCount(pointerNode, 2);

        TypeInfo ti = translateType(pointerNode.getChild(0), parseRes);
        pointer.setReferencedTypeName(ti.getTypeName());

        Tree targetFieldName = pointerNode.getChild(1);
        pointer.setReferencedFieldName(stripQuotes(targetFieldName.getText()));

        return pointer;
    }

    private VariantTypeImpl translateVariantType(Tree variantNode, SchemaParseResultImpl parseRes, boolean isAnonymous) {
        String name = isAnonymous ? parseRes.getAnonymousVariantName() : variantNode.getText();

        VariantTypeImpl variant = new VariantTypeImpl(stripQuotes(name));
        validateTypeName(variant.getName(), variantNode.getLine());

        for (int i = 0; i < variantNode.getChildCount(); i++) {
            Tree member = variantNode.getChild(i);
            TypeInfo ti = translateType(member, parseRes);
            variant.getPossibleTypesNames().add(ti.typeName);
        }

        return variant;
    }

    private ClassKindEnum translateClassKindEnum(Tree classKindNode) {

        validateNodeType(classKindNode, JLoximSchemaLexer.CLASS_KIND);
        validateChildrenCount(classKindNode, 1);

        Tree node = classKindNode.getChild(0);

        if (node.getType() == JLoximSchemaLexer.ABSTRACT) {
            return ClassKindEnum.Abstract;
        } else {
            throw new Error("Unexpcted node type: " + node.getType());
        }
    }

    private void validateNodeType(Tree treeNode, int expectedType) {
        if (treeNode.getType() != expectedType) {
            throw new RuntimeException("wrong node type: expected " + expectedType + ", was " + treeNode.getType());
        }
    }

    private void validateChildrenCount(Tree node, int expected) {
        if (node.getChildCount() != expected) {
            throw new Error(String.format("Schema parser: node of type %1$d is expected to have %2$s child nodes, but it has %3$d child nodes", node.getType(), node.getChildCount(), expected));
        }
    }

    private String stripQuotes(String name) {
        if ((name.length() > 0) && (name.charAt(0) == '`')) {
            name = name.substring(1, name.length() - 1);
        }
        return name;
    }
}