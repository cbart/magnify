/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 *
 * @author Paweł Mantur
 */
public class StructTypeImpl extends SchemaTypeImpl implements StructType {

    protected Map<String, StructMember> memebrsMap;

    public StructTypeImpl(String name) {
        super(name, TypeEnum.Struct);
        memebrsMap = new HashMap<String, StructMember>();
    }

    public void addMember(StructMember member) {
        memebrsMap.put(member.getObjectName(), member);
    }

    public ClassKindEnum getClassKind() {
        return ClassKindEnum.Selaed;
    }

    public StructMember getOwnMemberByName(String name) {
        return memebrsMap.get(name);
    }

    public StructMember getMemberByName(String name, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return memebrsMap.get(name);
    }

    public Iterator getOwnMembersIterator() {
        return new SimpleIterator(memebrsMap);
    }

    public Iterator getMembersIterator(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return new SimpleIterator(memebrsMap);
    }

    protected class SimpleIterator<T> implements Iterator {

        private Iterator<T> backingIterator;

        public SimpleIterator(Map<String, T> memebrsMap) {
            this.backingIterator = memebrsMap.values().iterator();
        }

        public boolean hasNext() {
            return backingIterator.hasNext();
        }

        public Object next() {
            return backingIterator.next();
        }

        public void remove() {
            throw new UnsupportedOperationException("Not supported operation.");
        }
    }

}
