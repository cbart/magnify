/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.signatures;

import pl.edu.mimuw.jloxim.stores.schema.api.signatures.BinderSignature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.Signature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesEnum;

/**
 *
 * @author Paweł Mantur
 */
public class BinderSignatureImpl extends SignatureImpl implements BinderSignature {

    private String name;

    private Signature signature;

    public BinderSignatureImpl(String name, Signature signature) {
        super(null, null);

        if (name == null) {
            throw new Error("BinderSignature name cannot be null");
        }

        if (signature == null) {
            throw new Error("BinderSignature inner signature cannot be null");
        }

        this.name = name;
        this.signature = signature;
        this.signatureKind = SignaturesEnum.Binder;
    }

    public String getName() {
        return name;
    }

    public Signature getSignature() {
        return signature;
    }

    public Signature copy() {
        Signature res = new BinderSignatureImpl(name, signature.copy());
        this.copyTo(res);
        return res;
    }

    @Override
    public String toString() {
        return this.getName() + "(" + this.getSignature().toString() + ")";
    }
}
