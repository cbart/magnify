/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BooleanAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationConstant;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.RestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 * This class checks if operations on store are allowed by schema constraints.
 *
 * It can be registered as a store events listener to be called
 * before any modification operations.
 *
 * @author Paweł Mantur
 */
public class SchemaAwareStoreObserver {

    private SchemaAwareStoreAS0Impl backingStore;

    private ValuesAgainstTypesChecker valuesChecker;

    public SchemaProvider getSchemaProvider() {
        return backingStore.getSchemaProvider();
    }

    public AtomicValueFactory getAtomicValFacory() {
        return backingStore.getAtomicValFacory();
    }

    public NamesTranslator getNamesTransaltor() {
        return backingStore.getNamesTranslator();
    }

    public AS0ObjectsFactory getObjectsFactory() {
        return backingStore.getObjectsFactory();
    }

    protected Logger logger = Logger.getLogger(SchemaAwareStoreObserver.class);

    public SchemaAwareStoreObserver(SchemaAwareStoreAS0Impl backingStore) {
        this.backingStore = backingStore;
        this.valuesChecker = new ValuesAgainstTypesChecker();
    }

    private Object getConstant(Transaction t, AbstractOid oid) {
        if (backingStore.getSuperRootOid().equals(oid)) {
            return null;
        }

        AS0ObjectRO obj = backingStore.getObjectByOID(t, oid);
        String name = getNamesTransaltor().getNameByNameId(obj.getNameId());
        TypeOid parentTypeId = backingStore.getTypeIdForObject(t, obj.getParentOID());
        SchemaType parent = getSchemaProvider().getTypeByOid(parentTypeId);
        if (parent.getTypeKind() == TypeEnum.AnyType)
            return null;
        ClassType parentClass = (ClassType) parent;
        StructMember memb = parentClass.getMemberByName(name, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        if (memb.isConstant()) {
            return memb.getDefaultValue();
        }
        return null;
    }

    public void setAtomicObjectValue(Transaction t, AbstractOid oid, AtomicValue newVal) throws StoreException {

        TypeOid typeId = backingStore.getTypeIdForObject(t, oid);

        SchemaType type = getSchemaProvider().getTypeByOid(typeId);
        String path = getPathForObject(t, oid);
        checkAtomicValue(type, newVal, getConstant(t, oid), path);
    }

    public void setNewPointerObjectDestination(Transaction t, AbstractOid pointerId, AbstractOid destOid) throws StoreException, SchemaViolationStoreException {

        SchemaType pointerType = getSchemaProvider().getTypeByOid(backingStore.getTypeIdForObject(t, pointerId));

        if (pointerType.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        if (pointerType.getTypeKind() != TypeEnum.Pointer) {
            throw new SchemaViolationStoreException(
                    backingStore.getStoreId(),
                    String.format("%1$s: Tried to assign pointer value to an object which is not a pointer", getPathForObject(t, pointerId)),
                    SchemaViolationStoreException.ERR_POINTER_EXPECTED);
        }

        PointerType pt = (PointerType) pointerType;
        SchemaType expectedType = getSchemaProvider().getTypeByOid(pt.getReferencedObjectTypeOid());

        AS0ObjectRO destObj = backingStore.getObjectByOID(t, destOid);
        String destObjectName = getNamesTransaltor().getNameByNameId(destObj.getNameId());
        SchemaType actualType = getSchemaProvider().getTypeByOid(backingStore.getTypeIdForObject(t, destOid));

        if (pt.getReferencedObjectName().compareTo(destObjectName) != 0) {
            throw new SchemaViolationStoreException(
                    backingStore.getStoreId(),
                    String.format("%1$s: Tried to assign a pointer to incompatible value. Field is a pointer to object of type '%2$s' and name '%3$s'. Destination object has type '%4$s' and name '%5$s'", getPathForObject(t, pointerId), pt.getReferencedObjectTypeName(), pt.getReferencedObjectName(), actualType.getName(), destObjectName),
                    SchemaViolationStoreException.ERR_INCOMPATIBLE_TYPE);
        }

        if (!actualType.canBeAssignedTo(getSchemaProvider(), expectedType)) {
            throw new SchemaViolationStoreException(
                    backingStore.getStoreId(),
                    String.format("%1$s: Tried to assign a pointer to incompatible value. Field is a pointer to object of type '%2$s' and name '%3$s'. Destination object has type '%4$s' and name '%5$s'", getPathForObject(t, pointerId), pt.getReferencedObjectTypeName(), pt.getReferencedObjectName(), actualType.getName(), destObjectName),
                    SchemaViolationStoreException.ERR_INCOMPATIBLE_TYPE);
        }
    }

    public void setNewComplexObjectValue(Transaction t, AbstractOid oid, Collection<AS0ObjectEditable> subobjects) throws SchemaViolationStoreException {
        TypeOid typeId = backingStore.getTypeIdForObject(t, oid);
        SchemaType type = getSchemaProvider().getTypeByOid(typeId);

        if (type.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        if (type.getTypeKind() == TypeEnum.Variant) {
            VariantType variant = (VariantType) type;
            boolean variantFound = false;
            for (String v : variant.getPossibleTypesNames()) {
                SchemaType vt = getSchemaProvider().getTypeByName(v);

                if (vt.getTypeKind() == TypeEnum.AnyType) {
                    return;
                }

                if (vt.getTypeKind().isComplex()) {
                    StructType struct = (StructType) vt;
                    try {
                        checkCardinalities(struct, subobjects);
                        for (AS0ObjectEditable obj : subobjects) {
                            String objName = getNamesTransaltor().getNameByNameId(obj.getNameId());
                            canAddSubobject(t, struct, objName, obj);
                        }
                        variantFound = true;
                        break;
                    } catch (SchemaViolationStoreException e) {
                        continue;
                    }
                }
            }

            if (!variantFound) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("%2$s: Object doesn't match any type defined in varaint '%1$s'", variant.getName(), getPathForObject(t, oid)), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
            }

        } else {
            StructType struct = toComplexType(type);
            checkCardinalities(struct, subobjects);
            for (AS0ObjectEditable obj : subobjects) {
                String objName = getNamesTransaltor().getNameByNameId(obj.getNameId());
                canAddSubobject(t, struct, objName, obj);
            }
        }
    }

    public void addSubobject(Transaction t, AbstractOid parentOid, AS0ObjectEditable object) throws SchemaViolationStoreException {
        TypeOid parentTypeId = backingStore.getTypeIdForObject(t, parentOid);
        SchemaType parentType = getSchemaProvider().getTypeByOid(parentTypeId);

        if (parentType.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        if (parentType.getTypeKind() == TypeEnum.Variant) {
            VariantType variant = (VariantType) parentType;
            String varNames = "";

            // find out possible parent types
            List<StructType> possibleParentTypes = new LinkedList<StructType>();
            for (String v : variant.getPossibleTypesNames()) {
                SchemaType vt = getSchemaProvider().getTypeByName(v);
                if (!vt.getTypeKind().isComplex()) {
                    continue;
                }

                try {
                    matchObjectToType(t, vt, getDeclarationForObject(t, parentOid), parentOid, false, new LinkedList<AbstractOid>(), null);
                    possibleParentTypes.add((StructType) vt);
                    varNames += v + ",";
                } catch (SchemaViolationStoreException e) {
                    continue;
                }
            }

            if (possibleParentTypes.size() == 0) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Variant '%1$s' cannot have subobjects (no matching complex type alternative found)", parentType.getName()));
            }

            boolean variantFound = false;
            for (StructType p : possibleParentTypes) {
                try {
                    String objName = getNamesTransaltor().getNameByNameId(object.getNameId());
                    checkCardinality(t, p, objName, parentOid);
                    canAddSubobject(t, p, objName, object);
                    variantFound = true;
                } catch (SchemaViolationStoreException e) {
                    continue;
                }
            }

            if (!variantFound) {
                varNames = varNames.substring(0, varNames.length() - 1);
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("%2$s: Subobject cannot be added to varaint '%1$s'. Possible alternaties checked: %3$s", variant.getName(), getPathForObject(t, parentOid), varNames), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
            }

        } else {

            if (parentType.getTypeKind() != TypeEnum.Class && parentType.getTypeKind() != TypeEnum.Struct) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Type '%1$s' cannot have subobjects", parentType.getName()));
            }

            StructType cl = (StructType) parentType;
            String objName = getNamesTransaltor().getNameByNameId(object.getNameId());
            checkCardinality(t, cl, objName, parentOid);
            canAddSubobject(t, cl, objName, object);
        }
    }

    public void removeObject(Transaction t, AbstractOid oid) throws SchemaViolationStoreException {
        AS0ObjectRO obj = backingStore.getObjectByOID(t, oid);
        canRemoveObject(t, obj.getNameId(), oid, 1L);
    }

    private class Pair {

        public AbstractOid oid;

        public int nameId;

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof Pair)) {
                return false;
            }
            Pair p = (Pair) o;
            return p.oid.compareTo(oid) == 0 && p.nameId == nameId;
        }

        @Override
        public int hashCode() {
            return oid.hashCode() * nameId;
        }
    }

    public void removeObjects(Transaction t, AbstractOid[] OIDs) throws SchemaViolationStoreException {

        Map<Pair, Long> counters = new HashMap<Pair, Long>();
        for (AbstractOid oid : OIDs) {
            AS0ObjectRO obj = backingStore.getObjectByOID(t, oid);
            Pair p = new Pair();
            p.nameId = obj.getNameId();
            p.oid = obj.getParentOID();
            if (counters.containsKey(p)) {
                counters.put(p, counters.get(p) + 1L);
            } else {
                counters.put(p, 1L);
            }
        }

        for (Pair p : counters.keySet()) {
            canRemoveObject(t, p.nameId, p.oid, counters.get(p));
        }
    }

    public void moveObject(Transaction t, AbstractOid oid, AbstractOid new_parent_oid) throws SchemaViolationStoreException {
        AS0ObjectRO obj = backingStore.getObjectByOID(t, oid);
        String name = getNamesTransaltor().getNameByNameId(obj.getNameId());

        canRemoveObject(t, obj.getNameId(), oid, 1L);

        TypeOid parentTypeId = backingStore.getTypeIdForObject(t, oid);
        SchemaType parentType = getSchemaProvider().getTypeByOid(parentTypeId);
        if (!parentType.getTypeKind().isComplex()) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Cannot move object: new parent is not a complex object"));
        }

        ClassType parentClass = (ClassType) parentType;
        StructMember memb = parentClass.getMemberByName(name, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        if (memb == null) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Cannot move object: new parent doesn't have member named %1$s", name));
        }

        Long maxCard = memb.getCardinality().getMaxOccurences();
        if (maxCard != null) {
        	  // TOOD Workaround caused by changes in the store api.
            Long cnt = 0L;
            for(ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, obj.getParentOID(), obj.getNameId());
                iter.hasNext();
                cnt++, iter.next(), iter.close());
            if (cnt + 1 > maxCard) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Cannot move object: maximal cardinality in new location exceeded"));
            }
        }
    }

    // ==================== private methods ============================
    private void checkAtomicValue(SchemaType type, AtomicValue value, Object constant, String objectPath) throws SchemaViolationStoreException {

        if (type.getTypeKind() == TypeEnum.Variant) {
            VariantType var = (VariantType) type;
            boolean variantFound = false;
            for (String vName : var.getPossibleTypesNames()) {
                SchemaType t = getSchemaProvider().getTypeByName(vName);
                try {
                    checkAtomicValue(t, value, constant, objectPath);
                    variantFound = true;
                    break;
                } catch (SchemaViolationStoreException e) {
                    continue;
                }
            }
            if (!variantFound) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("%2$s: Object doesn't match any alternative defined in variant '%1$s'.", var.getName(), objectPath), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
            }
        } else {
            checkAtomicValueNotVariant(type, value, constant, objectPath);
        }
    }

    private void checkAtomicValueNotVariant(SchemaType type, AtomicValue value, Object constant, String objectPath) throws SchemaViolationStoreException {

        TypeEnum te = type.getTypeKind();

        if (te == TypeEnum.AnyType) {
            return;
        }

        if (te.isComplex()) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Path %2$s : Atomic value not allowed in a field of complex type named %1$s", type.getName(), objectPath));
        }

        if (te == TypeEnum.Pointer) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Path %1$s : Atomic value not allowed in a field of pointer type", objectPath));
        }

        if (constant != null && !value.getValue().equals(constant)) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Path %3$s : Constant value %2$s cannot be changed in type %1$s", type.getName(), constant.toString(), objectPath));
        }

        if (te == TypeEnum.Restriction) {
            checkRestriction((RestrictionType) type, value, backingStore.getStoreId());
            return;
        }

        if (te == TypeEnum.Enum) {
            checkEnum((EnumerationType) type, value);
            return;
        }

        String msgFmt = "Path %1$s : Wrong atomic value. Expected '%2$s', got '%3$s'";
        String msg = String.format(msgFmt, objectPath, te.toString(), value.getClass().toString());
        SchemaViolationStoreException e = new SchemaViolationStoreException(backingStore.getStoreId(), msg);

        switch (te) {
            case AnyAtomic:
                break;

            case Binary:
                if (!(value instanceof BinaryAtomicValue)) {
                    throw e;
                }
                break;

            case Boolean:
                if (!(value instanceof BooleanAtomicValue)) {
                    throw e;
                }
                break;

            case DateTime:
                if (!(value instanceof DateAtomicValue)) {
                    throw e;
                }
                break;

            case Double:
                if (!(value instanceof DoubleAtomicValue)) {
                    throw e;
                }
                break;

            case Integer:
            case Long:
            case Short:
            case Byte:
                if (!(value instanceof IntegerAtomicValue) && !(value instanceof LongAtomicValue)) {
                    throw e;
                }
                valuesChecker.checkNumericValue((Number) value.getValue(), te, backingStore.getStoreId());
                break;

            case String:
                if (!(value instanceof TextAtomicValue)) {
                    throw e;
                }
                break;

            default:
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        "Unknown value of TypeEnum: " + te.toString());
        }
    }

    /**
     * Inner representation of enum is an integer
     * @param type
     * @param value
     */
    private void checkEnum(EnumerationType type, AtomicValue value) {
        if (!(value instanceof TextAtomicValue)) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(), "Enumeration value was expeced to be of type IntegerAtomicValue, found " + value.getClass().getName() + ", value: " + value.getValue().toString());
        }

        String val = (String) value.getValue();
        boolean constPresent = false;
        for (EnumerationConstant c : type.getAllowedValues()) {
            if (c.getName().compareTo(val) == 0) {
                constPresent = true;
                break;
            }
        }

        if (!constPresent) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Value %1$s is not a valid constant for enum %2$s", val, type.getName()));
        }
    }

    public void checkRestriction(RestrictionType restriction, AtomicValue value, String storeID) {
        if (value instanceof BinaryAtomicValue) {
            throw new SchemaViolationStoreException(storeID,
                    String.format("Binary value cannot be assigned to a restriction type '%1$s'", restriction.getName()));
        } else if (value instanceof BooleanAtomicValue) {
            throw new SchemaViolationStoreException(storeID,
                    String.format("Boolean value cannot be assigned to a restriction type '%1$s'", restriction.getName()));
        } else {
            valuesChecker.checkRestriction(restriction, value.getValue(), storeID);
        }
    }

    private StructType toComplexType(SchemaType type) {
        if (!type.getTypeKind().isComplex()) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(), String.format("Type '%1$s' is not complex and cannot have subobjects", type.getName()), SchemaViolationStoreException.ERR_COMPLEX_TYPE_EXPECTD);
        }
        return (StructType) type;
    }

    /**
     * This method doesn't check if cardinality will be OK. Make it before.
     * It makes comparison of object and corresponding class memeber type.
     */
    private void canAddSubobject(Transaction t, StructType parentStruct, String subobjectName, AS0ObjectEditable subobject) throws SchemaViolationStoreException {

        StructMember member = parentStruct.getMemberByName(subobjectName, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        if (member == null) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Type '%1$s' doesn't allow subobject named '%2$s'", parentStruct.getName(), subobjectName));
        }

        SchemaType type = getSchemaProvider().getTypeByOid(member.getObjectTypeOid());

        if (type.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        // compare subobject to add with member type
        if (subobject instanceof AS0ComplexObjectEditable) {
            if (type.getTypeKind() == TypeEnum.Variant) {
                VariantType variant = (VariantType) type;
                boolean variantFound = false;
                for (String v : variant.getPossibleTypesNames()) {
                    SchemaType vt = getSchemaProvider().getTypeByName(v);

                    if (vt.getTypeKind() == TypeEnum.AnyType) {
                        return;
                    }

                    try {
                        StructType cl = toComplexType(vt);
                        AS0ComplexObjectEditable complex = (AS0ComplexObjectEditable) subobject;
                        Set<AS0ObjectEditable> children = complex.getSubobjects();
                        checkCardinalities(cl, children);
                        for (AS0ObjectEditable child : children) {
                            String childName = getNamesTransaltor().getNameByNameId(child.getNameId());
                            canAddSubobject(t, cl, childName, child);
                        }
                        variantFound = true;
                        break;
                    } catch (SchemaViolationStoreException e) {
                        continue;
                    }
                }

                if (!variantFound) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("Object '%2$s' doesn't match any alternative defined in variant '%1$s'.", variant.getName(), subobjectName), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
                }

            } else {

                StructType cl = toComplexType(type);
                AS0ComplexObjectEditable complex = (AS0ComplexObjectEditable) subobject;
                Set<AS0ObjectEditable> children = complex.getSubobjects();
                checkCardinalities(cl, children);
                for (AS0ObjectEditable child : children) {
                    String childName = getNamesTransaltor().getNameByNameId(child.getNameId());
                    canAddSubobject(t, cl, childName, child);
                }
            }
        } else if (subobject instanceof AS0AtomicObjectEditable) {
            AS0AtomicObjectEditable atomic = (AS0AtomicObjectEditable) subobject;
            String path = getPathForObject(t, subobject.getOID());
            checkAtomicValue(type, atomic.getValue(), member.isConstant() ? member.getDefaultValue() : null, path);
        } else if (subobject instanceof AS0PointerObjectEditable) {
            AS0PointerObjectEditable pointer = (AS0PointerObjectEditable) subobject;
            checkPointer(t, type, member.getObjectName(), pointer, false, null, null);
        }
    }

    public void matchObjectToType(Transaction t, SchemaType type, StructMember objectDeclaration, AbstractOid objectOid, boolean followReferences, List<AbstractOid> checkedObjects, List<SchemaViolationStoreException> errors) {

        logger.debug("CHECKING PATH: " + getPathForObject(t, objectOid));

        if (checkedObjects.contains(objectOid)) {
            return;
        }

        if (type == null) {
            TypeOid typeId = backingStore.getTypeIdForObject(t, objectOid);
            type = getSchemaProvider().getTypeByOid(typeId);
        }

        if (type == null) {
            TypeOid typeId = backingStore.getTypeIdForObject(t, objectOid);
            throw new Error("type is null for obj in path: " + getPathForObject(t, objectOid) + ", typeId:" + typeId + ",objectOid=" + objectOid);
        }

        try {

            if (type.getTypeKind() == TypeEnum.AnyType) {
                return;
            }

            if (type.getTypeKind() == TypeEnum.Variant) {
                VariantType v = (VariantType) type;
                boolean matchingFound = false;
                for (String vName : v.getPossibleTypesNames()) {

                    List<SchemaViolationStoreException> errorsForVariant = new LinkedList<SchemaViolationStoreException>();
                    SchemaType vt = getSchemaProvider().getTypeByName(vName);

                    if (vt.getTypeKind() == TypeEnum.AnyType) {
                        return;
                    }

                    matchObjectToType(t, vt, objectDeclaration, objectOid, followReferences, checkedObjects, errorsForVariant);
                    checkedObjects.remove(objectOid);

                    if (errorsForVariant.size() == 0) {
                        matchingFound = true;
                        break;
                    }
                }

                checkedObjects.add(objectOid);

                if (!matchingFound) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%2$s: Object doesn't match any type defined in varaint '%1$s'", v.getName(), getPathForObject(t, objectOid)), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
                }

            } else {

                checkedObjects.add(objectOid);

                AS0ObjectRO obj = null;
                if (!isSuperRoot(objectOid)) {
                    obj = backingStore.getObjectByOID(t, objectOid);
                }

                if (isSuperRoot(objectOid) || obj instanceof AS0ComplexObjectRO) {
                    checkComplex(t, type, objectOid, followReferences, checkedObjects, errors);
                } else if (obj instanceof AS0AtomicObjectRO) {
                    AS0AtomicObjectRO atomicObject = (AS0AtomicObjectRO) obj;
                    String atomicObjPath = getPathForObject(t, obj.getOID());
                    checkAtomicValue(type, atomicObject.getValue(), objectDeclaration.isConstant() ? objectDeclaration.getDefaultValue() : null, atomicObjPath);
                } else if (obj instanceof AS0PointerObjectRO) {
                    AS0PointerObjectRO pointerObject = (AS0PointerObjectRO) obj;
                    checkPointer(t, type, objectDeclaration.getObjectName(), pointerObject, followReferences, checkedObjects, errors);
                } else {
                    throw new Error("Unexpected object class: " + obj.getClass().getName());
                }
            }

        } catch (SchemaViolationStoreException e) {
            if (errors != null) {
                errors.add(e);
            } else {
                throw e;
            }
        }
    }

    private boolean isSuperRoot(AbstractOid objectOid) {
      return backingStore.getSuperRootOid().equals(objectOid);
    }

    private void checkComplex(Transaction t, SchemaType type, AbstractOid objectOid, boolean followReferences, List<AbstractOid> checkedObjects, List<SchemaViolationStoreException> errors) {

        StructType cl = toComplexType(type);

        Map<String, Long> requiredMembers = new HashMap<String, Long>();
        Iterator<StructMember> membersIter = cl.getMembersIterator(getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        while (membersIter.hasNext()) {
            StructMember cm = membersIter.next();
            if (cm.getCardinality().getMinOccurences() > 0) {
                requiredMembers.put(cm.getObjectName(), cm.getCardinality().getMinOccurences());
            }
        }

        Map<String, Long> presentMembers = new HashMap<String, Long>();

        // iterating through all the subobjects
        ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDs(t, objectOid);
        while (iter.hasNext()) {

            AbstractOid subobjectOid = iter.next();
            AS0ObjectRO subobject = backingStore.getObjectByOID(t, subobjectOid);
            String subobjectName = getNamesTransaltor().getNameByNameId(subobject.getNameId());
            StructMember subobjectDeclaration = cl.getMemberByName(subobjectName, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);

            try {
                if (subobjectDeclaration == null) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%2$s: member '%1$s' not allowed in class '%3$s'", subobjectName, getPathForObject(t, subobjectOid), cl.getName()));
                } else {
                    if (presentMembers.containsKey(subobjectName)) {
                        presentMembers.put(subobjectName, presentMembers.get(subobjectName) + 1L);
                    } else {
                        presentMembers.put(subobjectName, 1L);
                    }
                    //List
                    matchObjectToType(t, null, subobjectDeclaration, subobjectOid, followReferences, checkedObjects, errors);
                }
            } catch (SchemaViolationStoreException e) {
                if (errors != null) {
                    errors.add(e);
                } else {
                    throw e;
                }
            }
        }
        iter.close();

        // checking if all required members were present
        for (String reqMember : requiredMembers.keySet()) {
            Long cnt = presentMembers.get(reqMember);
            StructMember childMemb = cl.getMemberByName(reqMember, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
            if (childMemb.getDefaultValue() != null) {
                for (long i = cnt == null ? 0 : cnt; i < requiredMembers.get(reqMember); i++) {
                    addDefaultValue(t, objectOid, childMemb);
                }
            } else {
                if (cnt == null) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%2$s: Required in class '%3$s' member '%1$s' not present", reqMember, getPathForObject(t, objectOid), cl.getName()));
                } else if (cnt < requiredMembers.get(reqMember)) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%2$s: Required in class '%3$s' member '%1$s' has cardinality %4$d (minimum cardinality is %5$d)", reqMember, getPathForObject(t, objectOid), cl.getName(), requiredMembers.get(reqMember), cnt));
                }
            }
        }
    }

    private void checkPointer(Transaction t, SchemaType memberType, String objectName, AS0PointerObjectRO pointer, boolean followReferences, List<AbstractOid> checkedObjects, List<SchemaViolationStoreException> errors) {

        if (memberType.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        if (memberType.getTypeKind() == TypeEnum.Variant) {

            VariantType var = (VariantType) memberType;
            boolean variantFound = false;
            for (String vName : var.getPossibleTypesNames()) {
                SchemaType st = getSchemaProvider().getTypeByName(vName);

                if (st.getTypeKind() == TypeEnum.AnyType) {
                    return;
                }

                if (st.getTypeKind() == TypeEnum.Pointer) {

                    try {
                        checkPointer(t, st, objectName, pointer, followReferences, checkedObjects, errors);
                        variantFound = true;
                        break;
                    } catch (SchemaViolationStoreException e) {
                        continue;
                    }
                }
            }

            if (!variantFound) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("%2$s: Object doesn't match any type defined in varaint '%1$s'", var.getName(), getPathForObject(t, pointer.getOID())), SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
            }

        } else {

            // check if schema allows a pointer here
            if (memberType.getTypeKind() != TypeEnum.Pointer) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Type of object '%1$s' is '%2$s'. Reference value is not allowed.", objectName, memberType.getName()));
            }

            if (pointer.getDestinationOID() != null) {
                // check if expected destination type declared in schema is compatible with referenced object type
                PointerType pntType = (PointerType) memberType;

                AS0ObjectRO destObject = backingStore.getObjectByOID(t, pointer.getDestinationOID());
                String destObjectName = getNamesTransaltor().getNameByNameId(destObject.getNameId());
                if (destObjectName.compareTo(pntType.getReferencedObjectName()) != 0) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%1$s: Pointer is expected to reference object named '%2$s', but it points to object named '%3$s'", getPathForObject(t, memberType.getTypeOid()), pntType.getReferencedObjectName(), destObjectName));
                }

                SchemaType expectedType = getSchemaProvider().getTypeByName(pntType.getReferencedObjectTypeName());

                TypeOid referencedObjectTypeId = backingStore.getTypeIdForObject(t, pointer.getDestinationOID());
                SchemaType referencedObjectType = getSchemaProvider().getTypeByOid(referencedObjectTypeId);

                if (!referencedObjectType.canBeAssignedTo(getSchemaProvider(), expectedType)) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("%1$s: destination type doesn't match the pointer type", getPathForObject(t, memberType.getTypeOid())));
                }

                if (followReferences && !checkedObjects.contains(pointer.getDestinationOID())) {
                    StructMember destinationObjectDeclaration = getDeclarationForObject(t, pointer.getDestinationOID());
                    matchObjectToType(t, referencedObjectType, destinationObjectDeclaration, pointer.getDestinationOID(), followReferences, checkedObjects, errors);
                }
            }
        }
    }

    public StructMember getDeclarationForObject(Transaction t, AbstractOid oid) {
        if (!isSuperRoot(oid)) {
            TypeOid typeId = backingStore.getTypeIdForObject(t, backingStore.getParentOID(t, oid));
            StructType parentClass = (StructType) getSchemaProvider().getTypeByOid(typeId);
            AS0ObjectRO obj = backingStore.getObjectByOID(t, oid);
            return parentClass.getMemberByName(getNamesTransaltor().getNameByNameId(obj.getNameId()), getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        }
        return null;
    }

    private void addDefaultValue(Collection<AS0ObjectEditable> subobjects, StructMember member) {
        int nameID = getNamesTransaltor().getOrRegisterName(member.getObjectName());
        AtomicValue av = getAtomicValFacory().newAtomicValue(member.getDefaultValue());
        AS0ObjectEditable obj = getObjectsFactory().newAtomicObject(nameID, av);
        subobjects.add(obj);
    }

    private void addDefaultValue(Transaction t, AbstractOid parentOid, StructMember member) {
        int nameID = getNamesTransaltor().getOrRegisterName(member.getObjectName());
        AtomicValue av = getAtomicValFacory().newAtomicValue(member.getDefaultValue());
        AS0ObjectEditable obj = getObjectsFactory().newAtomicObject(nameID, av);
        backingStore.addSubobject(t, parentOid, obj);
    }

    private class MinMax {
        public Long Min,  Max;
    }

    private void updateCardinalityCountersByStoreContent(Transaction t, MinMax cardCounters, StructType classType, String memberName, AbstractOid parentOid) {
    	  // TOOD Workaround caused by changes in the store api.
        Long itemsCnt = 0L;
        ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, parentOid, getNamesTransaltor().getNameIdByName(memberName));
        try {
          while(iter.hasNext()) { 
            itemsCnt++;
            iter.next();
          }
        } finally {
          iter.close();
        }
        if (cardCounters.Max != null) {
            if (itemsCnt > cardCounters.Max) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Store is in state inconsistent with schema! Object of type '%1$s' is expected to have maximum %2$d subobject(s) named '%3$s', found %4$d subobjets", classType.getName(), cardCounters.Max, memberName, itemsCnt));
            }
            cardCounters.Max -= itemsCnt;
        }

        if (itemsCnt < cardCounters.Min) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Store is in state inconsistent with schema! Object of type '%1$s' is expected to have at least %2$d subobject(s) named '%3$s', found just %4$d subobjets", classType.getName(), cardCounters.Min, memberName, itemsCnt));
        }
        cardCounters.Min = 0L;
    }

    private void checkCardinality(Transaction t, StructType classType, String objName, AbstractOid parentOid) {

        StructMember member = classType.getMemberByName(objName, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        Cardinality card = member.getCardinality();

        MinMax cardCounters = new MinMax();
        cardCounters.Min = card.getMinOccurences();
        cardCounters.Max = card.getMaxOccurences();

        updateCardinalityCountersByStoreContent(t, cardCounters, classType, objName, parentOid);

        if (cardCounters.Max != null && cardCounters.Max == 0) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("Cannot add more than %1$d subobject(s) named '%2$s' to an object of type '%3$s'", member.getCardinality().getMaxOccurences(), objName, classType.getName()));
        }
    }

    /**
     * objects contained in collection {@code subobjects} have to properly fill the
     * interior of of complex object of type {@code classType}. All required members
     * have to be present. Not defined members cannot be present.
     * @param classType
     * @param subobjects
     */
    private void checkCardinalities(StructType classType, Collection<AS0ObjectEditable> subobjects) {

        Map<String, MinMax> allowedContent = new HashMap<String, MinMax>();

        for (Iterator<StructMember> iter = classType.getMembersIterator(getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private); iter.hasNext();) {
            StructMember member = iter.next();
            Cardinality card = member.getCardinality();
            MinMax mm = new MinMax();
            mm.Min = card.getMinOccurences();
            mm.Max = card.getMaxOccurences();
            allowedContent.put(member.getObjectName(), mm);
        }

        // check how many objects are to be added and if their names are known
        for (AS0ObjectEditable obj : subobjects) {
            String name = getNamesTransaltor().getNameByNameId(obj.getNameId());
            if (!allowedContent.containsKey(name)) {
                throw new SchemaViolationStoreException(backingStore.getStoreId(),
                        String.format("Object of type '%1$s' doesn't allow members named '%2$s'", classType.getName(), name));
            }

            MinMax mm = allowedContent.get(name);
            mm.Min -= 1L;
            if (mm.Max != null) {
                // check if maxOccurences constraint isn't exceeded
                if (mm.Max == 0) {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("Cannot add more than %1$d subobject(s) named '%2$s' to an object of type '%3$s'",
                            classType.getMemberByName(name, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private).getCardinality().getMaxOccurences(), name, classType.getName()));
                }

                mm.Max -= 1L;
            }
        }

        // check if minOccurences constraint is satisfied
        for (String key : allowedContent.keySet()) {
            MinMax mm = allowedContent.get(key);
            if (mm.Min > 0) {
                StructMember cm = classType.getMemberByName(key, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);

                if (cm.getDefaultValue() != null) {
                    long minOccur = cm.getCardinality().getMinOccurences();
                    for (long i = 0; i < minOccur; i++) {
                        addDefaultValue(subobjects, cm);
                    }
                } else {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("Complex object of type '%3$s' must have at least %1$d subobject(s) named '%2$s'", cm.getCardinality().getMinOccurences(), key, classType.getName()));
                }
            }
        }
    }

    private void canRemoveObject(Transaction t, int objToRemoveNameId, AbstractOid objectToRemoveOID, long itemsToRemoveCnt) {

        String objToRemoveName = getNamesTransaltor().getNameByNameId(objToRemoveNameId);

        AbstractOid parentObjectOId = backingStore.getParentOID(t, objectToRemoveOID);
        TypeOid parentTypeId = backingStore.getTypeIdForObject(t, parentObjectOId);
        SchemaType pt = getSchemaProvider().getTypeByOid(parentTypeId);

        if (pt.getTypeKind() == TypeEnum.AnyType) {
            return;
        }

        StructType parentType = null;
        StructMember memberToRemove = null;
        if (pt.getTypeKind() == TypeEnum.Variant) {
            // TODO: till object doesn't know exact type, matched parent type can be ambigous
            VariantType vt = (VariantType) pt;
            for (String vName : vt.getPossibleTypesNames()) {
                SchemaType st = getSchemaProvider().getTypeByName(vName);
                if (st.getTypeKind().isComplex()) {
                    StructType s = (StructType) st;
                    memberToRemove = s.getMemberByName(objToRemoveName, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
                    if (memberToRemove != null) {
                        parentType = s;
                        break;
                    }
                }
            }
        } else {
            parentType = (ClassType) getSchemaProvider().getTypeByOid(parentTypeId);
            memberToRemove = parentType.getMemberByName(objToRemoveName, getSchemaProvider(), MembersSetType.OwnAndInherited, ScopeEnum.Private);
        }

        if (memberToRemove == null) {
            throw new SchemaViolationStoreException(backingStore.getStoreId(),
                    String.format("No member named '%1$s' in object of type '%2$s'", objToRemoveName, parentType.getName()));
        }

        Cardinality card = memberToRemove.getCardinality();

        if (card.getMinOccurences() > 0) {
        	  // TOOD Workaround caused by changes in the store api.
            Long cnt = 0L;
            ClosableIterator<AbstractOid> iter = backingStore.getSubobjectOIDsByNameOID(t, parentObjectOId, objToRemoveNameId);
            try {
              while (iter.hasNext()) {
                cnt++;
                iter.next();
              }               
            } finally {
              iter.close();
            }
            long leftItemsCnt = cnt - itemsToRemoveCnt;
            if (leftItemsCnt < card.getMinOccurences()) {
                if (memberToRemove.getDefaultValue() != null) {
                    for (long i = cnt - itemsToRemoveCnt; i < card.getMinOccurences(); i++) {
                        // if there is a default value, insert enough objects to satisfy minCardinality
                        addDefaultValue(t, parentObjectOId, memberToRemove);
                    }
                } else {
                    throw new SchemaViolationStoreException(backingStore.getStoreId(),
                            String.format("Cannot remove object '%2$s': minimal cardinality is %1$d, after removing there would be %3$s object(s) left", card.getMinOccurences(), objToRemoveName, leftItemsCnt));
                }
            }
        }
    }

    private String getPathForObject(Transaction t, AbstractOid oid) {
        if (oid == null) {
            return "OID is null, not persistent object";
        }

        String res = "";
        AbstractOid cur = oid;
        while (!isSuperRoot(cur)) {
            AS0ObjectRO obj = backingStore.getObjectByOID(t, cur);
            if (obj == null) {
                throw new StoreException(backingStore.getStoreId(),
                        String.format("Object with ID=%1$s doesn't exist", oid.toReadableString()));
            }
            if (res.length() > 0) {
                res = "." + res;
            }
            res = getNamesTransaltor().getNameByNameId(obj.getNameId()) + res;
            cur = obj.getParentOID();
        }
        res = "/" + res;
        return res;
    }
}
