/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.signatures;

import pl.edu.mimuw.jloxim.stores.schema.api.signatures.CollectionKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.Signature;
import pl.edu.mimuw.jloxim.stores.schema.api.signatures.SignaturesEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.CardinalityImpl;

/**
 *
 * @author Paweł Mantur
 */
public abstract class SignatureImpl implements Signature {

    protected Cardinality cardinality;

    protected CollectionKindEnum collectionKind;

    protected SignaturesEnum signatureKind;

    protected String typeName;

    protected boolean mutable;

    private int index;

    public SignatureImpl() {
        this.cardinality = new CardinalityImpl(1L, 1L);
        this.collectionKind = CollectionKindEnum.NotCollection;
    }

    public SignatureImpl(Cardinality cardinality, CollectionKindEnum collectionKind) {

        if (cardinality == null) {
            this.cardinality = new CardinalityImpl(1L, 1L);
        } else {
            this.cardinality = cardinality;
        }

        if (collectionKind == null) {
            Long max = this.cardinality.getMaxOccurences();
            if (max == null || (max != null && max > 1L)) {
                this.collectionKind = CollectionKindEnum.Bag;
            } else {
                this.collectionKind = CollectionKindEnum.NotCollection;
            }
        } else {
            this.collectionKind = collectionKind;
        }
    }

    public SignaturesEnum getSignatureKind() {
        return signatureKind;

    }

    public Cardinality getCardinality() {
        return cardinality;
    }

    public CollectionKindEnum getCollectionKind() {
        return collectionKind;
    }

    public String getTypeName() {
        return typeName;
    }

    public boolean isMutable() {
        return mutable;
    }

    public int getIndex() {
        return index;
    }

    public void setCardinality(Cardinality card) {
        this.cardinality = card;

        if (this.collectionKind == null || this.collectionKind == CollectionKindEnum.NotCollection) {
            Long max = this.cardinality.getMaxOccurences();
            if (max == null || (max != null && max > 1L)) {
                this.collectionKind = CollectionKindEnum.Bag;
            } else {
                this.collectionKind = CollectionKindEnum.NotCollection;
            }
        }
    }

    public void setCollectionKind(CollectionKindEnum colKind) {
        this.collectionKind = colKind;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public void setMutable(boolean isMutable) {
        this.mutable = isMutable;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    protected void copyTo(Signature sig) {
        sig.setCardinality(this.cardinality);
        sig.setCollectionKind(this.collectionKind);
        sig.setIndex(this.index);
        sig.setMutable(this.mutable);
        sig.setTypeName(this.typeName);
    }
}
