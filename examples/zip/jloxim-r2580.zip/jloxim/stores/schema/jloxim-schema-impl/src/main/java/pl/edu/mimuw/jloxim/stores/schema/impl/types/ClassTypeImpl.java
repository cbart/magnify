/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;

/**
 *
 * @author Paweł Mantur
 */
public class ClassTypeImpl extends StructTypeImpl implements ClassType {

    private List<String> extendsList;

    private List<TypeOid> extendsListOids;

    private String roleOf;

    private TypeOid roleOfOid;

    private Map<String, Method> methods;

    private Cardinality roleOfCardinality;

    private boolean isSealed;

    private boolean isAbstract;

    private ClassKindEnum classKind;

    public ClassTypeImpl(String className) {
        super(className);
        this.typeKind = TypeEnum.Class;
        this.extendsList = new LinkedList<String>();
        this.extendsListOids = new LinkedList<TypeOid>();
        this.methods = new HashMap<String, Method>();
        this.classKind = ClassKindEnum.Selaed;
    }

    public List<String> getExtendsList() {
        return extendsList;
    }

    public void addToExtendsList(String extendedClass) {
        this.extendsList.add(extendedClass);
    }

    public boolean addMethod(Method method) {
        String uname = method.getSignature();
        if (methods.containsKey(uname)) {
            return false;
        }
        this.methods.put(uname, method);
        return true;
    }

    public String getRoleOf() {
        return roleOf;
    }

    public void setRoleOf(String roleOfClassName) {
        this.roleOf = roleOfClassName;
    }

    public Cardinality getRoleOfCardinality() {
        return this.roleOfCardinality;
    }

    public void setRoleOfCardinality(Cardinality cardinality) {
        this.roleOfCardinality = cardinality;
    }

    public List<TypeOid> getExtendsListOid() {
        return extendsListOids;
    }

    public TypeOid getRoleOfOid() {
        return roleOfOid;
    }

    public void setRoleOfOid(TypeOid roleOfOid) {
        this.roleOfOid = roleOfOid;
    }

    public boolean isAbstract() {
        return isAbstract;
    }

    public void setAbstract(boolean isAbstract) {
        this.isAbstract = isAbstract;
    }

    public boolean isSealed() {
        return isSealed;
    }

    public void setSealed(boolean isSealed) {
        this.isSealed = isSealed;
    }

    @Override
    public ClassKindEnum getClassKind() {
        return classKind;
    }

    public void setClassKind(ClassKindEnum classKind) {
        this.classKind = classKind;
    }

    public boolean isSubclassOf(SchemaProvider schemaProvider, String parentClassName) {

        // checking static inheritance
        for (String id : this.getExtendsList()) {
            if (id.compareTo(parentClassName) == 0) {
                return true;
            }
            if (((ClassType) schemaProvider.getTypeByName(id)).isSubclassOf(schemaProvider, parentClassName)) {
                return true;
            }
        }

        if (this.getRoleOf() != null) {
            // checking dynamic inheritance (roles)
            if (this.getRoleOf().compareTo(parentClassName) == 0) {
                return true;
            }

            if (((ClassType) schemaProvider.getTypeByName(this.getRoleOf())).isSubclassOf(schemaProvider, parentClassName)) {
                return true;
            }
        }

        return false;
    }

    private void collectMembers(ClassType clazz, Map<String, StructMember> res, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        Iterator<StructMember> iter = clazz.getMembersIterator(schemaProvider, setType, scope);
        while (iter.hasNext()) {
            StructMember member = iter.next();
            if (member.getScope().getLevel() <= scope.getLevel()) {
                if (!res.containsKey(member.getObjectName())) {
                    res.put(member.getObjectName(), member);
                }
            }
        }
    }

    private Map<String, StructMember> getAllMembers(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {

        Map<String, StructMember> res = new HashMap<String, StructMember>();

        for (StructMember memb : this.memebrsMap.values()) {
            if (memb.getScope().getLevel() <= scope.getLevel()) {
                res.put(memb.getObjectName(), memb);
            }
        }

        ScopeEnum scopeForParents = scope;
        if (scope == ScopeEnum.Private) {
            scopeForParents = ScopeEnum.Protected;
        }

        if (setType.getLevel() >= MembersSetType.OwnAndInherited.getLevel()) {
            for (String parentName : this.getExtendsList()) {
                ClassType parent = (ClassType) schemaProvider.getTypeByName(parentName);
                collectMembers(parent, res, schemaProvider, setType, scopeForParents);
            }
        }

        if (setType == MembersSetType.OwnAndInheritedAndRoleOf && this.getRoleOf() != null) {
            ClassType roleOfClass = (ClassType) schemaProvider.getTypeByName(this.getRoleOf());
            collectMembers(roleOfClass, res, schemaProvider, setType, scopeForParents);
        }

        return res;
    }

    @Override
    public StructMember getMemberByName(String memberName, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return getAllMembers(schemaProvider, setType, scope).get(memberName);
    }

    @Override
    public Iterator getMembersIterator(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return new SimpleIterator(getAllMembers(schemaProvider, setType, scope));
    }

    /** METHODS **/
    public Method getOwnMethodBySignature(String methodSignature) {
        return methods.get(methodSignature);
    }

    public Iterator getOwnMethodsIterator() {
        return new SimpleIterator(methods);
    }

    private void collectMethods(ClassType clazz, Map<String, Method> res, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        Iterator<Method> iter = clazz.getMethodsIterator(schemaProvider, setType, scope);
        while (iter.hasNext()) {
            Method method = iter.next();
            if (method.getScope().getLevel() <= scope.getLevel()) {
                if (!res.containsKey(method.getSignature())) {
                    res.put(method.getSignature(), method);
                }
            }
        }
    }

    private Map<String, Method> getAllMethods(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {

        Map<String, Method> res = new HashMap<String, Method>();

        for (Method method : methods.values()) {
            if (method.getScope().getLevel() <= scope.getLevel()) {
                res.put(method.getName(), method);
            }
        }

        ScopeEnum scopeForParents = scope;
        if (scope == ScopeEnum.Private) {
            scopeForParents = ScopeEnum.Protected;
        }

        if (setType.getLevel() >= MembersSetType.OwnAndInherited.getLevel()) {
            for (String parentName : this.getExtendsList()) {
                ClassType parent = (ClassType) schemaProvider.getTypeByName(parentName);
                collectMethods(parent, res, schemaProvider, setType, scopeForParents);
            }
        }

        if (setType == MembersSetType.OwnAndInheritedAndRoleOf && this.getRoleOf() != null) {
            ClassType roleOfClass = (ClassType) schemaProvider.getTypeByName(this.getRoleOf());
            collectMethods(roleOfClass, res, schemaProvider, setType, scopeForParents);
        }

        return res;
    }

    public Method getMethodBySignature(String methodSignature, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return getAllMethods(schemaProvider, setType, scope).get(methodSignature);
    }

    public Iterator getMethodsIterator(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope) {
        return new SimpleIterator(getAllMethods(schemaProvider, setType, scope));
    }
}
