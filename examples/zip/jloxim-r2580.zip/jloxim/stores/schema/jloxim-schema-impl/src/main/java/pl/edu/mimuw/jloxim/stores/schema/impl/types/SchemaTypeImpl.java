/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.types;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaTypeImpl implements SchemaType {

    protected String name;

    protected TypeOid typeOid;

    protected TypeEnum typeKind;

    public SchemaTypeImpl(TypeEnum typeKind) {
        if (typeKind.isUesrDefined()) {
            throw new Error("UesrDefined type cannot be instantiated by this constructor");
        }

        this.typeKind = typeKind;
        this.name = typeKind.getSymbol();
    }

    public SchemaTypeImpl(String name, TypeEnum typeKind) {
        this.name = name;
        this.typeKind = typeKind;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TypeOid getTypeOid() {
        return typeOid;
    }

    public void setTypeOid(TypeOid typeOid) {
        this.typeOid = typeOid;
    }

    public TypeEnum getTypeKind() {
        return typeKind;
    }

    public void setTypeKind(TypeEnum typeKind) {
        this.typeKind = typeKind;
    }

    public boolean canBeAssignedTo(SchemaProvider schemaProvider, SchemaType expectedType) {
        if (this.getName().compareTo(expectedType.getName()) == 0) {
            return true;
        }

        if (this.getTypeKind() == TypeEnum.Variant) {
            VariantType vt = (VariantType) this;
            for (String vName : vt.getPossibleTypesNames()) {
                SchemaType st = schemaProvider.getTypeByName(vName);
                if (this.canBeAssignedTo(schemaProvider, st)) {
                    return true;
                }
            }
            return false;
        } else {
            return canBeAssignedToNotVariant(schemaProvider, expectedType);
        }
    }

    private boolean canBeAssignedToNotVariant(SchemaProvider schemaProvider, SchemaType expectedType) {

        if (this.getTypeKind() == TypeEnum.Method || expectedType.getTypeKind() == TypeEnum.Method) {
            return false;
        }

        if (this.getName().compareTo(expectedType.getName()) == 0) {
            return true;
        }

        // we already know that types are not exactly the same

        TypeEnum actualTypeKind = this.getTypeKind();
        TypeEnum expectedTypeKind = expectedType.getTypeKind();

        if (actualTypeKind.isComplex()) {

            if (!expectedTypeKind.isComplex()) {
                return false;
            }
            if (expectedTypeKind == TypeEnum.Struct) {
                return false;
            }
            if (expectedTypeKind != TypeEnum.Class) {
                throw new Error("Found complex type other than Class, Struct and AnyComplex");
            }
            // casting can be made only to ancestor class in inheritance hierarchy
            return ((ClassType) this).isSubclassOf(schemaProvider, expectedType.getName());

        } else if (actualTypeKind == TypeEnum.Pointer) {

            if (expectedTypeKind != TypeEnum.Pointer) {
                return false;
            }

            PointerType expectedPointer = (PointerType) expectedType;
            PointerType actualPointer = (PointerType) this;

            if (expectedPointer.getReferencedObjectName().compareTo(actualPointer.getReferencedObjectName()) != 0) {
                return false;
            }

            SchemaType typeReferencedByActualObject = schemaProvider.getTypeByOid(actualPointer.getReferencedObjectTypeOid());
            SchemaType typeExpectedToBeReferenced = schemaProvider.getTypeByOid(expectedPointer.getReferencedObjectTypeOid());
            typeReferencedByActualObject.canBeAssignedTo(schemaProvider, typeExpectedToBeReferenced);

        } else if (actualTypeKind.isAtomic()) {

            if (expectedTypeKind == TypeEnum.AnyAtomic) {
                return true;
            }
        }

        // There is no implicit casting enum <-> integer, restriction <-> restriction
        // or restriction <-> type. Such cast must be explicit. That's why
        // we finish with a negative result.

        return false;
    }
}
