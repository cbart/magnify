/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.parser;

import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParseResult;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassKindEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationConstant;
import pl.edu.mimuw.jloxim.stores.schema.api.types.EnumerationType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.RestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.impl.SchemaUtils;
import pl.edu.mimuw.jloxim.stores.schema.impl.ValuesAgainstTypesChecker;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.StructMemberImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumReference;

/**
 * Class used to check if schema definition is consistent.
 *
 * @author Paweł Mantur
 */
public class SchemaVerifier {

    private ValuesAgainstTypesChecker valuesChecker;

    public ValuesAgainstTypesChecker getValuesChecker() {
        if (valuesChecker == null) {
            valuesChecker = new ValuesAgainstTypesChecker();
        }
        return valuesChecker;
    }

    public void verifySchema(SchemaParseResult parseRes) throws SchemaDefinitionException {
        SchemaType root = parseRes.getRootType();
        if (root != null && !root.getTypeKind().isComplex()){
            throw new SchemaDefinitionException("Root type have to be complex (struct, class or any)");
        }
        checkReferencedTypesPresence(parseRes);
        InheritanceGraph ig = new InheritanceGraph();
        ig.addClasses(parseRes);
        checkCyclePresence(ig);
        processAllFields(parseRes, ig);
        checkEnumsWithRootMemberConfilcts(parseRes);
    }

    private void processAllFields(SchemaParseResult parseRes, InheritanceGraph ig) {
        for (SchemaType st : parseRes.getTypes().values()) {
            if (st instanceof StructType) {
                StructType struct = (StructType) st;

                HashSet<String> checked = new HashSet<String>();
                if (st.getTypeKind() == TypeEnum.Class) {
                    ClassType cl = (ClassType) st;
                    //findAmbigousSignatures(cl, ig);
                    checkAbstractClassesAsRoleOf(cl.getName(), cl.getRoleOf(), parseRes);
                    checkExtendsList(cl, parseRes);
                    if (!checked.contains(cl.getName())) {
                        checkMultiInheritanceConflicts(cl, parseRes, checked);
                    }
                }

                for (Iterator<StructMember> iter = struct.getOwnMembersIterator(); iter.hasNext();) {
                    StructMember memb = iter.next();
                    StructMemberImpl cm = (StructMemberImpl) memb;
                    checkTypesMatching(cm, parseRes);
                    checkAbstractClasses(cm, parseRes, struct.getName());
                }

            } else if (st.getTypeKind() == TypeEnum.Variant) {
                for (String vName : ((VariantType) st).getPossibleTypesNames()) {
                    SchemaType vt = parseRes.getType(vName);
                    if (vt == null) {
                        continue;
                    }
                    if (vt.getTypeKind() == TypeEnum.Variant) {
                        throw new SchemaDefinitionException(String.format("Variant cannot be a member of variant. Variant '%1$s' includes variant '%2$s' as possible type", vName, vt.getName()));
                    }
                }
            }
        }
    }

    /**
     * Checks if there is no fields with abstract type
     * @param cm
     * @param parseRes
     */
    private void checkAbstractClasses(StructMemberImpl cm, SchemaParseResult parseRes, String className) {
        if (cm.getObjectTypeKind() == TypeEnum.Pointer) {
            return;
        }

        SchemaType memberType = parseRes.getType(cm.getObjectTypeName());
        if (memberType == null) {
            if (SchemaUtils.PREDEFINED_TYPES_BY_NAME.containsKey(cm.getObjectTypeName())) {
                return;
            }
            throw new SchemaDefinitionException(String.format("Type %1$s referenced in member %2$s of class %3$s is not present in schema", cm.getObjectTypeName(), cm.getObjectName(), className));
        }

        if (memberType.getTypeKind() == TypeEnum.Class) {
            ClassType cl = (ClassType) memberType;
            if (cl.getClassKind() == ClassKindEnum.Abstract) {
                throw new SchemaDefinitionException(String.format("Abstract class %1$s cannot be used as a filed type", cl.getName()), SchemaDefinitionException.ERR_ABSTRACT_FIELD);
            }
        }
    }

    private void checkAbstractClassesAsRoleOf(String className, String roleOfClassName, SchemaParseResult parseRes) {
        if (roleOfClassName == null) {
            return;
        }
        SchemaType st = parseRes.getType(roleOfClassName);
        if (st.getTypeKind() != TypeEnum.Class) {
            throw new SchemaDefinitionException(String.format("Type '%1$s' used as 'role of' for class '%2$s' is not a class", roleOfClassName, className));
        }

        ClassType cl = (ClassType) st;
        if (cl.getClassKind() == ClassKindEnum.Abstract) {
            throw new SchemaDefinitionException(String.format("Abstract class '%1$s' cannot be used a as 'role of' for class '%2$s'", roleOfClassName, className));
        }
    }

    private void checkExtendsList(ClassType cl, SchemaParseResult parseRes) {
        for (String parentName : cl.getExtendsList()) {
            SchemaType p = parseRes.getType(parentName);
            if (p.getTypeKind() != TypeEnum.Class) {
                throw new SchemaDefinitionException(String.format("Type '%1$s' used in extends list of class '%2$s' is not a class", parentName, cl.getName()));
            }
        }
    }

    private class MultiInheitanceCheckRes {

        Map<String, String> allMembers = new HashMap<String, String>();

        boolean hasRoleOf;
    }

    /**
     * Checks if there is no conficts because of multi-inheritance.
     * A confilct occurs when there are fileds with the same name or methods
     * with the same signature in more than one parent classes and they are not
     * overriden.
     * @param cl
     * @param parseRes
     */
    private MultiInheitanceCheckRes checkMultiInheritanceConflicts(ClassType cl, SchemaParseResult parseRes, HashSet<String> checked) {
        // mine members + inherited members
        MultiInheitanceCheckRes res = new MultiInheitanceCheckRes();
        res.allMembers = new HashMap<String, String>();
        checked.add(cl.getName());

        boolean roleOfFound = false;
        String parentWithRoleOf = "";

        for (String parentName : cl.getExtendsList()) {
            ClassType parent = (ClassType) parseRes.getType(parentName);
            if (checkMultiInheritanceConflictsSingle(cl, parent, res.allMembers, parseRes, checked)) {
                if (roleOfFound) {
                    throw new SchemaDefinitionException(String.format("Class '%1$s' inherits 'role of' from both '%2$s' and '%3$s' parent classes",
                            cl.getName(), parentName, parentWithRoleOf));
                } else {
                    roleOfFound = true;
                    parentWithRoleOf = parentName;
                }
            }
        }

        if (cl.getRoleOf() != null) {
            if (roleOfFound) {
                throw new SchemaDefinitionException(String.format("Class '%1$s' has 'role of' defined and inherits 'role of' from '%2$s' parent class",
                        cl.getName(), parentWithRoleOf));
            }
            roleOfFound = true;
            ClassType roleOf = (ClassType) parseRes.getType(cl.getRoleOf());
            checkMultiInheritanceConflictsSingle(cl, roleOf, res.allMembers, parseRes, checked);
        }

        res.hasRoleOf = roleOfFound;

        // add current class fields, overwirite if exists
        for (Iterator<StructMember> iter = cl.getOwnMembersIterator(); iter.hasNext();) {
            StructMember m = iter.next();
            if (m.getScope() != ScopeEnum.Private) {
                res.allMembers.put(m.getObjectName(), cl.getName());
            }
        }

        // add current class methods, overwirite if exists
        for (Iterator<Method> iter = cl.getOwnMethodsIterator(); iter.hasNext();) {
            Method m = iter.next();
            if (m.getScope() != ScopeEnum.Private) {
                res.allMembers.put(m.getSignature(), cl.getName());
            }
        }

        return res;
    }

    private boolean checkMultiInheritanceConflictsSingle(ClassType cl, ClassType parent, Map<String, String> allMembers, SchemaParseResult parseRes, HashSet<String> checked) {
        MultiInheitanceCheckRes res = checkMultiInheritanceConflicts(parent, parseRes, checked);

        for (String membName : res.allMembers.keySet()) {

            // members was already inherited from another parent
            if (allMembers.containsKey(membName)) {
                if (cl.getOwnMemberByName(membName) != null || cl.getOwnMethodBySignature(membName) != null) {
                    // conflict will be overwritten in current class => do nothing
                    continue;
                }

                throw new SchemaDefinitionException(String.format("Multi-inheritance conflict in schema. Member '%1$s' of class '%4$s' was inherited from both %2$s and %3$s classes",
                        membName, allMembers.get(membName), res.allMembers.get(membName), cl.getName()), SchemaDefinitionException.MULTI_INHERITANCE_CONFLICT);
            }

            allMembers.put(membName, res.allMembers.get(membName));
        }

        return res.hasRoleOf;
    }

    /**
     * Sometimes 2 methods have different signatures, only because their correponding parameters
     * have different type names. Here we check if that types are not in child-parent
     * relation in inheritance hierarchy
     * @param cl
     * @param parseRes
    //     */
//    private void findAmbigousSignatures(ClassType cl, InheritanceGraph ig) {
//
//        // MINE AND INHERITED METHODS, not only MINE !!!
//
//        Method[] methods = cl.getMethodsBySignatureMap().values().toArray(new Method[0]);
//        for (int i = 0; i < methods.length; i++) {
//            for (int j = i + 1; j < methods.length; j++) {
//
//                Method m1 = methods[i];
//                Method m2 = methods[j];
//
//                if (m2.getName().compareTo(m1.getName()) != 0 || m2.getParameters().size() != m1.getParameters().size()) {
//                    continue;
//                }
//
//                for (int k = 0; k < m1.getParameters().size(); k++) {
//
//                    StructMember p1 = m1.getParameters().get(k);
//                    StructMember p2 = m2.getParameters().get(k);
//
//                    if (p1.getName().compareTo(p2.getName()) == 0) {
//                        continue;
//                    }
//
//                    if (p1.getTypeKind() == TypeEnum.Pointer ^ p2.getTypeKind() == TypeEnum.Pointer) {
//                        continue;
//                    }
//
//                    if (ig.isSubclass(p1.getTypeName(), p2.getTypeName())) {
//                        throw new SchemaDefinitionException(String.format("Methods %1%s and %2$s are amigous because of inheritance relation between types %3%s and %4$s (parameter number %5$d)", m1.getName(), m2.getName(), p1.getTypeName(), p2.getTypeName(), k));
//                    }
//
//                }
//            }
//
//        }
//    }
    private void checkTypesMatching(StructMemberImpl cm, SchemaParseResult parseRes) {

        if (cm.getDefaultValue() == null) {
            return;
        }

        SchemaType type = parseRes.getType(cm.getObjectTypeName());
        TypeEnum memberTypeKind = null;
        if (type == null) {
            memberTypeKind = SchemaUtils.PREDEFINED_TYPES_BY_NAME.get(cm.getObjectTypeName());
            if (memberTypeKind == null) {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): type %2$s doesn't exist", cm.getLine(), cm.getObjectTypeName()));
            }

        } else {
            memberTypeKind = getTypeKindOfDefaultValue(type);
        }

        Object val = cm.getDefaultValue();

        if (val instanceof EnumReference) {
            // enum (must be the same enum at left side)
            if (type instanceof EnumerationType) {
                EnumerationType enm = (EnumerationType) type;
                EnumReference er = (EnumReference) val;
                if (er.getEnumName().compareTo(enm.getName()) != 0) {
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): enum %2$s cannot have default value from different enum %3$s", cm.getLine(), memberTypeKind.toString(), er.getEnumName()));
                }

                boolean found = false;
                for (EnumerationConstant ec : enm.getAllowedValues()) {
                    if (ec.getName().compareTo(er.getEnumConstName()) == 0) {
                        // replace enum reference with real enum value
                        cm.setDefaultValue(ec.getName());
                        found = true;
                        break;

                    }
                }
                if (!found) {
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): enum %2$s doesn't have constant named %3$s", cm.getLine(), memberTypeKind.toString(), er.getEnumConstName()));
                }

            } else {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): type %2$s doesn't cannot have default value from enum %3$s", cm.getLine(), memberTypeKind.toString(), cm.getObjectTypeName()));
            }

        } else {
            // literal (must be a type of the same domain at the left side ot its restriction)
            if (!memberTypeKind.canHaveLiteralDefaultValue()) {
                throw new SchemaDefinitionException(String.format("Schema error (line %1$d): type %2$s cannot have default value. Given default is '%3$s'", cm.getLine(), memberTypeKind.toString(), val.toString() + " " + val.getClass()));
            }

            if (type != null && type.getTypeKind() == TypeEnum.Restriction) {
                getValuesChecker().checkRestriction((RestrictionType) type, val, null);
                return;

            }

            switch (memberTypeKind) {
                case String:
                    if (!(val instanceof String)) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine(), memberTypeKind.toString()));
                    }

                    break;
                case Boolean:
                    if (!(val instanceof Boolean)) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine(), memberTypeKind.toString()));
                    }

                    break;
                case Byte:
                case Integer:
                case Long:
                case Short:
                    if (!(val instanceof Long)) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine(), memberTypeKind.toString()));
                    }

                    getValuesChecker().checkNumericValue((Number) val, memberTypeKind, null);
                    break;

                case DateTime:
                    if (!(val instanceof Calendar)) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine(), memberTypeKind.toString()));
                    }

                    break;
                case Double:
                    if (!(val instanceof Double)) {
                        throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine(), memberTypeKind.toString()));
                    }

                    break;
                default:
                    throw new SchemaDefinitionException(String.format("Schema error (line %1$d): value given as default or constant doesn't match the type '%2$s'", cm.getLine()));
            }

        }
    }

    private TypeEnum getTypeKindOfDefaultValue(SchemaType type) {
        if (type instanceof RestrictionType) {
            RestrictionType restr = (RestrictionType) type;
            return restr.getBaseTypeKind();
        }

        if (type.getTypeKind() == null) {
            throw new Error(String.format("TypeKind of '%1$s' type is null in parse result", type.getName()));
        }

        return type.getTypeKind();
    }

    private void checkReferencedTypesPresence(SchemaParseResult parseResult) throws SchemaDefinitionException {
        for (String typeName : parseResult.getReferencedTypesNames()) {
            if (parseResult.getType(typeName) == null) {
                throw new SchemaDefinitionException(String.format("Type %1$s is referenced but was not declared", typeName));
            }

        }
    }

    public void checkCyclePresence(InheritanceGraph ig) {
        Set<String> cycle = ig.isCyclic();
        if (cycle != null) {
            String msg = "";
            boolean first = true;
            for (String s : cycle) {
                if (first) {
                    first = false;
                } else {
                    msg += ", ";
                }

                msg += s;
            }

            throw new SchemaDefinitionException(String.format("Cycle in inheritance graph detected: %1$s", msg));
        }
    }

    private void checkEnumsWithRootMemberConfilcts(SchemaParseResult pres) {
        HashSet<String> enumNames = new HashSet<String>();
        for (SchemaType t : pres.getTypes().values()) {
            if (t.getTypeKind() == TypeEnum.Enum) {
                enumNames.add(t.getName());
            }
        }

        SchemaType root = pres.getRootType();
        if (root == null) {
            return;
        }

        if (root instanceof StructType) {
            Iterator<StructMember> iter = ((StructType) root).getOwnMembersIterator();
            while (iter.hasNext()) {
                StructMember sm = iter.next();
                if (enumNames.contains(sm.getObjectName())) {
                    throw new SchemaDefinitionException(String.format("Enum '%1$s' is in conflict with root member named '%2$s'. Rename member on enum.", sm.getObjectName()));
                }
            }
        }
    }
}
