/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl.parser.antlr;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.ParserRuleReturnScope;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.tree.CommonTree;
import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParser;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.SchemaParseResultImpl;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaParserImpl implements SchemaParser {

    protected Logger logger = Logger.getLogger(SchemaParserImpl.class);

    private String readFileAsString(File file) throws FileNotFoundException, IOException {
        StringBuffer fileData = new StringBuffer(1000);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        char[] buf = new char[1024];
        int numRead = 0;
        while ((numRead = reader.read(buf)) != -1) {
            String readData = String.valueOf(buf, 0, numRead);
            fileData.append(readData);
            buf = new char[1024];
        }
        reader.close();
        return fileData.toString();
    }

    public SchemaParseResultImpl parseSchemaFromFile(String schemaDefinitionFilePath) throws SchemaDefinitionException, IOException {
        List<String> imports = new LinkedList<String>();
        List<String> allImports = new LinkedList<String>();
        return parseSchemaDefinition(schemaDefinitionFilePath, imports, allImports, false, false);
    }

    public SchemaParseResultImpl parseSchemaFromString(String schemaDefinition) throws SchemaDefinitionException {
        return parseSchemaDefinitionWithNoImports(schemaDefinition, false, false);
    }

    private SchemaParseResultImpl parseSchemaDefinitionWithNoImports(String schemaDefinition, boolean isImport, boolean isAlreadyImported) throws SchemaDefinitionException {

        try {
            ANTLRStringStream cs = new ANTLRStringStream(schemaDefinition);
            JLoximSchemaLexer lexer = new JLoximSchemaLexer(cs);
            CommonTokenStream tokens = new CommonTokenStream(lexer);

            CustomJLoximSchemaParser parser = new CustomJLoximSchemaParser(tokens);
            ParserRuleReturnScope res = parser.schema();

            int errCnt = parser.getNumberOfSyntaxErrors();
            if (errCnt > 0) {
                throw new SchemaDefinitionException("There are syntax errors in schema. Check log messages", parser.getErrors());
            }

            CommonTree ct = (CommonTree) res.getTree();
            AntlrTreeTranslator translator = new AntlrTreeTranslator();

            return translator.translateTree(ct, isImport, isAlreadyImported);
            
        } catch (RecognitionException e) {
            throw new SchemaDefinitionException(e);
        }
    }

    private SchemaParseResultImpl parseSchemaDefinition(String schemaDefinitionFilePath, List<String> importsInPath, List<String> allImports, boolean isImport, boolean isDuplicateImport) throws SchemaDefinitionException, IOException {

        logger.debug("schemaDefinitionFilePath: " + schemaDefinitionFilePath + ", isImport=" + isImport);

        File schemaFile = new File(schemaDefinitionFilePath);
        SchemaParseResultImpl parseRes = parseSchemaDefinitionWithNoImports(
                readFileAsString(schemaFile), isImport, isDuplicateImport);

        Map<String, String> importsCanonicalNames = new HashMap<String, String>();
        String baseDir = schemaFile.getParent();

        // converting imports to canonical names and removing duplicates
        for (String fileToImport : parseRes.getImports()) {
            File importedSchema = new File(baseDir, fileToImport);
            String filePath = importedSchema.getCanonicalPath();
            if (importsCanonicalNames.containsValue(filePath)) {
                continue;
            }
            importsCanonicalNames.put(fileToImport, filePath);
        }

        // parsing types from imported schemas and adding types
        for (String fileToImport : importsCanonicalNames.values()) {
            if (importsInPath.contains(fileToImport)) {
                throw new SchemaDefinitionException(String.format("Cycle in imports detected: importing %1$s in schema %2$s causes a cyclic import!",
                        fileToImport, parseRes.getSchemaId()));
            }
            importsInPath.add(fileToImport);
            boolean isDuplicate = false;
            if (allImports.contains(fileToImport)) {
                isDuplicate = true;
            } else {
                allImports.add(fileToImport);
            }
            SchemaParseResultImpl importRes = parseSchemaDefinition(fileToImport, importsInPath, allImports, true, isDuplicate);
            importsInPath.remove(fileToImport);

            if (!isDuplicate) {
                for (SchemaType t : importRes.getTypes().values()) {
                    SchemaType tmp = parseRes.getType(t.getName());
                    if (tmp != null) {
                        throw new SchemaDefinitionException(String.format("Type name conflict occured! Type %1$s imported from file %3$s in schema %2$s has been already defined!",
                                t.getName(), parseRes.getSchemaId(), fileToImport));
                    }
                    parseRes.addType(t);
                }
            }
        }

        return parseRes;
    }
}
