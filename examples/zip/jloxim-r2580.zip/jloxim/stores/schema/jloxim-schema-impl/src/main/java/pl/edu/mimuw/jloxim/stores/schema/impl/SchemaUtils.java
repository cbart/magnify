/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;

/**
 * Utils used by schema implementation
 * @author Paweł Mantur
 */
public class SchemaUtils {

    public static final Map<String, TypeEnum> PREDEFINED_TYPES_BY_NAME =
            Collections.unmodifiableMap(new HashMap<String, TypeEnum>() {
        {
            put("atomic", TypeEnum.AnyAtomic);
            put("binary", TypeEnum.Binary);
            put("boolean", TypeEnum.Boolean);
            put("byte", TypeEnum.Byte);
            put("datetime", TypeEnum.DateTime);
            put("double", TypeEnum.Double);
            put("int", TypeEnum.Integer);
            put("long", TypeEnum.Long);
            put("short", TypeEnum.Short);
            put("string", TypeEnum.String);
            put("any", TypeEnum.AnyType);
        }
    });

    public static boolean isNumberInRangeOfType(Long value, TypeEnum type) {
        switch (type) {
            case Byte:
                return value >= Byte.MAX_VALUE && value <= Byte.MAX_VALUE;
            case Integer:
                return value >= Integer.MAX_VALUE && value <= Integer.MAX_VALUE;
            case Long:
                return value >= Long.MAX_VALUE && value <= Long.MAX_VALUE;
            case Short:
                return value >= Short.MAX_VALUE && value <= Short.MAX_VALUE;
            default:
                return false;
        }
    }
}

