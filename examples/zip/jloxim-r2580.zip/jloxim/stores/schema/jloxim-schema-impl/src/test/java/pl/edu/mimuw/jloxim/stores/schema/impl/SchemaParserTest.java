/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.stores.schema.api.SchemaParseResult;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.PointerType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;
import pl.edu.mimuw.jloxim.stores.schema.impl.metabase.MetabaseNaming;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.SchemaParseResultImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.antlr.SchemaParserImpl;
import pl.edu.mimuw.jloxim.utils.impl.FileUtil;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaParserTest {
  protected final static String _sampleSchema = "/good-schema/sample-schema";
  protected final static String _restrictionsTest = "/good-schema/restrictions-test";
  protected final static String _metabaseSchema = "/good-schema/metabaseSchema";

    @Test
    public void parsingTest() throws Exception {

        SchemaParserImpl p = new SchemaParserImpl();

        SchemaParseResultImpl res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(getClass().getResourceAsStream(_sampleSchema)));
        res.verify();

        // testing schema
        Assert.assertEquals("sampleSchema", res.getSchemaId());
        Assert.assertEquals(res.getSchemaId() + "#" + MetabaseNaming.ROOT_CLASS_NAME, res.getRootType().getName());

        // testing fileds
        ClassType testClass = (ClassType) res.getType("TestClass");
        Assert.assertNotNull(testClass);
        StructMember testClassMember = testClass.getOwnMemberByName("field1");
        Assert.assertNotNull(testClassMember);
        Assert.assertNotNull(testClassMember.getObjectTypeKind());
        Assert.assertNotNull(testClassMember.getObjectTypeName());
        Assert.assertFalse(testClassMember.getObjectTypeName().isEmpty());
        Assert.assertEquals(TypeEnum.Binary, testClassMember.getObjectTypeKind());
        Cardinality card = testClassMember.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(0, card.getMinOccurences().intValue());
        Assert.assertEquals(1, card.getMaxOccurences().intValue());
        ScopeEnum scope = testClassMember.getScope();
        Assert.assertNotNull(scope);
        Assert.assertEquals(ScopeEnum.Public, scope);
        Assert.assertEquals("field1", testClassMember.getObjectName());

        testClassMember = testClass.getOwnMemberByName("oneOrMany");
        Assert.assertEquals(1L, testClassMember.getCardinality().getMinOccurences().longValue());
        Assert.assertEquals(null, testClassMember.getCardinality().getMaxOccurences());

        testClassMember = testClass.getOwnMemberByName("field2");
        Assert.assertNotNull(testClassMember);
        Assert.assertEquals(TypeEnum.Pointer, testClassMember.getObjectTypeKind());
        card = testClassMember.getCardinality();
        Assert.assertEquals(0, card.getMinOccurences().intValue());
        Assert.assertEquals(null, card.getMaxOccurences());
        Assert.assertEquals(ScopeEnum.Public, testClassMember.getScope());
        Assert.assertEquals("field2", testClassMember.getObjectName());

        testClassMember = testClass.getOwnMemberByName("field3");
        Assert.assertNotNull(testClassMember);
        Assert.assertEquals(TypeEnum.String, testClassMember.getObjectTypeKind());
        card = testClassMember.getCardinality();
        Assert.assertEquals(7, card.getMinOccurences().intValue());
        Assert.assertEquals(7, card.getMaxOccurences().intValue());
        Assert.assertEquals(ScopeEnum.Protected, testClassMember.getScope());
        Assert.assertEquals("ok", (String) testClassMember.getDefaultValue());

        testClassMember = testClass.getOwnMemberByName("field4");
        Assert.assertNotNull(testClassMember);
        Assert.assertEquals("DepartamentsEnum", testClassMember.getObjectTypeName());
        card = testClassMember.getCardinality();
        Assert.assertEquals(2, card.getMinOccurences().intValue());
        Assert.assertEquals(null, card.getMaxOccurences());
        Assert.assertEquals(ScopeEnum.Private, testClassMember.getScope());

        testClassMember = testClass.getOwnMemberByName("field5");
        Assert.assertNotNull(testClassMember);
        Assert.assertEquals(TypeEnum.Integer, testClassMember.getObjectTypeKind());
        card = testClassMember.getCardinality();
        Assert.assertEquals(1, card.getMinOccurences().intValue());
        Assert.assertEquals(1, card.getMaxOccurences().intValue());
        Assert.assertEquals(ScopeEnum.Public, testClassMember.getScope());
        Assert.assertEquals(10L, testClassMember.getDefaultValue());
        Assert.assertEquals(6, membersCount(testClass));

        // testing extend list

        Assert.assertTrue(testClass.getExtendsList().size() == 1);
        Assert.assertTrue(testClass.getExtendsList().contains("BaseTestClass"));

        ClassType classWithMultiInheritance = (ClassType) res.getType("MultiInheritance");
        Assert.assertNotNull(classWithMultiInheritance);
        Assert.assertTrue(classWithMultiInheritance.getExtendsList().size() == 2);
        Assert.assertTrue(classWithMultiInheritance.getExtendsList().contains("BaseTestClass"));
        Assert.assertTrue(classWithMultiInheritance.getExtendsList().contains("Some Other Class"));

        // methods test
        ClassType emploeeClass = (ClassType) res.getType("Emploee");
        Assert.assertEquals(5, ownMethodsCount(emploeeClass));
        Method test = emploeeClass.getOwnMethodBySignature("test(&Company, &int)");
        Assert.assertNotNull(test);
        Assert.assertEquals("Emploee", test.getClassName());

        // method result test
        StructMember mres = test.getResultDeclaration();
        Assert.assertNotNull(mres);
        card = mres.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(1, card.getMinOccurences().intValue());
        Assert.assertEquals(null, card.getMaxOccurences());
        Assert.assertEquals("PointerToManagerAsMng", mres.getObjectTypeName());
        Assert.assertEquals(TypeEnum.Pointer, mres.getObjectTypeKind());

        // parametrs test
        StructMember p1 = test.getParameterByName("p1");
        Assert.assertNotNull(p1);
        card = p1.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(0, card.getMinOccurences().intValue());
        Assert.assertEquals(null, card.getMaxOccurences());
        Assert.assertEquals("PointerToCompanyAsCmp", p1.getObjectTypeName());
        Assert.assertEquals(TypeEnum.Pointer, p1.getObjectTypeKind());

        StructMember p2 = test.getParameterByName("p2");
        Assert.assertNotNull(p2);
        card = p2.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(0, card.getMinOccurences().intValue());
        Assert.assertEquals(1, card.getMaxOccurences().intValue());
        Assert.assertEquals("PointerToIntAsNum", p2.getObjectTypeName());
        Assert.assertEquals(TypeEnum.Pointer, p2.getObjectTypeKind());
    }

    @Test
    public void restrictionsTest() throws Exception {

        SchemaParserImpl p = new SchemaParserImpl();
        SchemaParseResultImpl res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(getClass().getResourceAsStream(_restrictionsTest)));
        res.verify();
        StringRestrictionType ltdCompanyName = (StringRestrictionType) res.getType("LtdCompanyName");
        Assert.assertNotNull(ltdCompanyName);
        Assert.assertEquals(".*(s|S)(p|P)\\.?\\w(z|Z)\\w(o|O)\\.?\\w(o|O)\\.?\\w", ltdCompanyName.getRegex());

        StringRestrictionType stringRestriction = (StringRestrictionType) res.getType("stringRestriction");
        Assert.assertNotNull(stringRestriction);
        Assert.assertEquals("[0-9]*", stringRestriction.getRegex());
        Assert.assertEquals(5, stringRestriction.getMinLength().intValue());
        Assert.assertEquals(10, stringRestriction.getMaxLength().intValue());

        DateRestrictionType dateRestriction = (DateRestrictionType) res.getType("dateRestriction");
        Assert.assertNotNull(dateRestriction);
        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date min = formatter.parse("01-01-2010 00:00:00");
        Calendar cal = Calendar.getInstance();
        cal.setTime(min);
        Assert.assertEquals(cal, dateRestriction.getMinValue());
        Date max = formatter.parse("31-12-2010 23:59:59");
        cal.setTime(max);
        Assert.assertEquals(cal, dateRestriction.getMaxValue());

        DoubleRestrictionType doubleRestriction = (DoubleRestrictionType) res.getType("doubleRestriction");
        Assert.assertNotNull(doubleRestriction);
        Assert.assertEquals(0.5, doubleRestriction.getMinValue());
        Assert.assertEquals(5.93, doubleRestriction.getMaxValue());

        LongRestrictionType intRestriction = (LongRestrictionType) res.getType("intRestriction");
        Assert.assertNotNull(intRestriction);
        Assert.assertEquals(-1000L, intRestriction.getMinValue().longValue());
        Assert.assertEquals(1000L, intRestriction.getMaxValue().longValue());

        LongRestrictionType ubyteRestriction = (LongRestrictionType) res.getType("byteRestriction");
        Assert.assertNotNull(ubyteRestriction);
        Assert.assertEquals(32L, ubyteRestriction.getMinValue().longValue());
        Assert.assertEquals(64L, ubyteRestriction.getMaxValue().longValue());
    }

    @Test
    public void checkLogicalErors() throws Exception {

        SchemaParserImpl p = new SchemaParserImpl();
        Assert.assertTrue(testClassFragment("", p));
        Assert.assertFalse(testClassFragment("f1[2, 1] : int;", p));
    }

    @Test
    public void multiInheritanceConflict() throws Exception {
        testWrongSchema("mulit-inheritance-conflict", "multi inheritance conflict not detected", SchemaDefinitionException.MULTI_INHERITANCE_CONFLICT);
    }

    @Test
    public void abstractClassField() throws Exception {
        testWrongSchema("abstract-class-field", "filed of abstract field not detected", SchemaDefinitionException.ERR_ABSTRACT_FIELD);
    }

    @Test
    public void multiInheritanceConflictOverwritten() throws Exception {
        SchemaParseResult res = testGoodSchema("multi-inheritance");
        ClassType cl = (ClassType) res.getType("C");
        Assert.assertEquals(2, cl.getExtendsList().size());
        StructMember cm = cl.getOwnMemberByName("field");
        Assert.assertEquals(TypeEnum.DateTime, cm.getObjectTypeKind());
    }

    @Test
    public void testPointerType() throws Exception {
        SchemaParserImpl p = new SchemaParserImpl();
        SchemaParseResultImpl res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(getClass().getResourceAsStream(_sampleSchema)));
        res.verify();
        PointerType p1 = (PointerType) res.getType("P1");
        Assert.assertNotNull(p1);
        Assert.assertEquals(p1.getName(), "P1");
        Assert.assertEquals(p1.getTypeKind(), TypeEnum.Pointer);
        Assert.assertEquals("Address", p1.getReferencedObjectTypeName());

        PointerType p2 = (PointerType) res.getType("P2");
        Assert.assertNotNull(p2);
        Assert.assertEquals("P1", p2.getReferencedObjectTypeName());

        PointerType p3 = (PointerType) res.getType("P3");
        Assert.assertNotNull(p3);
        Assert.assertEquals("int", p3.getReferencedObjectTypeName());

        ClassType cl = (ClassType) res.getType("PTest");
        Assert.assertNotNull(cl);
        StructMember a = cl.getOwnMemberByName("a");
        Assert.assertNotNull(a);
        Assert.assertEquals("P1", a.getObjectTypeName());

        StructMember b = cl.getOwnMemberByName("b");
        Assert.assertNotNull(b);
        Assert.assertEquals("P2", b.getObjectTypeName());
    }

    private boolean testClassFragment(String fragment, SchemaParserImpl p) {
        String schema = "schema sch { class cl {" + fragment + "}}";
        try {
            p.parseSchemaFromString(schema);
            return true;
        } catch (SchemaDefinitionException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void testWrongSchema(String wrongSchemaName, String msg, int expectedErrorCode) throws Exception {
        SchemaParserImpl p = new SchemaParserImpl();
        try {
            SchemaParseResult res = p.parseSchemaFromString(
                FileUtil.getInstance().streamToString(getClass().getResourceAsStream("/wrong-schema/" + wrongSchemaName)));
            res.verify();
        } catch (SchemaDefinitionException e) {
            Assert.assertEquals(expectedErrorCode, e.getErrorCode());
            return;
        }
        Assert.assertFalse(msg, true);
    }

    private SchemaParseResult testGoodSchema(String goodSchemaName) throws Exception {
        SchemaParserImpl p = new SchemaParserImpl();
        SchemaParseResult res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(getClass().getResourceAsStream("/good-schema/" + goodSchemaName)));
        res.verify();
        return res;
    }

    @Test
    public void parsingMetabaseTest() throws Exception {

        SchemaParserImpl p = new SchemaParserImpl();
        SchemaParseResultImpl res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(getClass().getResourceAsStream(_metabaseSchema)));
        res.verify();

        ClassType enumType = (ClassType) res.getType("EnumType");
        StructMember s = enumType.getOwnMemberByName("kind");
        Assert.assertTrue(s.isConstant());
        Assert.assertTrue(s.getDefaultValue() != null);
        Assert.assertTrue(s.getDefaultValue().getClass().toString(), s.getDefaultValue() instanceof String);

    }
    
    protected int ownMethodsCount(ClassType struct) {
      Iterator<Method> iter = struct.getOwnMethodsIterator();
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
  }

  protected int membersCount(StructType struct) {
      Iterator<StructMember> iter = struct.getOwnMembersIterator();
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
  }

}

