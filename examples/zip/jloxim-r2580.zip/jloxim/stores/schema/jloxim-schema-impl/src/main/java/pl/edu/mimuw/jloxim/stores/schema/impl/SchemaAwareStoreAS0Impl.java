/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.PathNameProvidingStoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaAwareStoreAS0;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * Implementation of schema aware store.
 *
 * Each schema aware store should have exectly one schema provider. Types of
 * objects are resolved by the path locating object in the store. If we want to know
 * the type of an object we have to check the type located under the same path
 * in the schema.
 *
 * TODO:
 * maybe it's better to register <code>PathNamesModificationListener</code>
 * for a <code>PathNamesObservingStoreAS0</code>. Methods which are schema independent
 * would go directly to the store, so that it would be more efficent.
 * We use <code>PathNamesObservingStoreAS0</code> in this implemenatation,
 * which can be easily refactored to implement <code>PathNamesModificationListener</code>
 *
 * @author Paweł Mantur
 */
public class SchemaAwareStoreAS0Impl implements SchemaAwareStoreAS0 {

    private Logger logger = Logger.getLogger(SchemaAwareStoreAS0.class);

    private PathNameProvidingStoreAS0 backingStorePathNameProviding;

    private SchemaProvider schemaProvider;

    private boolean lazySchemaCheckingActive;

    private SchemaAwareStoreObserver storeObserver;

    private NamesTranslator namesTranslator;

    protected AS0ObjectsFactory objectsFactory;

    protected AtomicValueFactory atomicValFacory;

    public NamesTranslator getNamesTranslator() {
        return namesTranslator;
    }

    public void setNamesTranslator(NamesTranslator namesTranslator) {
        this.namesTranslator = namesTranslator;
    }

    public PathNameProvidingStoreAS0 getbackingStorePathNameProviding() {
        return backingStorePathNameProviding;
    }

    public void setbackingStorePathNameProviding(PathNameProvidingStoreAS0 backingStorePathNameProviding) {
        this.backingStorePathNameProviding = backingStorePathNameProviding;
    }

    public SchemaProvider getSchemaProvider() {
        return schemaProvider;
    }

    public void setSchemaProvider(SchemaProvider schemaProvider) {
        this.schemaProvider = schemaProvider;
    }

    public void setLazySchemaCheckingActive(boolean lazySchemaChecking) {
        this.lazySchemaCheckingActive = lazySchemaChecking;
    }

    public boolean isLazySchemaCheckingActive() {
        return this.lazySchemaCheckingActive;
    }

    public AtomicValueFactory getAtomicValFacory() {
        return atomicValFacory;
    }

    public void setAtomicValFacory(AtomicValueFactory atomicValFacory) {
        this.atomicValFacory = atomicValFacory;
    }

    public AS0ObjectsFactory getObjectsFactory() {
        return objectsFactory;
    }

    public void setObjectsFactory(AS0ObjectsFactory objectsFactory) {
        this.objectsFactory = objectsFactory;
    }

    public SchemaAwareStoreAS0Impl() {
        storeObserver = new SchemaAwareStoreObserver(this);
    }

    public List<SchemaViolationStoreException> recheckSubtree(Transaction t, AbstractOid oid, boolean followReferences) {

        List<SchemaViolationStoreException> errors = new LinkedList<SchemaViolationStoreException>();
        List<AbstractOid> checkedObjects = new LinkedList<AbstractOid>();

        this.lazySchemaCheckingActive = true;
        try {
            StructMember objectDeclaration = storeObserver.getDeclarationForObject(t, oid);
            storeObserver.matchObjectToType(t, null, objectDeclaration, oid, followReferences, checkedObjects, errors);
            return errors;
        } finally {
            this.lazySchemaCheckingActive = false;
        }
    }

    //
    // ===================== schema-sesnitive methods (modification) =======================
    //
    public void setAtomicObjectValue(Transaction t, AbstractOid OID, AtomicValue value) throws StoreException {
        logger.debug("Schema aware store operation: setAtomicObjectValue");
        if (!lazySchemaCheckingActive) {
            storeObserver.setAtomicObjectValue(t, OID, value);
        }
        backingStorePathNameProviding.setAtomicObjectValue(t, OID, value);
    }

    public void setNewPointerObjectDestination(Transaction t, AbstractOid OID, AbstractOid destination_OID) throws StoreException {
        logger.debug("Schema aware store operation: setNewPointerObjectDestination");
        if (!lazySchemaCheckingActive) {
            storeObserver.setNewPointerObjectDestination(t, OID, destination_OID);
        }
        backingStorePathNameProviding.setNewPointerObjectDestination(t, OID, destination_OID);
    }

    public void setNewComplexObjectValue(Transaction t, AbstractOid OID, Collection<AS0ObjectEditable> subobjects) throws StoreException {
        logger.debug("Schema aware store operation: setNewComplexObjectValue");
        if (!lazySchemaCheckingActive) {
            storeObserver.setNewComplexObjectValue(t, OID, subobjects);
        }
        backingStorePathNameProviding.setNewComplexObjectValue(t, OID, subobjects);
    }

    public AbstractOid addSubobject(Transaction t, AbstractOid parent_OID, AS0ObjectEditable object) throws StoreException {
        logger.debug("Schema aware store operation: addSubobject");
        if (!lazySchemaCheckingActive) {
            storeObserver.addSubobject(t, parent_OID, object);
        }
        return backingStorePathNameProviding.addSubobject(t, parent_OID, object);
    }

    public void removeObject(Transaction t, AbstractOid OID) throws StoreException {
        logger.debug("Schema aware store operation: removeObject");
        if (!lazySchemaCheckingActive) {
            storeObserver.removeObject(t, OID);
        }
        backingStorePathNameProviding.removeObject(t, OID);
    }

    public void removeObjects(Transaction t, AbstractOid[] OIDs) throws StoreException {
        logger.debug("Schema aware store operation: removeObjects");
        if (!lazySchemaCheckingActive) {
            storeObserver.removeObjects(t, OIDs);
        }
        backingStorePathNameProviding.removeObjects(t, OIDs);
    }

    public void moveObject(Transaction t, AbstractOid OID, AbstractOid new_parent_oid) throws StoreException {
        logger.debug("Schema aware store operation: moveObject");
        if (!lazySchemaCheckingActive) {
            storeObserver.moveObject(t, OID, new_parent_oid);
        }
        backingStorePathNameProviding.moveObject(t, OID, new_parent_oid);
    }


    //
    // ===================== schema-sesnitive methods (using names) =======================
    //
    public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(Transaction t, AbstractOid OID, int nameID) throws StoreException {
        logger.debug("Schema aware store operation: getSubobjectOIDsByNameOID");

        return backingStorePathNameProviding.getSubobjectOIDsByNameOID(t, OID, nameID);
    }

    public ClosableIterator<AbstractOid> getRootsByName(Transaction t, int name_id) throws StoreException {
        logger.debug("Schema aware store operation: getRootsByName");

        return backingStorePathNameProviding.getRootsByName(t, name_id);
    }

    public void prefetchSubobjectsByParentIDandName(AbstractOid parentId, int nameId) {
        logger.debug("Schema aware store operation: prefetchSubobjectsByParentIDandName");

        backingStorePathNameProviding.prefetchSubobjectsByParentIDandName(parentId, nameId);
    }
    //
    // ===================== methods below are schema independent =======================
    //

    public String getStoreId() {
        return backingStorePathNameProviding.getStoreId();
    }

    public AbstractOid getSuperRootOid() {
        return backingStorePathNameProviding.getSuperRootOid();
    }

    public AbstractOid getConfigRootOid() {
      return backingStorePathNameProviding.getConfigRootOid();
  }

    public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException {
        return backingStorePathNameProviding.getParentOID(t, oid);
    }

    public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(Transaction t, AbstractOid OID) throws StoreException {
        return backingStorePathNameProviding.getSubobjectOIDsMap(t, OID);
    }

    public ClosableIterator<AbstractOid> getSubobjectOIDs(Transaction t, AbstractOid OID) throws StoreException {
        return backingStorePathNameProviding.getSubobjectOIDs(t, OID);
    }

    public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(Transaction t) throws StoreException {
        return backingStorePathNameProviding.getRootsMap(t);
    }

    public ClosableIterator<AbstractOid> getRoots(Transaction t) throws StoreException {
        return backingStorePathNameProviding.getRoots(t);
    }

    public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid OID) throws StoreException {
        return backingStorePathNameProviding.getObjectByOID(t, OID);
    }

    public ClosableIterator<AbstractOid> getReferrers(Transaction t, AbstractOid OID) throws StoreException {
        return backingStorePathNameProviding.getReferrers(t, OID);
    }

    public void prefetchObject(AbstractOid OID) {
        backingStorePathNameProviding.prefetchObject(OID);
    }

    public void prefetchObjects(AbstractOid[] OIDs) {
        backingStorePathNameProviding.prefetchObjects(OIDs);
    }

    public void prefetchDeepObject(AbstractOid OID) {
        backingStorePathNameProviding.prefetchDeepObject(OID);
    }

    public void prefetchDeepObjects(AbstractOid[] OIDs) {
        backingStorePathNameProviding.prefetchDeepObjects(OIDs);
    }

    public TypeOid getTypeIdForObject(Transaction t, AbstractOid oid) throws StoreException {
        try {
            List<Integer> path = backingStorePathNameProviding.getPathNameForObject(t, oid);
            return schemaProvider.getTypeOidByPath(path);
        } catch (NameTranslatorException e) {
            throw new StoreException(backingStorePathNameProviding.getStoreId(), "Failed to resolve path for object", e);
        }
    }

    public List<Integer> getPathNameForObject(Transaction t, AbstractOid oid) throws StoreException {
        return backingStorePathNameProviding.getPathNameForObject(t, oid);
    }
}
