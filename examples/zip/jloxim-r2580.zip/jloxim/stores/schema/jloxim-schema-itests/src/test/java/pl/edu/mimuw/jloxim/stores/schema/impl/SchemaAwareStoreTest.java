/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaAwareStoreTest extends SchemaAbstractTest {

    @Test
    public void testRecheckSubtreeMethod() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _metabaseSchema, null);

        SchemaAwareStoreAS0Impl store = getSchemaAwareStore();

        List<SchemaViolationStoreException> errors = store.recheckSubtree(t, LongOid.ZERO, true);
        for (SchemaViolationStoreException e : errors) {
            logger.error(e.getMessage());
        }

        Assert.assertEquals(0, errors.size());
        t.commit();
    }

    @Test
    public void testRecheckSubtreeMethod2() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _sampleSchemaWithMetabase, new String[]{_metabaseSchema});

        SchemaAwareStoreAS0Impl store = getSchemaAwareStore();

        List<SchemaViolationStoreException> errors = store.recheckSubtree(t, LongOid.ZERO, true);
        for (SchemaViolationStoreException e : errors) {
            logger.error(e.getMessage());
        }

        Assert.assertEquals(0, errors.size());
        t.commit();
    }

    @Test
    public void testCarstoresSchema() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _carstoresSchema, new String[] {_metabaseSchema});

        SchemaAwareStoreAS0Impl store = getSchemaAwareStore();

        store.setLazySchemaCheckingActive(true);
        loadStoreContentFromFile(t, "/store-content/cars_10kb.xml");
        store.setLazySchemaCheckingActive(false);

        logStoreContent(t);

        List<SchemaViolationStoreException> errors = store.recheckSubtree(t, LongOid.ZERO, true);
        for (SchemaViolationStoreException e : errors) {
            logger.error("", e);
        }
        Assert.assertEquals(0, errors.size());

        int nameID = getNamesTranslator().getOrRegisterName("Carstores");
        ClosableIterator<AbstractOid> iter = store.getRootsByName(t, nameID);
        if (iter.hasNext()) {
            errors = store.recheckSubtree(t, iter.next(), true);
            for (SchemaViolationStoreException e : errors) {
                logger.error("", e);
            }
            Assert.assertEquals(0, errors.size());
        } else {
            Assert.assertFalse(true);
        }
        iter.close();


        Assert.assertEquals(0, errors.size());
        t.commit();
    }

    @Test
    public void testSchemaWithVariants() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, "/good-schema/variants", new String[]{_metabaseSchema});

        SchemaAwareStoreAS0Impl store = getSchemaAwareStore();

        store.setLazySchemaCheckingActive(true);
        loadStoreContentFromFile(t, "/store-content/variantsContent.xml");
        store.setLazySchemaCheckingActive(false);

        logStoreContent(t);

        List<SchemaViolationStoreException> errors = store.recheckSubtree(t, LongOid.ZERO, true);
        for (SchemaViolationStoreException e : errors) {
            logger.error("", e);
        }
        Assert.assertEquals(0, errors.size());
    }

    @Test
    public void testSchemaWithVariantsErr() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, "/good-schema/variants", new String[]{_metabaseSchema});

        SchemaAwareStoreAS0Impl store = getSchemaAwareStore();

        store.setLazySchemaCheckingActive(true);
        loadStoreContentFromFile(t, "/store-content/variantsContent_err.xml");
        store.setLazySchemaCheckingActive(false);

        logStoreContent(t);

        List<SchemaViolationStoreException> errors = store.recheckSubtree(t, LongOid.ZERO, true);
        Assert.assertEquals(1, errors.size());

        SchemaViolationStoreException e = errors.get(0);
        Assert.assertEquals(SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT, e.getErrorCode());
    }
}
