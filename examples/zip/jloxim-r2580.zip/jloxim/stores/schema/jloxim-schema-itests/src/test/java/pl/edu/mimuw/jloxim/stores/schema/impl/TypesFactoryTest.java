/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.stores.schema.api.types.*;

/**
 *
 * @author Paweł Mantur
 */
public class TypesFactoryTest extends SchemaAbstractTest {

    @Test
    public void newCardinalityTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        Cardinality card = tf.newCardinality(4l, 32L);
        Assert.assertEquals(4L, card.getMinOccurences().longValue());
        Assert.assertEquals(32L, card.getMaxOccurences().longValue());
    }

    @Test
    public void newClassTypeTest() throws Exception {

        TypesFactory tf = getTypesFactory();

        Cardinality card = tf.newCardinality(0L, 1L);
        SchemaType t = tf.newSystemType(TypeEnum.Integer);
        StructMember member1 = tf.newStructMember("member1", card, 1, true, ScopeEnum.Protected, t);
        Assert.assertEquals("member1", member1.getObjectName());
        Assert.assertEquals(0L, member1.getCardinality().getMinOccurences().longValue());
        Assert.assertEquals(1L, member1.getCardinality().getMaxOccurences().longValue());
        Assert.assertEquals(1, member1.getDefaultValue());
        Assert.assertEquals(ScopeEnum.Protected, member1.getScope());
        Assert.assertEquals(TypeEnum.Integer, member1.getObjectTypeKind());
        Assert.assertEquals(true, member1.isConstant());
        List<StructMember> members = new LinkedList<StructMember>();
        members.add(member1);

        Cardinality paramCard = tf.newCardinality(0L, 1L);
        SchemaType t2 = tf.newSchemaType(TypeEnum.Class, "k1");
        StructMember param = tf.newStructMember("param1", paramCard, null, false, ScopeEnum.Protected, t2);
        List<StructMember> params = new LinkedList<StructMember>();
        params.add(param);

        Cardinality resCard = tf.newCardinality(1L, 1L);
        SchemaType t3 = tf.newSchemaType(TypeEnum.Restriction, "r1");
        StructMember res = tf.newStructMember(null, resCard, null, false, ScopeEnum.Protected, t3);
        Method method = tf.newMethod("met1", params, res, ScopeEnum.Public);

        Assert.assertEquals("met1", method.getName());
        Assert.assertNotNull(method.getParameterByName("param1"));
        Assert.assertEquals("param1", method.getParameterByName("param1").getObjectName());
        Assert.assertEquals("k1", method.getParameterByName("param1").getObjectTypeName());
        Assert.assertEquals(TypeEnum.Class, method.getParameterByName("param1").getObjectTypeKind());
        Assert.assertEquals(1, method.getParameters().size());
        Assert.assertNotNull(method.getResultDeclaration());
        Assert.assertEquals("r1", method.getResultDeclaration().getObjectTypeName());
        Assert.assertEquals(TypeEnum.Restriction, method.getResultDeclaration().getObjectTypeKind());
        Assert.assertEquals(ScopeEnum.Public, method.getScope());

        List<Method> methods = new LinkedList<Method>();
        methods.add(method);

        ClassType cl = tf.newClassType("cname", members, methods, null, ClassKindEnum.Selaed, "roleOfClassName", tf.newCardinality(1L, null));
        Assert.assertEquals(0, cl.getExtendsList().size());
        Assert.assertNotNull(cl.getOwnMethodBySignature(method.getSignature()));
        Assert.assertEquals(1, ownMethodsCount(cl));
        Assert.assertEquals("roleOfClassName", cl.getRoleOf());
        Assert.assertNotNull(cl.getRoleOfCardinality());
        Assert.assertEquals(1L, cl.getRoleOfCardinality().getMinOccurences().longValue());
        Assert.assertEquals(null, cl.getRoleOfCardinality().getMaxOccurences());
        Assert.assertEquals(ClassKindEnum.Selaed, cl.getClassKind());
        Assert.assertNotNull(cl.getOwnMemberByName("member1"));
        Assert.assertEquals(1, membersCount(cl));
        Assert.assertEquals(TypeEnum.Class, cl.getTypeKind());
    }

    @Test
    public void newDoubleRestrictionTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        DoubleRestrictionType drt = tf.newDoubleRestrictionType("name", 0.24, 9.234);
        Assert.assertEquals("name", drt.getName());
        Assert.assertEquals(TypeEnum.Double, drt.getBaseTypeKind());
        Assert.assertTrue(drt.getMaxValue().toString(), 9.234 == drt.getMaxValue());
        Assert.assertTrue(drt.getMinValue().toString(), 0.24 == drt.getMinValue());
        Assert.assertEquals(TypeEnum.Restriction, drt.getTypeKind());
    }

    @Test
    public void newDateRestrictionTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        Calendar min = getCalendar("01-01-2000 12:45");
        Calendar max = getCalendar("01-01-2010 12:45");
        DateRestrictionType drt = tf.newDateRestrictionType("name", min, max);
        Assert.assertEquals("name", drt.getName());
        Assert.assertEquals(TypeEnum.DateTime, drt.getBaseTypeKind());
        Assert.assertEquals(min, drt.getMinValue());
        Assert.assertEquals(max, drt.getMaxValue());
        Assert.assertEquals(TypeEnum.Restriction, drt.getTypeKind());
    }

    @Test
    public void newLongRestrictionTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        LongRestrictionType drt = tf.newLongRestrictionType("name", -10L, 100L);
        Assert.assertEquals("name", drt.getName());
        Assert.assertEquals(TypeEnum.Long, drt.getBaseTypeKind());
        Assert.assertTrue(drt.getMaxValue().toString(), 100 == drt.getMaxValue());
        Assert.assertTrue(drt.getMinValue().toString(), -10 == drt.getMinValue());
        Assert.assertEquals(TypeEnum.Restriction, drt.getTypeKind());
    }

    @Test
    public void newEnumerationTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        EnumerationConstant c1 = tf.newEnumerationConstant("c1");
        EnumerationConstant c2 = tf.newEnumerationConstant("c2");
        List<EnumerationConstant> constants = new LinkedList<EnumerationConstant>();
        constants.add(c1);
        constants.add(c2);
        EnumerationType e = tf.newEnumerationType("", constants);
        Assert.assertEquals("c1", c1.getName());
        Assert.assertEquals("c2", c2.getName());
        Assert.assertEquals(2, e.getAllowedValues().size());
    }

    @Test
    public void newPointerTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        PointerType pt = tf.newPointerType("k1", "k3", "k4");
        Assert.assertEquals("k3", pt.getReferencedObjectTypeName());
        Assert.assertEquals("k1", pt.getName());
        Assert.assertEquals("k4", pt.getReferencedObjectName());
        Assert.assertEquals(TypeEnum.Pointer, pt.getTypeKind());
    }

    @Test
    public void newStringRestrictionTypeTest() throws Exception {
        TypesFactory tf = getTypesFactory();
        StringRestrictionType srt = tf.newStringRestrictionType("strRes", 1, 5, ".*");
        Assert.assertEquals(TypeEnum.String, srt.getBaseTypeKind());
        Assert.assertEquals(5, srt.getMaxLength().intValue());
        Assert.assertEquals(1, srt.getMinLength().intValue());
        Assert.assertEquals("strRes", srt.getName());
        Assert.assertEquals(".*", srt.getRegex());
        Assert.assertEquals(TypeEnum.Restriction, srt.getTypeKind());
    }
}
