/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pl.edu.mimuw.jloxim.executors.api.ExecutionBundle;
import pl.edu.mimuw.jloxim.executors.api.ExecutionProcess;
import pl.edu.mimuw.jloxim.executors.api.ExecutionStatus;
import pl.edu.mimuw.jloxim.executors.api.ParsedStatement;
import pl.edu.mimuw.jloxim.executors.api.PreparedStatement;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.impl.BasicResultCollector;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseEditable;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypesFactory;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.SchemaParseResultImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.parser.antlr.SchemaParserImpl;
import pl.edu.mimuw.jloxim.stores.utils.common.AS0StoreContentLogger;
import pl.edu.mimuw.jloxim.stores.utils.xml.importer.XmlImporter;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.FileUtil;

/**
 *
 * @author Paweł Mantur
 */
public abstract class SchemaAbstractTest {

    protected Logger logger = Logger.getLogger(SchemaAbstractTest.class);

    private AbstractApplicationContext context;

    public synchronized ApplicationContext getContext() {
        if (context == null) {
            context = new ClassPathXmlApplicationContext("/SchemaTest-context.xml");
        }
        return context;
    }

    public StoreAS0 getStore() {
        return (StoreAS0) getContext().getBean("store", StoreAS0.class);
    }

    public MetabaseEditable getMetabase() {
        return (MetabaseEditable) getContext().getBean("metabase", MetabaseEditable.class);
    }

    public CachedSchemaProviderImpl getSchemaProvider() {
        return (CachedSchemaProviderImpl) getContext().getBean("schemaProvider", CachedSchemaProviderImpl.class);
    }

    public SchemaAwareStoreAS0Impl getSchemaAwareStore() {
        return (SchemaAwareStoreAS0Impl) getContext().getBean("schemaAwareStore", SchemaAwareStoreAS0Impl.class);
    }

    protected ExecutionBundle getExecutionBundle() {
        return getContext().getBean("executionBundle", ExecutionBundle.class);
    }

    protected XmlImporter getXmlImporter() {
        return (XmlImporter) getContext().getBean("xmlImporter", XmlImporter.class);
    }

    public TransactionManager getTM() {
        return (TransactionManager) getContext().getBean("transactionManager", TransactionManager.class);
    }

    public NamesTranslator getNamesTranslator() {
        return (NamesTranslator) getContext().getBean("namesTranslator", NamesTranslator.class);
    }

    private AS0ResultsetFactory getResultsetFactory() {
        return (AS0ResultsetFactory) getContext().getBean("resultsetFactory", AS0ResultsetFactory.class);
    }

    public TypesFactory getTypesFactory() {
        return (TypesFactory) getContext().getBean("typesFactory", TypesFactory.class);
    }

    public void initMetabaseFromSchemaDefinition(Transaction t, String schemaDefinitionFileName) throws IOException {
        if (schemaDefinitionFileName == null) {
            throw new Error("schemaDefinitionFileName is null");
        }
        initMetabaseFromSchemaDefinition(t, getMetabase(), schemaDefinitionFileName);
    }

    public void initMetabaseFromSchemaResource(Transaction t, String schemaDefinitionResource, String[] imports) throws IOException {
        SchemaParserImpl p = new SchemaParserImpl();
        InputStream str = getClass().getResourceAsStream(schemaDefinitionResource);
        SchemaParseResultImpl res = p.parseSchemaFromString(
            FileUtil.getInstance().streamToString(str));
        if (imports != null) {
            for (String i : imports) {
                str = SchemaAbstractTest.class.getResourceAsStream(i);
                SchemaParseResultImpl res2 = p.parseSchemaFromString(
                    FileUtil.getInstance().streamToString(str));
                res.addTypes(res2);
            }
        }
        res.verify();
        getMetabase().initFromParseResult(t, res);
        getSchemaProvider().refresh();
    }

    public void initMetabaseFromSchemaResource(Transaction t, String schemaDefinitionResource) throws IOException {
        SchemaParserImpl p = new SchemaParserImpl();
        InputStream str = SchemaAbstractTest.class.getResourceAsStream(schemaDefinitionResource);
        String def = FileUtil.getInstance().streamToString(str);
        SchemaParseResultImpl res = p.parseSchemaFromString(def);
        res.verify();
        getMetabase().initFromParseResult(t, res);
        getSchemaProvider().refresh();
    }

    public void initMetabaseFromSchemaDefinition(Transaction t, MetabaseEditable metabase, String schemaDefinitionFileName) throws IOException {
        SchemaParserImpl p = new SchemaParserImpl();
        SchemaParseResultImpl res = p.parseSchemaFromFile(schemaDefinitionFileName);
        res.verify();
        metabase.initFromParseResult(t, res);
        getSchemaProvider().refresh();
    }

    protected Calendar parseDate(String date) throws Exception {
        Date min = formatter.parse(date);
        Calendar cal = Calendar.getInstance();
        cal.setTime(min);
        return cal;
    }

    protected void performQueryOnSchema(String query) throws Exception {
        performQueryOnSchema(query, "/good-schema/sample-schema", null);
    }

    protected void loadStoreContentFromFile(Transaction t, String sampleDataFileName) throws Exception {
        XmlImporter importer = getXmlImporter();
        InputStream str = SchemaAwareExecutorTest.class.getResourceAsStream(sampleDataFileName);
        importer.setTransation(t);
        importer.importXmlFile(str);
    }

    protected AS0Resultset performQueryOnSchema(String query, String schemaDefFile, String sampleData) throws Exception {
        return performQueryOnSchema(query, schemaDefFile, sampleData, false, null);
    }

    protected AS0Resultset performQueryOnSchema(String query, String schemaDefFile, String sampleData, boolean performStaticTypeCheck, String[] imports) throws Exception {

        Transaction t = getExecutionBundle().getTransactionManager().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        logger.info("populating metabase... ");
        initMetabaseFromSchemaResource(t, schemaDefFile, imports);
        getSchemaAwareStore().getSchemaProvider().refresh();

        getSchemaAwareStore().setLazySchemaCheckingActive(true);

        logger.info("populating store... ");
        if (sampleData != null) {
            loadStoreContentFromFile(t, sampleData);
        }

        getSchemaAwareStore().setLazySchemaCheckingActive(false);

        logStoreContent(t);

        logger.info("Parsing query: " + query);
        ParsedStatement parsed = getExecutionBundle().getStmtParser().parse(query);
        logger.info("Parsed statement: " + parsed.toString());

        if (performStaticTypeCheck) {
            getExecutionBundle().getStmtTypesChecker().checkTypes(parsed);
        }

        logger.info("Preparing query...");
        PreparedStatement prepared = getExecutionBundle().getStmtPrepare().prepareStmt(parsed);

        try {
            logger.info("Executing statement...");
            BasicResultCollector resultsetConstructor = new BasicResultCollector(getResultsetFactory());
            ExecutionProcess ec = getExecutionBundle().getStmtExecutor().executeStatement(t, prepared, resultsetConstructor);
            ec.waitForFinish();

            logger.info("Executing done:" + ec.getStatus());

            //Assert.assertFalse(String.valueOf(ec.getFailureReason()), ec.getStatus() == ExecutionStatus.ACTIVE);

            if (ec.getStatus() != ExecutionStatus.DONE) {
                Assert.assertNotNull(ec.getFailureReason());
                SchemaViolationStoreException schemaExc = findSchemaError(ec.getFailureReason());
                if (schemaExc != null) {
                    logger.error("schema error message: " + schemaExc.getLocalizedMessage());
                    throw schemaExc;
                } else {
                    throw ec.getFailureReason();
                }
            }

            AS0Resultset res = resultsetConstructor.getResultset();
            t.commit();
            return res;

        } catch (Exception e) {
            t.rollback();
            throw e;
        }
    }

    protected SchemaViolationStoreException findSchemaError(Throwable error) {
        if (error != null) {
            if (error instanceof SchemaViolationStoreException) {
                return (SchemaViolationStoreException) error;
            } else {
                return findSchemaError(error.getCause());
            }
        }
        return null;
    }

    protected void execSchemaInvalidQuery(String query, String schema, String sampleData, int expectedErrorCode) throws Exception {
        execSchemaInvalidQuery(query, schema, sampleData, null, expectedErrorCode);
    }

    protected void execSchemaInvalidQuery(String query, String schema, String sampleData, String[] imports, int expectedErrorCode) throws Exception {
        try {
            performQueryOnSchema(query, schema, sampleData, false, imports);
        } catch (SchemaViolationStoreException e) {
            if (e.getErrorCode() == expectedErrorCode || expectedErrorCode == -1) {
                return; // ok
            } else {
                throw e;
            }
        }
        Assert.fail("errors were expected");
    }

    protected void logStoreContent(Transaction t) {
        logger.info("Metabase content: ");
        AS0StoreContentLogger storeLogger = new AS0StoreContentLogger();
        ClosableIterator<AbstractOid> iter = getStore().getRoots(t);
        while (iter.hasNext()) {
            AbstractOid id = iter.next();
            AS0ObjectRO obj = getStore().getObjectByOID(t, id);
            storeLogger.logAs0StoreContent(t, 10, obj, getStore(), getNamesTranslator());
        }
        iter.close();
    }

    protected final static String _sampleSchema = "/good-schema/sample-schema";

    protected final static String _sampleSchemaWithMetabase = "/good-schema/sampleWithMetabase";

    protected final static String _metabaseSchema = "/good-schema/metabaseSchema";

    protected final static String _restrictionsTest = "/good-schema/restrictions-test";

    protected final static String _carstoresSchema = "/good-schema/carstores";

    private static DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    protected Calendar getCalendar(String date) throws ParseException {
        Date min = formatter.parse("01-01-2010 00:00:00");
        Calendar cal = Calendar.getInstance();
        cal.setTime(min);
        return cal;
    }

    protected int membersCount(StructType struct) {
      Iterator<StructMember> iter = struct.getOwnMembersIterator();
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
  }

    protected int membersCount(StructType struct, SchemaProvider prov, MembersSetType mst) {
      Iterator<StructMember> iter = struct.getMembersIterator(prov, mst, ScopeEnum.Private);
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
  }

  protected int membersCount(StructType struct, SchemaProvider prov, MembersSetType mst, ScopeEnum scope) {
      Iterator<StructMember> iter = struct.getMembersIterator(prov, mst, scope);
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
  }

  protected int ownMethodsCount(ClassType struct) {
    Iterator<Method> iter = struct.getOwnMethodsIterator();
    int cnt = 0;
    while (iter.hasNext()) {
        iter.next();
        cnt++;
    }
    return cnt;
  }

}
