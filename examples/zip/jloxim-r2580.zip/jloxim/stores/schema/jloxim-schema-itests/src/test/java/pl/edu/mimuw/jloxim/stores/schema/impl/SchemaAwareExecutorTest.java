/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaViolationStoreException;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaAwareExecutorTest extends SchemaAbstractTest {

    @Test
    public void query3() throws Exception {
        performQueryOnSchema("/ :< 5 as number");
    }

    @Test
    public void query4() throws Exception {
        performQueryOnSchema("sbr.pointerTest.pnt := val", _sampleSchema, "/store-content/sample-store-content.xml");
    }

    @Test
    public void query5() throws Exception {
        execSchemaInvalidQuery("sbr.pointerTest.pnt := sbr.pointerTest.val2", _sampleSchema, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_INCOMPATIBLE_TYPE);
    }

    @Test
    public void query6() throws Exception {
        execSchemaInvalidQuery("/ :< \"abc\" as stringRestrAll", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_STRING_RESTRICTION_REGEX);
    }

    @Test
    public void query7() throws Exception {
        execSchemaInvalidQuery("/ :< \"109\" as stringRestrAll", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_STRING_RESTRICTION_MINLEN);
    }

    @Test
    public void query8() throws Exception {
        execSchemaInvalidQuery("/ :< \"1097575887567342\" as stringRestrAll", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_STRING_RESTRICTION_MAXLEN);
    }

    @Test
    public void query8ok() throws Exception {
        performQueryOnSchema("/ :< \"123456\" as stringRestrAll", _restrictionsTest, "/store-content/sample-store-content.xml");
    }

// DATE literals are not supported in SBQL parser yet!
//    @Test
//    public void query9() throws Exception {
//        execSchemaInvalidQuery("/ :< 01-01-2008 00:00:00 as dateRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MINVAL);
//    }
//
//    @Test
//    public void query10() throws Exception {
//        execSchemaInvalidQuery("/ :< 12-04-2011 00:00:00 as dateRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MAXVAL);
//    }
    @Test
    public void query9() throws Exception {
        execSchemaInvalidQuery("/ :< 0.4 as doubleRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MINVAL);
    }

    @Test
    public void query10() throws Exception {
        execSchemaInvalidQuery("/ :< 6.123 as doubleRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MAXVAL);
    }

    @Test
    public void query10a() throws Exception {
        performQueryOnSchema("/ :< 3.14 as doubleRestr", _restrictionsTest, "/store-content/sample-store-content.xml");
    }

    @Test
    public void query11() throws Exception {
        execSchemaInvalidQuery("/ :< -2000 as intRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MINVAL);
    }

    @Test
    public void query12() throws Exception {
        execSchemaInvalidQuery("/ :< 1024 as intRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MAXVAL);
    }

    @Test
    public void query12a() throws Exception {
        performQueryOnSchema("/ :< 5 as intRestr", _restrictionsTest, "/store-content/sample-store-content.xml");
    }

    @Test
    public void query13() throws Exception {
        execSchemaInvalidQuery("/ :< 21 as byteRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MINVAL);
    }

    @Test
    public void query14() throws Exception {
        execSchemaInvalidQuery("/ :< 87 as byteRestr", _restrictionsTest, "/store-content/sample-store-content.xml", SchemaViolationStoreException.ERR_RANGE_RESTRICTION_MAXVAL);
    }

    @Test
    public void query14a() throws Exception {
        performQueryOnSchema("/ :< 40 as byteRestr", _restrictionsTest, "/store-content/sample-store-content.xml");
    }

    @Test
    public void query15() throws Exception {
        AS0Resultset res = performQueryOnSchema("deref(sbr.def.intField)", _sampleSchema, "/store-content/sample-store-content.xml");
        Assert.assertTrue(res.getClass().toString(), res instanceof AS0ResultsetAtomic);
    }

    @Test
    public void query16() throws Exception {
        AS0Resultset res = performQueryOnSchema("deref(deref(sbr.pointerTest.pnt))", _sampleSchema, "/store-content/sample-store-content.xml");
        Assert.assertTrue(res.getClass().toString(), res instanceof AS0ResultsetAtomic);
        AS0ResultsetAtomic a = (AS0ResultsetAtomic) res;
        Assert.assertEquals(123, a.getValue().getValue());
    }

    @Test
    public void query17() throws Exception {
        AS0Resultset res = performQueryOnSchema("s.b := s.c", "/good-schema/recursive_pointers", "/store-content/recursive_pointers_content.xml", false, new String[]{"/good-schema/metabaseSchema"});
        Assert.assertTrue(res.getClass().toString(), res instanceof AS0ResultsetRef);

    }

    @Test
    public void query18() throws Exception {
        AS0Resultset res = performQueryOnSchema("s.a := s.a", "/good-schema/recursive_pointers", "/store-content/recursive_pointers_content.xml", false, new String[]{"/good-schema/metabaseSchema"});
        Assert.assertTrue(res.getClass().toString(), res instanceof AS0ResultsetRef);
    }

    @Test
    public void query19() throws Exception {
        execSchemaInvalidQuery("s.b := s.a", "/good-schema/recursive_pointers", "/store-content/recursive_pointers_content.xml", new String[]{"/good-schema/metabaseSchema"}, -1);
    }

    @Test
    public void testVariants() throws Exception {
        performQueryOnSchema("s.v1 := 1", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.v1 := 3.14", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});

        performQueryOnSchema("s.v2 := 1", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.v2 := \"ttt\"", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.v2 := true", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.v2 := 3.14", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.v2 := struct(1 as a)", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});

        performQueryOnSchema("s.r := struct(\"ttt\" as f1, 1 as a)", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.r := struct(\"ttt\" as f1, \"ttt\" as a)", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
        performQueryOnSchema("s.r := struct(\"ttt\" as f1, (sequence(s.v1)[1]) as a)", "/good-schema/variants", "/store-content/variantsContent.xml", false, new String[]{"/good-schema/metabaseSchema"});
    }

    @Test
    public void testVariantsErr() throws Exception {
        execSchemaInvalidQuery("s.v1 := true", "/good-schema/variants", "/store-content/variantsContent.xml", new String[]{"/good-schema/metabaseSchema"}, SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
        execSchemaInvalidQuery("s.v1 := \"tttt\"", "/good-schema/variants", "/store-content/variantsContent.xml", new String[]{"/good-schema/metabaseSchema"}, SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);

        execSchemaInvalidQuery("s.v2 := struct(1 as a, 1 as b)", "/good-schema/variants", "/store-content/variantsContent.xml", new String[]{"/good-schema/metabaseSchema"}, SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);

        execSchemaInvalidQuery("s.r := struct(true as a)", "/good-schema/variants", "/store-content/variantsContent.xml", new String[]{"/good-schema/metabaseSchema"}, SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
        execSchemaInvalidQuery("s.r := struct((sequence(s.v2)[0]) as a)", "/good-schema/variants", "/store-content/variantsContent.xml", new String[]{"/good-schema/metabaseSchema"}, SchemaViolationStoreException.ERR_NO_MATCHING_VARIANT);
    }
}
