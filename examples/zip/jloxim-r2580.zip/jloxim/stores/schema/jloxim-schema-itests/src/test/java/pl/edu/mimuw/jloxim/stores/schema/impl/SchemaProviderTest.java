/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseEditable;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.MembersSetType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.Method;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ScopeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructMember;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.api.types.VariantType;
import pl.edu.mimuw.jloxim.stores.schema.impl.metabase.MetabaseNaming;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationConstantImpl;
import pl.edu.mimuw.jloxim.stores.schema.impl.types.EnumerationTypeImpl;
import pl.edu.mimuw.jloxim.stores.utils.common.AS0StoreContentLogger;

import com.google.common.collect.ImmutableSet;

/**
 *
 * @author Paweł Mantur
 */
public class SchemaProviderTest extends SchemaAbstractTest {

    @Test
    public void testSchemaProvider() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _metabaseSchema, null);
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        Assert.assertNotNull(schemaProvider.getSchemaId());
        Assert.assertEquals("metabaseSchema", schemaProvider.getSchemaId());

        List<Integer> path = new LinkedList<Integer>();
        // empty path -> we should receive root type
        TypeOid rootTypeDesc = schemaProvider.getTypeOidByPath(path);
        Assert.assertNotNull(rootTypeDesc);

        logger.info("Metabase content: ");
        AS0StoreContentLogger storeLogger = new AS0StoreContentLogger();
        storeLogger.logAs0StoreContent(t, 10, getStore().getObjectByOID(t, getStore().getParentOID(t, rootTypeDesc)), getStore(), getNamesTranslator());
        t.commit();

        Assert.assertEquals(schemaProvider.getTypesByNameMap().size(), schemaProvider.getTypesByOidMap().size());
        Assert.assertTrue(schemaProvider.getTypesByNameMap().size() > 20);

        SchemaType metabase = schemaProvider.getTypeByName("Metabase");
        Assert.assertNotNull(metabase);
        Assert.assertNotNull(metabase);
        Assert.assertTrue(metabase instanceof ClassType);
        Assert.assertEquals("Metabase", metabase.getName());
        ClassType metabaseCl = (ClassType) metabase;

        StructMember schemaId = metabaseCl.getOwnMemberByName("schemaId");
        Assert.assertNotNull(schemaId);
        Assert.assertEquals("schemaId", schemaId.getObjectName());
        Cardinality card = schemaId.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(1, card.getMinOccurences().intValue());
        Assert.assertEquals(1, card.getMaxOccurences().intValue());
        Assert.assertNotNull(schemaProvider.getTypeByName("string"));
        Assert.assertEquals(schemaProvider.getTypeByName("string").getTypeOid(), schemaId.getObjectTypeOid());
        Assert.assertNotSame(schemaProvider.getTypeByName("int").getTypeOid(), schemaId.getObjectTypeOid());
        Assert.assertNull(schemaId.getDefaultValue());
        Assert.assertEquals(ScopeEnum.Public, schemaId.getScope());
        Assert.assertEquals(TypeEnum.String, schemaId.getObjectTypeKind());
        Assert.assertEquals("string", schemaId.getObjectTypeName());

        StructMember rootType = metabaseCl.getOwnMemberByName("rootType");
        Assert.assertNotNull(rootType);
        Assert.assertEquals("rootType", rootType.getObjectName());
        card = rootType.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(1, card.getMinOccurences().intValue());
        Assert.assertEquals(1, card.getMaxOccurences().intValue());
        Assert.assertEquals(schemaProvider.getTypeByName("PointerToClassTypeAsType").getTypeOid(), rootType.getObjectTypeOid());
        Assert.assertNull(rootType.getDefaultValue());
        Assert.assertEquals(ScopeEnum.Public, rootType.getScope());
        Assert.assertEquals(TypeEnum.Pointer, rootType.getObjectTypeKind());
        Assert.assertEquals("PointerToClassTypeAsType", rootType.getObjectTypeName());

        StructMember types = metabaseCl.getOwnMemberByName(MetabaseNaming.CLASSES);
        Assert.assertNotNull(types);
        Assert.assertEquals(MetabaseNaming.CLASSES, types.getObjectName());
        card = types.getCardinality();
        Assert.assertNotNull(card);
        Assert.assertEquals(1L, card.getMinOccurences().longValue());
        Assert.assertEquals(1L, card.getMaxOccurences().longValue());
        Assert.assertNull(types.getDefaultValue());
        Assert.assertEquals(ScopeEnum.Public, types.getScope());
        Assert.assertEquals(TypeEnum.Struct, types.getObjectTypeKind());
        //Assert.assertEquals("ClassType", types.getTypeName());

        SchemaType schemaType = schemaProvider.getTypeByOid(rootType.getObjectTypeOid());
        Assert.assertNotNull(schemaType);


    // TODO test
    }

    @Test
    public void testRefreshMethod() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _sampleSchema, null);

        MetabaseEditable metabase = getMetabase();
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();


        EnumerationTypeImpl newType = new EnumerationTypeImpl("NewEnum");
        EnumerationConstantImpl ec = new EnumerationConstantImpl();
        ec.setName("A");
//        ec.setValue(1L);
        newType.getAllowedValues().add(ec);
        ec = new EnumerationConstantImpl();
        ec.setName("B");
//        ec.setValue(2L);
        newType.getAllowedValues().add(ec);

        Assert.assertNull(schemaProvider.getTypeByName("NewEnum"));

        metabase.addTypes(t, ImmutableSet.of((SchemaType)newType));
        t.commit();

        Assert.assertNull(schemaProvider.getTypeByName("NewEnum"));

        schemaProvider.refresh();

        Assert.assertNotNull(schemaProvider.getTypeByName("NewEnum"));
    }

    @Test
    public void test() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _sampleSchema, null);

        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        StructType root = (StructType)schemaProvider.getRootType();
        StructMember m = root.getOwnMemberByName("number");
        Assert.assertEquals(TypeEnum.Integer, m.getObjectTypeKind());
    }

    @Test
    public void testDefaultsAndConsts() throws Exception {
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        ClassType cl = (ClassType) schemaProvider.getTypeByName("DefAndConst");
        StructMember memb = cl.getOwnMemberByName("intField");
        Assert.assertEquals(5, ((Number) memb.getDefaultValue()).intValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("boolField");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals(true, memb.getDefaultValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("dateField");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals(parseDate("12-12-2009 23:30:00"), memb.getDefaultValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("doubleConstPi");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals(3.14, memb.getDefaultValue());
        Assert.assertTrue(memb.isConstant());

        memb = cl.getOwnMemberByName("dept");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals("IT", memb.getDefaultValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("dept2");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals("Sales", memb.getDefaultValue());
        Assert.assertTrue(memb.isConstant());

        memb = cl.getOwnMemberByName("smallInt");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals(4, ((Number) memb.getDefaultValue()).intValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("smallString");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals("abc", memb.getDefaultValue());
        Assert.assertFalse(memb.isConstant());

        memb = cl.getOwnMemberByName("smallIntCnst");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals(4, ((Number) memb.getDefaultValue()).intValue());
        Assert.assertTrue(memb.isConstant());

        memb = cl.getOwnMemberByName("smallStringCnst");
        Assert.assertNotNull(memb.getDefaultValue());
        Assert.assertEquals("abc", memb.getDefaultValue());
        Assert.assertTrue(memb.isConstant());
    }

    @Test
    public void testClassMembers() throws Exception {
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        ClassType testClass = (ClassType) schemaProvider.getTypeByName("TestClass");
        Assert.assertEquals(6, membersCount(testClass));
        Assert.assertEquals(6, membersCount(testClass, schemaProvider, MembersSetType.OwnMembers));
        Assert.assertEquals(7, membersCount(testClass, schemaProvider, MembersSetType.OwnAndInherited));

        ClassType someOtherClass = (ClassType) schemaProvider.getTypeByName("Some Other Class");
        Assert.assertEquals(3, membersCount(someOtherClass));
        Assert.assertEquals(3, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Private));
        Assert.assertEquals(2, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Protected));
        Assert.assertEquals(1, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Public));

        Assert.assertEquals(5, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Private));
        Assert.assertEquals(4, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Protected));
        Assert.assertEquals(3, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Public));

        Assert.assertEquals(11, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Private));
        Assert.assertEquals(10, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Protected));
        Assert.assertEquals(8, membersCount(someOtherClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Public));
    }

    @Test
    public void testMethods() throws Exception {
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        ClassType emploeeClass = (ClassType) schemaProvider.getTypeByName("Emploee");
        Assert.assertEquals(5, ownMethodsCount(emploeeClass));
        for (Iterator<Method> iter = emploeeClass.getOwnMethodsIterator(); iter.hasNext();) {
            Method m = iter.next();
            if (m.getName().compareTo("changeSalary") == 0) {
                Assert.assertEquals(1, m.getParameters().size());
                StructMember p = m.getParameterByName("newSalary");
                Assert.assertEquals("double", p.getObjectTypeName());
                Assert.assertEquals(1L, p.getCardinality().getMinOccurences().longValue());
                Assert.assertEquals(1L, p.getCardinality().getMaxOccurences().longValue());
                Assert.assertEquals(TypeEnum.Double, p.getObjectTypeKind());
                Assert.assertEquals("Emploee", m.getClassName());
                StructMember res = m.getResultDeclaration();
                Assert.assertNull("res", res);
            }
        }
    }

    @Test
    public void testMethods2() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        SchemaProvider schemaProvider = getSchemaProvider();
        schemaProvider.refresh();

        ClassType testClass = (ClassType) schemaProvider.getTypeByName("TestClass");
        Assert.assertEquals(3, ownMethodsCount(testClass));
        Assert.assertEquals(1, methodsCount(testClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Public));
        Assert.assertEquals(2, methodsCount(testClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Protected));
        Assert.assertEquals(3, methodsCount(testClass, schemaProvider, MembersSetType.OwnMembers, ScopeEnum.Private));
        Assert.assertEquals(2, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Public));
        Assert.assertEquals(4, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Protected));
        Assert.assertEquals(5, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInherited, ScopeEnum.Private));
        Assert.assertEquals(2, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Public));
        Assert.assertEquals(4, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Protected));
        Assert.assertEquals(5, methodsCount(testClass, schemaProvider, MembersSetType.OwnAndInheritedAndRoleOf, ScopeEnum.Private));
    }

    @Test
    public void testVariants() throws Exception {
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, "/good-schema/variants", new String[]{_metabaseSchema});
        SchemaProvider schemaProvider = getSchemaProvider();
        VariantType v1 = (VariantType) schemaProvider.getTypeByName("V1");
        Assert.assertNotNull(v1);
        Assert.assertEquals(2, v1.getPossibleTypesNames().size());

        VariantType v2 = (VariantType) schemaProvider.getTypeByName("V2");
        Assert.assertEquals(5, v2.getPossibleTypesNames().size());

        ClassType clA = (ClassType) schemaProvider.getTypeByName("A");
        StructMember a = clA.getOwnMemberByName("a");
        Assert.assertEquals(TypeEnum.Variant, a.getObjectTypeKind());
        VariantType v3 = (VariantType) schemaProvider.getTypeByOid(a.getObjectTypeOid());
        Assert.assertEquals(3, v3.getPossibleTypesNames().size());
        Assert.assertEquals("int", v3.getPossibleTypesNames().get(0));
        Assert.assertEquals("string", v3.getPossibleTypesNames().get(1));
        Assert.assertEquals("B", v3.getPossibleTypesNames().get(2));
    }
    
    protected int methodsCount(ClassType struct, SchemaProvider prov, MembersSetType mst, ScopeEnum scope) {
      Iterator<Method> iter = struct.getMethodsIterator(prov, mst, scope);
      int cnt = 0;
      while (iter.hasNext()) {
          iter.next();
          cnt++;
      }
      return cnt;
    }
}
