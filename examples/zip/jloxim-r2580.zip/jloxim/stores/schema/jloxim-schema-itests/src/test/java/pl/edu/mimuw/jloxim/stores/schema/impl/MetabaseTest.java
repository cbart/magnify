/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.impl;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.schema.api.MetabaseEditable;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DateRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.DoubleRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.LongRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StringRestrictionType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.StructType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.impl.metabase.MetabaseNaming;

/**
 * Metabase tests.
 * SchemaProviderTests are also metabase tests, as SchemaProcider uses metabase internally.
 * @author Paweł Mantur
 */
public class MetabaseTest extends SchemaAbstractTest {

    @Test
    public void TestPersistentSchema() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        MetabaseEditable metabase = getMetabase();

        String schemaId = metabase.getSchemaId(t);
        Assert.assertNotNull(schemaId);
        Assert.assertTrue(schemaId.matches("sampleSchema"));

        TypeOid rootTypeOid = metabase.getRootTypeOid(t);
        Assert.assertNotNull(rootTypeOid);
        SchemaType rootType = metabase.getTypeByOid(t, rootTypeOid);
        Assert.assertNotNull(rootType);
        Assert.assertEquals(TypeEnum.Class, rootType.getTypeKind());
        Assert.assertEquals(metabase.getSchemaId(t) + "#" + MetabaseNaming.ROOT_CLASS_NAME, rootType.getName());
        StructType rootTypeClass = (StructType) rootType;
        Assert.assertNotNull(rootTypeClass.getOwnMembersIterator());
        Assert.assertEquals(4, membersCount(rootTypeClass));
        SchemaType root2 = metabase.getTypeByName(t, rootType.getName());
        Assert.assertNotNull(root2);

        t.commit();
    }

    @Test
    public void removeTest() throws Exception {

        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

        int ptSize = 0;
        for (TypeEnum type : TypeEnum.values()) {
            if (!type.isUesrDefined()) {
                ptSize++;
            }
        }

        initMetabaseFromSchemaResource(t, _sampleSchema, null);
        MetabaseEditable metabase = getMetabase();

        logStoreContent(t);

        logger.info("size before remove: " + metabase.getTypesByNameMap(t).size());
        Assert.assertTrue(metabase.getTypesByNameMap(t).size() > ptSize);
        metabase.removeAllTypes(t);
        logger.info("size after remove: " + metabase.getTypesByNameMap(t).size());
        Assert.assertEquals(ptSize, metabase.getTypesByNameMap(t).size());

        initMetabaseFromSchemaResource(t, _sampleSchema, null);

        Assert.assertTrue(metabase.getTypesByNameMap(t).size() > ptSize);
        metabase.removeAllTypes(t);
        Assert.assertEquals(ptSize, metabase.getTypesByNameMap(t).size());

        t.commit();
    }

    @Test
    public void restrictionsTest() throws Exception {
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        initMetabaseFromSchemaResource(t, _restrictionsTest, null);

        MetabaseEditable metabase = getMetabase();

        SchemaType rootType = metabase.getTypeByOid(t, metabase.getRootTypeOid(t));
        Assert.assertNotNull(rootType);
        Assert.assertEquals(metabase.getSchemaId(t) + "#" + MetabaseNaming.ROOT_CLASS_NAME, rootType.getName());
        Assert.assertEquals(6, membersCount((StructType) rootType));
        SchemaType stringRestrictionBase = metabase.getTypeByName(t, "stringRestriction");
        Assert.assertNotNull(stringRestrictionBase);
        Assert.assertTrue(stringRestrictionBase instanceof StringRestrictionType);
        StringRestrictionType stringRestriction = (StringRestrictionType) stringRestrictionBase;
        Assert.assertNotNull(stringRestriction.getRegex());
        Assert.assertEquals("[0-9]*", stringRestriction.getRegex());
        Assert.assertNotNull(stringRestriction.getMinLength());
        Assert.assertEquals(5, stringRestriction.getMinLength().intValue());
        Assert.assertNotNull(stringRestriction.getMaxLength());
        Assert.assertEquals(10, stringRestriction.getMaxLength().intValue());

        SchemaType dateRestrictionBase = metabase.getTypeByName(t, "dateRestriction");
        Assert.assertNotNull(dateRestrictionBase);
        Assert.assertTrue(dateRestrictionBase instanceof DateRestrictionType);
        DateRestrictionType dateRestriction = (DateRestrictionType) dateRestrictionBase;
        Assert.assertNotNull(dateRestriction.getMinValue());
        Assert.assertEquals(parseDate("01-01-2010 00:00:00"), dateRestriction.getMinValue());
        Assert.assertNotNull(dateRestriction.getMaxValue());
        Assert.assertEquals(parseDate("31-12-2010 23:59:59"), dateRestriction.getMaxValue());

        SchemaType baseRestriction = metabase.getTypeByName(t, "doubleRestriction");
        Assert.assertNotNull(baseRestriction);
        Assert.assertTrue(baseRestriction instanceof DoubleRestrictionType);
        DoubleRestrictionType doubleRestriction = (DoubleRestrictionType) baseRestriction;
        Assert.assertNotNull(doubleRestriction.getMinValue());
        Assert.assertEquals(0.5, doubleRestriction.getMinValue());
        Assert.assertNotNull(doubleRestriction.getMaxValue());
        Assert.assertEquals(5.93, doubleRestriction.getMaxValue());

        baseRestriction = metabase.getTypeByName(t, "intRestriction");
        Assert.assertNotNull(baseRestriction);
        Assert.assertTrue(baseRestriction instanceof LongRestrictionType);
        LongRestrictionType intRestriction = (LongRestrictionType) baseRestriction;
        Assert.assertNotNull(intRestriction.getMinValue());
        Assert.assertEquals(-1000, intRestriction.getMinValue().intValue());
        Assert.assertNotNull(intRestriction.getMaxValue());
        Assert.assertEquals(1000, intRestriction.getMaxValue().intValue());

        baseRestriction = metabase.getTypeByName(t, "byteRestriction");
        Assert.assertNotNull(baseRestriction);
        Assert.assertTrue(baseRestriction instanceof LongRestrictionType);
        intRestriction = (LongRestrictionType) baseRestriction;
        Assert.assertNotNull(intRestriction.getMinValue());
        Assert.assertEquals(32, intRestriction.getMinValue().intValue());
        Assert.assertNotNull(intRestriction.getMaxValue());
        Assert.assertEquals(64, intRestriction.getMaxValue().intValue());

        t.commit();
    }
}
