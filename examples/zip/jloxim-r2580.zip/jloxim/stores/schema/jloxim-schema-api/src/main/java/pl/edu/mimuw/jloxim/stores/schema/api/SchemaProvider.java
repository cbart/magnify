/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api;

import java.util.List;
import java.util.Map;

import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeEnum;
import pl.edu.mimuw.jloxim.stores.schema.api.types.TypeOid;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException;

/**
 * Schema provider holds information about the type system during runtime.
 * In common implementation it reades types from metabase and keeps it in
 * a cache to provide the for other database components
 */
public interface SchemaProvider {

    /**
     * Gets type defined in schema by type name
     * @param typeName
     * @return
     */
    SchemaType getTypeByName(String typeName);

    /**
     * Gets a map of all types map defined in schema (by type name)
     * @return
     */
    Map<String, SchemaType> getTypesByNameMap();

    /**
     * Gets type defined in schema by type id
     * @param typeId
     * @return
     * @throws pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaProviderException
     */
    SchemaType getTypeByOid(TypeOid typeId) throws SchemaProviderException;

    /**
     * Gets a map of all types defined in schema (by type id)
     * @return
     */
    Map<TypeOid, SchemaType> getTypesByOidMap();

    /**
     * Gets the id of schema represented by this provider
     * @return
     */
    String getSchemaId();

    /**
     * Gets all types of given kind. For example it can be used to get all
     * classes or restrictions from schema
     * @param typeKind
     * @return
     */
    Map<String, SchemaType> getTypesByTypeKindMap(TypeEnum typeKind);

    /**
     * Forces this schema provider to update its cache by reading up to date
     * information from metabase. It should be called when underlying schema definition
     * changes
     */
    void refresh();

    /**
     * It is useful to know the type of object located under the specified path.
     * For example if a query is: Person.Familiy.Wife, we want to
     * know the type of objects selected by this query (Wife).
     *
     * This method gives the information about type by object path.
     *
     * If path is empty or is null this method returns the id of root type
     *
     * @param navigation path in the store
     * @return identifier of type under specified path 
     * @throws SchemaProviderException when specified path is not allowed by underlying schema
     */
    TypeOid getTypeOidByPath(List<Integer> objectLocationPath) throws SchemaProviderException;

    /**
     * Returns root type of schema.
     * @return SchemaType Gets the root type (type of superroot object)
     */
    SchemaType getRootType();
}
