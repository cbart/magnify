/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.exceptions;

import java.util.LinkedList;
import java.util.List;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;

/**
 * exception representing an error in external schema definition
 * @author Paweł Mantur
 */
public class SchemaDefinitionException extends JLoximException {

    private static final long serialVersionUID = -377876319213678449L;

    private static final String msgPrefix = "Schema definition error (line ";

    public static int ERR_GENERAL = 0;

    public static int ERR_ABSTRACT_FIELD = 1;

    public static int MULTI_INHERITANCE_CONFLICT = 1;

    private List<String> errorMessages = new LinkedList<String>();

    public SchemaDefinitionException() {
        super("There are syntax errors in schema. Check log messages");
    }

    public SchemaDefinitionException(String message, Throwable cause) {
        super(message, cause);
    }

    public SchemaDefinitionException(String message) {
        super(message);
    }

    public SchemaDefinitionException(String message, List<String> errorMessages) {
        super(message);
        this.errorMessages = errorMessages;
    }

    public SchemaDefinitionException(String message, int errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public SchemaDefinitionException(Throwable cause) {
        super(cause);
    }

    public SchemaDefinitionException(int line, String message) {
        super(msgPrefix + line + "): " + message);
    }

    private int errorCode;

    public int getErrorCode() {
        return errorCode;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }
}
