/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.signatures;

import pl.edu.mimuw.jloxim.stores.schema.api.types.Cardinality;

/**
 * Base interface for all signatures.
 * Signatures represent information about query results during static query eveluation.
 * They contain data about object type and oter properties which can be deducted
 * from metabase and query operators behaviour.
 *
 * @author Paweł Mantur
 */
public interface Signature {

    /**
     * Kinf of the signature
     * @see{SignaturesEnum}
     * @return
     */
    SignaturesEnum getSignatureKind();

    /**
     * @return Cardinlity of the result (how many objects are expected). Default is 1..1,
     * except for UnknownSignature for which default value is 0..1
     */
    Cardinality getCardinality();

    /**
     * Set the cadinality of signature
     * @param card
     */
    void setCardinality(Cardinality card);

    /**
     * @return Coolection kind can be Bag or Sequence. If upper cardnility is greater
     * tha1 1, the default colection kind is Bag. If upper cardinality is not more than 1 the
     * collection kind returns CollectionKindEnum.NotCollection
     */
    CollectionKindEnum getCollectionKind();

    /**
     * Set the collection kind of signature
     * @param colKind
     */
    void setCollectionKind(CollectionKindEnum colKind);

    /**
     * Gets type name attribute
     * @return
     */
    String getTypeName();

    /**
     * Sets type name attribute
     * @param typeName
     */
    void setTypeName(String typeName);

    /**
     * Gets mutability attribute
     * @return
     */
    boolean isMutable();

    /**
     * Sets mutability attribute
     * @param isMutable
     */
    void setMutable(boolean isMutable);

    /**
     * If signature represents an operator argument, this index indicates the index of argument
     * @return
     */
    int getIndex();

    /**
     * Sets argument index
     * @param index
     */
    void setIndex(int index);

    /**
     * Makes deep copy of signature
     * @return
     */
    public Signature copy();
}
