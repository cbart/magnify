/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.types;

/**
 * Enumeration for all kinds of types in system
 * @author Paweł Mantur
 */
public enum TypeEnum {

    /**** types for cmplex objects  ****/

    // user defined
    Class("class"),
    Struct("struct"), // anonymous

    // predefined
    //AnyComplex("complex"),
    /**** types for atomic objects ****/
    // user defined
    Enum("enum"),
    Restriction("restriction"),
    // predefined
    String("string"),
    Boolean("boolean"),
    Byte("byte"),
    Short("short"),
    Integer("int"),
    Long("long"),
    Double("double"),
    DateTime("datetime"),
    Binary("binary"),
    AnyAtomic("atomic"),
    /**** types for pointer objects ****/
    Pointer("pointer"),
    /** other ***/
    Method("method"),
    Variant("variant"),
    AnyType("any");

    private String symbol;

    private TypeEnum(String s) {
        symbol = s;
    }

    public String getSymbol() {
        return symbol;
    }

    public boolean isUesrDefined() {
        switch (this) {
            case Class:
            case Enum:
            case Method:
            case Pointer:
            case Restriction:
            case Struct:
            case Variant:
                return true;
            default:
                return false;
        }
    }

    public boolean isComplex() {
        return this == TypeEnum.Class || this == TypeEnum.Struct || this == TypeEnum.AnyType;
    }

    public boolean isAtomic() {
        return this == TypeEnum.AnyAtomic || this == TypeEnum.Binary || this == TypeEnum.Boolean || this == TypeEnum.Byte || this == TypeEnum.DateTime || this == TypeEnum.Double || this == TypeEnum.Enum || this == TypeEnum.Integer || this == TypeEnum.Long || this == TypeEnum.Restriction || this == TypeEnum.Short || this == TypeEnum.String || this == TypeEnum.AnyType;
    }

    public boolean canHaveLiteralDefaultValue() {
        return this == TypeEnum.Boolean || this == TypeEnum.Byte || this == TypeEnum.DateTime || this == TypeEnum.Double || this == TypeEnum.Integer || this == TypeEnum.Long || this == TypeEnum.Short || this == TypeEnum.String || this == TypeEnum.Restriction;
    }
}
