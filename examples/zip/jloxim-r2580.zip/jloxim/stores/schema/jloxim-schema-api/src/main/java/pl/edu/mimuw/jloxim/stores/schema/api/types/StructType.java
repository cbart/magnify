/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.types;

import java.util.Iterator;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;

/**
 *
 * @author Paweł Mantur
 */
public interface StructType extends SchemaType {

    /**
     * Gets class member by its name.
     * If type was read from metabase (TypeOid is not null) inherited members are accessable with this metod.
     * @param name Name of the member
     * @return
     */
    StructMember getMemberByName(String name, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope);

    StructMember getOwnMemberByName(String name);

    /**
     * Class kind: abstract, normal (default) or sealed.
     * @return
     * @see ClassKindEnum
     */
    ClassKindEnum getClassKind();

    /**
     * Gets members declared in this class (inherited members are not inluded)
     * @return
     */
    Iterator<StructMember> getOwnMembersIterator();

    /**
     * Gets members of this class. The set of members depends on @code{setType}
     * and @code{scope} attributes.
     * @see{MembersSetType}
     * @see{ScopeEnum}
     * @param schemaProvider
     * @param setType
     * @param scope
     * @return
     */
    Iterator<StructMember> getMembersIterator(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope);
}
