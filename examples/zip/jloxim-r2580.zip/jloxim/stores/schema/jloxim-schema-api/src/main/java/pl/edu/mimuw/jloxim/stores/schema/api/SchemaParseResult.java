/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api;

import java.util.List;
import java.util.Map;
import pl.edu.mimuw.jloxim.stores.schema.api.types.ClassType;
import pl.edu.mimuw.jloxim.stores.schema.api.types.SchemaType;
import pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException;

/**
 * Reporesents a parse result of external schema.
 *
 * @see{SchemaParser}
 * @author Paweł Mantur
 */
public interface SchemaParseResult {

    /**
     * Gets parsed type by name
     * @param name
     * @return
     */
    SchemaType getType(String name);

    /**
     * Gets all parsed types
     * @return
     */
    Map<String, SchemaType> getTypes();

    /**
     * Gets schema id
     * @return
     */
    String getSchemaId();

    /**
     * Gets root class of the schema
     * @return
     */
    SchemaType getRootType();

    /**
     * Gets paths of schema definition files used in current schema. Paths are defined
     * in ecternal schema by 'import' kewyword
     * @return
     */
    List<String> getImports();

    /**
     * Gets names of al the types referenced in this schema. If some of them are not
     * present in the schema, they should be imported from other schema, otherwise
     * schema is inconsistent
     * @return
     */
    List<String> getReferencedTypesNames();

    /**
     * Add types to this parse result from another parse result. It can be used
     * instead of 'import' keyword if you want to build a schema from multiple
     * definitions
     * @param parseRes
     */
    void addTypes(SchemaParseResult parseRes);

    /**
     * Verifies if schema definition is consistent. If logical errors are detected,
     * @code{SchemaDefinitionException} is thrown
     *
     * @throws pl.edu.mimuw.jloxim.stores.schema.exceptions.SchemaDefinitionException
     */
    void verify() throws SchemaDefinitionException;
}
