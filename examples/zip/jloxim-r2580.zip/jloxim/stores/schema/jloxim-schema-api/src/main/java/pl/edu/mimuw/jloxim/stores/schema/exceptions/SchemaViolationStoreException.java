/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.exceptions;

import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;

/**
 * Exception raised when attempting to made a modification in store which is
 * not allowed by schema constraints.
 *
 * @author Pawel Mantur
 */
public class SchemaViolationStoreException extends StoreException {

    public SchemaViolationStoreException(String storeId) {
        super(storeId);
    }

    public SchemaViolationStoreException(String storeId, String message, Throwable cause) {
        super(storeId, message, cause);
    }

    public SchemaViolationStoreException(String storeId, String message) {
        super(storeId, message);
    }

    public SchemaViolationStoreException(String storeId, Throwable cause) {
        super(storeId, cause);
    }

    public SchemaViolationStoreException(String storeId, String message, int code) {
        super(storeId, message);
        this.errorCode = code;
    }

    int errorCode;

    public int getErrorCode() {
        return errorCode;
    }

    public static int ERR_GENERAL = 0;

    public static int ERR_STRING_RESTRICTION_REGEX = 1;

    public static int ERR_STRING_RESTRICTION_MINLEN = 2;

    public static int ERR_STRING_RESTRICTION_MAXLEN = 3;

    public static int ERR_RANGE_RESTRICTION_MINVAL = 4;

    public static int ERR_RANGE_RESTRICTION_MAXVAL = 5;

    public static int ERR_COMPLEX_TYPE_EXPECTD = 6;

    public static int ERR_POINTER_EXPECTED = 7;

    public static int ERR_ATOMIC_VAL_EXPECTED = 8;

    public static int ERR_INCOMPATIBLE_TYPE = 9;

    public static int ERR_NO_MATCHING_VARIANT = 10;
}
