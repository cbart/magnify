/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.types;

/**
 * It is a class for representing objets declrataions.
 * Object declaration is for example a  class field or method parameter.
 *
 * @author Paweł Mantur
 */
public interface StructMember {

    /**
     * Name of the object
     * @return
     */
    String getObjectName();

    /**
     * Data type oid of the object
     * @return
     */
    TypeOid getObjectTypeOid();

    /**
     * type identifier
     * @return unique identifier of the type
     */
    TypeEnum getObjectTypeKind();

    /**
     * type name
     * @return name of the type
     */
    String getObjectTypeName();

    /**
     * Cardinality of this object
     * @return
     */
    Cardinality getCardinality();

    /**
     * If class member is an atmic field, it can have a default value
     * (not for all atmic types it is possible to define default value, 
     * for example for binary type it is not possible)
     *
     * Default value is implicity assigned to an object until it is explicity
     * set to some other value
     *
     * @return
     */
    Object getDefaultValue();

    /**
     * If the field is constant it alwas have the value defined as default value.
     * It cannot take other value than default
     *
     * @return
     */
    boolean isConstant();

    /**
     * Introduced in AS3 model.
     *
     * Sets visibility of the member. Scope can be public, protected or private
     * @return
     */
    ScopeEnum getScope();
}
