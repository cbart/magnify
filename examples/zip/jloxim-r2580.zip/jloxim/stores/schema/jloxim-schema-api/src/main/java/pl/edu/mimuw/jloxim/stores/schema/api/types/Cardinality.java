/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.types;

/**
 * Cardinality tells how many objects we can expect.
 *
 * @author Paweł Mantur
 */
public interface Cardinality {

    // used to represent unlimited number of occurences
    public static final Long INFINITY = -1L;

    /**
     * Minimal number of occurences. Null value means the same as 0
     * @return Not negative integer or null (interpreted as 0)
     */
    Long getMinOccurences();

    /**
     * Maximum number of occurences or null. If null it should be assumed that the
     * maximum number of occurences is unbounded.
     * @return Not negative integer or null (interpreted as infinity)
     */
    Long getMaxOccurences();

    /**
     * set min occurences
     * @param min
     */
    void setMinOccurences(Long min);

    /***
     * sets max occurences
     * @param max
     */
    void setMaxOccurences(Long max);
}
