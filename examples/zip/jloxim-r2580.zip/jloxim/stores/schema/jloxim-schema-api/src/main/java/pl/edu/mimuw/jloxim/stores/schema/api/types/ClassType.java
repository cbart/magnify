/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.schema.api.types;

import java.util.Iterator;
import java.util.List;
import pl.edu.mimuw.jloxim.stores.schema.api.SchemaProvider;

/**
 * Extends StructType to provide functionality for classes modelling.
 * Classes are not used in AS0 model, but they are introduced in higher level
 * store models: AS1, AS2 and AS3.
 *
 * @author Paweł Mantur
 */
public interface ClassType extends StructType {

    /**
     * This list contains parent classes in iheritance relation.
     * Multi-inheritance is allowed, so that there can be more than one
     * parent class.
     *
     * @return
     */
    List<String> getExtendsList();

    List<TypeOid> getExtendsListOid();

    /**
     * Methods contained by this class
     * If type was read from metabase (TypeOid is not null) inherited members are included.
     * @return
     */
    //Map<String, Method> getMethodsBySignatureMap();
    /**
     * If type was read from metabase (TypeOid is not null) inherited methods are accessable with this metod.
     * @param methodName
     * @return
     */
    Method getOwnMethodBySignature(String methodSignature);

    Method getMethodBySignature(String methodSignature, SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope);

    /**
     * Introduced in AS2 model.
     *
     * Instances of this class can be dynamic roles of a class specified here
     * @return name of the class
     */
    String getRoleOf();

    TypeOid getRoleOfOid();

    /**
     * This cardinality tells how many instances of this class can be
     * a role of single instance of 'role of' class
     * @return
     */
    Cardinality getRoleOfCardinality();

    /**
     * Returns true if this class is in static (as a subclass ) or dynamic 
     * (as a role) inheritance relation with superclass of given ID.
     *
     * @param schemaProvider
     * @param parentClassTypeOid 
     * @return
     */
    boolean isSubclassOf(SchemaProvider schemaProvider, String parentClassName);

    /**
     * Gets methods declared in this class (inherited methods are not inluded)
     * @return
     */
    Iterator<Method> getOwnMethodsIterator();

    /**
     * Gets methods of this class. The set of methods depends on @code{setType}
     * and @code{scope} attributes.
     * @see{MembersSetType}
     * @see{ScopeEnum}
     * @param schemaProvider
     * @param setType
     * @param scope
     * @return
     */
    Iterator<Method> getMethodsIterator(SchemaProvider schemaProvider, MembersSetType setType, ScopeEnum scope);
}
