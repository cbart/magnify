/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.as0.basic;

//~--- non-JDK imports --------------------------------------------------------

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.basic.trans.NullTransactionManager;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.tests.StoreAs0Test;

/**
 * Test are inherited from common tests
 * @author kadamczyk
 * @version $Id: StoreAS0ImplTest.java 1805 2010-05-30 20:18:56Z kadamczyk $
 */
public class StoreAS0ImplTest extends StoreAs0Test {
    @SuppressWarnings("unused")
    private static final Logger      logger             = Logger.getLogger(StoreAS0ImplTest.class);
    private final StoreAS0           storeAs0           = new StoreAS0Impl();
    private final TransactionManager transactionManager = new NullTransactionManager();

    @Override
    public StoreAS0 getStore() {
        return storeAs0;
    }

    @Override
    public TransactionManager getTM() {
        return transactionManager;
    }

    @Override
    public AS0ObjectsFactory getAS0ObjectsFactory() {
        return new AS0ObjectsFactoryImpl();
    }

    @Override
    public AtomicValueFactory getAtomicValueFactory() {
        return new AtomicValueFactoryImpl();
    }

    @Override
    @Ignore("This test checks if rollback works. The store does not support rollback")
    @Test
    public void addSubobjectsPointerRollback()
            throws TransactionManagerException, TransactionException, StoreException {
        super.addSubobjectsPointerRollback();
    }

    @Override
    @Test
    public void concurrentOperationsTest() throws Throwable {
        for (int i = 0; i < 100; i++) {
            super.concurrentOperationsTest();
        }
    }
}
