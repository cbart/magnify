/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.basic.trans;

import java.util.List;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;

/**
 * Only for tests
 * @author kadamczyk
 * @version $Id: NullTransactionManager.java 1693 2010-05-07 17:43:03Z ptab $
 */
public class NullTransactionManager implements TransactionManager {

    public Transaction newTransaction(TransactionIsolationLevel isolationLevel)
            throws TransactionManagerException {
        return new NullTransaction();
    }

    public List<Transaction> getAllActiveTransactions() {
        return null;
    }
}
