/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.basic;

import java.util.HashMap;
import java.util.Map.Entry;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundNameTranslatorException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.EntryISIterator;

/**
 * @author kdamczyk
 * @version $Id: NamesTranslatorImpl.java 2539 2011-12-02 00:24:35Z ptab $
 */
public class NamesTranslatorImpl implements NamesTranslator {
    private final HashMap<Integer, String> map = new HashMap<Integer, String>();
    private Integer counter = 0;
    
    public NamesTranslatorImpl() {
      map.put(SUPERROOT, SUPERROOT_NAME);
    }

    public synchronized int getOrRegisterName(String name) {
        EntryISIterator iterator = new EntryISIterator(map.entrySet());
        Entry<Integer, String> elem;
        while (iterator.hasNext()) {
            elem = iterator.next();
            if (elem.getValue().equals(name)) {
                return elem.getKey().intValue();
            }
        }
        map.put(counter, name);
        counter++;
        return counter - 1;
    }

    public synchronized String getNameByNameId(int nameId) {
        if (map.containsKey(nameId)) {
            return map.get(nameId);
        }
        throw new ObjectNotFoundNameTranslatorException();
    }

    public synchronized int getNameIdByName(String name)
            throws NameTranslatorException {
        EntryISIterator iterator = new EntryISIterator(map.entrySet());
        Entry<Integer, String> elem;
        while (iterator.hasNext()) {
            elem = iterator.next();
            if (elem.getValue().equals(name)) {
                return elem.getKey().intValue();
            }
        }
        throw new ObjectNotFoundNameTranslatorException();
    }

    public ClosableIterator<? extends Entry<Integer, String>> getAllEntries() {
        EntryISIterator iterator = new EntryISIterator(map.entrySet());
        return iterator;
    }

    public synchronized void removeName(String name)
            throws NameTranslatorException {
        EntryISIterator iterator = new EntryISIterator(map.entrySet());
        Entry<Integer, String> elem;
        while (iterator.hasNext()) {
            elem = iterator.next();
            if (elem.getValue().equals(name)) {
                iterator.remove();
                return;
            }
        }
        throw new ObjectNotFoundNameTranslatorException();
    }

    public void removeNameId(int nameId) throws NameTranslatorException {
        if (map.containsKey(nameId)) {
            map.remove(nameId);
        } else {
            throw new NameTranslatorException();
        }

    }
}
