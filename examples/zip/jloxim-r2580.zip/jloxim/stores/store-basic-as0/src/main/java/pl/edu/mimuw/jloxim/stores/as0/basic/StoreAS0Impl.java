/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.basic;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.basic.utils.ClosableAndSizeAwareAbstractOidIterator;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.util.*;

/**
 * @author kdamczyk
 * @version $Id: StoreAS0Impl.java 2539 2011-12-02 00:24:35Z ptab $
 */
public class StoreAS0Impl implements StoreAS0 {

    private static final Logger logger = Logger.getLogger(StoreAS0Impl.class);
    private final AS0ObjectsFactory objectsFactory = new AS0ObjectsFactoryImpl();
    private final String storeId = "BasicStoreAs0";
    private final Map<AbstractOid, AS0ObjectRO> realStore = new HashMap<AbstractOid, AS0ObjectRO>();
    private Long lastInsertedOid;

    /**
     *
     */
    public StoreAS0Impl() {
        AS0ComplexObjectEditable root = objectsFactory.newEmptyComplexObject(0);
        root.setOID(getSuperRootOid());
        realStore.put(getSuperRootOid(), root);
        
        AS0ComplexObjectEditable config = objectsFactory.newEmptyComplexObject(0);
        config.setOID(getConfigRootOid());
        config.setParentOID(getSuperRootOid());
        realStore.put(getConfigRootOid(), config);
        lastInsertedOid = 1L;
    }

    public String getStoreId() {
        return storeId;
    }

    private synchronized AbstractOid generateOID(Transaction t) {
        if (t != null) {
            logger.trace(
                    "This implementation of store does not support transaction, "
                            + " so transaction should be null");
        }
        return new LongOid(++lastInsertedOid);
    }

    private AS0ObjectRO getObjectOrSuperRootByOID(Transaction t, AbstractOid oid)
            throws StoreException {
        if (t != null) {
            logger.trace(
                    "This implementation of store does not support transaction, "
                            + " so transaction should be null");
        }
        synchronized (realStore) {
            if (!realStore.containsKey(oid)) {
                throw new ObjectNotFoundStoreException(getStoreId(),
                        "Cannot find object with OID=" + oid);
            }
            return realStore.get(oid);
        }
    }

    public AbstractOid getParentOID(Transaction t, AbstractOid oid)
            throws StoreException {
        return getObjectByOID(t, oid).getParentOID();
    }

    public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(
            Transaction t, AbstractOid oid) throws StoreException {
        AS0ObjectRO obj = this.getObjectOrSuperRootByOID(t, oid);
        if (!(obj instanceof AS0ComplexObjectEditable)) {
            return new HashMap<Integer, ClosableIterator<AbstractOid>>();
        }
        AS0ComplexObjectEditable compl = (AS0ComplexObjectEditable) obj;
        Iterator<AS0ObjectEditable> iter = compl.getSubobjects().iterator();
        TreeSet<Integer> names = new TreeSet<Integer>();
        while (iter.hasNext()) {
            names.add(iter.next().getNameId());
        }
        Iterator<Integer> namesIter = names.iterator();
        Map<Integer, ClosableIterator<AbstractOid>> result =
                new HashMap<Integer, ClosableIterator<AbstractOid>>();
        Integer key;
        while (namesIter.hasNext()) {
            key = namesIter.next();
            try {
                result.put(key, compl.getIteratorBySubobjectNameId(key));
            } catch (ModelException me) {
                throw new StoreException(
                        "Cannot create the map of iterators", me);
            }
        }
        return result;
    }

    public ClosableIterator<AbstractOid> getSubobjectOIDs(
            Transaction t, AbstractOid oid) throws StoreException {
        AS0ObjectRO object = getObjectByOID(t, oid);
        if (object instanceof AS0ComplexObjectEditable) {
            AS0ComplexObjectEditable complexObject =
                    (AS0ComplexObjectEditable) object;
            try {
                return complexObject.iterator();
            } catch (ModelException e) {
                throw new StoreException(getStoreId(), e);
            }
        }
        return new ClosableAndSizeAwareAbstractOidIterator();
    }

    public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(
            Transaction t, AbstractOid oid, int nameId) throws StoreException {
        ClosableIterator<AbstractOid> allSubobject =
                getSubobjectOIDs(t, oid);
        TreeSet<AbstractOid> set = new TreeSet<AbstractOid>();
        AS0ObjectRO o;
        while (allSubobject.hasNext()) {
            o = this.getObjectByOID(t, allSubobject.next());
            if (o.getNameId() == nameId) {
                set.add(o.getOID());
            }
        }
        return new ClosableAndSizeAwareAbstractOidIterator(set);
    }

    public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(
            Transaction t) throws StoreException {
        return this.getSubobjectOIDsMap(t, new LongOid(0L));
    }

    public ClosableIterator<AbstractOid> getRoots(Transaction t)
            throws StoreException {
        AS0ObjectRO object = getObjectOrSuperRootByOID(t, getSuperRootOid());
        if (object instanceof AS0ComplexObjectEditable) {
            AS0ComplexObjectEditable complexObject = (AS0ComplexObjectEditable) object;
            try {
                return complexObject.iterator();
            } catch (ModelException e) {
                throw new StoreException(getStoreId(), e);
            }
        } else {
            throw new StoreException(storeId,
                    "Superroot expected to be complex object");
        }
    }

    public ClosableIterator<AbstractOid> getRootsByName(
            Transaction t, int nameId) throws StoreException {
        ClosableIterator<AbstractOid> allSubobject = getRoots(t);
        TreeSet<AbstractOid> set = new TreeSet<AbstractOid>();
        AS0ObjectRO o;
        while (allSubobject.hasNext()) {
            o = this.getObjectByOID(t, allSubobject.next());
            if (o.getNameId() == nameId) {
                set.add(o.getOID());
            }
        }
        return new ClosableAndSizeAwareAbstractOidIterator(set);
    }

    public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid oid)
            throws StoreException {
        if (logger.isDebugEnabled()) {
          logger.debug("Getting object by OID:" + oid);
        }
        return getObjectOrSuperRootByOID(t, oid);
    }

    public void setAtomicObjectValue(Transaction t, AbstractOid oid,
                                     AtomicValue value) throws StoreException {
        synchronized (realStore) {
            AS0ObjectRO object = getObjectByOID(t, oid);
            if (object instanceof AS0ComplexObjectEditable) {
                removeObject(t, object.getOID(), false);

                AS0AtomicObjectEditable atomicObject = objectsFactory.newAtomicObject(object.getNameId(), value);
                atomicObject.setOID(oid);
                atomicObject.setParentOID(object.getParentOID());
                realStore.put(oid, atomicObject);

                // it make sense to do this because of moveObject implementation and if we cast ASOComplexObjectRO (getObjectByOID result) to ASOComplexObjectEditable
                AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, object.getParentOID());
                parentObject.getSubobjects().remove(object);
                parentObject.getSubobjects().add(atomicObject);

            } else {
                if (object instanceof AS0PointerObjectEditable) {
                    removeObject(t, object.getOID(), false);

                    AS0AtomicObjectEditable atomicObject = objectsFactory.newAtomicObject(object.getNameId(), value);
                    atomicObject.setOID(oid);
                    atomicObject.setParentOID(object.getParentOID());
                    realStore.put(oid, atomicObject);

                    AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, object.getParentOID());
                    parentObject.getSubobjects().remove(object);
                    parentObject.getSubobjects().add(atomicObject);

                } else {
                    if (object instanceof AS0AtomicObjectEditable) {
                        AS0AtomicObjectEditable atomicObject = (AS0AtomicObjectEditable) object;
                        atomicObject.setValue(value);
                    } else {
                        throw new StoreException(storeId, "Unexpected AS0ObjectRO class type:" + object.getClass().getCanonicalName());
                    }
                }
            }
        }
    }

    /**
     * @throws ModelException
     */
    public final void dumpStore() throws ModelException {
        synchronized (realStore) {
            for (Map.Entry<AbstractOid, AS0ObjectRO> e : realStore.entrySet()) {
                logger.info(e.getKey() + ": " + e.getValue().toString());
                if (e.getValue() instanceof AS0ComplexObjectRO) {
                    AS0ComplexObjectRO complex = (AS0ComplexObjectRO) e.getValue();
                    ClosableIterator<AbstractOid> iterator = complex.iterator();
                    while (iterator.hasNext()) {
                        logger.info(" - oid:" + iterator.next());
                    }
                }
            }
        }
    }

    public void setNewPointerObjectDestination(Transaction t, AbstractOid oid,
                                               AbstractOid destinationOid) throws StoreException {
        synchronized (realStore) {
            AS0ObjectRO object = getObjectByOID(t, oid);
            if (object instanceof AS0ComplexObjectEditable) {
                /*remove object and subobjects*/
                AS0ComplexObjectEditable complexObject = (AS0ComplexObjectEditable) object;
                for (AS0ObjectRO child : complexObject.getSubobjects()) {
                    removeObject(t, child.getOID());
                }
                realStore.remove(oid);

                AS0PointerObjectEditable pointerObject = objectsFactory.newPointerObject(complexObject.getNameId(), destinationOid);
                pointerObject.setOID(oid);
                pointerObject.setParentOID(complexObject.getParentOID());
                realStore.put(oid, pointerObject);

                AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, complexObject.getParentOID());
                parentObject.getSubobjects().remove(complexObject);
                parentObject.getSubobjects().add(pointerObject);

            } else {
                if (object instanceof AS0AtomicObjectEditable) {
                    realStore.remove(oid);
                    AS0PointerObjectEditable pointerObject = objectsFactory.newPointerObject(object.getNameId(), destinationOid);
                    pointerObject.setOID(oid);
                    pointerObject.setParentOID(object.getParentOID());
                    realStore.put(oid, pointerObject);

                    AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, object.getParentOID());
                    parentObject.getSubobjects().remove(object);
                    parentObject.getSubobjects().add(pointerObject);

                } else {
                    if (object instanceof AS0PointerObjectEditable) {
                        AS0PointerObjectEditable pointerObject = (AS0PointerObjectEditable) object;
                        pointerObject.setDestinationOID(destinationOid);
                    } else {
                        throw new StoreException(storeId, "Unexpected AS0ObjectRO class type:" + object.getClass().getCanonicalName());
                    }
                }
            }
        }
    }

    public void setNewComplexObjectValue(Transaction t, AbstractOid oid,
                                         Collection<AS0ObjectEditable> subobjects) throws StoreException {
        synchronized (realStore) {
            AS0ObjectRO object = getObjectByOID(t, oid);
            removeObject(t, object.getOID(), false);

            AS0ComplexObjectEditable complexObject = objectsFactory.newEmptyComplexObject(object.getNameId());
            complexObject.setOID(oid);
            complexObject.setParentOID(object.getParentOID());

            realStore.put(complexObject.getOID(), complexObject);
            for (AS0ObjectEditable subobject : subobjects) {
                addSubobject(t, object.getOID(), subobject);
            }

            AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, object.getParentOID());
            parentObject.getSubobjects().remove(object);
            parentObject.getSubobjects().add(complexObject);
        }
    }

    public AbstractOid addSubobject(Transaction t, AbstractOid parentOid,
                             AS0ObjectEditable object) throws StoreException {
        AbstractOid oid=generateOID(t);
        object.setOID(oid);
        object.setParentOID(parentOid);
        synchronized (realStore) {
            AS0ObjectRO obj = getObjectOrSuperRootByOID(t, parentOid);
            if (obj instanceof AS0ComplexObjectRO) {
                AS0ComplexObjectEditable parentObject = (AS0ComplexObjectEditable) obj;
                parentObject.getSubobjects().add(object);
            } else {
                throw new ObjectNotFoundStoreException(getStoreId(), "Object with oid:" + parentOid + " expected to be complex object.");
            }

            realStore.put(object.getOID(), object);
            if (object instanceof AS0ComplexObjectEditable) {
                AS0ComplexObjectEditable complexObject = (AS0ComplexObjectEditable) object;
                for (AS0ObjectEditable subobject : complexObject.getSubobjects()) {
                    addSubobject(t, object.getOID(), subobject);
                }
            }
        }
        return oid;
    }

    public void removeObject(Transaction t, AbstractOid oid)
            throws StoreException {
        removeObject(t, oid, true);
    }

    /**
     * @param t
     * @param oid
     * @param withReferrers
     * @throws StoreException
     */
    void removeObject(Transaction t, AbstractOid oid,
                             boolean withReferrers) throws StoreException {
        //  logger.info("Removing oid="+OID);
        synchronized (realStore) {
            if (getSuperRootOid().equals(oid)) {
                throw new StoreException(getStoreId(), "Cannot remove super root");
            }
            if (getConfigRootOid().equals(oid)) {
              throw new StoreException(getStoreId(), "Cannot remove config root");
            }
            AS0ObjectRO object = getObjectByOID(t, oid);
            if (object == null) {
                throw new StoreException(storeId, "Cannot find object with OID=" + oid);
            }
            /*Removing as child from parents*/
            AS0ComplexObjectRO complex = (AS0ComplexObjectRO) realStore.get(object.getParentOID());
            if (complex == null) {
                throw new StoreException(storeId, "Cannot find parent (OID=" + object.getParentOID() + ") of object with OID=" + oid);
            }
            try {
                complex.getSubobjectOIDsMap().remove(object.getNameId());
            } catch (ModelException e) {
                throw new StoreException(storeId, e);
            }

            /* removing subobjects */
            ClosableIterator<AbstractOid> iter = getSubobjectOIDs(t, oid);
            try {
                while (iter.hasNext()) {
                    removeObject(t, iter.next(), true);
                }
            } finally {
                iter.close();
            }
            if (withReferrers) {
                /* removing referrers to the object */
                iter = getReferrers(t, oid);
                realStore.remove(oid);
                try {
                    while (iter.hasNext()) {
                        removeObject(t, iter.next(), true);
                    }
                } finally {
                    iter.close();
                }
            }
        }
    }

    public void removeObjects(Transaction t, AbstractOid[] oids)
            throws StoreException {
        for (AbstractOid oid : oids) {
            removeObject(t, oid);
        }
    }

    public void moveObject(Transaction t, AbstractOid OID,
                           AbstractOid newParentOid) throws StoreException {
        AS0ObjectEditable object = (AS0ObjectEditable) getObjectByOID(t, OID);
        synchronized (realStore) {
            AS0ObjectRO obj = getObjectOrSuperRootByOID(t, newParentOid);
            if (obj instanceof AS0ComplexObjectEditable) {
                AS0ComplexObjectEditable newParent = (AS0ComplexObjectEditable) obj;
                AS0ComplexObjectEditable oldParent = (AS0ComplexObjectEditable) getObjectOrSuperRootByOID(t, object.getParentOID());
                if (!oldParent.getSubobjects().remove(object)) {
                    throw new StoreException(storeId, "Cannot change object with OID=" + OID + " parent from OID=" + object.getParentOID() + " to OID=" + newParentOid);
                }

                newParent.getSubobjects().add(object);
                object.setParentOID(newParentOid);
            } else {
                throw new ObjectNotFoundStoreException(getStoreId(), "Object with oid:" + newParentOid + " expected to be complex object.");
            }
        }
    }

    public ClosableIterator<AbstractOid> getReferrers(Transaction t,
                                                                 AbstractOid oid) throws StoreException {
        Iterator<AS0ObjectRO> it = this.realStore.values().iterator();
        TreeSet<AbstractOid> tree = new TreeSet<AbstractOid>();
        AS0ObjectRO object;
        AS0PointerObjectEditable pointerObject;
        while (it.hasNext()) {
            object = it.next();
            if ((object instanceof AS0PointerObjectEditable)) {
                pointerObject = (AS0PointerObjectEditable) object;
                if (pointerObject.getDestinationOID().equals(oid)) {
                    tree.add(pointerObject.getOID());
                }
            }
        }
        return new ClosableAndSizeAwareAbstractOidIterator(tree);
    }

    /**
     * @return
     */
    @Override
    public String toString() {
//    try {
//      dumpStore();
//    } catch (ModelException e) {
//      e.printStackTrace();
//    }
        return storeId;
    }

    //TODO: prefetch not implemented yet.

    public void prefetchObject(AbstractOid oid) {
    }

    public void prefetchObjects(AbstractOid[] oids) {
    }

    public void prefetchDeepObject(AbstractOid oid) {
    }

    public void prefetchDeepObjects(AbstractOid[] oids) {
    }

    public void prefetchSubobjectsByParentIDandName(AbstractOid parentId,
                                                    int nameId) {
    }

    public AbstractOid getSuperRootOid() {
        return LongOid.ZERO;
    }

    public AbstractOid getConfigRootOid() {
      return LongOid.ONE;
    }
}
