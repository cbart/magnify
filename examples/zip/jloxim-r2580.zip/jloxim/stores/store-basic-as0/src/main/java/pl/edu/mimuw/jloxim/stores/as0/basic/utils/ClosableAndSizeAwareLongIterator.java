/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.basic.utils;

import java.util.Collection;
import java.util.Iterator;

import pl.edu.mimuw.jloxim.utils.api.ClosableAndSizeAwareIterator;

/**
 * @author kadamczyk
 * @version $Id: ClosableAndSizeAwareLongIterator.java 1693 2010-05-07 17:43:03Z ptab $
 */
public class ClosableAndSizeAwareLongIterator implements ClosableAndSizeAwareIterator<Long> {

    private long availableItemsCnt;
    private Iterator<Long> realIterator;

    /** Empty */
    public ClosableAndSizeAwareLongIterator() {
        availableItemsCnt = 0L;
    }

    /**
     *
     * @param c
     */
    public ClosableAndSizeAwareLongIterator(Collection<Long> c) {
        availableItemsCnt = c.size();
        realIterator = c.iterator();
    }

    public void close() {
        // TODO: ignoring- no real cursor
    }

    /**
     *
     * @return
     */
    public boolean hasNext() {
        if (availableItemsCnt == 0) {
            return false;
        }

        return realIterator.hasNext();
    }

    /**
     *
     * @return
     */
    public Long next() {
        Long object = realIterator.next();
        availableItemsCnt--;
        return object;
    }

    /**
     *
     */
    public void remove() {
        throw new UnsupportedOperationException("remove in the iterator");
    }

    public long availableItemsCnt() {
        return availableItemsCnt;
    }
}

