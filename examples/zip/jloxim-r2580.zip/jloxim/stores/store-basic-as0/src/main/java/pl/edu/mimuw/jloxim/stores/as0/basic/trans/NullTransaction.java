/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.basic.trans;

import java.sql.Date;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionStatus;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.utils.api.callbacks.CallbackManager;
import pl.edu.mimuw.jloxim.utils.impl.CallbackManagerImpl;

/**
 * Only for tests
 * @author kadamczyk
 * @version $Id: NullTransaction.java 2235 2011-01-26 13:31:00Z ptab $
 */
public class NullTransaction implements Transaction {

    public long getTransactionId() {
        return 0L;
    }

    public double getTransactionPriority() {
        return 0;
    }

    public Date getTransactionStarted() {
        return new Date(0);
    }

    public TransactionStatus getTransactionStatus() {
        return TransactionStatus.ACTIVE;
    }
    
    @Override
    public boolean isActive() {
      return getTransactionStatus() == TransactionStatus.ACTIVE;
    }

    public TransactionIsolationLevel getIsolationLevel() {
        return TransactionIsolationLevel.READ_COMMITED;
    }

    public void commit() throws TransactionException {
    }

    public void interrupt(String reason) throws TransactionException {
    }

    public void rollback() throws TransactionException {
    }

    public long createSavepoint() throws TransactionException {
        return 0;
    }

    public void partialRollbackToSavePoint(long savepointId)
            throws TransactionException {
    }

    /**
     *
     * @return
     */
    public CallbackManager<Transaction, TransactionException> getAfterCommitCallbacksManager() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }

    /**
     *
     * @return
     */
    public CallbackManager<Transaction, TransactionException> getBeforeCommitCallbacksManager() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }

    public CallbackManager<Transaction, TransactionException> getAfterRollbackCallbacksManager() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }

    public CallbackManager<Transaction, TransactionException> getBeforeRollbackCallbacksManager() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }

    public CallbackManager<Transaction, TransactionException> getOnTransactionVictimCallbackManager() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }

    public CallbackManager<Transaction, TransactionException> getOnTransactionInterrupted() {
        return new CallbackManagerImpl<Transaction, TransactionException>();
    }
}
