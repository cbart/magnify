/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.stream;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.stream.AS0Cursor;
import pl.edu.mimuw.jloxim.stores.as0.stream.AtomicObjectEvent;
import pl.edu.mimuw.jloxim.stores.as0.stream.ComplexObjectEndEvent;
import pl.edu.mimuw.jloxim.stores.as0.stream.ComplexObjectStartEvent;
import pl.edu.mimuw.jloxim.stores.as0.stream.Event;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

public abstract class StreamStoreAs0Test {

  public abstract StoreAS0 getStore();

  public abstract StreamStoreAS0 getStreamStore();

  public abstract TransactionManager getTM();

  public abstract AS0ObjectsFactory getAS0ObjectsFactory();

  public abstract AtomicValueFactory getAtomicValueFactory();

  @Test
  public void as0Cursor_simple() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    List<AS0ObjectEditable> list = new ArrayList<AS0ObjectEditable>();
    for (int i = 0; i < 30; i++) {
    	List<AS0ObjectEditable> subList = new ArrayList<AS0ObjectEditable>();
    	for (int j = 0; j < 30; j++) {
    		subList.add(getAS0ObjectsFactory().newAtomicObject(20, getAtomicValueFactory().newAtomicValue(66)));
    	}
    	list.add(getAS0ObjectsFactory().newComplexObject(10, subList));
    }
    AS0ComplexObjectEditable object = getAS0ObjectsFactory().newComplexObject(5, list);
    getStore().addSubobject(t, getStore().getSuperRootOid(), object);

    AS0Cursor cursor = getStreamStore().getCursor(t);
    Event event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof ComplexObjectStartEvent);
  	AS0ObjectRO obj = ((ComplexObjectStartEvent) event).getObject();
  	Assert.assertEquals(5, obj.getNameId());
  	Assert.assertEquals(getStore().getSuperRootOid(), obj.getParentOID());
  	Assert.assertEquals(object.getOID(), obj.getOID());
    for (int i = 0; i < 30; i++) {
    	event = cursor.nextEvent(false);
      Assert.assertTrue(event instanceof ComplexObjectStartEvent);
    	obj = ((ComplexObjectStartEvent) event).getObject();
    	Assert.assertTrue(obj instanceof AS0ComplexObjectRO);
    	Assert.assertEquals(10, obj.getNameId());
    	Assert.assertEquals(object.getOID(), obj.getParentOID());
    	AbstractOid oid = obj.getOID();
    	for (int j = 0; j < 30; j++) {
    		event = cursor.nextEvent(false);
    		Assert.assertTrue(event instanceof AtomicObjectEvent);
    		obj = ((AtomicObjectEvent) event).getObject();
      	Assert.assertTrue(obj instanceof AS0AtomicObjectRO);
      	Assert.assertTrue(((AS0AtomicObjectRO) obj).getValue() instanceof IntegerAtomicValue);
      	Assert.assertEquals(20, obj.getNameId());
      	Assert.assertEquals(oid, obj.getParentOID());
    	}
      Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    }
    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    Assert.assertNull(cursor.nextEvent(false));
    cursor.close();
    t.commit();
  }

  @Test
  public void as0Cursor_skipping() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    List<AS0ObjectEditable> list = new ArrayList<AS0ObjectEditable>();
    for (int i = 0; i < 30; i++) {
    	List<AS0ObjectEditable> subList = new ArrayList<AS0ObjectEditable>();
    	for (int j = 0; j < 30; j++) {
    		subList.add(getAS0ObjectsFactory().newAtomicObject(20, getAtomicValueFactory().newAtomicValue(66)));
    	}
    	list.add(getAS0ObjectsFactory().newComplexObject(10, subList));
    }
    AS0ComplexObjectEditable object = getAS0ObjectsFactory().newComplexObject(5, list);
    getStore().addSubobject(t, getStore().getSuperRootOid(), object);

    AS0Cursor cursor = getStreamStore().getCursor(t);
    Event event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof ComplexObjectStartEvent);
  	AS0ObjectRO obj = ((ComplexObjectStartEvent) event).getObject();
  	Assert.assertEquals(5, obj.getNameId());
  	Assert.assertEquals(getStore().getSuperRootOid(), obj.getParentOID());
  	Assert.assertEquals(object.getOID(), obj.getOID());
    for (int i = 0; i < 30; i++) {
    	event = cursor.nextEvent(false);
      Assert.assertTrue(event instanceof ComplexObjectStartEvent);
    	obj = ((ComplexObjectStartEvent) event).getObject();
    	Assert.assertTrue(obj instanceof AS0ComplexObjectRO);
    	Assert.assertEquals(10, obj.getNameId());
    	Assert.assertEquals(object.getOID(), obj.getParentOID());
    	if (i % 2 == 1) {
        Assert.assertTrue(cursor.nextEvent(true) instanceof ComplexObjectEndEvent);
        continue;
    	}
    	AbstractOid oid = obj.getOID();
    	for (int j = 0; j < 30; j++) {
    		event = cursor.nextEvent(false);
    		Assert.assertTrue(event instanceof AtomicObjectEvent);
    		obj = ((AtomicObjectEvent) event).getObject();
      	Assert.assertTrue(obj instanceof AS0AtomicObjectRO);
      	Assert.assertTrue(((AS0AtomicObjectRO) obj).getValue() instanceof IntegerAtomicValue);
      	Assert.assertEquals(20, obj.getNameId());
      	Assert.assertEquals(oid, obj.getParentOID());
    	}
      Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    }
    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    Assert.assertNull(cursor.nextEvent(false));
    cursor.close();
    t.commit();
  }

  @Test
  public void as0Cursor_fromOid_inScope() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    List<AS0ObjectEditable> list = new ArrayList<AS0ObjectEditable>();
    for (int i = 0; i < 10; i++) {
    	List<AS0ObjectEditable> subList = new ArrayList<AS0ObjectEditable>();
    	for (int j = 0; j < 10; j++) {
    		List<AS0ObjectEditable> subsubList = new ArrayList<AS0ObjectEditable>();
    		for (int k = 0; k < 10; k++) {
    			subsubList.add(getAS0ObjectsFactory().newAtomicObject(30,
    					getAtomicValueFactory().newAtomicValue("" + i + " " + j + " " + k)));
    		}
    		subList.add(getAS0ObjectsFactory().newComplexObject(20, subsubList));
    	}
    	list.add(getAS0ObjectsFactory().newComplexObject(10, subList));
    }
    AS0ComplexObjectEditable object = getAS0ObjectsFactory().newComplexObject(5, list);
    getStore().addSubobject(t, getStore().getSuperRootOid(), object);

    AS0Cursor cursor = getStreamStore().getCursor(t);
    Event event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof ComplexObjectStartEvent);
  	AS0ObjectRO obj1 = ((ComplexObjectStartEvent) event).getObject();
  	Assert.assertEquals(5, obj1.getNameId());
  	Assert.assertEquals(getStore().getSuperRootOid(), obj1.getParentOID());
  	Assert.assertEquals(object.getOID(), obj1.getOID());
    for (int i = 0; i < 10; i++) {
    	event = cursor.nextEvent(false);
      Assert.assertTrue(event instanceof ComplexObjectStartEvent);
      AS0ObjectRO obj2 = ((ComplexObjectStartEvent) event).getObject();
    	Assert.assertTrue(obj2 instanceof AS0ComplexObjectRO);
    	Assert.assertEquals(10, obj2.getNameId());
    	Assert.assertEquals(obj1.getOID(), obj2.getParentOID());
    	Assert.assertTrue(cursor.nextEvent(true) instanceof ComplexObjectEndEvent);

    	AS0Cursor cursor2 = getStreamStore().getCursorFromOid(t, obj2.getOID(), true);
    	event = cursor2.nextEvent(false);
      Assert.assertTrue(event instanceof ComplexObjectStartEvent);
      AS0ObjectRO obj3 = ((ComplexObjectStartEvent) event).getObject();
    	Assert.assertTrue(obj3 instanceof AS0ComplexObjectRO);
    	Assert.assertEquals(10, obj3.getNameId());
    	Assert.assertEquals(obj2.getOID(), obj3.getOID());
    	Assert.assertEquals(obj1.getOID(), obj2.getParentOID());
    	for (int j = 0; j < 10; j++) {
    		event = cursor2.nextEvent(false);
        Assert.assertTrue(event instanceof ComplexObjectStartEvent);
        AS0ObjectRO obj4 = ((ComplexObjectStartEvent) event).getObject();
      	Assert.assertTrue(obj3 instanceof AS0ComplexObjectRO);
      	Assert.assertEquals(20, obj4.getNameId());
      	Assert.assertEquals(obj3.getOID(), obj4.getParentOID());

      	AS0Cursor cursor3 = getStreamStore().getCursorFromOid(t, obj4.getOID(), true);
      	event = cursor3.nextEvent(false);
      	Assert.assertTrue(event instanceof ComplexObjectStartEvent);
        AS0ObjectRO obj5 = ((ComplexObjectStartEvent) event).getObject();
      	Assert.assertTrue(obj5 instanceof AS0ComplexObjectRO);
      	Assert.assertEquals(20, obj5.getNameId());
      	Assert.assertEquals(obj3.getOID(), obj5.getParentOID());
      	Assert.assertEquals(obj4.getOID(), obj5.getOID());

      	for (int k = 0; k < 10; k++) {
      		event = cursor2.nextEvent(false);
      		Assert.assertTrue(event instanceof AtomicObjectEvent);
      		AS0AtomicObjectRO obj6 = ((AtomicObjectEvent) event).getObject();
        	Assert.assertEquals(30, obj6.getNameId());
        	Assert.assertEquals(obj4.getOID(), obj6.getParentOID());
        	AtomicValue value = obj6.getValue();
        	Assert.assertTrue(value instanceof TextAtomicValue);

      		event = cursor3.nextEvent(false);
      		Assert.assertTrue(event instanceof AtomicObjectEvent);
      		AS0AtomicObjectRO obj7 = ((AtomicObjectEvent) event).getObject();
        	Assert.assertEquals(30, obj7.getNameId());
        	Assert.assertEquals(obj4.getOID(), obj7.getParentOID());
        	Assert.assertEquals(obj6.getOID(), obj7.getOID());
        	AtomicValue value2 = obj7.getValue();
        	Assert.assertTrue(value instanceof TextAtomicValue);
        	Assert.assertEquals(value.getValue(), value2.getValue());
      	}
      	Assert.assertTrue(cursor2.nextEvent(false) instanceof ComplexObjectEndEvent);
      	Assert.assertTrue(cursor3.nextEvent(false) instanceof ComplexObjectEndEvent);
      	Assert.assertNull(cursor3.nextEvent(false));
      	cursor3.close();
    	}
    	Assert.assertTrue(cursor2.nextEvent(false) instanceof ComplexObjectEndEvent);
    	Assert.assertNull(cursor2.nextEvent(false));
    	cursor2.close();
    }
    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    Assert.assertNull(cursor.nextEvent(false));
    cursor.close();
    t.commit();
  }

  @Test
  // WARNING! This test relies on some premises about how objects are ordered.
  // This is wrong, but there's no better way to test not-in-scope cursor.
  // This test might fail if engine behind prepost:nodestructure changes significantly.
  public void as0Cursor_fromOid_notInScope() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ComplexObjectEditable object = getAS0ObjectsFactory().newEmptyComplexObject(5);
    getStore().addSubobject(t, getStore().getSuperRootOid(), object);

    AS0AtomicObjectEditable subatomic = getAS0ObjectsFactory().newAtomicObject(10,
    		getAtomicValueFactory().newAtomicValue("rotfl"));
    getStore().addSubobject(t, object.getOID(), subatomic);

    AS0ComplexObjectEditable subobject = getAS0ObjectsFactory().newEmptyComplexObject(15);
    getStore().addSubobject(t, object.getOID(), subobject);

    AS0AtomicObjectEditable subsubatomic = getAS0ObjectsFactory().newAtomicObject(20,
    		getAtomicValueFactory().newAtomicValue("omg"));
    getStore().addSubobject(t, subobject.getOID(), subsubatomic);

    AS0ComplexObjectEditable subsubobject = getAS0ObjectsFactory().newEmptyComplexObject(25);
    getStore().addSubobject(t, subobject.getOID(), subsubobject);

    AS0AtomicObjectEditable subsubsubatomic = getAS0ObjectsFactory().newAtomicObject(30,
    		getAtomicValueFactory().newAtomicValue("lol"));
    getStore().addSubobject(t, subsubobject.getOID(), subsubsubatomic);


    AS0Cursor cursor = getStreamStore().getCursorFromOid(t, subsubsubatomic.getOID(), false);

    Event event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof AtomicObjectEvent);
    AS0AtomicObjectRO atom = ((AtomicObjectEvent) event).getObject();
    Assert.assertEquals(subsubsubatomic.getOID(), atom.getOID());
    Assert.assertEquals(30, atom.getNameId());
    Assert.assertEquals(subsubobject.getOID(), atom.getParentOID());
    Assert.assertEquals(((TextAtomicValue)atom.getValue()).getValue(), "lol");

    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);

    event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof AtomicObjectEvent);
    atom = ((AtomicObjectEvent) event).getObject();
    Assert.assertEquals(subsubatomic.getOID(), atom.getOID());
    Assert.assertEquals(20, atom.getNameId());
    Assert.assertEquals(subobject.getOID(), atom.getParentOID());
    Assert.assertEquals(((TextAtomicValue)atom.getValue()).getValue(), "omg");

    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);

    event = cursor.nextEvent(false);
    Assert.assertTrue(event instanceof AtomicObjectEvent);
    atom = ((AtomicObjectEvent) event).getObject();
    Assert.assertEquals(subatomic.getOID(), atom.getOID());
    Assert.assertEquals(10, atom.getNameId());
    Assert.assertEquals(object.getOID(), atom.getParentOID());
    Assert.assertEquals(((TextAtomicValue)atom.getValue()).getValue(), "rotfl");

    Assert.assertTrue(cursor.nextEvent(false) instanceof ComplexObjectEndEvent);
    Assert.assertNull(cursor.nextEvent(false));

    cursor.close();
    t.commit();
  }
}
