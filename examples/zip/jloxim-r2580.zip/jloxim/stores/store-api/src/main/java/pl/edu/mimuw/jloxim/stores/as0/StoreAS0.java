/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0;

import java.util.Collection;
import java.util.Map;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 * Store compatible with <a
 * href="http://sbql.pl/Topics/AS0%20store%20model.html">AS<sub>0</sub></a>
 *
 * @author piotr.tabor@gmail.com
 * @version $Id: StoreAS0.java 2304 2011-05-31 18:48:10Z piotrswigon $
 */
public interface StoreAS0 {
  /**
   * Returns id of the store
   *
   * @return id of the store.
   */
  public String getStoreId();

  /**
   * Returns Oid of superRoot (parent of the roots) object in the store.
   * @return
   */
  public AbstractOid getSuperRootOid();

  /**
   * Returns Oid of superRoot (parent of the roots) object in the store.
   *
   * Config root has SuperRoot as its parent (but configRoot is not visible as
   * a child of superRoot).
   */
  public AbstractOid getConfigRootOid();


  /**
   * Returns oid of parent of object with given oid
   *
   * @param oid
   * @return oid of the parent object
   *
   * @throws ObjectNotFoundStoreException
   */
  public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException;

  /**
   * Returns all subobjects of the given object (by OID).
   *
   * <p>
   * If the OID represents object that is not complex - the empty map is
   * returned.
   * </p>
   *
   * <p>
   * The object is returned as map from name_ids into iterators. The iterators
   * iterates through all the OID's of the children.
   * </p>
   *
   * <p>
   * If the OID does not exists - {@link ObjectNotFoundStoreException} is
   * thrown
   * </p>
   *
   * <p>If you call this method with OID=0 it will return roots of given name
   * (search superroot)</p>
   *
   * @param t
   * @param OID
   * @return map: name_id -&gt; iterator through the objects.
   * @throws StoreException
   */
  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(
      Transaction t, AbstractOid OID) throws StoreException;

  /**
   * Returns all subobjects of the given object (by OID).
   *
   * @param t
   * @param OID
   * @return
   * @throws StoreException
   */
  public ClosableIterator<AbstractOid> getSubobjectOIDs(
      Transaction t, AbstractOid OID) throws StoreException;

  /**
   * Returns some subobjects of the given object (by parent's OID and
   * subobject's name).
   *
   * <p>
   * If the OID represents object that is not complex - the empty map is
   * returned.
   * </p>
   *
   * <p>
   * The object is returned as iterator over OID's of the children.
   * </p>
   *
   * <p>
   * If the OID does not exists - {@link ObjectNotFoundStoreException} is
   * thrown.
   * </p>
   *
   * <p>If you call this method with OID=0 it will return roots of given name
   * (search superroot)</p>
   *
   * @param t
   * @param OID
   * @return map: name_id -&gt; iterator through the objects.
   * @throws StoreException
   */
  public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(
      Transaction t, AbstractOid OID, int nameID) throws StoreException;

  /**
   * Returns map of all roots.
   * Works like {@link StoreAS0#getSubobjectOIDsMap(Transaction, 0)}
   *
   * @return iterator over roots.
   */
  public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(Transaction t) throws StoreException;

  /**
   * Returns list of all roots.
   * Works like {@link StoreAS0#getSubobjectOIDs(Transaction, 0)}
   *
   * @return iterator over roots.
   */
  public ClosableIterator<AbstractOid> getRoots(Transaction t) throws StoreException;

  /**
   * Returns list of roots having given name.
   *
   * @param name_id - name, that we are looking for.
   * @return list of roots.
   */
  public ClosableIterator<AbstractOid> getRootsByName(Transaction t, int name_id) throws StoreException;

  /**
   * Returns the whole (one level) object by given object's oid.
   *
   * @param t
   * @param OID
   * @return the object.
   * @throws StoreException
   */
  public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid OID)
      throws StoreException;

  // ============================= Modifications ===========================
  /**
   * Sets value of the given object. If the object is not "atomic" - it is
   * replaced by the atomic object.
   *
   * <p>
   * In particular the whole "complex" object (with all subobjects) would be
   * replaced by the atomic object.
   * </p>
   */
  public void setAtomicObjectValue(Transaction t, AbstractOid OID, AtomicValue value)
      throws StoreException;

  /**
   * Sets value of the given object. If the object is not "pointer" - it is
   * replaced by the pointer object.
   *
   * <p>
   * In particular the whole "complex" object (with all subobjects) would be
   * replaced by the simple object.
   * </p>
   *
   * @throws ObjectNotFoundStoreException -
   *             If neither OID nor destination_oid exists
   */
  public void setNewPointerObjectDestination(Transaction t, AbstractOid OID,
                         AbstractOid destination_OID) throws StoreException;

  /**
   * Sets value of the given object. If the object is not "complex" - it is
   * replaced by the complex object.
   */
  public void setNewComplexObjectValue(Transaction t, AbstractOid OID,
                     Collection<AS0ObjectEditable> subobjects) throws StoreException;

  /**
   * Adds subobject to the given "complex" object.
   *
   * <p>If the parent_OID does not point to complex object - the
   *  {@link ObjectNotFoundStoreException} is thrown.
   *
   *
   * @param parent_OID -
   *            use 0 to create ROOT
   * @param object to add
   * @return oid of the added object
   */
  public AbstractOid addSubobject(Transaction t, AbstractOid parent_OID, AS0ObjectEditable object)
      throws StoreException;

  /**
   * Removes given object.
   *
   * <p>If complex object is removed - all subobjects are also removed.</p>
   * <p>All pointer  objects referring to removed object are also removed.</p>
   * @param t
   * @param OID
   * @throws StoreException
   */
  public void removeObject(Transaction t, AbstractOid OID) throws StoreException;

  /**
   * Removes set of objects.
   *
   * <p>For more information, read: {@link #removeObject(Transaction, long)}</p>
   *
   * <p>
   * When exception is thrown - it is possible that some of the nodes has been
   * deleted, and some hasn't. </>
   *
   * @param OIDs
   * @throws StoreException
   */
  public void removeObjects(Transaction t, AbstractOid[] OIDs) throws StoreException;

  /**
   * Changes object's parent (moves object to another node).
   *
   * @param OID
   * @param new_parent_oid
   *            use 0 to move the object as root
   * @throws StoreException
   */
  public void moveObject(Transaction t, AbstractOid OID, AbstractOid new_parent_oid) throws StoreException;

  /**
   * Returns OIDs of all pointer object that refers to the object.
   * @param OID
   * @return
   */
  public ClosableIterator<AbstractOid> getReferrers(Transaction t, AbstractOid OID) throws StoreException;

  // ===================== Prefetch methods ================================
  /**
   * Prefetches object by OID of the object.
   */
  void prefetchObject(AbstractOid OID);

  /**
   * Prefetches set of objects by OID of the object.
   */
  void prefetchObjects(AbstractOid[] OIDs);

  /**
   * Try to prefetch the object and all subobjects (recursively).
   *
   * It's store's decision how deep (big) prefetches are done.
   *
   * @param OID -
   *            object to prefetch
   */
  void prefetchDeepObject(AbstractOid OID);

  /**
   * Try to prefetch given objects and all subobjects (recursively).
   *
   * It's store's decision how deep (big) prefetches are done.
   *
   * @param OIDs -
   *            array of objects to prefetch
   */
  void prefetchDeepObjects(AbstractOid[] OIDs);

  /**
   * Prefetches all subobjects of given object by the object's parentId and object's name.
   * @param parentId
   * @param nameId
   */
  void prefetchSubobjectsByParentIDandName(AbstractOid parentId, int nameId);
}
