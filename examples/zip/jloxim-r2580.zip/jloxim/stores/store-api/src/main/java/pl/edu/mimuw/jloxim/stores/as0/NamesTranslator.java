/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.as0;

import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundNameTranslatorException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Map.Entry;

/**
 * This object represent map (association) between
 * object's names (bindings) and numeric identifiers.
 *
 * <p>NamesTranslator has to guarantee that name added to the
 * translator is durable in terms of transaction (change is flushed
 * on WAL logged before transaction commit).</p>
 * <p>It is acceptable that name, that was created in rollbacked
 * transaction will not be removed in the rollback process</p>    
 * 
 * @author piotr.tabor@gmail.com
 * @version $Id: NamesTranslator.java 2539 2011-12-02 00:24:35Z ptab $
 */
public interface NamesTranslator {

  int SUPERROOT = -1;
  String SUPERROOT_NAME = "/";

  /** 
   * Translates given name to name identificator.
   * 
   * <p>If the name isn't already in the store - it is added and created id is returned.</p> 
   * 

   * @param name - to find or create
   * @return name_id of the given name
   * 
   * @throws NameTranslatorException
   */
  int getOrRegisterName(String name)  throws NameTranslatorException;
  
  /**
   * Finds name by name id.
   *
   * @param name_id
   * @return name
   * @throws ObjectNotFoundNameTranslatorException - if given name_id does not exist in the map.
   */
  String getNameByNameId(int name_id) throws NameTranslatorException;

  /**
   * Finds name_id by the name.
   *
   * @param name
   * @return the name's name_id.
   * @throws NameTranslatorException
   */
  int getNameIdByName(String name) throws NameTranslatorException;
  
  /**
   * Returns iterator that allows traversing through the whole map. Should
   * be used for maintenance operations (like consistency check).
   * 
   * <p>Please - remember to close the iterator after usage.</p>
   *
   * @return iterator over all the entries.
   * @throws NameTranslatorException
   */
  ClosableIterator<? extends Entry<Integer, String>> getAllEntries() throws NameTranslatorException;
  
  /**
   * Removes the name from the map. Be careful to 
   * call this method only if you are sure that
   * there is no reference to this name_id in the store.   
   * 
   * @param name
   * @throws NameTranslatorException
   */
  void removeName(String name) throws NameTranslatorException;
  
  /**
   * Removes the name from the map. Be careful to 
   * call this method only if you are sure that
   * there is no reference to this name_id in the store.
   * 
   * @param name_id
   * @throws NameTranslatorException
   */
  void removeNameId(int name_id) throws NameTranslatorException;
}
