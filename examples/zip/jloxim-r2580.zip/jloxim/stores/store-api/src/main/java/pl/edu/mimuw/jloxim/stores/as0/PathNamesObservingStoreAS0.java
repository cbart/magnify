/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0;

import java.util.List;

/**
 * A store that notifies listeners about events occuring on particular paths.
 *
 * @author mlenart
 * @version $Id: PathNamesObservingStoreAS0.java 2517 2011-09-29 19:10:35Z mlenart $
 */
public interface PathNamesObservingStoreAS0 extends StoreAS0WithLogicalLocksSupport {

  /**
   * Registers listener for given path
   * @param path
   * @param listener
   */
  public void registerListener(List<Integer> path, PathNamesModificationListener listener);

  /**
   * Unregisters given listener from listening on all paths.
   * @param listener
   */
  public void unregisterListener(PathNamesModificationListener listener);

  /**
   * Unregisters all listeners from listening on particular path.
   * @param path
   */
  public void unregisterListeners(List<Integer> path);

  /**
   * Unregisters all listeners on all paths.
   */
  public void unregisterAllListeners();
}
