/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0;

import java.util.Collection;
import java.util.List;

import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 * Listens for events occuring on some <code>PathNamesObservingStore</code>.
 *
 * @author mlenart
 * @version $Id: PathNamesModificationListener.java 2066 2010-09-17 16:24:55Z ptab $
 */
public interface PathNamesModificationListener {

  /**
   * Notifies that setting atomic value will be done.
   * Does not notify about removed descendants
   * 
   * @param t - transaction in which the action was done
   * @param path - path of the changed object
   * @param oid - oid of the changed object
   * @param newVal - new atomic value
   * @throws StoreException
   */
  public void beforeAtomicValSet(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AtomicValue newVal)
      throws StoreException;

  /**
   * Notifies that setting atomic value was done.
   * Does not notify about removed descendants
   *
   * @param t - transaction in which the action was done
   * @param path - path of the changed object
   * @param oid - oid of the changed object
   * @param newVal - new atomic value
   * @throws StoreException
   */
  public void afterAtomicValSet(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AtomicValue newVal)
      throws StoreException;

  /**
   * Notifies that destination will be set.
   * Does not notify about removed descendants
   *
   * @param t - transaction in which the action was done
   * @param path - path of the pointer object
   * @param oid - oid of the changed object
   * @param destOid - destination of the new pointer value
   * @throws StoreException
   */
  public void beforePointerDestSet(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AbstractOid destOid)
      throws StoreException;

  /**
   * Notifies that pointer destination was set
   * Does not notify about removed descendants
   *
   * @param t - transaction in which the action was done
   * @param path - path of the pointer object
   * @param oid - oid of the changed object
   * @param destOid - destination of the new pointer value
   * @throws StoreException
   */
  public void afterPointerDestSet(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AbstractOid destOid)
      throws StoreException;

  /**
   * Notifies that a subobject is going to be added to some parent object
   *
   * @param t - transaction in which the action was done
   * @param path - path of the parent object
   * @param oid - oid of the parent (changed) object
   * @param object - new child object
   * @throws StoreException
   */
  public void beforeAddSubobject(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AS0ObjectEditable object)
      throws StoreException;

  /**
   * Notifies that a subobject was added to some parent object
   * 
   * @param t - transaction in which the action was done
   * @param path - path of the parent object
   * @param oid - oid of the parent (changed) object
   * @param object - new child object
   * @throws StoreException
   */
  public void afterAddSubobject(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      AS0ObjectEditable object)
      throws StoreException;

  /**
   * Notifies that a subobject is going to be added to some parent object.
   * Does not notify about removed descendants.
   *
   * @param t - transaction in which the action was done
   * @param path - path of the parent object
   * @param oid - oid of the parent (changed) object
   * @param subobjects - new child objects
   * @throws StoreException
   */
  public void beforeSetComplexObjectValue(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      Collection<AS0ObjectEditable> subobjects)
      throws StoreException;

  /**
   * Notifies that a subobject was added to some parent object.
   * Does not notify about removed descendants.
   *
   * @param t - transaction in which the action was done
   * @param path - path of the parent object
   * @param oid - oid of the parent (changed) object
   * @param subobjects - new child objects
   * @throws StoreException
   */
  public void afterSetComplexObjectValue(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      Collection<AS0ObjectEditable> subobjects)
      throws StoreException;

  /**
   * Notifies that an object will be moved.
   * Does not notify recursively about descendants being moved.
   *
   * @param t - transaction
   * @param path - path of the moved object
   * @param oid - oid of the moved object
   * @param newParentPath - path to the moved object's new parent
   * @param newParentOid - oid of the moved object's new parent
   * @throws StoreException
   */
  public void beforeMoveObject(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      List<Integer> newParentPath,
      AbstractOid newParentOid)
      throws StoreException;

  /**
   * Notifies that an object was moved.
   * Does not notify recursively about descendants being moved.
   *
   * @param t - transaction
   * @param path - path of the moved object
   * @param oid - oid of the moved object
   * @param newParentPath - path to the moved objects new parent
   * @param newParentOid - oid of the moved objects new parent
   * @throws StoreException
   */
  public void afterMoveObject(
      Transaction t,
      List<Integer> path,
      AbstractOid oid,
      List<Integer> newParentPath,
      AbstractOid newParentOid)
      throws StoreException;

  /**
   * Notifies that an object is going to be removed.
   * Does not notify about removed descendants.
   *
   * @param t - transaction in which the action will be done
   * @param path - path of the removed object
   * @param oid - oid of the removed object
   * @throws StoreException
   */
  public void beforeRemoveObject(
      Transaction t,
      List<Integer> path,
      AbstractOid oid)
      throws StoreException;
}
