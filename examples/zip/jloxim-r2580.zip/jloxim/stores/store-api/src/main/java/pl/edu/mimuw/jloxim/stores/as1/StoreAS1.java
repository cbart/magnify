/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as1;


import java.util.List;

import pl.edu.mimuw.jloxim.model.as1.api.ro.AS1ClassComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as1.api.ro.AS1ObjectRO;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;


public interface StoreAS1 extends StoreAS0 {
  /*
   * Order of superclasses should be preserved. 
   */
  public List<AS1ClassComplexObjectRO> getSuperclassesForObject(AbstractOid OID) throws StoreException;
  
  /*
   * Add superclass to the object. The superclass is added in any place in the list.   
   */
  public void addSuperclassForObject(AbstractOid OID, AbstractOid superClassOID) throws StoreException;
  
  /*
   * Add superclass to the object. The superclass after given superclass. 
   * 
   * <p>If afterThisSuperclass is null the new superclass is added as a first one in the list</p> 
   */
  public void addSuperclassForObjectBefore(AbstractOid OID, AbstractOid newSuperclassOID, AbstractOid afterThisSuperclassOID);
  
  public void removeSuperclassFromObject(AbstractOid OID, AbstractOid superClassOID) throws StoreException;
  
  public AS1ObjectRO getObjectByOID(Transaction t, AbstractOid OID) throws StoreException;
  
}
