/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.comparator.LongOidComparator;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.ComparatorConverter;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author kadamczyk
 * @version $Id: AbstractNodeTest.java 2418 2011-07-18 21:53:41Z kadamczyk $
 */  
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/TransBtreeSpringTest-context.xml"})
abstract public class AbstractNodeTest {
    
    @Autowired protected NodeManager nodeManager;
    @Autowired protected PageManager pageManager;
    @Autowired protected TransactionManager transactionManager;
            
    @Autowired protected TransBtreeValueBinding<LongOid> longOidBinding; // = new LongOidBinding();
    @Autowired protected TransBtreeValueBinding<String> stringBinding; // = new StringBinding();   
    
    @Before
    public void init() {
        nodeManager.setKeyComparator(new ComparatorConverter(new LongOidComparator()));
    }
    
    protected TransBtreeValue longOidToValue(LongOid oid) {
        TransBtreeValue key = new TransBtreeValueImpl();
        longOidBinding.objectToRawValue(oid, key);
        return key;
    }

    protected TransBtreeValue stringToValue(String text) {
        TransBtreeValue value = new TransBtreeValueImpl();
        stringBinding.objectToRawValue(text, value);
        return value;
    }
    
}
