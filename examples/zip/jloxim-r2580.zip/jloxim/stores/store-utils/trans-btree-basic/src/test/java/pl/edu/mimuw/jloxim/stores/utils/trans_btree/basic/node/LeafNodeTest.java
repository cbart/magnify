/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.util.Arrays;

/**
 * @author kadamczyk
 * @version $Id: LeafNodeTest.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
//@Ignore
public class LeafNodeTest extends AbstractNodeTest {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(LeafNodeTest.class);

    @Test
    public void basicTest() throws Exception {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        LeafNode leaf = nodeManager.newLeafNode(t);
        TransBtreeValue key = longOidToValue(new LongOid(1));
        TransBtreeValue value = longOidToValue(new LongOid(2));
        leaf.putValue(key, value);
        leaf.consistencyCheck();
        leaf.write();

        TransBtreeValue key2 = longOidToValue(new LongOid(6));
        TransBtreeValue value2 = longOidToValue(new LongOid(7));
        leaf.putValue(key2, value2);
        leaf.consistencyCheck();
        leaf.write();

        LeafNode openedLeaf = nodeManager.getLeafNode(t, leaf.getId(), BufferUsePurpose.READ_WRITE);
        openedLeaf.read();

        openedLeaf.consistencyCheck();
        TransBtreeValue key3 = longOidToValue(new LongOid(123126));
        TransBtreeValue value3 = longOidToValue(new LongOid(712312));
        openedLeaf.putValue(key3, value3);
        openedLeaf.consistencyCheck();

        openedLeaf.removeValue(key);
        openedLeaf.consistencyCheck();
        openedLeaf.removeValue(key2);
        openedLeaf.consistencyCheck();
        openedLeaf.removeValue(key3);

        openedLeaf.consistencyCheck();
        openedLeaf.write();
        openedLeaf.consistencyCheck();

        t.commit();
    }

    @Test
    public void splitTest() throws TransactionException {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        LeafNode node = nodeManager.newLeafNode(t);

        final int COUNT = 20;
        TransBtreeValue[] keys = new TransBtreeValueImpl[COUNT];

        for (int i = 0; i < COUNT; ++i) {
            TransBtreeValue key = longOidToValue(new LongOid(i));
            keys[i] = key;
            TransBtreeValue value = longOidToValue(new LongOid(i+1));

            node.putValue(key, value);
        }

        node.consistencyCheck();

        TransactionBufferPage page2 = pageManager.allocatePage(t);
        LeafNode rightNode = (LeafNode) node.split(page2);

        Assert.assertEquals(COUNT, node.getKeyCount() + rightNode.getKeyCount());

        Assert.assertEquals(node.getKeys().length, node.getKeyCount());
        Assert.assertEquals(node.getValues().length, node.getKeyCount());

        Assert.assertEquals(node.getKeys()[node.getKeys().length - 1], node.getMaxKey());
        Assert.assertEquals(rightNode.getKeys()[rightNode.getKeys().length - 1], rightNode.getMaxKey());

        rightNode.write();
        rightNode.consistencyCheck();
        //logger.info("leftNode: " + leftNode.debug());

        node.write();
        node.consistencyCheck();
        //logger.info("rightNode: " + rightNode.debug());

        Arrays.sort(keys);

        for (int i = 0; i < node.getKeyCount(); ++i) {
            TransBtreeValue v = node.getValue(keys[i]);
            //logger.info("(leftNode) key:" + keys[i] + " value:" + v);

            Assert.assertFalse(v == null);
        }

        for (int i = 1; i <= rightNode.getKeyCount(); ++i) {
            TransBtreeValue v = rightNode.getValue(keys[COUNT - i]);
            //logger.info("(rightNode) key:" + keys[COUNT - i] + " value:" + v);

            Assert.assertFalse(v == null);
        }

        t.commit();
    }
}
