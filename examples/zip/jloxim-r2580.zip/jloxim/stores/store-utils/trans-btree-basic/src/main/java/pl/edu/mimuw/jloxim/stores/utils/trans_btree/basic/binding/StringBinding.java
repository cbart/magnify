/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding;

import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import org.springframework.stereotype.Component;

/**
 * @author kadamczyk
 * @version $Id: StringBinding.java 2415 2011-07-15 22:40:00Z kadamczyk $
 */
@Component
public class StringBinding implements TransBtreeValueBinding<String> {

    @Override
    public String rawValueToObject(TransBtreeValue entry) {
        byte[] byteArray = entry.getData();
        ByteBuffer data = ByteBuffer.wrap(byteArray);
        int len = data.getInt();       

        try {
            String value = new String(data.array(), data.position(), len, "utf-8");
            return value;
        } catch (UnsupportedEncodingException ex) {
            String value = new String(data.array(), data.position(), len);
            return value;
        }
    }

    @Override
    public void objectToRawValue(String object, TransBtreeValue key) {
        byte[] byteArray = new byte[object.getBytes().length + Integer.SIZE];
        ByteBuffer data = ByteBuffer.wrap(byteArray);        
        
        data.putInt(object.getBytes().length);
        data.put(object.getBytes());

        key.setData(byteArray, 0, byteArray.length);
    }
}