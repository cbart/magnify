/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

import java.util.Comparator;

/**
 * @author kadamczyk
 * @version $Id: RootNode.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
public class RootNode extends BranchNode {
    private final static Logger logger = Logger.getLogger(RootNode.class);

    public RootNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator) throws TransactionException {
        super(page, keyComparator);
    }

    public static RootNode newNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator) {
        page.getContent().clear();
        RootNode node = new RootNode(page, keyComparator);
        node.clear();
        return node;
    }

    @Override
    public void consistencyCheck() throws TransactionException {
        super.consistencyCheck();
        if (getNodeType() != NodeType.ROOT_NODE) {
            logger.error("wrong node type:" + getNodeType() + " expected:" + NodeType.ROOT_NODE);
        }
    }

    @Override
    public int getHeaderLength() {
        return super.getHeaderLength() + 0;
    }

    @Override
    public void clear() {
        super.clear();
        setNodeType(NodeType.ROOT_NODE);
    }
}
