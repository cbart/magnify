/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;

import java.nio.ByteBuffer;
import java.util.Comparator;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author kadamczyk
 * @version $Id: NodeManager.java 2423 2011-07-26 22:34:12Z kadamczyk $
 */
public class NodeManager {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(NodeManager.class);
    
    @Autowired private PageManager pageManager;
    @Autowired private NodeCache cache;
    private Comparator<TransBtreeValue> keyComparator;

    public void setPageManager(PageManager pageManager) {
        this.pageManager = pageManager;
    }

    public void setKeyComparator(Comparator<TransBtreeValue> keyComparator) {
        this.keyComparator = keyComparator;
    }

    public RootNode newRootNode(Transaction t) {
        RootNode node = RootNode.newNode(pageManager.allocatePage(t), keyComparator);
        cache.put(t, node);
        return node;
    }

    public BranchNode newBranchNode(Transaction t) {
        BranchNode node = BranchNode.newNode(pageManager.allocatePage(t), keyComparator);
        cache.put(t, node);
        return node;
    }

    public LeafNode newLeafNode(Transaction t) {
        LeafNode node =  LeafNode.newNode(pageManager.allocatePage(t), keyComparator, pageManager);
        //cache.put(t, node);
        return node;
    }

    public TreeNode readNodeFromPage(TransactionBufferPage page) throws TransactionException {
        ByteBuffer data = page.getContent();
        Integer nodeTypeID = data.getInt();
        NodeType nodeType = NodeType.get(nodeTypeID);
        if (nodeType == null) {
            throw new TransBtreeException("Unknown node type id " + nodeTypeID + ". Page is isEmpty?");
        }
        TreeNode node;
        switch (nodeType) {
            case ROOT_NODE:
                node = new RootNode(page, keyComparator);
                break;
            case BRANCH_NODE:
                node = new BranchNode(page, keyComparator);
                break;
            case LEAF_NODE:
                node = new LeafNode(page, keyComparator, pageManager);
                break;
            default:
                throw new TransBtreeException("Unknown node type " + nodeType);
        }
        node.read();
        return node;
    }

  public TreeNode getTreeNode(Transaction t, int nodeId, BufferUsePurpose usePurpose) throws TransactionException {
      TreeNode node = cache.get(t, nodeId, usePurpose);
      if (node == null) {
          TransactionBufferPage page = pageManager.getPage(t, nodeId, usePurpose);
          //if (usePurpose == BufferUsePurpose.READ_WRITE)
          //    logger.error("READ_WRITE tid:" + page.getTransaction().getTransactionId() + " nodeId:" + nodeId);
          node = readNodeFromPage(page);
          cache.put(t, node);
      }
      return node;
  }
  
  public BranchNode getBranchNode(Transaction t, int rootPageID, BufferUsePurpose bufferUsePurpose) {
    TreeNode node = getTreeNode(t, rootPageID, bufferUsePurpose);
    if (node instanceof BranchNode) {
      return (BranchNode) node;
    } else {
      throw new TransBtreeException("expected: BranchNode, found: " + node.getNodeType());
    }
  }

  public RootNode getRootNode(Transaction t, int rootPageID, BufferUsePurpose bufferUsePurpose) {
    TreeNode node = getTreeNode(t, rootPageID, bufferUsePurpose);
    if (node instanceof RootNode) {
      return (RootNode) node;
    } else {
      throw new TransBtreeException("expected: RootNode, found: " + node.getNodeType());
    }
  }

  public LeafNode getLeafNode(Transaction t, int nextNodeId, BufferUsePurpose bufferUsePurpose) {
    TreeNode node = getTreeNode(t, nextNodeId, bufferUsePurpose);
    if (node instanceof LeafNode) {
      return (LeafNode) node;
    } else {
      throw new TransBtreeException("expected: LeafNode, found: " + node.getNodeType());
    }
  }
}
