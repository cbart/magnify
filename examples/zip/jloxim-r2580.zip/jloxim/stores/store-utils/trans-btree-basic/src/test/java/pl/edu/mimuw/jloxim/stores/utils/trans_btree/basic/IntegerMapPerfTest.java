/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

/**
 *
 * @author kadamczyk
 * @version $Id: IntegerMapPerfTest.java 2467 2011-09-14 19:33:57Z kadamczyk $
 */

//@Ignore
public class IntegerMapPerfTest extends AbstractTransBtreePerfTest {
    
    @Autowired TransBtree<Integer, Integer> integerMap;
    
    class CreatorThread extends BenchmarkThread {       
        private int k, N;
        Random rand = new Random();
        
        public CreatorThread(String name, int count) {
            super(name);
            this.N = count;
            this.k = 0;
        }

        @Override
        protected void testBody() {
            integerMap.put(getTransaction(), rand.nextInt(1000000), rand.nextInt());
            k++;
        }

        @Override
        protected boolean isTestFinished() {
            return k >= N;
        }

        @Override
        protected boolean isCheckTimeNow() {
            return (k % (N/3) == 0) && (k > 1);
        }

        @Override
        protected TransactionIsolationLevel getTransactionIsolationLevel() {
            return TransactionIsolationLevel.READ_COMMITED;
        }

        @Override
        protected int getOperationsPerTransaction() {
            return 1000;
        }
    }
    
    class ReaderThread extends BenchmarkThread {
        
        private long testTime = 10 * 1000;    // 10 seconds
        private long checkPeriod = 2 * 1000;  // 2 seconds
        Random integerGenerator = new Random();
        private long startTime, nextCheckTime;

        public ReaderThread(String name) {
            super(name);
        }
        
        @Override
        protected void testBody() {
            Integer value = integerMap.get(getTransaction(), integerGenerator.nextInt(500000));
        }

        @Override
        protected boolean isTestFinished() {
            return System.currentTimeMillis() - startTime > testTime;
        }
        
        @Override
        public void start() {
            startTime = System.currentTimeMillis();            
            nextCheckTime = startTime + checkPeriod;
            super.start();
        }

        @Override
        protected boolean isCheckTimeNow() {
            if (System.currentTimeMillis() >= nextCheckTime) {
                nextCheckTime = System.currentTimeMillis() + checkPeriod;
                return true;
            }
            return false;
        }
        
        @Override
        protected TransactionIsolationLevel getTransactionIsolationLevel() {
            return TransactionIsolationLevel.READ_COMMITED;
        }

        @Override
        protected int getOperationsPerTransaction() {
            return 100000;
        }
    }
    
    @Test
    public void sequentialWriteAndRead() throws Throwable {
        RememberExceptionThread creator = new CreatorThread("creator", 100000);
        creator.start();
        
        creator.join();
        if (!creator.isSuccessful()) {
            throw creator.getThrownException();
        }

        
        RememberExceptionThread reader = new ReaderThread("reader");
        reader.start();
        
        reader.join();
        if (!reader.isSuccessful()) {
            throw reader.getThrownException();
        }
    }
    
    //@Ignore
    @Test
    public void writeAndReadConcurrent() throws Throwable {
        
        List<BenchmarkThread> creators = new ArrayList<BenchmarkThread>();
        
        for (int i=0; i<2; ++i)
            creators.add(new CreatorThread("creator " + i, 50000));

        for(BenchmarkThread t: creators) {
            t.start();
        }
        
        for(BenchmarkThread t: creators) {
            t.join();
            if (!t.isSuccessful()) {
                throw t.getThrownException();
            }
        }        

        List<BenchmarkThread> readers = new ArrayList<BenchmarkThread>();

        for (int i=0; i<3; ++i)
            readers.add(new ReaderThread("reader " + i));

        for(BenchmarkThread t: readers) {
            t.start();
        }
        
        for(BenchmarkThread t: readers) {
            t.join();
            if (!t.isSuccessful()) {
                throw t.getThrownException();
            }
        }
    }
    
    //@Ignore
    @Test
    public void concurrentWriteAndRead() throws Throwable {        
        RememberExceptionThread creator = new CreatorThread("initializer", 10000);
        creator.start();
        
        creator.join();
        if (!creator.isSuccessful()) {
            throw creator.getThrownException();
        }
                       
        List<BenchmarkThread> threads = new ArrayList<BenchmarkThread>();

        for (int i=0; i<2; ++i)
            threads.add(new CreatorThread("creator " + i, 50000));
        
        for (int i=0; i<2; ++i)
            threads.add(new ReaderThread("reader " + i));
                
        for(BenchmarkThread t: threads) {
            t.start();
            Thread.sleep(1000);
        }
        
        for(BenchmarkThread t: threads) {
            t.join();
            if (!t.isSuccessful()) {
                throw t.getThrownException();
            }
        }
    }
    
}
