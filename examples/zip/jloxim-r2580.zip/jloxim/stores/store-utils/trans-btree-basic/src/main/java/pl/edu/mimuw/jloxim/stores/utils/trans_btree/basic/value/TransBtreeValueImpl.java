/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Comparator;

/**
 * @author kadamczyk
 * @version $Id: TransBtreeValueImpl.java 2467 2011-09-14 19:33:57Z kadamczyk $
 */
public class TransBtreeValueImpl implements TransBtreeValue {

    @SuppressWarnings("unused")
    private final static Logger logger = Logger.getLogger(TransBtreeValueImpl.class);
    private byte[] data;
    private int len;
    private int pos;
    private int hash;
    private int meta;

    private static final int META_MASK = 0xf0000000;
    private static final int VALUE_MASK = 0x0fffffff;

    private static final int MIN_VALUE_META = 0x10000000;
    private static final int MAX_VALUE_META = 0x20000000;

    public static final TransBtreeValueImpl MIN_VALUE = new TransBtreeValueImpl(MIN_VALUE_META, "MIN_VALUE");
    public static final TransBtreeValueImpl MAX_VALUE = new TransBtreeValueImpl(MAX_VALUE_META, "MAX_VALUE");

    public TransBtreeValueImpl() {
        data = new byte[0];
        len = 0;
        pos = 0;
        meta = 0;
    }

    private TransBtreeValueImpl(int meta, String data) {
        this.meta = meta;
        this.data = data.getBytes();
        this.len = this.data.length;
        this.pos = 0;
    }

    public TransBtreeValueImpl(byte[] data) {
        this.data = data;
        this.len = data.length;
        this.pos = 0;
        this.meta = 0;
    }

    public TransBtreeValueImpl(byte[] data, int pos, int len) {
        if (pos < 0 || pos >= data.length || pos + len > data.length) {
            throw new ArrayIndexOutOfBoundsException("pos out of range:" + pos);
        }

        this.data = data;
        this.len = len;
        this.pos = pos;
        this.meta = 0;
    }

    public TransBtreeValueImpl(String data) {
        this.data = data.getBytes();
        this.len = this.data.length;
        this.pos = 0;
        this.meta = 0;
    }

    @Override
    public byte[] getData() {
        return data;
    }

    @Override
    public void setData(byte[] data, int pos, int len) {
        if (pos < 0 || pos >= data.length || pos + len > data.length) {
            throw new ArrayIndexOutOfBoundsException("pos out of range:" + pos);
        }

        this.data = data;
        this.len = len;
        this.pos = pos;
        this.meta = 0;
    }

    public void setData(String data) {
        this.data = data.getBytes();
        this.len = this.data.length;
        this.pos = 0;
        this.meta = 0;
    }

    @Override
    public int serializeInto(ByteBuffer data) {
        data.putInt(meta | len);
        data.put(this.data, pos, len);
        return serializableLength();
    }

    @Override
    public int deserialize(ByteBuffer data) {
        int tmp = data.getInt();
        this.meta = tmp & META_MASK;
        this.len = tmp & VALUE_MASK;

        this.data = new byte[len];
        data.get(this.data, 0, len);
        this.pos = 0;

        return serializableLength();
    }

    @Override
    public int serializableLength() {
        return len + Integer.SIZE;
    }

    @Override
    public int hashCode() {
        // String.hashCode()
        if (hash == 0) {
            int tempHash = 0;
            for (int i = 0; i < len; i++) {
                tempHash = 31 * tempHash + data[pos + i];
            }
            this.hash = Math.abs(tempHash);
        }
        return hash;
    }

    public boolean equals(TransBtreeValueImpl value) {
        return len == value.len && compareTo(value) == 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj instanceof TransBtreeValueImpl) {
            return equals((TransBtreeValueImpl) obj);
        }

        return obj != null && equals(new TransBtreeValueImpl(obj.toString()));
    }

    @Override
    public final String toString() {
        try {
            return new String(data, pos, len, "utf-8");
        } catch (UnsupportedEncodingException e) {
            return "" + data;
        }
    }
    
    protected int compareMata(TransBtreeValueImpl value) {
        if (this.meta == MAX_VALUE_META) {
            if (value.meta == MAX_VALUE_META) {
                return 0;
            } else {
                return 1;
            }
        }
        if (this.meta == MIN_VALUE_META) {
            if (value.meta == MIN_VALUE_META) {
                return 0;
            }
            return -1;
        }
        if (value.meta == MAX_VALUE_META) {
            return -1;
        }
        if (value.meta == MIN_VALUE_META) {
            return 1;
        }       
  
        return 0;
    }

    // TODO potrzebne?
    public int compareTo(TransBtreeValueImpl value) {

        if (this.meta + value.meta > 0)
          return compareMata(value);

        byte[] ddata = value.data;
        int dpos = value.pos;
        int dlen = value.len;

        if (len != dlen) {
            return len > dlen ? dlen + 1 : -(len + 1);
        }

        for (int i = 0; i < len; i++) {
            byte b1 = data[pos + i];
            byte b2 = ddata[dpos + i];
            if (b1 != b2) {
                return b1 > b2 ? (i + 1) : -(i + 1);
            }
        }

        return 0;
    }

    public int compareTo(TransBtreeValueImpl value, Comparator<TransBtreeValue> comparator) {

        if (this.meta + value.meta > 0)
          return compareMata(value);

        return comparator.compare(this, value);
    }

    @Override
    public int compareTo(Object obj) {
        if (obj instanceof TransBtreeValueImpl) {
            return compareTo((TransBtreeValueImpl) obj);
        }

        return compareTo(new TransBtreeValueImpl(obj.toString()));
    }
}
