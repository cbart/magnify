/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import org.apache.log4j.Logger;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

/**
 *
 * @author kadamczyk
 * @version $Id: AbstractTransBtreePerfTest.java 2423 2011-07-26 22:34:12Z kadamczyk $
 */
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(locations = {"/TransBtreeSpringTest-context.xml"})
abstract public class AbstractTransBtreePerfTest {
    
    private static final Logger logger = Logger.getLogger(AbstractTransBtreePerfTest.class);

    @Autowired public TransactionManager transactionManager;
    
    private static long opTotal = 1;
    private static long startTime = 0;
    private long checkPoint = 200000;
    
    abstract class BenchmarkThread extends RememberExceptionThread {
        
        private Transaction transaction;
 
        public BenchmarkThread(String name) {
            super(name);
        }
                
        protected Transaction getTransaction() {        
            return transaction;
        }
        
        abstract protected void testBody();
        abstract protected boolean isTestFinished();
        abstract protected boolean isCheckTimeNow();
        abstract protected TransactionIsolationLevel getTransactionIsolationLevel();
        abstract protected int getOperationsPerTransaction();

        @Override
        public void runWithException() throws Exception {

            long threadOpNumber = 0;
            long threadStartTime = System.currentTimeMillis();
            long opPerTransaction = getOperationsPerTransaction();

            transaction = transactionManager.newTransaction(getTransactionIsolationLevel());
            while(!isTestFinished()) {

                if (isCheckTimeNow()) {
                    long realTimePeriod = System.currentTimeMillis() - threadStartTime;
                    if (realTimePeriod > 0)
                        logger.error(String.format("thread %10d operatins in %5d seconds, rate: %5d", threadOpNumber, realTimePeriod / 1000, (threadOpNumber * 1000) / realTimePeriod));
                    threadOpNumber = 0;
                    threadStartTime = System.currentTimeMillis();
                }
                
                //synchronized (logger) {
                //    if (opTotal % checkPoint == 0) {
                //        long realTimePeriod = System.currentTimeMillis() - startTime;
                //        if (realTimePeriod > 0 && opTotal > 0)
                //            logger.error(String.format("total %10d operatins in %5d seconds, rate: %5d", opTotal, realTimePeriod / 1000, (opTotal * 1000) / realTimePeriod));
                //        opTotal = 1;
                //        startTime = System.currentTimeMillis();
                //    }
                //}

                if (threadOpNumber % opPerTransaction == 0) {
                    transaction.commit();
                    transaction = transactionManager.newTransaction(getTransactionIsolationLevel());
                }

                try {
                    testBody();

                } catch (InterruptedOperationTransBtreeException e) {
                    logger.error(e);
                    transaction = transactionManager.newTransaction(getTransactionIsolationLevel());
                }

                threadOpNumber++;
                opTotal++;
            }
            
            transaction.commit();
        }
    }
    
}
