/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.RawTransBtree;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Comparator;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author kadamczyk
 * @version $Id: TransBtreeImpl.java 2505 2011-09-26 06:05:41Z kadamczyk $
 */
public class TransBtreeImpl<KEY, VALUE> implements TransBtree<KEY, VALUE> {

    private static final Logger logger = Logger.getLogger(TransBtreeImpl.class);
    
    @Autowired private RawTransBtree rawTransBtree;
    
    private TransBtreeValueBinding<KEY> keyBinding;
    private TransBtreeValueBinding<VALUE> valueBinding;
    private Comparator<TransBtreeValue> keyComparator;
    private String name;

    public void init() {
        rawTransBtree.setKeyComparator(keyComparator);
        ((RawTransBtreeImpl)rawTransBtree).init();
    }
    
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setKeyBinding(TransBtreeValueBinding<KEY> keyBinding) {
        this.keyBinding = keyBinding;
    }

    @Override
    public void setValueBinding(TransBtreeValueBinding<VALUE> valueBinding) {
        this.valueBinding = valueBinding;
    }

    @Override
    public void setRootPageId(int pageId) {
        rawTransBtree.setRootPageId(pageId);
    }

    public RawTransBtree getRawTransBtree() {
        return rawTransBtree;
    }

    public void setRawTransBtree(RawTransBtree rawTransBtree) {
        this.rawTransBtree = rawTransBtree;
    }

    @Override
    public void setKeyComparator(Comparator<TransBtreeValue> keyComparator) {
        this.keyComparator = keyComparator;   
        rawTransBtree.setKeyComparator(keyComparator);
    }      

    @Override
    public ClosableIterator<? extends Map.Entry<KEY, VALUE>> iterator(Transaction transaction) {
        return new RecordIteratorConverter<KEY, VALUE>(rawTransBtree.iterator(transaction), keyBinding, valueBinding);
    }

    @Override
    public ClosableIterator<? extends Map.Entry<KEY, VALUE>> find(Transaction transaction, KEY key) throws TransBtreeException {
        TransBtreeValue rKey = new TransBtreeValueImpl();
        keyBinding.objectToRawValue(key, rKey);
        return new RecordIteratorConverter<KEY, VALUE>(rawTransBtree.find(transaction, rKey), keyBinding, valueBinding);
    }

    @Override
    public VALUE get(Transaction transaction, KEY key) throws TransBtreeException {
        TransBtreeValue rKey = new TransBtreeValueImpl();
        keyBinding.objectToRawValue(key, rKey);
        TransBtreeValue rValue = rawTransBtree.get(transaction, rKey);
        if ( rValue != null )
            return valueBinding.rawValueToObject(rValue);
        else
            return null;
    }

    @Override
    public void put(Transaction transaction, KEY key, VALUE value) throws TransBtreeException {        
        TransBtreeValue rKey = new TransBtreeValueImpl();
        keyBinding.objectToRawValue(key, rKey);
        TransBtreeValue rValue = new TransBtreeValueImpl();
        valueBinding.objectToRawValue(value, rValue);
        rawTransBtree.put(transaction, rKey, rValue);
    }

    @Override
    public void remove(Transaction transaction, KEY key) throws TransBtreeException {
        TransBtreeValue rKey = new TransBtreeValueImpl();
        keyBinding.objectToRawValue(key, rKey);
        rawTransBtree.remove(transaction, rKey);
    }

    @Override
    public boolean isEmpty(Transaction transaction) throws TransBtreeException {
        return rawTransBtree.isEmpty(transaction);
    }

    @Override
    public void clear(Transaction transaction) throws TransBtreeException {
        rawTransBtree.clear(transaction);
    }

    @Override
    public void drop(Transaction transaction) throws TransBtreeException {
        rawTransBtree.drop(transaction);
    }

    public String printDebug(Transaction transaction) {
        String log = new String();
        log += name + ".pringDebug ";
        log += ((RawTransBtreeImpl)rawTransBtree).printDebug(transaction, keyBinding, valueBinding);
        return log;
    }
}
