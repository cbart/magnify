/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author kadamczyk
 * @version $Id: NodeManagerTest.java 2467 2011-09-14 19:33:57Z kadamczyk $
 */
public class NodeManagerTest extends AbstractNodeTest {
    
    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(LeafNodeTest.class);
    
    @Test
    public void nodeManager() {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        RootNode root = nodeManager.newRootNode(t);
        root.write();
        t.commit();

        t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        RootNode root2 = nodeManager.getRootNode(t, root.getId(), BufferUsePurpose.READ_WRITE);

        LongOid key = new LongOid(0);
        root2.putPointer(longOidToValue(key), 1);
        root2.write();

        RootNode root3 = nodeManager.getRootNode(t, root.getId(), BufferUsePurpose.READ);

        Assert.assertFalse(root3.isEmpty());
        Assert.assertEquals(1, root3.getPointer(longOidToValue(key)));

        t.commit();
    }
         
    @Test
    public void changeUsePurpose() {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

        LeafNode node = nodeManager.newLeafNode(t);
        node.write();
        t.commit();

        Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Transaction t3 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        LeafNode node2 = nodeManager.getLeafNode(t2, node.getId(), BufferUsePurpose.READ);
        LeafNode node3 = nodeManager.getLeafNode(t3, node.getId(), BufferUsePurpose.READ);

        t2.commit();

        node3.changeUsePurpose(BufferUsePurpose.READ_WRITE);
        node3.putValue(longOidToValue(new LongOid(3)), stringToValue("trrzy"));
        node3.write();
        t3.commit();
    }

    @Test
    public void releaseNodeTest() {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);               
        LeafNode node = nodeManager.newLeafNode(t);
        node.write();
        int nodeId = node.getId();
        t.commit();        

        // return unchenged page
        {
          Transaction t1 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
          Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        
          node = nodeManager.getLeafNode(t1, nodeId, BufferUsePurpose.READ_WRITE);
          node.changeUsePurpose(BufferUsePurpose.READ);
                
          nodeManager.getLeafNode(t2, nodeId, BufferUsePurpose.READ);
        
          t1.commit();
          t2.commit();
        }

        {
          Transaction t1 = transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
          Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

          nodeManager.getLeafNode(t1, nodeId, BufferUsePurpose.READ);
          
          node = nodeManager.getLeafNode(t2, nodeId, BufferUsePurpose.READ);
          node.changeUsePurpose(BufferUsePurpose.READ_WRITE);

          t1.commit();
          t2.commit();
        }
        
    }

    
}
