/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

import java.util.Arrays;
import java.util.Comparator;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;

/**
 *
 * @author kadamczyk
 * @version $Id: LeafNode.java 2418 2011-07-18 21:53:41Z kadamczyk $
 */
public class LeafNode extends TreeNode {

    private final static Logger logger = Logger.getLogger(LeafNode.class);
    private TransBtreeValue[] values;
    private PageManager pageManager;

    public LeafNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator, PageManager pageManager) throws TransactionException {
        super(page, keyComparator);
        this.pageManager = pageManager;
    }

    public static LeafNode newNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator, PageManager pageManager) {
        page.getContent().clear();
        LeafNode node = new LeafNode(page, keyComparator, pageManager);
        node.clear();
        return node;
    }

    @Override
    public void read() throws TransactionException {
        try {
            page.beginWorkingOnPage(false);
            super.read();

            keys = new TransBtreeValueImpl[getKeyCount()];
            values = new TransBtreeValueImpl[getKeyCount()];

            //deserialize
            for (int i = 0; i < getKeyCount(); ++i) {
                TransBtreeValueImpl key = new TransBtreeValueImpl();
                key.deserialize(data);
                keys[i] = key;

                TransBtreeValueImpl value = new TransBtreeValueImpl();
                value.deserialize(data);
                values[i] = value;
            }
        } finally {
            page.finishWorkingOnPage(false);
        }
    }

    @Override
    public void write() throws TransactionException {
        try {
            page.beginWorkingOnPage(true /*will write*/);
            super.write();

            //serialize
            for (int i = 0; i < getKeyCount(); ++i) {
                keys[i].serializeInto(data);
                values[i].serializeInto(data);
            }
        } finally {
            page.finishWorkingOnPage(true /*mark dirty*/);
        }
    }

    public void putValue(TransBtreeValue key, TransBtreeValue value) {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Adding value to node with use purpose  " + page.getUsePurpose());
        }

        if (key == null || key.serializableLength() == 0) {
            logger.info("putValue: Invalid key: '" + key + "'");
            return;
        }
        if (value == null || value.serializableLength() == 0) {
            logger.info("putValue: Invalid TransBtreeValueImpl: '" + value + "'");
            return;
        }

        int idx = Arrays.binarySearch(keys, key, keyComparator);
        if (idx >= 0) {
            // update page header
            incFreeSpace(values[idx].serializableLength());
            decFreeSpace(value.serializableLength());

            this.values[idx] = value;
        } else {
            idx = -(idx + 1);

            // update page header
            decFreeSpace((key.serializableLength() + value.serializableLength()));
            incKeyCount();

            this.keys = ArrayUtils.arrayInsert(keys, key, idx);
            this.values = ArrayUtils.arrayInsert(values, value, idx);
        }
    }

    public TransBtreeValue getValue(TransBtreeValue key) {
        int idx = Arrays.binarySearch(keys, key, keyComparator);

        if (idx >= 0) {
            //key found
            return values[idx];
        } else {
            //key not found
            return null;
        }
    }

    public void removeValue(TransBtreeValue key) {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Removing value from node with use purpose  " + page.getUsePurpose());
        }

        int idx = Arrays.binarySearch(keys, key, keyComparator);

        if (idx >= 0) { //key found
            // update page header
            incFreeSpace(keys[idx].serializableLength() + values[idx].serializableLength());
            decKeyCount();

            keys = ArrayUtils.arrayDelete(keys, idx);
            values = ArrayUtils.arrayDelete(values, idx);
        } else { //key not found
            logger.debug("LeafNode:removeValue: Key '" + key + "' doesn't exist.");
        }
    }

    @Override
    public boolean needSplit(int KEY_LENGTH_MAX) {
        return getFreeSpace() < 0;
    }

    @Override
    public TreeNode split(TransactionBufferPage page) throws TransactionException {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Spliting node with use purpose  " + page.getUsePurpose());
        }

        consistencyCheck();

        int size = getDataLength();
        int tsize = 0;
        int pivot = 0;
        while (tsize <= (size / 2) && pivot < keys.length) {
            tsize += keys[pivot].serializableLength();
            tsize += values[pivot].serializableLength();
            ++pivot;
        }

        // left node [0:pivot)
        // right node [pivot:end]

        // split keys
        TransBtreeValue[] leftKeys = new TransBtreeValueImpl[pivot];
        TransBtreeValue[] rightKeys = new TransBtreeValueImpl[keys.length - pivot];
        System.arraycopy(keys, 0, leftKeys, 0, leftKeys.length);
        System.arraycopy(keys, leftKeys.length, rightKeys, 0, rightKeys.length);

        // split values
        TransBtreeValue[] leftValues = new TransBtreeValueImpl[pivot];
        TransBtreeValue[] rightValues = new TransBtreeValueImpl[values.length - pivot];
        System.arraycopy(values, 0, leftValues, 0, leftValues.length);
        System.arraycopy(values, leftValues.length, rightValues, 0, rightValues.length);

        //rightNode
        LeafNode rightNode = LeafNode.newNode(page, keyComparator, pageManager);
        rightNode.keys = rightKeys;
        rightNode.values = rightValues;
        rightNode.setKeyCount(rightKeys.length);
        rightNode.decFreeSpace(size - tsize);
        rightNode.setNextNodeId(this.getNextNodeId());
        //rightNode.setKeyComparator(keyComparator);
                        
        if (rightNode.getMaxKey() == null) {
            logger.error("split keys.length=" + keys.length + " pivot=" + pivot + " rkeyCount=" + rightNode.getKeyCount() + " tsize=" + tsize);
        }

        //leftNode - this
        this.clear();
        this.keys = leftKeys;
        this.values = leftValues;
        this.setKeyCount(leftKeys.length);
        this.decFreeSpace(tsize);
        this.setNextNodeId(rightNode.getId());

        return rightNode;
    }

    public TransBtreeValue[] getValues() {
        return values;
    }

    public void clear() {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Clearing node with use purpose  " + page.getUsePurpose());
        }

        setNodeType(NodeType.LEAF_NODE);
        setKeyCount(0);
        setFreeSpace(data.capacity() - getHeaderLength());

        keys = new TransBtreeValueImpl[0];
        values = new TransBtreeValueImpl[0];
    }

    @Override
    public int getHeaderLength() {
        return super.getHeaderLength() + 0;
    }

    @Override
    public void remove() throws TransactionException {
        page.markToRemove();
    }

    @Override
    public void consistencyCheck() throws TransactionException {
        super.consistencyCheck();

        if (getNodeType() != NodeType.LEAF_NODE) {
            logger.error("checkConsistance: wrong node type:" + getNodeType() + " expected:" + NodeType.LEAF_NODE);
        }

        int size = 0;
        for (int i = 0; i < keys.length; i++) {
            size += keys[i].serializableLength();
            size += values[i].serializableLength();
        }

        if (size != getDataLength()) {
            logger.error("wrong value length " + getDataLength() + " size " + size);
        }
    }

    //*
    @Override
    public String debug(TransBtreeValueBinding keyBinding, TransBtreeValueBinding valueBinding) {
        String info = super.debug(keyBinding, valueBinding);
        
        info += "\n keys.length: " + keys.length + " value:";
        for (int i = 0; i < getKeyCount(); ++i) {
            if (keys[i].compareTo(TransBtreeValueImpl.MAX_VALUE) != 0) {
                info += "'" + keyBinding.rawValueToObject(keys[i]) + "' => '" + valueBinding.rawValueToObject(values[i]) + "', ";
            } else {
                info += "'" + keys[i] + "' => '" + values[i] + "', ";
            }
        }
        info += "\n";

        return info;
    }
    //*/

}
