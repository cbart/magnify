/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.Test;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;

import java.nio.ByteBuffer;

import static org.junit.Assert.*;

/**
 * @author kadamczyk
 * @version $Id: LeafNodeExtTest.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/TransBtreeSpringTest-context.xml"})
public class LeafNodeExtTest {
    
    private static final Logger logger = Logger.getLogger(LeafNodeExtTest.class);

    @Autowired PageManager pageManager;
    @Autowired TransactionManager transactionManager;

    @Test
    public void readBuffers() {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        TransactionBufferPage page1 = pageManager.allocatePage(t);
        TransactionBufferPage page2 = pageManager.allocatePage(t);
        TransactionBufferPage page3 = pageManager.allocatePage(t);

        ByteBuffer vbuffer = ByteBuffer.allocate(page1.getContent().capacity() * 3);
        
        vbuffer.rewind();        
        for (int i=0; i < (page1.getContent().capacity()* 3) / 4; ++i) {
            logger.debug(i + " " + vbuffer.putInt(7));            
        }
        
        vbuffer.rewind();
        for (int i=0; i < (page1.getContent().capacity()* 3) / 4; ++i) {
            logger.debug("v2[" + i + "] " + vbuffer.getInt());
        }
        //vbuffer.putInt(54321);

        ByteBuffer b1 = page1.getContent();
        ByteBuffer b2 = page2.getContent();
        ByteBuffer b3 = page3.getContent();
        
        vbuffer.rewind();
        System.arraycopy(vbuffer.array(), 0, b1.array(), 0, b1.capacity());
        System.arraycopy(vbuffer.array(), b1.capacity(), b2.array(), 0, b2.capacity());
        System.arraycopy(vbuffer.array(), b2.capacity() * 2, b3.array(), 0, b3.capacity());
        
        ByteBuffer vbuffer2 = ByteBuffer.allocate(page1.getContent().capacity() * 3);
        System.arraycopy(b1.array(), 0, vbuffer2.array(), 0, b1.capacity());
        System.arraycopy(b2.array(), 0, vbuffer2.array(), b2.capacity(), b1.capacity());
        System.arraycopy(b3.array(), 0, vbuffer2.array(), b2.capacity()*2, b2.capacity());

        vbuffer2.rewind();        
        for (int i=0; i < (page1.getContent().capacity()* 3) / 4; ++i) {
            logger.debug("v2[" + i + "] " + vbuffer2.getInt());
        }
        
        //assertEquals(12345, vbuffer.getInt(page1.getContent().capacity()));
    }
}
