/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;

import java.nio.ByteBuffer;

/**
 * @author kadamczyk
 * @version $Id: LeafNodeExt.java 2505 2011-09-26 06:05:41Z kadamczyk $
 */
public class LeafNodeExt {

    private final static Logger logger = Logger.getLogger(TreeNode.class);    
    TransactionBufferPage page;
    protected ByteBuffer data;
    private NodeType nodeType;
    private int nextNodeId;
    private int dataLength;
    private byte[] vdata;
    
    public LeafNodeExt(TransactionBufferPage page) {
        this.page = page;
    }

    public int getNextNodeId() {
        return nextNodeId;
    }

    public void setNextNodeId(int nextNodeId) {
        this.nextNodeId = nextNodeId;
    }

    public byte[] getVdata() {
        return vdata;
    }

    public void setVdata(byte[] vdata) {
        this.vdata = vdata;
        this.dataLength = vdata.length;
    }

    public int getDataLength() {
        return dataLength;
    }
    
    public int getCapacity() {
        return data.capacity() - (3 * Integer.SIZE);
    }

    public int read() {
        data.rewind();
        this.nodeType = NodeType.get(data.getInt());
        this.nextNodeId = data.getInt();
        this.dataLength = data.getInt();
        
        vdata = new byte[dataLength];
        for (int i = 0; i < dataLength; ++i) {
          vdata[i] = data.get();
        }

        return dataLength + (3 * Integer.SIZE);
    }

    public int write() {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Writing on page with use purpose  " + page.getUsePurpose());
        }
        data.rewind();
        data.putInt(nodeType.getValue());
        data.putInt(nextNodeId);        
        data.putInt(vdata.length);
        data.put(vdata, 0, vdata.length);

        return vdata.length + (3 * Integer.SIZE);
    }

    public void remove() throws TransactionException {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Removing node with use purpose  " + page.getUsePurpose());
        }

        page.markToRemove();
    }
}
