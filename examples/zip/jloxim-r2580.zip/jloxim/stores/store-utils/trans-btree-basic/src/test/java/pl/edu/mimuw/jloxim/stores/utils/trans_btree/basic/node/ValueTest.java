/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding.LongOidBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding.StringBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.comparator.LongOidComparator;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.ComparatorConverter;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeRecordImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

/**
 * @author kadamczyk
 * @version $Id: ValueTest.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
public class ValueTest {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(ValueTest.class);

    TransBtreeValueBinding<LongOid> longOidBinding = new LongOidBinding();
    TransBtreeValueBinding<String> stringBinding = new StringBinding();

    Comparator<TransBtreeValue> longOidComparator = new ComparatorConverter(new LongOidComparator());

    @Test
    public void infinityValues() {

        Assert.assertTrue(TransBtreeValueImpl.MIN_VALUE.compareTo(TransBtreeValueImpl.MAX_VALUE) == -1);
        Assert.assertTrue(TransBtreeValueImpl.MAX_VALUE.compareTo(TransBtreeValueImpl.MIN_VALUE) == 1);

        Assert.assertTrue(TransBtreeValueImpl.MIN_VALUE.compareTo(TransBtreeValueImpl.MIN_VALUE) == 0);
        Assert.assertTrue(TransBtreeValueImpl.MAX_VALUE.compareTo(TransBtreeValueImpl.MAX_VALUE) == 0);

        Assert.assertEquals(new TransBtreeRecordImpl<TransBtreeValueImpl, TransBtreeValueImpl>(TransBtreeValueImpl.MAX_VALUE, TransBtreeValueImpl.MAX_VALUE), new TransBtreeRecordImpl<TransBtreeValueImpl, TransBtreeValueImpl>(TransBtreeValueImpl.MAX_VALUE, TransBtreeValueImpl.MAX_VALUE));

        Assert.assertTrue(TransBtreeValueImpl.MAX_VALUE.compareTo(new TransBtreeValueImpl("SUPER_MAX_VALUE")) == 1);
        Assert.assertTrue((new TransBtreeValueImpl("SUPER_MAX_VALUE")).compareTo(TransBtreeValueImpl.MAX_VALUE) == -1);

        final int COUNT = 5000;
        for (int i = 0; i < COUNT; ++i) {
            TransBtreeValue value = new TransBtreeValueImpl();
            LongOid oId = new LongOid(100000000 + new Random().nextInt());
            longOidBinding.objectToRawValue(oId, value);

            TransBtreeValue value2 = new TransBtreeValueImpl();
            LongOid oId2 = new LongOid(new Random().nextInt());
            longOidBinding.objectToRawValue(oId2, value2);

            Assert.assertTrue(value.compareTo(TransBtreeValueImpl.MAX_VALUE) == -1);
            Assert.assertTrue(value.compareTo(TransBtreeValueImpl.MIN_VALUE) == 1);

            Assert.assertTrue(value2.compareTo(TransBtreeValueImpl.MAX_VALUE) == -1);
            Assert.assertTrue(value2.compareTo(TransBtreeValueImpl.MIN_VALUE) == 1);
        }
    }

    @Test
    public void compareTest() {
        Assert.assertEquals(new TransBtreeValueImpl("value"), new TransBtreeValueImpl("value"));
        Assert.assertTrue(new TransBtreeValueImpl(" ").hashCode() == new TransBtreeValueImpl(" ").hashCode());
        Assert.assertTrue(new TransBtreeValueImpl("basic").hashCode() == new TransBtreeValueImpl("basic").hashCode());
        Assert.assertFalse(new TransBtreeValueImpl("basic").hashCode() == new TransBtreeValueImpl("basis").hashCode());

        Assert.assertNotSame(new TransBtreeValueImpl("name_0"), new TransBtreeValueImpl("name_1"));

        Assert.assertTrue((new TransBtreeValueImpl("123000")).compareTo(new TransBtreeValueImpl("124000")) == -3);
    }

    @Test
    public void sortTest() {

        final int COUNT = 100000;
        TransBtreeValue[] values = new TransBtreeValueImpl[COUNT + 2];

        for (int i = 0; i < COUNT; ++i) {
            TransBtreeValue value = new TransBtreeValueImpl();
            //LongOid oId = new LongOid(new Random().nextInt());
            LongOid oId = new LongOid(COUNT - i);
            longOidBinding.objectToRawValue(oId, value);
            values[i] = value;
        }

        values[COUNT] = TransBtreeValueImpl.MAX_VALUE;
        values[COUNT + 1] = TransBtreeValueImpl.MIN_VALUE;

        Arrays.sort(values, longOidComparator);

        for (int i = 1; i < COUNT + 2; ++i) {
            //logger.info("sortTest:" + longOidBinding.rawValueToObject(values[i-1]).toString() );
            Assert.assertTrue( longOidComparator.compare(values[i], values[i - 1]) >= 0);
        }

        int idx = Arrays.binarySearch(values, TransBtreeValueImpl.MAX_VALUE, longOidComparator);
        logger.info("MAX_VALUE idx = " + idx);
        Assert.assertEquals(COUNT + 1, idx);
    }

    @Test
    public void serialize() {
        ByteBuffer buffer = ByteBuffer.allocate(256);

        final int COUNT = 100;
        for (int i = 0; i < COUNT; i++) {
            buffer.rewind();

            TransBtreeValueImpl value = new TransBtreeValueImpl();
            LongOid oId = new LongOid(i);
            longOidBinding.objectToRawValue(oId, value);
            int ret = value.serializeInto(buffer);
            Assert.assertTrue(ret == value.serializableLength());
            //log.info("write:'" + value + "'");

            value = new TransBtreeValueImpl("123");
            ret = value.serializeInto(buffer);
            Assert.assertTrue(ret == value.serializableLength());
            //log.info("write:'" + value + "'");

            value = new TransBtreeValueImpl();
            String text = Integer.toString(i);
            stringBinding.objectToRawValue(text, value);
            ret = value.serializeInto(buffer);
            Assert.assertTrue(ret == value.serializableLength());
            //log.info("write:'" + value + "'");

            TransBtreeValueImpl value2 = new TransBtreeValueImpl();
            buffer.rewind();

            ret = value2.deserialize(buffer);
            //log.info("read:'" + value2 + "'");
            Assert.assertTrue(ret == value2.serializableLength());
            longOidBinding.objectToRawValue(oId, value);
            Assert.assertEquals(value2, value);

            ret = value2.deserialize(buffer);
            //log.info("read:'" + value2 + "'");
            Assert.assertTrue(ret == value2.serializableLength());
            Assert.assertEquals(value2, new TransBtreeValueImpl("123"));

            ret = value2.deserialize(buffer);
            //log.info("read:'" + value2 + "'");
            Assert.assertTrue(ret == value2.serializableLength());
            stringBinding.objectToRawValue(text, value);
            Assert.assertEquals(value2, value);
        }
    }
}
