/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import java.util.Map.Entry;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeRecordImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;

/**
 * @author kadamczyk
 * @version $Id: TransBtreeImplTest.java 2423 2011-07-26 22:34:12Z kadamczyk $
 */
 
public class TransBtreeImplTest extends AbstractTransBtreeTest {

    private static final Logger logger = Logger.getLogger(RawTransBtreeImpl.class);

     
    @Test
    public void clearTest() {
        
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        longOidToStringMap.clear(t);

        final int COUNT = 50;
        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(i);
            String value = Integer.toString(i);
            longOidToStringMap.put(t, key, value);
            //logger.debug("rec " + i);
        }
        
        for (int i = 0; i < COUNT / 2; ++i) {
            LongOid key = new LongOid(i);
            longOidToStringMap.remove(t, key);
        }

        longOidToStringMap.clear(t);

        Assert.assertTrue(longOidToStringMap.isEmpty(t));

        ClosableIterator<? extends Map.Entry<LongOid, String>> iter = longOidToStringMap.iterator(t);
        try {
            Assert.assertFalse(iter.hasNext());
        } finally {
            iter.close();
        }

        longOidToStringMap.clear(t);
        t.commit();
    }

     
    @Test
    public void iteratorTest() {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        longOidToStringMap.clear(t);

        final int COUNT = 1000;
        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(i);
            String value = Integer.toString(i);
            longOidToStringMap.put(t, key, value);
            //logger.debug("rec " + i);
        }
        
        //((TransBtreeImpl)longOidToStringMap).printDebug(t);

        ClosableIterator<? extends Map.Entry<LongOid, String>> iter = longOidToStringMap.iterator(t);
        try {
            for (int i = 0; i < COUNT; ++i) {
                Assert.assertTrue(iter.hasNext());

                Map.Entry<LongOid, String> record = iter.next();
                logger.debug("rec " + i + " " + record);
                LongOid key = new LongOid(i);
                String value = Integer.toString(i);
                Assert.assertEquals(new TransBtreeRecordImpl<LongOid, String>(key, value), record);
            }

            // last value is a special value
            Assert.assertFalse(iter.hasNext());
        } finally {
            iter.close();
        }

        longOidToStringMap.clear(t);
        longOidToStringMap.drop(t);
        t.commit();
    }

    @Test
    public void transactionCommit() {        
        logger.info("transactionCommit start");
        
        Transaction t0 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        longOidToStringMap.clear(t0);
        t0.commit();        

        final int COUNT = 500;

        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(Math.abs(i + 10000000L));
            String value = Integer.toString(i);

            Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            Assert.assertNull(longOidToStringMap.get(t, key));
            longOidToStringMap.put(t, key, value);
            Assert.assertNotNull(longOidToStringMap.get(t, key));
            //logger.error(printDebug(t));
            t.commit();

            Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            //logger.error(printDebug(t2));
            String value2 = longOidToStringMap.get(t2, key);
            if (value2 == null) {
                logger.error(printDebug(t2));
                logger.error("get " + key);
            }
            Assert.assertNotNull(value2);
            Assert.assertNotNull(longOidToStringMap.get(t2, key));
            t2.commit();

            //logger.error("step " + i);        
        }       
    }

     
    @Test
    public void putAndGet() throws TransactionException, TransBtreeException {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);        

        final int COUNT = 1000;
        List<LongOid> insertedKeys = new ArrayList<LongOid>();

        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(i);
            String value = Integer.toString(i);
            longOidToStringMap.put(t, new LongOid(i), "" + i);

            //longOidToStringMapImpl.printDebug(t);
            //logger.debug("test " + key + " " + value + " " + longOidToStringMap.get(t, key));

            String value2 = longOidToStringMap.get(t, key);
            if (value2 == null) {
                printDebug(t);
                logger.error("get k " + key + " v " + value);
            }
            Assert.assertEquals(value, value2);

            // once again
            longOidToStringMap.put(t, key, value);
            insertedKeys.add(key);
        }

        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(new Random().nextInt());
            String value = Integer.toString(i);

            //logger.info("put " + key + " " + value);
            longOidToStringMap.put(t, key, value);

            String value2 = longOidToStringMap.get(t, key);
            if (value2 == null) {
                logger.info("get " + key + " " + value);
                printDebug(t);
            }
            Assert.assertEquals(value, value2);
        }

        for (LongOid a : insertedKeys) {
            String value3 = longOidToStringMap.get(t, a);
            if (value3 == null) {
                printDebug(t);
                logger.error("get " + a);
            }
            Assert.assertNotNull(value3);
        }
        
        for (LongOid a : insertedKeys) {
            ClosableIterator<? extends Entry<LongOid, String>> it = longOidToStringMap.find(t, a);
            Assert.assertTrue(it.hasNext());
            Entry<LongOid, String> rec = it.next();
            Assert.assertNotNull(rec);
            Assert.assertEquals(a, rec.getKey());
        }

        //longOidToStringMapImpl.printDebug(t);

        longOidToStringMap.drop(t);
        t.commit();
    }

     
    @Test(expected = NullPointerException.class)
    public void nullTransaction() {
        LongOid key = new LongOid(4);
        String value = Integer.toString(5);
        longOidToStringMap.put(null, key, value);
    }

     
    @Test
    public void iteratorFindTest() {

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

        final int COUNT = 500;
        for (int i = 0; i < COUNT; ++i) {
            LongOid key = new LongOid(Math.abs(new Random().nextInt() % 1000));
            String value = Integer.toString(i + 1);
            longOidToStringMap.put(t, key, value);

            //logger.info(key.toString());
            //longOidToStringMapImpl.printDebug(t);

            ClosableIterator<? extends Map.Entry<LongOid, String>> iter = longOidToStringMap.find(t, key);
            try {
                if (!iter.hasNext()) {
                    printDebug(t);
                    logger.error("find " + key + "=>" + value + " failed");
                    logger.error("get " + key + " : " + longOidToStringMap.get(t, key));
                }

                Assert.assertTrue(iter.hasNext());
                Assert.assertEquals(new TransBtreeRecordImpl<LongOid, String>(key, value), iter.next());
            } finally {
                iter.close();
            }
        }

        longOidToStringMap.clear(t);
        t.commit();
    }

      
    @Test
    public void concurrentOperationsTest() throws Throwable {
        logger.info("concurrentOperationsTest started");
        final int COUNT = 500;

        RememberExceptionThread writer = new RememberExceptionThread() {
            @Override
            public void runWithException() throws TransBtreeException {
                setName("writer");
                Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                try {
                    for (int i = 0; i < COUNT; i++) {
                        LongOid key = new LongOid(i);
                        LongOid key2 = new LongOid(i);
                        String value = Integer.toString(new Random().nextInt());
                        try {
                            longOidToStringMap.put(t, key, value);
                            longOidToStringMap.put(t, key2, value);
                        } catch (InterruptedOperationTransBtreeException e) {
                            logger.error(e);
                            t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                        }
                    }
                } finally {
                    t.commit();
                }
            }
        };

        RememberExceptionThread randomWriter = new RememberExceptionThread() {
            @Override
            public void runWithException() throws TransBtreeException {
                setName("randomWriter");
                Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                try {
                    for (int i = 0; i < COUNT; i++) {
                        LongOid key = new LongOid(new Random().nextInt() % 4 * COUNT);
                        LongOid key2 = new LongOid(new Random().nextInt() % 4 * COUNT);
                        String value = Integer.toString(new Random().nextInt());
                        try {
                          longOidToStringMap.put(t, key, value);
                          longOidToStringMap.put(t, key2, value);
                        } catch (InterruptedOperationTransBtreeException e) {
                            logger.error(e);
                            t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                        }
                    }
                } finally {
                    t.commit();
                }
            }
        };

        RememberExceptionThread reader = new RememberExceptionThread() {
            @Override
            public void runWithException() throws TransBtreeException {
                setName("reader");
                Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                try {
                    for (int i = 0; i < COUNT; i++) {
                        LongOid key = new LongOid(i);
                        LongOid key2 = new LongOid(i);
                        try {
                          String value = longOidToStringMap.get(t, key);
                          String value2 = longOidToStringMap.get(t, key2);
                        } catch (InterruptedOperationTransBtreeException e) {
                            logger.error(e);
                            t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                        }
                    }
                } finally {
                    t.commit();
                }
            }
        };

        RememberExceptionThread readerIter = new RememberExceptionThread() {
            @Override
            public void runWithException() throws TransBtreeException {
                setName("randomReader");
                Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                try {
                    for (int i = 0; i < COUNT; i++) {
                        LongOid key = new LongOid(i);
                        ClosableIterator<? extends Map.Entry<LongOid, String>> iter = null;
                        try {
                            iter = longOidToStringMap.find(t, key);
                            while (iter.hasNext()) {
                                Assert.assertNotNull(iter.next());
                            }
                        } catch (InterruptedOperationTransBtreeException e) {
                            logger.error(e);
                            t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
                        } finally {
                            if (iter != null)
                              iter.close();
                        }
                    }
                } finally {
                    t.commit();
                }
            }
        };

        writer.start();
        randomWriter.start();
        reader.start();
        readerIter.start();

        reader.join();
        writer.join();
        randomWriter.join();
        readerIter.join();

        if (!reader.isSuccessful()) {
            throw reader.getThrownException();
        }
        if (!writer.isSuccessful()) {
            throw writer.getThrownException();
        }
        if (!randomWriter.isSuccessful()) {
            throw randomWriter.getThrownException();
        }
        if (!readerIter.isSuccessful()) {
            throw readerIter.getThrownException();
        }

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        longOidToStringMap.clear(t);
        t.commit();
    }


}
