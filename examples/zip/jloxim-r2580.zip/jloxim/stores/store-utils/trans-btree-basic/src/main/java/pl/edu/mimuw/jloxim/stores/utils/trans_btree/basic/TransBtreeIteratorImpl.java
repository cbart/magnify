/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.LeafNode;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.NodeManager;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeRecordImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author kadamczyk
 * @version $Id: TransBtreeIteratorImpl.java 2467 2011-09-14 19:33:57Z kadamczyk $
 */
class TransBtreeIteratorImpl implements ClosableIterator<Map.Entry<TransBtreeValue, TransBtreeValue>> {

    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(TransBtreeIteratorImpl.class);
    private NodeManager nodeManager;
    private Transaction t;
    private Iterator<Map.Entry<TransBtreeValue, TransBtreeValue>> realIterator;
    private int nextNodeId;

    public TransBtreeIteratorImpl(Transaction t, NodeManager nodeManager, LeafNode node, int pos) {
        this.nodeManager = nodeManager;
        this.t = t;
        openNode(node, pos);
    }

    TransBtreeIteratorImpl() {
        this.nextNodeId = 0;
        this.realIterator = new ArrayList<Map.Entry<TransBtreeValue, TransBtreeValue>>().iterator();
    }

    private void openNode(LeafNode node, int pos) {
        // assert pos >= 0;
        
        ArrayList<Map.Entry<TransBtreeValue, TransBtreeValue>> list = new ArrayList<Map.Entry<TransBtreeValue, TransBtreeValue>>();
        if (!node.isEmpty()) {
            TransBtreeValue[] keys = node.getKeys();
            TransBtreeValue[] values = node.getValues();

            for (int i = pos; i < keys.length; ++i)
                list.add(new TransBtreeRecordImpl<TransBtreeValue, TransBtreeValue>(keys[i], values[i]));
        }

        this.nextNodeId = node.getNextNodeId();
        this.realIterator = list.iterator();
    }

    @Override
    public void close() {
        // do nothing
    }

    @Override
    public boolean hasNext() {
        if (realIterator.hasNext()) {
            return true;
        } else if (nextNodeId != 0) {
            LeafNode node = nodeManager.getLeafNode(t, nextNodeId, BufferUsePurpose.READ);
            openNode(node, 0);
            return hasNext();
        }
        return false;
    }

    @Override
    public Map.Entry<TransBtreeValue, TransBtreeValue> next() {
        return realIterator.next();
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("remove on the iterator");
    }
}
