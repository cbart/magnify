/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.utils.api.callbacks.Callback;

/**
 * Simple LRU cache with size limited per transaction
 *
 * @author kadamczyk
 * @version $Id: NodeCache.java 2474 2011-09-16 23:12:48Z kadamczyk $
 */
public class NodeCache implements Callback<Transaction, TransactionException> {

    // transactionId -> nodeId -> node
    private final Map<Long, Map<Integer, TreeNode>> cache = new HashMap<Long, Map<Integer, TreeNode>>();
    private boolean cacheEnabled;
    private int cacheSize;

    public void setCacheEnabled(boolean cacheEnabled) {
        this.cacheEnabled = cacheEnabled;
    }

    public void setCacheSize(int cacheSize) {
        this.cacheSize = cacheSize;
    }        
    
    /**
     * Remove cache after the end of the transaction.
     * Triggered by TransManager collback.
     */
    @Override
    public void process(Transaction t) throws TransactionException {
        cache.remove(t.getTransactionId());
    }
    
    /**
     * Putting node into cache for this transaction
     * 
     * @param t
     * @param node 
     */    
    public void put(Transaction t, TreeNode node) {                
      if (!cacheEnabled)
        return;

        Map<Integer, TreeNode> transactionCache = cache.get(t.getTransactionId());
        if (transactionCache == null) {            
          /// register TransactionManager collbacks
          t.getAfterCommitCallbacksManager().addCallback(this);
          t.getAfterRollbackCallbacksManager().addCallback(this);
    
          /**
           * Simple LRU cache implementation
           */
          transactionCache = new LinkedHashMap<Integer, TreeNode>(64, 0.75f, true) {
              @Override protected boolean removeEldestEntry (Map.Entry<Integer,TreeNode> eldest) {
                 return size() > cacheSize;
              }
          };
          cache.put(t.getTransactionId(), transactionCache);
        }
        transactionCache.put(node.getId(), node);
    }
    
    /**
    * Retrieving node from cache for this transaction. 
    * Node usePurpose is adjusted if necessary.
    * 
    * @param t
    * @param node 
    */    
    public TreeNode get(Transaction t, int nodeId, BufferUsePurpose usePurpose) {
      if (!cacheEnabled)
        return null;
      
        Map<Integer, TreeNode> transactionCache = cache.get(t.getTransactionId());
  	if (transactionCache != null) {
            TreeNode node = transactionCache.get(nodeId);
            if (node != null) {
                if (node.getUsePurpose() != usePurpose && 
                    usePurpose == BufferUsePurpose.READ_WRITE)
                    node.changeUsePurpose(usePurpose);
                return node;
            }
        }
        
      return null;
    }
}
