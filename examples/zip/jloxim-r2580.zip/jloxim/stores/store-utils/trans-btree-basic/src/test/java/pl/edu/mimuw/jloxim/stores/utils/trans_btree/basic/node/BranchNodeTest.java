/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * @author kadamczyk
 * @version $Id: BranchNodeTest.java 2411 2011-07-06 22:00:07Z kadamczyk $
 */
//@Ignore
public class BranchNodeTest extends AbstractNodeTest {
    private static final Logger logger = Logger.getLogger(BranchNodeTest.class);
    
    //@Ignore
    @Test
    public void moveToTest() {

        logger.info("moveToTest: start");

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        BranchNode node = nodeManager.newBranchNode(t);

        final int COUNT = 20;
        TransBtreeValue[] keys = new TransBtreeValueImpl[COUNT];

        for (int i = 0; i < COUNT; ++i) {
            TransBtreeValue key = new TransBtreeValueImpl();
            longOidBinding.objectToRawValue(new LongOid(i), key);
            keys[i] = key;
            node.putPointer(key, i + 1);
        }

        node.consistencyCheck();

        BranchNode node2 = nodeManager.newBranchNode(t);
        node.moveDataTo(node2);

        node.consistencyCheck();
        node2.consistencyCheck();

        Assert.assertTrue(node.isEmpty());
        Assert.assertTrue(node.getMaxKey() == null);
        Assert.assertTrue(node.getMinKey() == null);
        Assert.assertTrue(!node2.isEmpty());
        Assert.assertNotNull(node2.getMaxKey());       
        Assert.assertNotNull(node2.getMinKey());
        Assert.assertEquals(COUNT, node.getKeyCount() + node2.getKeyCount());

        Assert.assertEquals(node.getKeys().length, node.getKeyCount());
        Assert.assertEquals(node.getPointers().length, node.getKeyCount());

        Assert.assertEquals(node2.getKeys()[node2.getKeys().length - 1], node2.getMaxKey());
        
        node2.removePointer(10);
        node2.write();
        node2.consistencyCheck();
        //log.info("leftNode: " + leftNode.debug());
        
        node.write();
        node.consistencyCheck();
        //log.info("rightNode: " + rightNode.debug());

        t.commit();
    }

}
