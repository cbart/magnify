/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

import java.util.Arrays;
import java.util.Comparator;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;

/**
 *
 * @author kadamczyk
 * @version $Id: BranchNode.java 2467 2011-09-14 19:33:57Z kadamczyk $
 */
public class BranchNode extends TreeNode {

  private final static Logger logger = Logger.getLogger(BranchNode.class);
  protected int[] pointers;

  BranchNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator) throws TransactionException {
    super(page, keyComparator);
  }

  public static BranchNode newNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator) {
    page.getContent().clear();
    BranchNode node = new BranchNode(page, keyComparator);
    node.clear();
    return node;
  }

  public int[] getPointers() {
    return pointers;
  }

  @Override
  public void read() throws TransactionException {
    try {
      page.beginWorkingOnPage(false);
      super.read();

      keys = new TransBtreeValueImpl[getKeyCount()];
      pointers = new int[getKeyCount()];

      //deserialize
      for (int i = 0; i < getKeyCount(); ++i) {
        TransBtreeValueImpl key = new TransBtreeValueImpl();
        key.deserialize(data);
        keys[i] = key;

        pointers[i] = data.getInt();
      }

    } finally {
      page.finishWorkingOnPage(false);
    }
  }

  @Override
  public void write() throws TransactionException {
    try {
      page.beginWorkingOnPage(true);

      super.write();

      //serialize
      for (int i = 0; i < getKeyCount(); ++i) {
        keys[i].serializeInto(data);
        data.putInt(pointers[i]);
      }

    } finally {
      page.finishWorkingOnPage(true);
    }
  }

  public int getPointer(TransBtreeValue key) {
    if (getKeyCount() == 0) {
      return 0;
    }

    int idx = Arrays.binarySearch(keys, key, keyComparator);
    if (idx >= 0) {
      return pointers[idx];
    } else {
      idx = -(idx + 1);

      if (idx == keys.length) {
        idx = keys.length - 1;
      }

      return pointers[idx];
    }
  }

  public int putPointer(TransBtreeValue key, int pointer) {
    logger.debug("putPointer k " + key + " p " + pointer);

    if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
      logger.error("Adding pointer to node with use purpose  " + page.getUsePurpose());
    }
    if (key == null || key.serializableLength() == 0) {
      logger.error("putPointer: Invalid key: '" + key + "'");
    }

    // posortowane po key
    // pointer jest unikalny

    // drop old (key => pointer) if pointer exists
    int idx = 0;
    while (idx < pointers.length && pointers[idx] != pointer) {
      idx++;
    }
    if (idx < pointers.length) {
      incFreeSpace(keys[idx].serializableLength() + Integer.SIZE);
      decKeyCount();

      this.keys = ArrayUtils.arrayDelete(keys, idx);
      this.pointers = ArrayUtils.arrayDelete(pointers, idx);
    }

    // find index of the first element that is larger than value
    idx = Arrays.binarySearch(keys, key, keyComparator);

    // duplicate key detection
    assert idx < 0;

    idx = -(idx + 1);
    decFreeSpace(key.serializableLength() + Integer.SIZE);
    incKeyCount();
    this.keys = ArrayUtils.arrayInsert(keys, key, idx);
    this.pointers = ArrayUtils.arrayInsert(pointers, pointer, idx);

    return 1;
  }

  public int removePointer(int pointer) {
    if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
      logger.error("Removing,  pointer from node with use purpose  " + page.getUsePurpose());
    }

    int idx = 0;
    while (idx < pointers.length && pointers[idx] != pointer) {
      idx++;
    }

    if (idx < pointers.length) {
      incFreeSpace(keys[idx].serializableLength() + Integer.SIZE);
      decKeyCount();

      keys = ArrayUtils.arrayDelete(keys, idx);
      pointers = ArrayUtils.arrayDelete(pointers, idx);

      return 1;
    } else {
      logger.error("pointer '" + pointer + "' doesn't exist");
      return 0;
    }
  }

  @Override
  public boolean needSplit(int maxKeyLength) {
    return getFreeSpace() < maxKeyLength + Integer.SIZE;
  }

  // return right node after split
  @Override
  public TreeNode split(TransactionBufferPage page) throws TransactionException {

    // chceck free space consistence
    consistencyCheck();

    int size = getDataLength();
    int tsize = 0;
    int pivot = 0;
    while (tsize < (size / 2) && pivot < keys.length) {
      tsize += keys[pivot].serializableLength();
      tsize += Integer.SIZE;
      ++pivot;
    }

    // left node [0:pivot)
    // right node [pivot:end]

    // split keys
    TransBtreeValue[] leftKeys = new TransBtreeValueImpl[pivot];
    TransBtreeValue[] rightKeys = new TransBtreeValueImpl[keys.length - pivot];
    System.arraycopy(keys, 0, leftKeys, 0, leftKeys.length);
    System.arraycopy(keys, leftKeys.length, rightKeys, 0, rightKeys.length);

    // split values
    int[] leftPointers = new int[pivot];
    int[] rightPointers = new int[pointers.length - pivot];
    System.arraycopy(pointers, 0, leftPointers, 0, leftPointers.length);
    System.arraycopy(pointers, leftPointers.length, rightPointers, 0, rightPointers.length);

    //rightNode
    BranchNode rightNode = BranchNode.newNode(page, keyComparator);
    rightNode.keys = rightKeys;
    rightNode.pointers = rightPointers;
    rightNode.setKeyCount(rightKeys.length);
    rightNode.decFreeSpace(size - tsize);
    rightNode.setNextNodeId(this.getNextNodeId());
    //logger.info("split(): after right: " + debug());

    //leftNode - this
    this.clear();
    this.keys = leftKeys;
    this.pointers = leftPointers;
    this.setKeyCount(leftKeys.length);
    this.decFreeSpace(tsize);
    this.setNextNodeId(rightNode.getId());
    //logger.info("split(): after left: " + leftNode.debug());

    return rightNode;
  }


  public void moveDataTo(BranchNode node) {
    node.clear();
    super.moveDataTo(node);
    setNodeType(NodeType.BRANCH_NODE);
    node.pointers = this.pointers;
    this.clear();
  }

  @Override
  public int getHeaderLength() {
    return super.getHeaderLength() + 0;
  }

  public void clear() {
    setKeyCount(0);
    setFreeSpace(data.capacity() - getHeaderLength());
    setNodeType(NodeType.BRANCH_NODE);

    keys = new TransBtreeValueImpl[0];
    pointers = new int[0];
  }

  @Override
  public void consistencyCheck() throws TransactionException {
    super.consistencyCheck();

    int size = keys.length * Integer.SIZE;
    for (int i = 0; i < keys.length; i++) {
      size += keys[i].serializableLength();
    }

    if (size != getDataLength()) {
      logger.error("wrong value length " + getDataLength() + " size " + size);
    }
  }

  //*
  @Override
  public String debug(TransBtreeValueBinding keyBinding, TransBtreeValueBinding valueBinding) {
        String info = super.debug(keyBinding, valueBinding);
        
        info += "\n keys.length: " + keys.length + " value:";
        for (int i = 0; i < getKeyCount(); ++i) {            
            if (keys[i].compareTo(TransBtreeValueImpl.MAX_VALUE) != 0) {
                info += "'" + keyBinding.rawValueToObject(keys[i]) + "' => '" + pointers[i] + "', ";
            } else {
                info += "'" + keys[i] + "' => '" + pointers[i] + "', ";
            }
        }
        info += "\n";

        return info;
  }
  //*/
}
