/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

import java.nio.ByteBuffer;
import java.util.Comparator;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;

/**
 *
 * @author kadamczyk
 * @version $Id: TreeNode.java 2423 2011-07-26 22:34:12Z kadamczyk $
 */
public abstract class TreeNode {

    private final static Logger logger = Logger.getLogger(TreeNode.class);
    protected TransactionBufferPage page;
    protected ByteBuffer data;
    private NodeType nodeType;
    private int keyCount;
    private int freeSpace;
    private int nextNodeId;
    protected TransBtreeValue[] keys;
    protected Comparator<TransBtreeValue> keyComparator;

    public TreeNode(TransactionBufferPage page, Comparator<TransBtreeValue> keyComparator) throws TransactionException {
        this.page = page;
        this.data = page.getContent();
        this.keyComparator = keyComparator;
    }

    public int getHeaderLength() {
        return Integer.SIZE * 4;
    }

    public int getDataLength() {
        return data.capacity() - getFreeSpace() - getHeaderLength();
    }

    public void consistencyCheck() throws TransactionException {
        if (getNodeType() == null) {
            logger.error("wrong node type:" + getNodeType());
        }
        if (getDataLength() + getHeaderLength() != data.capacity() - getFreeSpace()) {
            logger.error("wrong free space count " + getFreeSpace());
        }
    }

    public int getId() {
        return page.getPageId();
    }

    public NodeType getNodeType() {
        return nodeType;
    }

    public void setNodeType(NodeType nodeType) {
        this.nodeType = nodeType;
    }

    public int getFreeSpace() {
        return freeSpace;
    }

    protected void setFreeSpace(int freeSpace) {
        this.freeSpace = freeSpace;
    }

    public int incFreeSpace(int count) {
        freeSpace += count;
        return freeSpace;
    }

    public int decFreeSpace(int count) {
        freeSpace -= count;
        return freeSpace;
    }

    public int getKeyCount() {
        return keyCount;
    }

    protected void setKeyCount(int keyCount) {
        this.keyCount = keyCount;
    }

    public boolean isEmpty() {
        return getKeyCount() == 0;
    }

    public int incKeyCount() {
        return ++keyCount;
    }

    public int decKeyCount() {
        if (isEmpty())
            throw new TransBtreeException("decKeyCount on empty node");
        return --keyCount;
    }

    public TransBtreeValue[] getKeys() {
        return keys;
    }

    public TransBtreeValue getMaxKey() {
        if (isEmpty()) {
            return null;
        }
        return keys[getKeyCount() - 1];
    }

    public TransBtreeValue getMinKey() {
        if (isEmpty()) {
            return null;
        }
        return keys[0];
    }

    public int getNextNodeId() {
        return nextNodeId;
    }

    protected void setNextNodeId(int nodeId) {
        this.nextNodeId = nodeId;
    }

    public void read() {
        data.rewind();
        this.nodeType = NodeType.get(data.getInt());
        this.keyCount = data.getInt();
        this.freeSpace = data.getInt();
        this.nextNodeId = data.getInt();
    }

    public void write() {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Writing on page with use purpose  " + page.getUsePurpose());
        }
        data.rewind();
        data.putInt(nodeType.getValue());
        data.putInt(keyCount);
        data.putInt(freeSpace);
        data.putInt(nextNodeId);
    }

    public void remove() throws TransactionException {
        if (page.getUsePurpose() != BufferUsePurpose.READ_WRITE) {
            logger.error("Removing node with use purpose  " + page.getUsePurpose());
        }

        page.markToRemove();
    }

    public abstract boolean needSplit(int keyLenMax);

    public abstract TreeNode split(TransactionBufferPage page) throws TransactionException;

    protected void moveDataTo(TreeNode node) {
        node.keyCount = this.keyCount;
        node.freeSpace = this.freeSpace;
        node.nextNodeId = this.nextNodeId;
        node.keys = this.keys;
    }

    public void changeUsePurpose(BufferUsePurpose usePurpose) throws TransactionException {
        if (page.getUsePurpose() != usePurpose) {            
            //if (usePurpose == BufferUsePurpose.READ_WRITE)            
            //    logger.error("READ_WRITE tid:" + page.getTransaction().getTransactionId() + " nodeId:" + getId());
            logger.debug("changeUsePurpose begin");
            page.changeUsePurpose(usePurpose);
            logger.debug("changeUsePurpose end");
            if (usePurpose == BufferUsePurpose.READ) {
              data = page.getContent();
              read();
            }
        }
    }
    
    public BufferUsePurpose getUsePurpose() {
        return page.getUsePurpose();
    }

    //*
    public String debug(TransBtreeValueBinding keyBinding, TransBtreeValueBinding valueBinding) {
        String info = new String();

        info += "nodeID " + page.getPageId() + " nodeType:" + nodeType + " keyCount:" + keyCount + " freeSpace:" + freeSpace;

        //try {
        //  info += "\n value:'" + new String(value.array(), 0, value.capacity(), "utf-8") + "'";
        //} catch (UnsupportedEncodingException ex) {
        //}

        return info;
    }
    //*/
}
