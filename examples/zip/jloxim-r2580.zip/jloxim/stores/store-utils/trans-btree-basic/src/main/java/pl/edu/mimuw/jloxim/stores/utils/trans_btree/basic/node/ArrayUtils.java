/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node;

import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;

/**
 * utility methods
 *
 * @author kadamczyk
 * @version $Id: ArrayUtils.java 2410 2011-07-06 19:21:41Z kadamczyk $
 */
public class ArrayUtils {

  public static TransBtreeValue[] arrayInsert(TransBtreeValue[] values, TransBtreeValue value, int idx) {
    TransBtreeValue[] newValues = new TransBtreeValueImpl[values.length + 1];
    if (idx > 0) {
      System.arraycopy(values, 0, newValues, 0, idx);
    }
    newValues[idx] = value;
    if (idx < values.length) {
      System.arraycopy(values, idx, newValues, idx + 1, values.length - idx);
    }
    return newValues;
  }

  public static TransBtreeValue[] arrayDelete(TransBtreeValue[] values, int idx) {
    TransBtreeValue[] newValues = new TransBtreeValueImpl[values.length - 1];
    if (idx > 0) {
      System.arraycopy(values, 0, newValues, 0, idx);
    }
    if (idx < newValues.length) {
      System.arraycopy(values, idx + 1, newValues, idx, newValues.length - idx);
    }
    return newValues;
  }

  public static int[] arrayInsert(int[] values, int value, int idx) {
    int[] newValues = new int[values.length + 1];
    if (idx > 0) {
      System.arraycopy(values, 0, newValues, 0, idx);
    }
    newValues[idx] = value;
    if (idx < values.length) {
      System.arraycopy(values, idx, newValues, idx + 1, values.length - idx);
    }
    return newValues;
  }

  public static int[] arrayDelete(int[] values, int idx) {
    int[] newValues = new int[values.length - 1];
    if (idx > 0) {
      System.arraycopy(values, 0, newValues, 0, idx);
    }
    if (idx < newValues.length) {
      System.arraycopy(values, idx + 1, newValues, idx, newValues.length - idx);
    }
    return newValues;
  }

}
