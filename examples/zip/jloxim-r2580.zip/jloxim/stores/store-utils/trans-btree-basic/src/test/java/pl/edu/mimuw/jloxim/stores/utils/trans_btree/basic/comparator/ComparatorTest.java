/*
 * Copyright 2011 Faculty of Mathematics Informatics and Mechanics at the University of Warsaw.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.comparator;

import java.util.Comparator;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding.ReadableIntegerBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding.ReadableLongOidBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.binding.StringBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author kadamczyk
 */
public class ComparatorTest {
        
    @Ignore
    @Test
    public void stringUtf8Test() {        
        StringComparator comparator = new StringComparator();
        StringBinding binding = new StringBinding();
        comparator.setStringBinding(binding);

        TransBtreeValue key1 = new TransBtreeValueImpl();
        TransBtreeValue key2 = new TransBtreeValueImpl();
        
        binding.objectToRawValue("ąśżźćłęóþł", key1);
        Assert.assertEquals("ąśżźćłęóþł", binding.rawValueToObject(key1));
        binding.objectToRawValue("ąśżźćłęóþł", key2);
        Assert.assertTrue(comparator.compare(key1, key2) == 0);
        
        binding.objectToRawValue("aąbcć", key1);
        Assert.assertEquals("aąbcć", binding.rawValueToObject(key1));
        binding.objectToRawValue("abccc", key2);
        Assert.assertTrue(comparator.compare(key1, key2) > 0);
        
        binding.objectToRawValue("aąbca", key1);
        binding.objectToRawValue("aąbcą", key2);
        Assert.assertEquals("aąbcą", binding.rawValueToObject(key2));
        Assert.assertTrue(comparator.compare(key1, key2) < 0);
    }
    
    
    @Test
    public void redableIntegerTest() {        
        Comparator comparator = new ReadableIntegerComparator();
        ReadableIntegerBinding binding = new ReadableIntegerBinding();
        
        TransBtreeValue key1 = new TransBtreeValueImpl();
        TransBtreeValue key2 = new TransBtreeValueImpl();
        
        binding.objectToRawValue(123123, key1);
        Assert.assertEquals(new Integer(123123), binding.rawValueToObject(key1));
        binding.objectToRawValue(123123, key2);
        Assert.assertTrue(comparator.compare(key1, key2) == 0);
        
        binding.objectToRawValue(23432, key1);
        Assert.assertEquals(new Integer(23432), binding.rawValueToObject(key1));
        binding.objectToRawValue(114233, key2);
        Assert.assertTrue(comparator.compare(key1, key2) == -1);
        
        binding.objectToRawValue(245645, key1);
        Assert.assertEquals(new Integer(245645), binding.rawValueToObject(key1));
        binding.objectToRawValue(999, key2);
        Assert.assertTrue(comparator.compare(key1, key2) == 1);
    }
    
    
    @Test
    public void redableLongTest() {
        Comparator comparator = new ReadableLongOidComparator();
        ReadableLongOidBinding binding = new ReadableLongOidBinding();
        
        TransBtreeValue key1 = new TransBtreeValueImpl();
        TransBtreeValue key2 = new TransBtreeValueImpl();
        
        binding.objectToRawValue(new LongOid(123123), key1);
        //Assert.assertEquals(new LongOid(123123), binding.rawValueToObject(key1));
        binding.objectToRawValue(new LongOid(123123), key2);
        //Assert.assertTrue(comparator.compare(key1, key2) == 0);
        
        binding.objectToRawValue(new LongOid(23432), key1);
        //Assert.assertEquals(new LongOid(23432), binding.rawValueToObject(key1));
        binding.objectToRawValue(new LongOid(114233), key2);
        //Assert.assertTrue(comparator.compare(key1, key2) == -1);
        
        binding.objectToRawValue(new LongOid(245645), key1);
        //Assert.assertEquals(new LongOid(245645), binding.rawValueToObject(key1));
        binding.objectToRawValue(new LongOid(999), key2);
        //Assert.assertTrue(comparator.compare(key1, key2) == 1);
    }
    
}
