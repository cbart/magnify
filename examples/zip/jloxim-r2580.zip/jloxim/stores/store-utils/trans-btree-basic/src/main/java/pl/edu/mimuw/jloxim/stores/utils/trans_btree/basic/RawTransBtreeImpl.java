/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic;

import org.apache.log4j.Logger;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.*;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.RawTransBtree;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.*;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.ComparatorConverter;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.value.TransBtreeValueImpl;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionInterruptedException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;


/**
 * @author kadamczyk
 * @version $Id: RawTransBtreeImpl.java 2505 2011-09-26 06:05:41Z kadamczyk $
 */
public class RawTransBtreeImpl implements RawTransBtree {

    private static final Logger logger = Logger.getLogger(RawTransBtreeImpl.class);

    // config
    private int maxKeyLength;
    private int rootPageId = -1;

    @Autowired private TransactionManager transactionManager;
    @Autowired private NodeManager nodeManager;
    @Autowired private PageManager pageManager;

    private Comparator<TransBtreeValue> keyComparator;

    // launch after setting the keyComparator and rootPageId
    public synchronized void init() {
        assert keyComparator != null;
        nodeManager.setKeyComparator(this.keyComparator);

        Transaction t = transactionManager.newTransaction(
                TransactionIsolationLevel.SERIALIZABLE);        
        RootNode rootNode;
        
        if (rootPageId == -1) {
            // create root node            
            rootNode = nodeManager.newRootNode(t);
            rootNode.write();
            setRootPageId(rootNode.getId());        
        } else {
            rootNode = nodeManager.getRootNode(t, rootPageId, 
                    BufferUsePurpose.READ_WRITE);    
        }
        
        initRootNode(t, rootNode);

        t.commit();
    }

    private synchronized void initRootNode(Transaction t, RootNode rootNode) {
        if (rootNode.isEmpty()) {
            // creating leaf node
            LeafNode leafNode = nodeManager.newLeafNode(t);
            leafNode.write();

            rootNode.changeUsePurpose(BufferUsePurpose.READ_WRITE);
            rootNode.putPointer(TransBtreeValueImpl.MAX_VALUE, leafNode.getId());
            rootNode.write();
        }
    }

    public int getRootPageId() {
        return rootPageId;
    }

    @Override
    public void setRootPageId(int rootPageId) {
        this.rootPageId = rootPageId;
    }
 
    @Override
    public void setKeyComparator(Comparator<TransBtreeValue> keyComparator) {
        this.keyComparator = new ComparatorConverter(keyComparator);
    }

    public void setNodeManager(NodeManager nodeManager) {
        this.nodeManager = nodeManager;
    }

    public void setPageManager(PageManager pageManager) {
        this.pageManager = pageManager;
    }

    public void setMaxKeyLength(int maxKeyLength) {
        this.maxKeyLength = maxKeyLength;
    }

    public void setTransactionManager(TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }
    
    private void acquireSerializableLock(Transaction t) {
        if (t.getIsolationLevel() == TransactionIsolationLevel.SERIALIZABLE) {
            // synchronize on rootNode
            nodeManager.getRootNode(t, getRootPageId(), BufferUsePurpose.READ_WRITE);        
        }
    }

    private LeafNode getLeafNodeByKey(Transaction t, TransBtreeValue key, BufferUsePurpose usePurpose) throws TransactionException {
        RootNode rootNode = nodeManager.getRootNode(t, getRootPageId(), usePurpose);
        int pageId = rootNode.getPointer(key);
        int count = 0;
        while (pageId != 0) {
            if (count++ > 32) {
                throw new TransBtreeException("Possible endless loop last page id " + pageId);
            }

            TreeNode treeNode = nodeManager.getTreeNode(t, pageId, usePurpose);
            if (treeNode instanceof BranchNode) {
                treeNode.read();
                pageId = ((BranchNode) treeNode).getPointer(key);
            } else {
                return (LeafNode) treeNode;
            }
        }
        return null;
    }       
    
    @Override
    public void put(Transaction t, TransBtreeValue key, TransBtreeValue value) throws TransBtreeException {        
        try {
            acquireSerializableLock(t);

            if (key.serializableLength() > maxKeyLength) {
                throw new TransBtreeException("Key too long. Max key length is " + maxKeyLength + " bytes.");
            }
                              
            BranchNode parentNode = nodeManager.getRootNode(t, getRootPageId(), BufferUsePurpose.READ_WRITE);
            if (parentNode.isEmpty()) {
                initRootNode(t, (RootNode) parentNode);
            } else if (parentNode.needSplit(maxKeyLength)) {
                parentNode = splitRootNode(t, (RootNode) parentNode);
            }
            int currPageId = parentNode.getPointer(key);

            // find LeafNode
            int count = 0;
            LeafNode leafNode = null;
            while (leafNode == null) {
                if (count++ > 32) {
                    throw new TransBtreeException("Possible endless loop last page id " + currPageId);
                }

                TreeNode currNode = nodeManager.getTreeNode(t, currPageId, BufferUsePurpose.READ_WRITE);
                if (currNode.needSplit(maxKeyLength)) {
                    splitNode(t, currNode, parentNode);
                    currPageId = parentNode.getPointer(key);
                    currNode = nodeManager.getTreeNode(t, currPageId, BufferUsePurpose.READ_WRITE);
                } else if (currNode instanceof BranchNode) {
                    parentNode.changeUsePurpose(BufferUsePurpose.READ);
                }

                if (currNode instanceof BranchNode) {
                    currPageId = ((BranchNode) currNode).getPointer(key);
                    parentNode = (BranchNode) currNode;
                } else if (currNode instanceof LeafNode) {
                    leafNode = (LeafNode) currNode;
                }
            }

            leafNode.putValue(key, value);           
            if (leafNode.needSplit(0)) {
                splitNode(t, leafNode, parentNode);                
            } else {
                parentNode.changeUsePurpose(BufferUsePurpose.READ);
                leafNode.write();
            }
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("put interrupted", ex);
        } catch (TransactionException ex) {
            throw new TransBtreeException("put", ex);
        }
    }

    @Override
    public TransBtreeValue get(Transaction t, TransBtreeValue key) throws TransBtreeException {
        try {
            acquireSerializableLock(t);
            
            LeafNode leafNode = getLeafNodeByKey(t, key, BufferUsePurpose.READ);
            if (leafNode != null) {
                return leafNode.getValue(key);
            } else {
                return null;
            }
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("get interrupted", ex);
        } catch (TransactionException ex) {
            throw new TransBtreeException("get", ex);
        }
    }

    @Override
    public void remove(Transaction t, TransBtreeValue key) throws TransBtreeException {
        try {
            acquireSerializableLock(t);
            
            LeafNode leafNode = getLeafNodeByKey(t, key, BufferUsePurpose.READ);
            leafNode.changeUsePurpose(BufferUsePurpose.READ_WRITE);
            if (leafNode != null) {
                leafNode.removeValue(key);
                leafNode.write();
            }
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("remove interrupted", ex);
        } catch (TransactionException ex) {
            throw new TransBtreeException("remove", ex);
        }
    }

    @Override
    public boolean isEmpty(Transaction t) throws TransBtreeException {
        try {
            acquireSerializableLock(t);            
            return nodeManager.getRootNode(t, getRootPageId(), BufferUsePurpose.READ).getKeyCount() <= 1; // special value
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("isEmpty interrupted", ex);            
        } catch (TransactionException ex) {
            throw new TransBtreeException("isEmpty", ex);
        }
    }

    @Override
    public void clear(Transaction t) throws TransBtreeException {
        try {
            acquireSerializableLock(t);
            
            RootNode rootNode = nodeManager.getRootNode(t, getRootPageId(), BufferUsePurpose.READ_WRITE);
            List<Integer> pageIds = new ArrayList<Integer>();
            int[] pointers = rootNode.getPointers();
            for (int pointer : pointers) {
                pageIds.add(pointer);
            }

            rootNode.clear();
            rootNode.write();
            while (!pageIds.isEmpty()) {
                int pageId = pageIds.get(0);
                pageIds.remove(0);
                TreeNode treeNode = nodeManager.getTreeNode(t, pageId, BufferUsePurpose.READ_WRITE);
                if (treeNode instanceof BranchNode) {
                    pointers = ((BranchNode) treeNode).getPointers();
                    for (int pointer : pointers) {
                        pageIds.add(pointer);
                    }
                }
                treeNode.remove();
            }
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("clear interrupted", ex);
        } catch (TransactionException ex) {
            throw new TransBtreeException("clear", ex);
        }
    }

    @Override
    public void drop(Transaction t) throws TransBtreeException {
        try {
            acquireSerializableLock(t);
            
            clear(t);
            TreeNode rootNode = nodeManager.getTreeNode(t, rootPageId, BufferUsePurpose.READ_WRITE);
            rootNode.remove();
        } catch (TransactionInterruptedException ex) {
            throw new InterruptedOperationTransBtreeException("drop interrupted", ex);
        } catch (TransactionException ex) {
            throw new TransBtreeException("drop", ex);
        }
    }

    private RootNode splitRootNode(Transaction t, RootNode rootNode) throws TransactionException {        
        logger.debug("Splitting root node id " + rootNode.getId());
        
        if (!rootNode.needSplit(maxKeyLength)) {
            logger.error("splitRootNode race");
            return rootNode;
        }

        // right node
        TreeNode rightNode = rootNode.split(pageManager.allocatePage(t));
        rightNode.write();

        // left node
        BranchNode leftNode = nodeManager.newBranchNode(t);
        rootNode.moveDataTo(leftNode);
        leftNode.write();
        
        if ( leftNode.getMaxKey() == null || rightNode.getMaxKey() == null)
            logger.error("splitRootNode l=" + leftNode.getMaxKey() + " r=" + rightNode.getMaxKey());
        
        // root node (isEmpty now)        
        rootNode.putPointer(leftNode.getMaxKey(), leftNode.getId());
        rootNode.putPointer(rightNode.getMaxKey(), rightNode.getId());
        rootNode.write();

        return rootNode;
    }

    private TreeNode splitNode(Transaction t, TreeNode node, BranchNode parentNode) throws TransactionException {
        logger.debug("Splitting " + node.getNodeType() + " id " + node.getId());
        
        if (!node.needSplit(maxKeyLength)) {
            logger.error("splitNode race");
            return node;
        }

        TreeNode rightNode = node.split(pageManager.allocatePage(t));
        node.write();
        rightNode.write();
        
        parentNode.putPointer(node.getMaxKey(), node.getId());
        parentNode.putPointer(rightNode.getMaxKey(), rightNode.getId());
        parentNode.write();

        return rightNode;
    }

    @Override
    public ClosableIterator<? extends Map.Entry<TransBtreeValue, TransBtreeValue>> iterator(Transaction t) {
      try {
        LeafNode node = getLeafNodeByKey(t, TransBtreeValueImpl.MIN_VALUE, BufferUsePurpose.READ);
        if (node == null) {
            if (!isEmpty(t)) {
                throw new TransBtreeException("iterator");
            }
            return new TransBtreeIteratorImpl();
        }
        return new TransBtreeIteratorImpl(t, nodeManager, node, 0);
        
      } catch (TransactionInterruptedException ex) {
        throw new InterruptedOperationTransBtreeException("find interrupted", ex);
      } catch (TransactionException ex) {
         throw new TransBtreeException("find", ex);
      }
    }

    @Override
    public ClosableIterator<? extends Map.Entry<TransBtreeValue, TransBtreeValue>> find(Transaction t, TransBtreeValue key) throws TransBtreeException {
      try {
        LeafNode node = getLeafNodeByKey(t, key, BufferUsePurpose.READ);
        if (node != null) {
            TransBtreeValue[] keys = node.getKeys();
            int idx = Arrays.binarySearch(keys, key, keyComparator);
            if (idx >= 0) {
                return new TransBtreeIteratorImpl(t, nodeManager, node, idx);
            } else {
                idx = -(idx + 1);
                if ( idx < keys.length ) {
                    return new TransBtreeIteratorImpl(t, nodeManager, node, idx);
                }
            }
        }
        return new TransBtreeIteratorImpl();
        
      } catch (TransactionInterruptedException ex) {
        throw new InterruptedOperationTransBtreeException("find interrupted", ex);
      } catch (TransactionException ex) {
         throw new TransBtreeException("find", ex);
      }
    }
    
    //*
    public String printDebug(Transaction t, TransBtreeValueBinding keyBinding, TransBtreeValueBinding valueBinding) throws TransactionException {
        RootNode node = nodeManager.getRootNode(t, getRootPageId(), BufferUsePurpose.READ);
        
        String log = new String();
        log += node.debug(keyBinding, valueBinding);

        int[] pointers = node.getPointers();
        for (int pointer : pointers) {
            log += printDebug(t, keyBinding, valueBinding, pointer, 1);
        }
        
        return log;
    }

    public String printDebug(Transaction transaction, TransBtreeValueBinding keyBinding, TransBtreeValueBinding valueBinding, int pageId, int depth) throws TransactionException {
        TreeNode node = nodeManager.getTreeNode(transaction, pageId, BufferUsePurpose.READ);

        String log = new String();
        String indent = " ";
        for (int i = 0; i < depth; ++i) {
            indent += " ";
        }
        log += indent + "  " + node.getKeyCount() + " " + node.getNodeType() + " " + node.debug(keyBinding, valueBinding);

        if (node instanceof BranchNode) {
            int[] pointers = ((BranchNode) node).getPointers();
            for (int pointer : pointers) {
                log += printDebug(transaction, keyBinding, valueBinding, pointer, depth + 1);
            }
        }
        
        return log;
    }
    //*/
    
}
