/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import java.io.FileOutputStream;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;

import junit.framework.Assert;
import net.sf.saxon.Configuration;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.query.DynamicQueryContext;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.query.XQueryExpression;
import net.sf.saxon.tinytree.TinyTextImpl;

import org.junit.Test;
import org.springframework.test.annotation.DirtiesContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.utils.xml.importer.AS0StoreToXmlComparer;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author Pawel Mantur
 */
public class DOMTest extends AbstractDomTest {

    @Test
    @DirtiesContext
    public void testCreatingDocumentFromStore() throws Exception {

        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());

        createStoreFromXml(store, namesTranslator, "/test_xml_dom.xml");
        AS0DOMImplementation impl = new AS0DOMImplementation();
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Document doc = impl.createAS0DocumentRO(store, namesTranslator, t);

        // checking document content

        Assert.assertEquals(store.getStoreId(), doc.getDocumentElement().getTagName());
        String superootOID = doc.getDocumentElement().getAttributeNS(Consts.loximNamespace, Consts.loximIdAttr);
        Assert.assertEquals(LongOid.ZERO.toReadableString(), superootOID);
        NodeList children = doc.getDocumentElement().getChildNodes();
        Assert.assertEquals(1, children.getLength());
        Element root = (Element) children.item(0);
        NodeList rootChildren = root.getChildNodes();
        Assert.assertEquals(3, rootChildren.getLength());

        Element element1 = (Element) rootChildren.item(0);
        Assert.assertEquals(0, element1.getAttributes().getLength());
        Assert.assertTrue(element1.hasChildNodes());
        Assert.assertFalse(element1.hasAttributes());
        Assert.assertEquals("element1", element1.getTagName());
        Assert.assertEquals("element1", element1.getLocalName());
        Assert.assertEquals("element1", element1.getNodeName());

        NodeList element1Children = element1.getChildNodes();
        Assert.assertEquals(1, element1Children.getLength());
        Node element1Child = element1Children.item(0);
        Assert.assertTrue(element1Child instanceof Text);

        Text atomic1 = (Text) element1Child;
        Assert.assertTrue(atomic1.getNodeValue().equalsIgnoreCase("atomic1"));
        Assert.assertTrue(atomic1.getData().equalsIgnoreCase("atomic1"));
        Assert.assertTrue(atomic1.getWholeText().equalsIgnoreCase("atomic1"));
        Assert.assertFalse(atomic1.hasAttributes());
        Assert.assertFalse(atomic1.hasChildNodes());

        Element element3 = (Element) rootChildren.item(2);
        NodeList element3Children = element3.getChildNodes();
        Assert.assertEquals(3, element3Children.getLength());
        Assert.assertEquals("subelem2", element3Children.item(0).getNextSibling().getLocalName());

        NodeList lst = root.getElementsByTagName("subelem1");
        Assert.assertEquals(1, lst.getLength());
        Assert.assertTrue(lst.item(0) instanceof Element);
        Assert.assertEquals("subelem1", ((Element) lst.item(0)).getTagName());
        
        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }

    @Test
    @DirtiesContext
    public void testIdenticalXsltTransform() throws Exception {
        String source = "/cars_10kb.xml";
        createStoreFromXml(store, namesTranslator, source);
        writeStoreToXmlChackTransactionNumber(store, new FileOutputStream("target/StoreAsXml.xml"));
    }

    @Test
    @DirtiesContext
    public void testManipulatingStoreViaDOM() throws Exception {

        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());

        AS0DOMImplementation impl = new AS0DOMImplementation();
        clearStore();

        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Document doc = impl.createAS0DocumentEditable(store, namesTranslator, t, atomicValueFactory, objectsFactory);

        // creating in memory elements which will be later appended to the store
        Element root = doc.createElement("root1");
        // creating atomic object
        Element atomic = doc.createElement("atomic");
        Text text = doc.createTextNode("atomic value");
        atomic.appendChild(text);
        root.appendChild(atomic);

        // appending created nodes to the document tree - it will add them to the store
        doc.getDocumentElement().appendChild(root);

        // cloning document from which we populated the store
        Element superrot = new AS0Element(store.getStoreId(), null);
        Document clone = new AS0Document(superrot, false, doc.getImplementation(), t);
        Element rootClone = (Element) root.cloneNode(true);
        clone.adoptNode(rootClone);
        superrot.appendChild(rootClone);

        // comapring store content to clone content
        AS0StoreToXmlComparer comparer = new AS0StoreToXmlComparer(t, store, namesTranslator);
        Assert.assertTrue(comparer.CompareElementsStructureGeneral(clone, store, true));

        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }

    @Test
    @DirtiesContext
    public void testAttributes() throws Exception {

        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());

        clearStore();
        AS0DOMImplementation impl = new AS0DOMImplementation();
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Document doc = impl.createAS0DocumentEditable(store, namesTranslator, t, atomicValueFactory, objectsFactory);

        // creating in memory elements which will be later appended to the store
        Element root = doc.createElement("root1");
        root.setAttribute("a", "1");
        root.setAttribute("b", "2");

        // appending created nodes to the document tree - it will add them to the store
        doc.getDocumentElement().appendChild(root);

        Element r = (Element) doc.getDocumentElement().getChildNodes().item(0);
        Assert.assertEquals(r.getAttribute("a"), "1");
        Assert.assertEquals(r.getAttribute("b"), "2");
        Assert.assertEquals(r.getAttributes().getLength(), 2);

        r.removeAttribute("a");
        Assert.assertEquals(r.getAttributes().getLength(), 1);
        r.setAttribute("b", "5");
        Assert.assertEquals(r.getAttribute("b"), "5");
        Assert.assertEquals(r.getAttributes().getLength(), 1);
        t.commit();

        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }

    @DirtiesContext
    @Test(expected = IllegalStateException.class)
    public void testBadTagNames() throws Exception {
        clearStore();
        StoreAS0 s = store;
        int nameID = namesTranslator.getOrRegisterName("chrząszcz brzmi w czcinie głośno");
        AtomicValue val = atomicValueFactory.newAtomicValue("wartośc");
        AS0AtomicObjectEditable obj = objectsFactory.newAtomicObject(nameID, val);
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        s.addSubobject(t, LongOid.ZERO, obj);
        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
        writeStoreToXmlChackTransactionNumber(s, new FileOutputStream("target/badTagNames.xml"));
    }

    @DirtiesContext
    @Test
    public void XQueryTests() throws Exception {

        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());

        clearStore();
        createStoreFromXml(store, namesTranslator, "/cars_10kb.xml");
        AS0DOMImplementation impl = new AS0DOMImplementation();
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Document doc = impl.createAS0DocumentRO(store, namesTranslator, t);

        // store as xml
        Configuration config = new Configuration();
        DocumentInfo di = config.buildDocument(new DOMSource(doc));
        DynamicQueryContext dynamicContext = new DynamicQueryContext(config);
        dynamicContext.setContextItem(di);
        StaticQueryContext sqc = new StaticQueryContext(config);

        // context 2 (immidiately to xml)
        Configuration config2 = new Configuration();
        DocumentInfo di2 = config2.buildDocument(new StreamSource(DOMTest.class.getResourceAsStream("/cars_10kb.xml")));
        DynamicQueryContext dynamicContext2 = new DynamicQueryContext(config2);
        dynamicContext2.setContextItem(di2);
        StaticQueryContext sqc2 = new StaticQueryContext(config2);

        // comapring results

        // 1
        XQueryExpression expA = sqc.compileQuery("for $i in /test_store/Carstores/Corporation return $i/Name/text()");
        Text resultA = (Text) expA.evaluateSingle(dynamicContext);

        XQueryExpression expB = sqc2.compileQuery("for $i in /Carstores/Corporation return $i/Name/text()");
        TinyTextImpl resultB = (TinyTextImpl) expB.evaluateSingle(dynamicContext2);

        Assert.assertEquals(resultA.getNodeValue(), resultB.getStringValue());

        // 2
        XQueryExpression exp2A = sqc.compileQuery("for $x in /test_store/Carstores/Corporation/StoresList/Store/Sales/Sale/Pricing where $x/BasePrice > 20000 return $x/BasePrice/text()");
        Text result2A = (Text) exp2A.evaluateSingle(dynamicContext);

        XQueryExpression exp2B = sqc2.compileQuery("for $x in /Carstores/Corporation/StoresList/Store/Sales/Sale/Pricing where $x/BasePrice > 20000 return $x/BasePrice/text()");
        TinyTextImpl result2B = (TinyTextImpl) exp2B.evaluateSingle(dynamicContext2);

        Assert.assertEquals(result2A.getNodeValue(), result2B.getStringValue());

        //3
        XQueryExpression exp3A = sqc.compileQuery("for $x in count(/test_store/Carstores/Corporation/StoresList/Store/Sales) return $x");
        Long result3A = (Long) exp3A.evaluateSingle(dynamicContext);

        XQueryExpression exp3B = sqc2.compileQuery("for $x in count(/Carstores/Corporation/StoresList/Store/Sales) return $x");
        Long result3B = (Long) exp3B.evaluateSingle(dynamicContext2);

        Assert.assertEquals(result3A, result3B);

        //4
        XQueryExpression exp4A = sqc.compileQuery("for $x in /test_store/Carstores/Corporation/StoresList/Store/Sales/Sale order by $x/Date return $x/Pricing/BasePrice/text() ");
        Text result4A = (Text) exp4A.evaluateSingle(dynamicContext);

        XQueryExpression exp4B = sqc2.compileQuery("for $x in /Carstores/Corporation/StoresList/Store/Sales/Sale order by $x/Date return $x/Pricing/BasePrice/text() ");
        TinyTextImpl result4B = (TinyTextImpl) exp4B.evaluateSingle(dynamicContext2);

        Assert.assertEquals(result4A.getNodeValue(), result4B.getStringValue());

        //5
        XQueryExpression exp5A = sqc.compileQuery("for $x in avg(/test_store/Carstores/Corporation/StoresList/Store/Sales/Sale/Pricing/FinalPrice) return $x");
        Double result5A = (Double) exp5A.evaluateSingle(dynamicContext);

        XQueryExpression exp5B = sqc2.compileQuery("for $x in avg(/Carstores/Corporation/StoresList/Store/Sales/Sale/Pricing/FinalPrice) return $x");
        Double result5B = (Double) exp5B.evaluateSingle(dynamicContext2);

        Assert.assertEquals(result5A, result5B);

        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }
}

