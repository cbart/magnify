/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author Pawel Mantur
 */
public class DOMUtils {

    public static AbstractOid castStringToJLoximOID(String id) {
        return new LongOid(id);
    }

    public static void getDescendantsByName(StoreAS0 s, Transaction t, AbstractOid parentOID, int nameID, AS0Document owner, AS0NodeList res) throws JLoximException{

        try {
            ClosableIterator<AbstractOid> allChildren = s.getSubobjectOIDs(t, parentOID);
            ClosableIterator<AbstractOid> matchingNames = s.getSubobjectOIDsByNameOID(t, parentOID, nameID);
            while (matchingNames.hasNext()) {
                res.AddNode(new AS0Element(matchingNames.next(), owner));
            }
            matchingNames.close();

            while (allChildren.hasNext()) {
                getDescendantsByName(s, t, allChildren.next(), nameID, owner, res);
            }
            allChildren.close();

        } catch (StoreException e) {
            t.rollback();
            throw new JLoximDOMException(e);
        }
    }

    public static boolean isIdAttribute(String attrName) {
        return attrName.compareToIgnoreCase(Consts.loximIdAttr) == 0;
    }

    public static boolean isRefAttribute(String attrName) {
        return attrName.compareToIgnoreCase(Consts.loximRefAttr) == 0;
    }
}
