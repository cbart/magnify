/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.importer;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;
import java.util.NoSuchElementException;

import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * <p>It is similar to <code>JLoximSAXLoaderHandler</code> but less general. It expects input
 * XML files to follow special format like below:</p>
 * 
 * <complexObjectName id="oid">
 *  <subobject...>
 * </complexObjectName >
 * <atomicObjectName id="oid" type="integer, float, string">value</atomicObjectName>
 * <pointerObjectName id="oid" ref="oid"/>
 *
 * <p>Element representing atomic object must have attribute <code>type</code> and
 * optionally attribute <code>format</code> if type is <code>Date</code>. Default
 * format is "yyyy-MM-dd".</p>
 *
 * <p>Element representing pointer object must have attribute <code>ref</code>.
 *
 * <p>If neither <code>type</code> nor <code>ref</code> attribte is present, element
 * is considered as complex object.</p>
 *
 * <p>If both <code>type</code> and <code>ref</code> attribtes are present,
 * it is considered as error.</p>
 *
 * @author Pawel Mantur
 */
public class XmlImportSAXHandler extends DefaultHandler {
  private Locator locator;

    public XmlImportSAXHandler() {
        super();

        this.remapper = new Remapper();
    }

    public XmlImportSAXHandler(NamesTranslator namesTranslator, StoreAS0 storeAS0, Transaction transation, AS0ObjectsFactory as0objectFactory, AtomicValueFactory atomicValueFactory, Map<String, AbstractOid> xmlIdToOidMap) {

        super();

        this.namesTranslator = namesTranslator;
        this.storeAS0 = storeAS0;
        this.transation = transation;
        this.as0objectFactory = as0objectFactory;
        this.atomicValueFactory = atomicValueFactory;
    this.xmlIdToOidMap = xmlIdToOidMap;
    
        this.remapper = new Remapper();
    }
    private Remapper remapper;
    private NamesTranslator namesTranslator;
    private StoreAS0 storeAS0;
    private Transaction transation;
    private AS0ObjectsFactory as0objectFactory;
    private AtomicValueFactory atomicValueFactory;
  private Map<String, AbstractOid> xmlIdToOidMap;

    @Override
    public void setDocumentLocator(Locator locator) {
      this.locator=locator;
      super.setDocumentLocator(locator);
    }
    
    public NamesTranslator getNamesTranslator() {
        return namesTranslator;
    }

    public void setNamesTranslator(NamesTranslator namesTranslator) {
        this.namesTranslator = namesTranslator;
    }

    public StoreAS0 getStoreAS0() {
        return storeAS0;
    }

    public void setStoreAS0(StoreAS0 storeAS0) {
        this.storeAS0 = storeAS0;
    }

    public Transaction getTransation() {
        return transation;
    }

    public void setTransation(Transaction transcation) {
        this.transation = transcation;
    }

    public AS0ObjectsFactory getAs0objectFactory() {
        return as0objectFactory;
    }

    public void setAs0objectFactory(AS0ObjectsFactory as0objectFactory) {
        this.as0objectFactory = as0objectFactory;
    }

    public AtomicValueFactory getAtomicValueFactory() {
        return atomicValueFactory;
    }

    public void setAtomicValueFactory(AtomicValueFactory atomicValueFactory) {
        this.atomicValueFactory = atomicValueFactory;
    }
    private StringBuilder lastContent;
    private LinkedList<AS0ObjectEditable> startedElements = new LinkedList<AS0ObjectEditable>();
    private LinkedList<ObjectTypeEnum> startedElementsTypes = new LinkedList<ObjectTypeEnum>();
    private AtomicValueTypeEnum waitingAtomicObjectType;
    private String waitingDateFormat;

    @Override
    public void startDocument() {
    }

    @Override
    public void endDocument() throws SAXException {
        try {
            remapper.setAllRegisteredReferences(storeAS0, transation);
        } catch (Exception e) {
            throw new SAXException(e);
        }
    }

    @Override
    public void startElement(String uri, String name, String qName, Attributes atts) throws SAXException {

        if (!startedElementsTypes.isEmpty() && startedElementsTypes.getLast() != ObjectTypeEnum.Complex)
            throw new SAXException("Only ComplexObject can have children");

        try {

            // looking for atributes with special meaning, other attributes are ignored
            String refID = atts.getValue("ref");
            String type = atts.getValue("type");
            String id = atts.getValue("id");

            if (refID != null && type != null)
                throw new SAXException("Elements cannot have both ref and type attribute");

            AS0ObjectEditable obj = null;
            String objName = generateObjectName(uri, name, qName);
            int name_id = namesTranslator.getOrRegisterName(objName);

            if (refID != null) {

                // pointer object
                startedElementsTypes.add(ObjectTypeEnum.Pointer);
                obj = as0objectFactory.newPointerObject(name_id, new LongOid(0));
                storeAS0.addSubobject(transation, getCurrentOid(), obj);
                remapper.registerRefernce(obj.getOID(), refID);

            } else if (type != null) {

                // atomic value object
                startedElementsTypes.add(ObjectTypeEnum.Atomic);
                waitingAtomicObjectType = parseAtmicValueTypeName(type);
                lastContent = null;
                if (type.equalsIgnoreCase("Date"))
                    waitingDateFormat = atts.getValue("format");
                AtomicValue val = atomicValueFactory.newAtomicValue("null"); // will be updated later (TODO: performance issue)
                obj = as0objectFactory.newAtomicObject(name_id, val);
                storeAS0.addSubobject(transation, getCurrentOid(), obj);

            } else {

                // complex object
                startedElementsTypes.add(ObjectTypeEnum.Complex);
                obj = as0objectFactory.newEmptyComplexObject(name_id);
                storeAS0.addSubobject(transation, getCurrentOid(), obj);

                // storing attributes of complex object
                
            }

            if (id != null) {
                remapper.registerIdMapping(id, obj.getOID());
        xmlIdToOidMap.put(id, obj.getOID());
      }
            startedElements.add(obj);

        } catch (NameTranslatorException e) {
            throw new SAXException(e);
        } catch (StoreException e) {
            throw new SAXException(e);
        }
    }

    @Override
    public void endElement(String uri, String name, String qName) throws SAXException {

        ObjectTypeEnum endingObjecType = startedElementsTypes.getLast();

        try {
            switch (endingObjecType) {

                case Atomic:
                    AtomicValue value = createAtomicValue();
                    this.storeAS0.setAtomicObjectValue(transation, getCurrentOid(), value);
                    break;

                case Complex:
                    // do nothing
                    break;

                case Pointer:
                    // do nothing
                    break;
            }

            startedElements.removeLast();
            startedElementsTypes.removeLast();

        } catch (ParseException e) {
            throw new SAXException(e);
        } catch (StoreException e) {
            throw new SAXException(e);
        }
    }

    @Override
    public void characters(char ch[], int start, int length) throws SAXException{
        String content = new String(ch, start, length);
        if (lastContent == null) {
            lastContent = new StringBuilder();
        }
        
        if (startedElementsTypes.getLast()!=ObjectTypeEnum.Atomic 
            && content.trim().length()!=0){
          String l=currentPositingString();
          throw new SAXException("Unexpected content inside of not atomic object. Probably you forgot to use type='string' "+l+": "+content.trim());
        }
        
        lastContent.append(content);
    }

    private String currentPositingString() {
      if (locator!=null){
        return locator.getSystemId()+":"+locator.getPublicId()+":"+locator.getLineNumber()+":"+locator.getColumnNumber();
      }else{
        return "";
      }
  }

  private AbstractOid getCurrentOid() {
        try {
            return startedElements.getLast().getOID();
        } catch (NoSuchElementException e) {
            return storeAS0.getSuperRootOid();
        }
    }

    private String generateObjectName(String uri, String name, String qName) {
        if ("".equals(uri))
            return qName;
        else
            return uri + ":" + name;
    }

    private AtomicValue createAtomicValue() throws ParseException {

        String value = flushContent();

        switch (waitingAtomicObjectType) {
            case Boolean:
                return atomicValueFactory.newAtomicValue(Boolean.parseBoolean(value));
            case Date:
                String fmt = waitingDateFormat == null ? "yyyy-MM-dd" : waitingDateFormat;
                waitingDateFormat = null;
                DateFormat df = new SimpleDateFormat(fmt);
                Date date = df.parse(value);
                
                return atomicValueFactory.newAtomicValue(date);
            case Double:
                return atomicValueFactory.newAtomicValue(Double.parseDouble(value));
            case Float:
                return atomicValueFactory.newAtomicValue(Double.parseDouble(value));
            case Integer:
            case Int:
                return atomicValueFactory.newAtomicValue(new Integer(value));
            case Long:
                return atomicValueFactory.newAtomicValue(new Long(value));
            default:
                return atomicValueFactory.newAtomicValue(value);
        }
    }

    private AtomicValueTypeEnum parseAtmicValueTypeName(String typeName) {
        String res = typeName.trim();
        String prefix = res.substring(0, 1).toUpperCase();
        String suffix = res.substring(1, res.length()).toLowerCase();
        res = prefix + suffix;
        return AtomicValueTypeEnum.valueOf(res);
    }

    private String flushContent() {
        String res = lastContent.toString();
        lastContent = null;
        return res.trim();
    }

    private enum ObjectTypeEnum {

        Complex,
        Pointer,
        Atomic
    }
}
