/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.TypeInfo;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;

/**
 *
 * @author Pawel Mantur
 */
public class AS0Attr extends AS0Node implements Attr {

    public Element ownerElement;
    private String attrName;
    private String value;
    public AbstractOid underlyingObjectOID;
    
    private Logger logger = Logger.getLogger(AS0Node.class);

    public AS0Attr(String name, String value, AS0Element ownerElement) {
        this.attrName = name;
        this.value = value;
        this.ownerElement = ownerElement;
        this.ownerDocument = ownerElement.ownerDocument;
        this.underlyingObjectOID = null;
    }

    /**
     * Constructor used by doc.createAttribute when we don't know the parent node
     */
    public AS0Attr(String name, String value, AS0Document ownerDoc) {
        this.attrName = name;
        this.value = value;
        this.ownerElement = null;
        this.ownerDocument = ownerDoc;
        this.underlyingObjectOID = null;
    }

    public AS0Attr(String name, String value, String namespaceUri, AS0Document ownerDoc) {
        this.attrName = name;
        this.value = value;
        this.ownerElement = null;
        this.ownerDocument = ownerDoc;
        this.underlyingObjectOID = null;
        this.namespaceUri = namespaceUri;
    }

    public String getName() {

        if (underlyingObjectOID == null)
            return attrName;
        
        logger.debug("getName");

        try {
            AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
            return getDocNamesTranslator().getNameByNameId(obj.getNameId());

        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    public String getValue() {

        if (underlyingObjectOID == null)
            return this.value;
        
        logger.debug("getValue");

        try {
            AS0AtomicObjectRO obj = (AS0AtomicObjectRO) getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
            return obj.getValue().getValue().toString();

        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    public void setValue(String value) throws DOMException {
        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (underlyingObjectOID == null) {
            this.value = value;
            return;
        }
        
        logger.debug("setValue");

        try {
            AS0AtomicObjectEditable obj = (AS0AtomicObjectEditable) getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
            AtomicValue sv = getDocAtomicValueFactory().newAtomicValue(value);
            obj.setValue(sv);

        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    public Element getOwnerElement() {
        return ownerElement;
    }

    public boolean getSpecified() {
        // it could be false only if schema support was present
        // and attribute had not modified default value
        return true;
    }

    // level 3
    public TypeInfo getSchemaTypeInfo() {
        return null;
    }

    // level 3
    public boolean isId() {
        return this.attrName.compareToIgnoreCase("id") == 0;
    }

    @Override
    public String getLocalName() {
        return this.getName();
    }

    @Override
    public String getNodeName() {
        return this.getName();
    }

    @Override
    public String getNodeValue() {
        return this.getValue();
    }

    @Override
    public void setNodeValue(String nodeValue) throws DOMException {
        this.setValue(nodeValue);
    }

    public short getNodeType() {
        return Node.ATTRIBUTE_NODE;
    }

    public AS0AtomicObjectEditable toAtomicObject() {

        try {
            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + this.getNodeName());
            AtomicValue val = getDocAtomicValueFactory().newAtomicValue(this.getValue());
            AS0AtomicObjectEditable atomic = getDocAS0ObjectsFactory().newAtomicObject(nameID, val);
            return atomic;
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    @Override
    public Node cloneNode(boolean deep) {
        AS0Attr res = new AS0Attr(getName(), getValue(), ownerDocument);
        copyValuesOnClone(res);
        return res;
    }
}
