/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinderExtTemp;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection.Builder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.process.AbstractRecursiveAs0ResultsetTranslator;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;

/**
 * Rebuilds given {@link AS0Resultset} tree and replaces all found
 * {@link AS0ResultsetBinder} (internal - integer representation of name) into
 * {@link AS0ResultsetBinderExt} representation (string representation of
 * names).
 * 
 * @author ptab
 * 
 */
public class AS0ResultsetNameIdResolveRewriteTransformer extends
		AbstractRecursiveAs0ResultsetTranslator {
	// private final static Logger
	// logger=Logger.getLogger(AS0ResultsetNameTranslatorToExternalTransformer.class);
	private NamesTranslator namesTranslator;

	public AS0ResultsetNameIdResolveRewriteTransformer(
			AS0ResultsetFactory factory) {
		this.resultsetFactory = factory;

	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetBinder r) {
		AS0Resultset rValue = process(r.getValue());
		if (!r.hasName()) {
			r.setName(namesTranslator.getNameByNameId(r.getNameId()));
			return resultsetFactory.createBinder(rValue, r.getNameId(),
					r.getName());
		}
		if (r instanceof AS0ResultsetBinderExtTemp) {
			AS0ResultsetBinderExtTemp rt = (AS0ResultsetBinderExtTemp) r;
			if (!rt.isInitialized()) {
				rt.initNameIdAs(namesTranslator.getOrRegisterName(rt.getName()));
			}
			return ((AS0ResultsetBinderExtTemp) resultsetFactory.createBinder(
					rValue, rt.getName()));
		} else {
			return resultsetFactory.createBinder(rValue, r.getNameId());
		}
		
	}

	public NamesTranslator getNamesTranslator() {
		return namesTranslator;
	}

	public void setNamesTranslator(NamesTranslator namesTranslator) {
		this.namesTranslator = namesTranslator;
	}

	@Override
	public AS0Resultset transform(AS0Resultset r) {
		return process(r);
	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetRef r) {
		return resultsetFactory.createRef(r.getRefOID());
	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetStruct r) {
		Builder builder = resultsetFactory.createStructBuilder();
		processCollection(r, builder );
		return builder.build();
	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetBag r) {
		Builder builder = resultsetFactory.createBagBuilder();
		processCollection(r, builder);
		return builder.build();
	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetSequence r) {
		Builder builder = resultsetFactory.createSequenceBuilder();
		processCollection(r, builder );
		return builder.build();
	}

	@Override
	protected AS0Resultset processTyped(AS0ResultsetAtomic r) {		
		return resultsetFactory.createAtomic(r.getValue());
	}

}
