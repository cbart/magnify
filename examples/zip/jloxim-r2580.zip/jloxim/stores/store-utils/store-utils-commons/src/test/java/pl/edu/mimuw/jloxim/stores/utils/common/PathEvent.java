/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author mlenart
 * @version $Id: PathEvent.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class PathEvent {
  //TODO(ptab): Use ENUM instead on 'String' - faster, static type control, ... 
  final String name;
  final String pathString;
  final AbstractOid oid;

  public PathEvent(String name, String pathString, AbstractOid oid) {
    this.name = name;
    this.pathString = pathString;
    this.oid = oid;
  }

  @Override
  public boolean equals(Object o) {
    if (o instanceof PathEvent) {
      PathEvent event = (PathEvent) o;
      return event.name.equals(name) && event.pathString.equals(pathString) && event.oid.equals(oid);
    }
    else
      return false;
  }

  @Override
  public int hashCode() {
    int hash = 7;
    hash = 67 * hash + (this.name != null ? this.name.hashCode() : 0);
    hash = 67 * hash + (this.pathString != null ? this.pathString.hashCode() : 0);
    hash = 67 * hash + (this.oid != null ? this.oid.hashCode() : 0);
    return hash;
  }

  public String toString() {
    return "PathEvent(name="+name+", path="+pathString+", oid="+oid.toReadableString()+")";
  }
}
