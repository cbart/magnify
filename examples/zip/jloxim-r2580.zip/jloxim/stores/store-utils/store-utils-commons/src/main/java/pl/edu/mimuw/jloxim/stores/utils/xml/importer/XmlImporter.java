/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.importer;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author Pawel Mantur
 */
public class XmlImporter {

  private NamesTranslator namesTranslator;
  private StoreAS0 storeAS0;
  private Transaction transation;
  private AS0ObjectsFactory as0objectFactory;
  private AtomicValueFactory atomicValueFactory;
  private Map<String, AbstractOid> xmlIdToOidMap =
      new HashMap<String, AbstractOid>();

  public NamesTranslator getNamesTranslator() {
    return namesTranslator;
  }

  public void setNamesTranslator(NamesTranslator namesTranslator) {
    this.namesTranslator = namesTranslator;
  }

  public StoreAS0 getStoreAS0() {
    return storeAS0;
  }

  public void setStoreAS0(StoreAS0 storeAS0) {
    this.storeAS0 = storeAS0;
  }

  public Transaction getTransation() {
    return transation;
  }

  public void setTransation(Transaction transcation) {
    this.transation = transcation;
  }

  public AS0ObjectsFactory getAs0objectFactory() {
    return as0objectFactory;
  }

  public void setAs0objectFactory(AS0ObjectsFactory as0objectFactory) {
    this.as0objectFactory = as0objectFactory;
  }

  public AtomicValueFactory getAtomicValueFactory() {
    return atomicValueFactory;
  }

  public void setAtomicValueFactory(AtomicValueFactory atomicValueFactory) {
    this.atomicValueFactory = atomicValueFactory;
  }

  public Map<String, AbstractOid> getXmlIdToOidMap() {
    return xmlIdToOidMap;
  }

  public void setXmlIdToOidMap(Map<String, AbstractOid> map) {
    xmlIdToOidMap = map;
  }

  public XmlImporter() {
  }

  /**
   * <p>Reads data from XML file and stores it in database.
   * It expects input XML files to follow format like below:</p>
   *
   * <complexObjectName id="oid">
   *  <subobject...>
   * </complexObjectName >
   * <atomicObjectName id="oid" type="integer, float, string">value</atomicObjectName>
   * <pointerObjectName id="oid" ref="oid"/>
   *
   * <p>Element representing atomic object must have attribute <code>type</code> and
   * optionally attribute <code>format</code> if type is <code>Date</code>. Default
   * format is "yyyy-MM-dd".</p>
   *
   * <p>Element representing pointer object must have attribute <code>ref</code>.
   *
   * <p>If neither <code>type</code> nor <code>ref</code> attribte is present, element
   * is considered as complex object.</p>
   *
   * <p>If both <code>type</code> and <code>ref</code> attribtes are present,
   * it is considered as error.</p>
   *
   * @param inputStream XML file to import
   * @throws ParserConfigurationException
   * @throws IOException
   */
  public void importXmlFile(InputStream inputStream) throws SAXException, ParserConfigurationException, IOException {

    SAXParserFactory fact = SAXParserFactory.newInstance();
    SAXParser parser = fact.newSAXParser();
    XmlImportSAXHandler handler = new XmlImportSAXHandler(namesTranslator, storeAS0, transation, as0objectFactory, atomicValueFactory, xmlIdToOidMap);

    parser.parse(inputStream, handler);

  }
}
