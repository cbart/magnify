/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

public class AS0StoreContentLogger {

    private Logger logger = Logger.getLogger(AS0StoreContentLogger.class);

    public void logAs0StoreContent(Transaction t, int level, AS0ObjectRO object, StoreAS0 store, NamesTranslator nt) throws NameTranslatorException, ModelException, StoreException {
        String name = nt.getNameByNameId(object.getNameId());
        String prefix = iterate(" ", level);
        if (object instanceof AS0AtomicObjectRO) {
            logger.info(prefix + "<" + name + " id='" + object.getOID() + "'>" + ((AS0AtomicObjectRO) object).getValue().toString() + "</" + name + ">");
        } else if (object instanceof AS0PointerObjectRO) {
            logger.info(prefix + "<" + name + " id='" + object.getOID() + "' ref='" + ((AS0PointerObjectRO) object).getDestinationOID() + "'/>");
        } else if (object instanceof AS0ComplexObjectRO) {
            logger.info(prefix + "<" + name + " id='" + object.getOID() + "'>");
            AS0ComplexObjectRO c = (AS0ComplexObjectRO) object;
            ClosableIterator<AbstractOid> oid_iter = c.iterator();
            while (oid_iter.hasNext()) {
                logAs0StoreContent(t, level + 1, store.getObjectByOID(t, oid_iter.next()), store, nt);
            }
            oid_iter.close();
            logger.info(prefix + "</" + name + ">");
        }
    }

    private String iterate(String string, int level) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < level; i++) {
            sb.append(string);
        }
        return sb.toString();
    }
}
