/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.PathNamesModificationListener;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author mlenart
 * @version $Id: ListenerImpl.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class ListenerImpl implements PathNamesModificationListener {
  @SuppressWarnings("unused")
  private final static Logger logger = Logger.getLogger(ListenerImpl.class);

  private final List<PathEvent> events = new LinkedList<PathEvent>();

  private final PathNamesObservingAndProvidingStoreAS0Impl store;
  
  private final NamesTranslator nt;

  private final PathConverter rpr;

  public ListenerImpl(PathNamesObservingAndProvidingStoreAS0Impl store, NamesTranslator nt) {
    this.store = store;
    this.nt = nt;
    rpr = new PathConverter(nt);
    }
  
  public List<PathEvent> getEvents() {
    return events;
  }

    public void beforeAtomicValSet(Transaction t, List<Integer> path, AbstractOid oid, AtomicValue newVal) throws StoreException {
        events.add(new PathEvent("beforeAtomicValSet", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void afterAtomicValSet(Transaction t, List<Integer> path, AbstractOid oid, AtomicValue newVal) throws StoreException {
        events.add(new PathEvent("afterAtomicValSet", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void beforePointerDestSet(Transaction t, List<Integer> path, AbstractOid oid, AbstractOid destOid) throws StoreException {
        events.add(new PathEvent("beforePointerDestSet", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void afterPointerDestSet(Transaction t, List<Integer> path, AbstractOid oid, AbstractOid destOid) throws StoreException {
        events.add(new PathEvent("afterPointerDestSet", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void beforeAddSubobject(Transaction t, List<Integer> path, AbstractOid oid, AS0ObjectEditable object) throws StoreException {
        events.add(new PathEvent("beforeAddSubobject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void afterAddSubobject(Transaction t, List<Integer> path, AbstractOid oid, AS0ObjectEditable object) throws StoreException {
        events.add(new PathEvent("afterAddSubobject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void beforeSetComplexObjectValue(Transaction t, List<Integer> path, AbstractOid oid, Collection<AS0ObjectEditable> subobjects) throws StoreException {
      events.add(new PathEvent("beforeSetComplexValue", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }
  
    public void afterSetComplexObjectValue(Transaction t, List<Integer> path, AbstractOid oid, Collection<AS0ObjectEditable> subobjects) throws StoreException {
      events.add(new PathEvent("afterSetComplexValue", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void beforeMoveObject(Transaction t, List<Integer> path, List<Integer> newPath, AbstractOid oid) throws StoreException {
    events.add(new PathEvent("beforeMoveObject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

    public void afterMoveObject(Transaction t, List<Integer> path, List<Integer> newPath, AbstractOid oid) throws StoreException {
    events.add(new PathEvent("afterMoveObject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }
  
  public void beforeRemoveObject(Transaction t, List<Integer> path, AbstractOid oid) throws StoreException {
        events.add(new PathEvent("beforeRemoveObject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
    }

  public void beforeMoveObject(Transaction t,
                 List<Integer> path, AbstractOid oid,
                 List<Integer> newParentPath,
                 AbstractOid newParentOid) throws StoreException {
    events.add(new PathEvent("beforeMoveObject", rpr.toString(store.getPathNameForObject(t, oid)), oid));
  }

  public void afterMoveObject(Transaction t,
                List<Integer> path, AbstractOid oid,
                List<Integer> newParentPath,
                AbstractOid newParentOid) throws StoreException {
    events.add(new PathEvent("afterMoveObject", rpr.toString(store.getPathNameForObject(t, newParentOid)), newParentOid));
  }
}
