/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;

/**
 *
 * @author Pawel Mantur
 */
public abstract class AS0CharacterData extends AS0Node implements CharacterData {

    protected String textData;

    public AS0CharacterData() {
    }

    public AS0CharacterData(String textData) {
        this.textData = textData;
    }

    public String getData() throws DOMException {
        return this.textData;
    }

    public void setData(String data) throws DOMException {
        if (isReadOnly()) {
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
    }

    public int getLength() {
        return textData.length();
    }

    public String substringData(int offset, int count) throws DOMException {
        if (offset < 0 || offset > textData.length() || count < 0) {
            throw new DOMException(DOMException.INDEX_SIZE_ERR, ErrorMsg.INDEX_SIZE_ERR);
        }
        int endIndex = offset + count - 1;
        if (endIndex >= textData.length()) {
            return textData.substring(offset);
        }
        return textData.substring(offset, endIndex);
    }

    public void appendData(String arg) throws DOMException {
        if (isReadOnly()) {
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
        textData += arg;
    }

    public void insertData(int offset, String arg) throws DOMException {
        if (isReadOnly()) {
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
        if (offset < 0 || offset >= textData.length()) {
            throw new DOMException(DOMException.INDEX_SIZE_ERR, ErrorMsg.INDEX_SIZE_ERR);
        }
        String suffix = textData.substring(offset);
        String prefix = offset > 0 ? textData.substring(0, offset - 1) : "";
        textData = prefix + arg + suffix;
    }

    public void deleteData(int offset, int count) throws DOMException {
        if (isReadOnly()) {
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
        if (offset < 0 || offset >= textData.length() || count < 0) {
            throw new DOMException(DOMException.INDEX_SIZE_ERR, ErrorMsg.INDEX_SIZE_ERR);
        }
        String suffix;
        if (offset + count >= textData.length()) {
            suffix = "";
        } else {
            suffix = textData.substring(offset + count);
        }
        String prefix = offset > 0 ? textData.substring(0, offset - 1) : "";
        textData = prefix + suffix;
    }

    public void replaceData(int offset, int count, String arg) throws DOMException {
        if (isReadOnly()) {
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
        if (offset < 0 || offset >= textData.length() || count < 0) {
            throw new DOMException(DOMException.INDEX_SIZE_ERR, ErrorMsg.INDEX_SIZE_ERR);
        }
        String suffix;
        if (offset + count >= textData.length()) {
            suffix = "";
        } else {
            suffix = textData.substring(offset + count);
        }
        String prefix = offset > 0 ? textData.substring(0, offset - 1) : "";
        textData = prefix + arg + suffix;
    }
}
