/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.importer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.w3c.dom.Document;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.utils.common.AS0StoreContentLogger;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 *
 * @author Pawel Mantur
 */
@ContextConfiguration(locations = {"classpath:/XmlImporterTest_spring.xml"})
public class XmlImporterTest extends AbstractJUnit4SpringContextTests {

    @Autowired
    NamesTranslator namesTranslator;
    @Autowired
    StoreAS0 store;
    @Autowired
    XmlImporter xmlImporter;
    @Autowired
    TransactionManager transactionManager;
    @Autowired
    AS0StoreContentLogger storeContentLogger;

    @DirtiesContext
    @Test
    public void testImportXmlFile10kb() throws Exception {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        xmlImporter.setTransation(t);
        xmlImporter.importXmlFile(XmlImporter.class.getResourceAsStream("/cars_10kb.xml"));
        t.commit();

        // testing the result
        t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        AS0StoreToXmlComparer storeToXmlComparer = new AS0StoreToXmlComparer(t, store, namesTranslator);
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(XmlImporter.class.getResourceAsStream("/cars_10kb.xml"));
        Assert.assertTrue(storeToXmlComparer.CompareElementsStructure(doc, store, true));

        // 'human driven tests' can read the log also ;A
        ClosableIterator<AbstractOid> iter = store.getRoots(t);
        try{
          AbstractOid oid = iter.next();
          storeContentLogger.logAs0StoreContent(t, 0, store.getObjectByOID(t, oid), store, namesTranslator);
        } finally {
          iter.close();
          t.commit();
        };
    }

    @Test
    @DirtiesContext
    public void testImportXmlFile100kb() throws Exception {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        xmlImporter.setTransation(t);
        xmlImporter.importXmlFile(XmlImporter.class.getResourceAsStream("/cars_100kb.xml"));

        // just the log, not using storeToXmlComparer because of overhead
        ClosableIterator<AbstractOid> iter = store.getRoots(t);
        try{
          AbstractOid oid = iter.next();
          storeContentLogger.logAs0StoreContent(t, 0, store.getObjectByOID(t, oid), store, namesTranslator);
        } finally {
          iter.close();
          t.commit();
        };
    }
}
