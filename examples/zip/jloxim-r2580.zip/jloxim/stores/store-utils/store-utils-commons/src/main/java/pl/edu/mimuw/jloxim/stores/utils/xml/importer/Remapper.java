/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.importer;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author Pawel Mantur
 */
public class Remapper {
  private Logger logger=Logger.getLogger(Remapper.class);
    private Map<String, AbstractOid> idToOIdMaping;
    private Map<AbstractOid, String> references;

    public Remapper() {
        this.idToOIdMaping = new HashMap<String, AbstractOid>();
        this.references = new HashMap<AbstractOid, String>();
    }

    /**
     * If element in xml had its identifier, keep information about what OID this
     * element received in the store
     * @param xmlID id of element defined in xml file
     * @param OID OID of this element after sotring in the store
     */
    public void registerIdMapping(String xmlID, AbstractOid OID) {
        if (idToOIdMaping.put(xmlID, OID)!=null)
        {
          logger.warn("Duplicated value id="+xmlID+" during import. Corrupted import source data.");
        }
    }

    /**
     * Keep information about reference which should be set after whole
     * document will be stored.
     * @param pointerObjectOID OID of the pointer object
     * @param xmlID id of destination object, this id comes from XML and is not
     * an object OID. To set proper reference, this id should be remapped
     */
    public void registerRefernce(AbstractOid pointerObjectOID, String xmlID) {
        references.put(pointerObjectOID, xmlID);
    }

    /**
     * It sets all references that have been registered
     */
    public void setAllRegisteredReferences(StoreAS0 store, Transaction t) throws Exception {
        for (AbstractOid OID : references.keySet()) {

            String dest = references.get(OID);
            AbstractOid realDest = idToOIdMaping.get(dest);

            if (realDest == null)
                throw new Exception(String.format("Remapper cannot resolve mapping for id='%1$s' used as reference destination", dest));

            store.setNewPointerObjectDestination(t, OID, realDest);
        }
    }
}
