/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.logiclocks;

import java.util.Collection;
import java.util.Map;

import pl.edu.mimuw.jloxim.lock_mgrs.api.LockInterruptedException;
import pl.edu.mimuw.jloxim.lock_mgrs.api.LockTypeEnum;
import pl.edu.mimuw.jloxim.lock_mgrs.utils.multi_locks.api.MultipleLocksLockMgr;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0WithLogicalLocksSupport;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 * {@link StoreAS0} that provides additional - logical - locking layer.
 * @author ptab
 *
 */
public class AS0StoreWithLogicalLocksSupportAdapter implements StoreAS0WithLogicalLocksSupport{
  private final StoreAS0 backingStore;
  private final MultipleLocksLockMgr<Transaction> lockMgr;
  private boolean releaseRWjustAfterWrite=true;
  private boolean releaseROjustAfterRead=true;

  public AS0StoreWithLogicalLocksSupportAdapter(StoreAS0 backingStore,
      MultipleLocksLockMgr<Transaction> lockMgr,
      boolean releaseROjustAfterRead,
      boolean releaseRWjustAfterWrite
      ) {
    super();
    this.backingStore = backingStore;
    this.lockMgr = lockMgr;
    this.releaseRWjustAfterWrite=releaseRWjustAfterWrite;
    this.releaseROjustAfterRead=releaseROjustAfterRead;
  }

  public void getLogicalLock(Transaction t, AbstractOid OID, LockTypeEnum type)
      throws StoreException {
    try {
      lockMgr.acquireLock(t, OID.longHashCode(), type);
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+type+" on "+OID, e);
    }
  }

  public void getLogicalLocks(Transaction t, AbstractOid[] OIDs,
      LockTypeEnum type) throws StoreException {
    try {
      lockMgr.acquireLocks(t, toArrayOfLongOids(OIDs), type);
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+type+" on "+OIDs, e);
    }
  }

  private static long[] toArrayOfLongOids(AbstractOid[] OIDs) {
    long[] res=new long[OIDs.length];
    for ( int i=0; i<OIDs.length; i++){
      res[i]=OIDs[i].longHashCode();
    }
    return res;
  }

  public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid OID) throws StoreException {
    try{
      lockMgr.acquireLock(t, OID.longHashCode(), LockTypeEnum.PROTECTED_READ);
      try{
        return backingStore.getObjectByOID(t, OID);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, OID.longHashCode(), LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on "+OID, e);
    }
  }

  public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException {
    return backingStore.getParentOID(t, oid);
  }

  public ClosableIterator<AbstractOid> getReferrers(Transaction t, AbstractOid OID) throws StoreException {
    try{
      lockMgr.acquireLock(t, OID.longHashCode(), LockTypeEnum.PROTECTED_READ);
      try{
        return backingStore.getReferrers(t, OID);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, OID.longHashCode(), LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on "+OID, e);
    }
  }

  public ClosableIterator<AbstractOid> getRoots(Transaction t) throws StoreException {
    try{
      long OID=backingStore.getSuperRootOid().longHashCode();
      lockMgr.acquireLock(t, OID, LockTypeEnum.PROTECTED_READ);
      try{
        return backingStore.getRoots(t);
      }finally{
        if (releaseROjustAfterRead) {
          lockMgr.releaseLock(t, OID, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public ClosableIterator<AbstractOid> getRootsByName(
      Transaction t, int nameId) throws StoreException {
    try{
      long OID=backingStore.getSuperRootOid().longHashCode();
      lockMgr.acquireLock(t, OID, LockTypeEnum.PROTECTED_READ);
      try{
        return backingStore.getRootsByName(t, nameId);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, OID, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

    public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(Transaction t) throws StoreException {
    try{
      long OID=backingStore.getSuperRootOid().longHashCode();
      lockMgr.acquireLock(t, OID, LockTypeEnum.PROTECTED_READ);
      try{
          return backingStore.getRootsMap(t);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, OID, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public String getStoreId() {
    return backingStore.getStoreId();
  }

  public ClosableIterator<AbstractOid>
      getSubobjectOIDs(Transaction t, AbstractOid OID) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_READ);
      try{
          return backingStore.getSubobjectOIDs(t, OID);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(
      Transaction t, AbstractOid OID, int nameID) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_READ);
      try{
          return backingStore.getSubobjectOIDsByNameOID(t, OID, nameID);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(
      Transaction t, AbstractOid OID) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_READ);
      try{
          return backingStore.getSubobjectOIDsMap(t, OID);
      }finally{
        if (releaseROjustAfterRead){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_READ);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public AbstractOid getSuperRootOid() {
    return backingStore.getSuperRootOid();
  }

  @Override
  public AbstractOid getConfigRootOid() {
      return backingStore.getConfigRootOid();
  }

  public void moveObject(Transaction t, AbstractOid OID,
      AbstractOid newParentOid) throws StoreException {
    AbstractOid oldParentOid=getParentOID(t, OID);
    long[] locks=new long[]{oldParentOid.longHashCode(), newParentOid.longHashCode()};
    try{
      lockMgr.acquireLocks(t, locks, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.moveObject(t, OID, newParentOid);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLocks(t, locks, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }

    backingStore.moveObject(t, OID, newParentOid);
  }

  public void prefetchDeepObject(AbstractOid OID) {
    backingStore.prefetchDeepObject(OID);
  }

  public void prefetchDeepObjects(AbstractOid[] OIDs) {
    backingStore.prefetchDeepObjects(OIDs);
  }

  public void prefetchObject(AbstractOid OID) {
    backingStore.prefetchObject(OID);
  }

  public void prefetchObjects(AbstractOid[] OIDs) {
    backingStore.prefetchObjects(OIDs);
  }

  public void prefetchSubobjectsByParentIDandName(AbstractOid parentId,
      int nameId) {
    backingStore.prefetchSubobjectsByParentIDandName(parentId, nameId);
  }

  public void removeObject(Transaction t, AbstractOid OID)
      throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.removeObject(t, OID);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public void removeObjects(Transaction t, AbstractOid[] OIDs)
      throws StoreException {
    try{
      long[] oids=toArrayOfLongOids(OIDs);
      lockMgr.acquireLocks(t, oids, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.removeObjects(t, OIDs);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLocks(t, oids, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }

  }

  public void setAtomicObjectValue(Transaction t, AbstractOid OID,
      AtomicValue value) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.setAtomicObjectValue(t, OID, value);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public void setNewComplexObjectValue(Transaction t, AbstractOid OID,
      Collection<AS0ObjectEditable> subobjects) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.setNewComplexObjectValue(t, OID, subobjects);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public void setNewPointerObjectDestination(Transaction t, AbstractOid OID,
      AbstractOid destinationOID) throws StoreException {
    try{
      long oid=OID.longHashCode();
      lockMgr.acquireLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
      try{
        backingStore.setNewPointerObjectDestination(t, OID, destinationOID);
      }finally{
        if (releaseRWjustAfterWrite){
          lockMgr.releaseLock(t, oid, LockTypeEnum.PROTECTED_WRITE);
        }
      }
    } catch (LockInterruptedException e) {
       throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }

  public AbstractOid addSubobject(Transaction t, AbstractOid parentOID, AS0ObjectEditable object) throws StoreException {
    try{
      AbstractOid newOid=backingStore.addSubobject(t, parentOID, object);
      if (!releaseRWjustAfterWrite){
        lockMgr.acquireLock(t, newOid.longHashCode(), LockTypeEnum.PROTECTED_WRITE);
      }
      return newOid;
    } catch (LockInterruptedException e) {
      throw new StoreException("Transaction "+t+" cannot acquire lock "+LockTypeEnum.PROTECTED_READ+" on superroot", e);
    }
  }
}
