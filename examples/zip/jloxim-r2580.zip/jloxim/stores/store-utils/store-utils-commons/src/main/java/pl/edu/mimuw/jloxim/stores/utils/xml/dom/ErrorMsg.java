/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

/**
 *
 * @author Pawel Mantur
 */
public class ErrorMsg {

    public static final String INDEX_SIZE_ERR = "If index or size is negative, or greater than the allowed value";
    public static final String DOMSTRING_SIZE_ERR = "specified range of text does not fit into a DOMString";
    public static final String HIERARCHY_REQUEST_ERR = "Node inserted somewhere it doesn't belong.";
    public static final String WRONG_DOCUMENT_ERR = "Node is used in a different document than the one that created it";
    public static final String INVALID_CHARACTER_ERR = "Invalid or illegal character";
    public static final String NO_DATA_ALLOWED_ERR = "Data specified for a Node which does not support data.";
    public static final String NO_MODIFICATION_ALLOWED_ERR = "Modifications are not allowed";
    public static final String NOT_FOUND_ERR = "Reference to Node in a context where it does not exist";
    public static final String NOT_SUPPORTED_ERR = "The implementation does not support the requested type of object or operation";
    public static final String INUSE_ATTRIBUTE_ERR = "An attempt was made to add an attribute that is already in use elsewhere";
    public static final String INVALID_STATE_ERR = "An attempt was made to use an object that is not, or is no longer, usable";
    public static final String SYNTAX_ERR = "Invalid or illegal string was specified";
    public static final String INVALID_MODIFICATION_ERR = "An attempt was made to modify the type of the underlying object";
    public static final String NAMESPACE_ERR = "An attempt was made to create or change an object in a way which is incorrect with regard to namespaces";
    public static final String INVALID_ACCESS_ERR = "A parameter or an operation is not supported by the underlying object";
    public static final String VALIDATION_ERR = "Validation error";
    public static final String TYPE_MISMATCH_ERR = "The type of an object is incompatible with the expected type of the parameter associated to the object.";

}
