/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * TODO 1:
 * We support namespaces here, but when Nodes are saved to the store,
 * information about namespaces is lost. To make it well, a special place in the
 * store should be defined to hold information about objects to namespaces mapping.
 * It could be done by saving namespaces to prefixes mappings somewhere and
 * adding prefixes to names.
 * TODO 2:
 * AS0Document should also remember namespaces declarations.
 *
 * @author Pawel Mantur
 */
public class AS0NamedNodeMap implements NamedNodeMap {

    // nodes that do not belong to any nameaspace
    private Map<String, Node> items;

    // mapping between namespaces and a set of nodes belonging to it
    // - the key in outer map is namespace URI
    // - the key in inner map is local node name
    private Map<String, Map<String, Node>> namespaces;
    private AS0Document ownerDocument;

    public AS0NamedNodeMap(AS0Document doc) {
        this.ownerDocument = doc;
        items = new HashMap<String, Node>();
        namespaces = new HashMap<String, Map<String, Node>>();
    }

    public Node getNamedItem(String name) {
        if (items.containsKey(name)) {
            return items.get(name);
        }
        return null;
    }

    public Node setNamedItem(Node arg) throws DOMException {

        if (this.ownerDocument != null && this.ownerDocument.isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        return internalSet(arg);
    }

    public Node removeNamedItem(String name) throws DOMException {
        if (this.ownerDocument != null && this.ownerDocument.isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        return internalRemove(name);

    }

    public Node item(int index) {

        if (index < 0 || index >= items.size())
            return null;

        Iterator<Node> iter = items.values().iterator();

        int pos = 0;
        while (iter.hasNext()) {
            if (pos == index)
                return iter.next();

            iter.next();
            pos++;
        }

        return null;
    }

    public int getLength() {
        return items.size();
    }

    public Node getNamedItemNS(String namespaceURI, String localName) throws DOMException {
        if (namespaceURI == null || namespaceURI.length()==0)
            return getNamedItem(localName);

        Map<String, Node> ns = namespaces.get(namespaceURI);
        if (ns == null)
            return null;
        return ns.get(localName);
    }

    public Node setNamedItemNS(Node arg) throws DOMException {

        if (this.ownerDocument != null && this.ownerDocument.isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        return internalSetNS(arg);
    }

    public Node removeNamedItemNS(String namespaceURI, String localName) throws DOMException {

        if (this.ownerDocument != null && this.ownerDocument.isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        return internalRemoveNS(namespaceURI, localName);
    }

    // methods used internally by implementation to avoid readonly constraint checking
    public Node internalSet(Node arg) {

        if (arg.getOwnerDocument() != this.ownerDocument)
            throw new DOMException(DOMException.WRONG_DOCUMENT_ERR, ErrorMsg.WRONG_DOCUMENT_ERR);

        if (arg.getParentNode() != null)
            throw new DOMException(DOMException.INUSE_ATTRIBUTE_ERR, ErrorMsg.INUSE_ATTRIBUTE_ERR);

        return items.put(arg.getNodeName(), arg);
    }

    public Node internalSetNS(Node arg) {

        if (arg.getOwnerDocument() != this.ownerDocument)
            throw new DOMException(DOMException.WRONG_DOCUMENT_ERR, ErrorMsg.WRONG_DOCUMENT_ERR);

        if (arg.getParentNode() != null)
            throw new DOMException(DOMException.INUSE_ATTRIBUTE_ERR, ErrorMsg.INUSE_ATTRIBUTE_ERR);

        if (arg.getNamespaceURI() == null || arg.getNamespaceURI().length()==0)
            return internalSet(arg);

        Map<String, Node> ns = namespaces.get(arg.getNamespaceURI());
        if (ns == null) {
          ns = new HashMap<String, Node>();
            namespaces.put(arg.getNamespaceURI(), ns);         
        }

        return ns.put(arg.getNodeName(), arg);
    }

    public Node internalRemove(String name) {

        if (!items.containsKey(name))
            throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);

        return items.remove(name);
    }

    public Node internalRemoveNS(String namespaceURI, String localName) {
        if (namespaceURI == null || namespaceURI.length()==0)
            return internalRemove(localName);

        Map<String, Node> ns = namespaces.get(namespaceURI);

        if (ns == null || !ns.containsKey(localName))
            throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);

        return ns.remove(localName);
    }
}
