/**
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;

/**
 * Groups utility methods simplifying work with path names.
 *
 * @author mlenart
 * @version $Id: PathUtils.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class PathUtils {
  private static final Logger logger = Logger.getLogger(PathUtils.class);

  /**
   * Returns path string from given path name
   *
   * @param nt
   * @param path
   * @return
   */
  public static String toPathString(NamesTranslator nt, List<Integer> path) {
    StringBuilder sb = new StringBuilder();
    for (int name_id: path) {
      sb.append(".");
      sb.append(nt.getNameByNameId(name_id));
    }
    String str = sb.toString();
    return str.length() > 0 ? str.substring(1) : "";
  }

  /**
   * <p>Returns paths to ancestors or self of given path</p>
   *
   * For example for /people/person returns:<br />
   * "/", "/people" and "/people/person"
   *
   * @param path
   * @return
   */
  public static List<List<Integer>> getAncestorOrSelfPaths(List<Integer> path) {
    logger.debug("PATH SIZE: "+path.size());
    List<List<Integer>> res = new LinkedList<List<Integer>>();
    for (int i = 0; i <= path.size(); i++)
      res.add(path.subList(0, i));
    return res;
  }

  /**
   * Returns real path name from path string like "people.person"
   *
   * @param nt
   * @param pathStr
   * @return
   */
  public static List<Integer> getFromString(NamesTranslator nt, String pathStr) {
    logger.debug("get from string "+pathStr);
    String[] names = pathStr.split("\\.");
    List<Integer> res = new LinkedList<Integer>();
    for (String name: names) {
      int name_id = nt.getOrRegisterName(name);
      res.add(name_id);
      logger.debug("ADD: "+name_id+" for: "+name);
    }
    return res;
  }

  /**
   * Returns real path names list from string array
   *
   * @param nt
   * @param pathStrs
   * @return list of path names
   */
  public static List<List<Integer>> getFromStrings(NamesTranslator nt, String... pathStrs) {
    List<List<Integer>> res = new LinkedList<List<Integer>>();
    for (String str: pathStrs)
      res.add(getFromString(nt, str));
    return res;
  }

  public static boolean isSubpath(List<Integer> path, List<Integer> ofPath) {
    if (path.size() > ofPath.size())
      return false;
    else
      return ofPath.subList(0, path.size()).equals(path);
  }
}
