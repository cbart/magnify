/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;
import org.springframework.test.annotation.DirtiesContext;

import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0AtomicObjectEditableImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.DoubleAtomicValueImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.TextAtomicValueImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author mlenart
 * @version $Id: PathNamesObservingStoreTest.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class PathNamesObservingStoreTest extends AbstractStoreUtilsCommonsTest {

  @Test
  @DirtiesContext
  public void testSetAtomicObjectValue() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person"), listener);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person/name"), listener);
    AbstractOid personOID = oidMap.get("kowalski");
    enhancedStore.setAtomicObjectValue(t, personOID, atomicValueFactory.newAtomicValue("NULL"));

    t.commit();

    assertEquals(2, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforeAtomicValSet", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(0));
    assertEquals(
        new PathEvent("afterAtomicValSet", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(1));
  }

  @Test
  @DirtiesContext
  public void testSetNewPointerObjectDestination() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person"), listener);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person/name"), listener);
    AbstractOid personOID = oidMap.get("kowalski");
    AbstractOid nowhereOID = oidMap.get("nowhere");
    enhancedStore.setNewPointerObjectDestination(t, personOID, nowhereOID);

    t.commit();

    assertEquals(2, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforePointerDestSet", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(0));
    assertEquals(
        new PathEvent("afterPointerDestSet", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(1));
  }

  @Test
  @DirtiesContext
  public void testSetNewComplexObjectValue() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);

    AbstractOid personOID = oidMap.get("kowalski");

    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person/name"), listener);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person"), listener);

    enhancedStore.setNewComplexObjectValue(t, personOID, new LinkedList<AS0ObjectEditable>());

    t.commit();

    assertEquals(2, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforeSetComplexValue", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(0));
    assertEquals(
        new PathEvent("afterSetComplexValue", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(1));
  }

  @Test
  @DirtiesContext
  public void testAddSubobject() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);

    AbstractOid personOID = oidMap.get("kowalski");
    
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants/person"), listener);

    AtomicValue value = new TextAtomicValueImpl("Jan");
    int nameId = namesTranslator.getOrRegisterName("first_name");
    AS0ObjectEditable object = new AS0AtomicObjectEditableImpl(null, nameId, null, value);
    enhancedStore.addSubobject(t, personOID, object);

    t.commit();

    assertEquals(2, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforeAddSubobject", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(0));
    assertEquals(
        new PathEvent("afterAddSubobject", "/root/city/inhabitants/person", personOID),
        listener.getEvents().get(1));

    assertNotNull(object.getOID());
    assertEquals(object.getParentOID(), personOID);
  }

  @Test
  @DirtiesContext
  public void testRemoveObject() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    AbstractOid inhOID = oidMap.get("forest_inhabitants");
    enhancedStore.registerListener(pc.toPathName("/root/forest/inhabitants"), listener);
    enhancedStore.registerListener(pc.toPathName("/root/forest/inhabitants/bear/name"), listener);
    enhancedStore.removeObject(t, inhOID);

    t.commit();

    assertEquals(1, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforeRemoveObject", "/root/forest/inhabitants", inhOID),
        listener.getEvents().get(0));
  }

  @Test
  @DirtiesContext
  public void testMoveObject() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    enhancedStore.registerListener(pc.toPathName("/root/city/inhabitants"), listener);
    enhancedStore.registerListener(pc.toPathName("/root/forest"), listener);
    AbstractOid oid = oidMap.get("city_inhabitants");
    AbstractOid poid = oidMap.get("forest");
    enhancedStore.moveObject(t, oid, poid);
    t.commit();

    assertEquals(2, listener.getEvents().size());
    assertEquals(
        new PathEvent("beforeMoveObject", "/root/city/inhabitants", oid),
        listener.getEvents().get(0));
    assertEquals(
        new PathEvent("afterMoveObject", "/root/forest", poid),
        listener.getEvents().get(1));
  }
  
  private AS0ObjectEditable generateRandomAtomic() {
    AtomicValue value = new DoubleAtomicValueImpl(Math.random());
    int nameId = namesTranslator.getOrRegisterName("rand_atomic");
    return new AS0AtomicObjectEditableImpl(null, nameId, null, value);
  }

  @Test
  @DirtiesContext
  public void testUnregisterListeners() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    ListenerImpl listener1 = new ListenerImpl(enhancedStore, namesTranslator);
    ListenerImpl listener2 = new ListenerImpl(enhancedStore, namesTranslator);

    AbstractOid cityOID = oidMap.get("city");
    AbstractOid forestOID = oidMap.get("forest");

    assertEquals(0, listener1.getEvents().size());
    assertEquals(0, listener2.getEvents().size());

    enhancedStore.registerListener(pc.toPathName("/root/city"), listener1);
    enhancedStore.registerListener(pc.toPathName("/root/city"), listener2);
    enhancedStore.registerListener(pc.toPathName("/root/forest"), listener1);
    enhancedStore.registerListener(pc.toPathName("/root/forest"), listener2);

    enhancedStore.addSubobject(t, cityOID, generateRandomAtomic());
    assertEquals(2, listener1.getEvents().size());
    assertEquals(2, listener2.getEvents().size());

    enhancedStore.unregisterListeners(pc.toPathName("/root/city"));

    enhancedStore.addSubobject(t, cityOID, generateRandomAtomic());
    assertEquals(2, listener1.getEvents().size());
    assertEquals(2, listener2.getEvents().size());

    enhancedStore.addSubobject(t, forestOID, generateRandomAtomic());
    assertEquals(4, listener1.getEvents().size());
    assertEquals(4, listener2.getEvents().size());

    enhancedStore.unregisterAllListeners();

    enhancedStore.addSubobject(t, cityOID, generateRandomAtomic());
    enhancedStore.addSubobject(t, forestOID, generateRandomAtomic());

    assertEquals(4, listener1.getEvents().size());
    assertEquals(4, listener2.getEvents().size());

    t.rollback();
  }

  @Test
  @DirtiesContext
  public void testUnregisterParticularListener() {
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    ListenerImpl listener1 = new ListenerImpl(enhancedStore, namesTranslator);
    ListenerImpl listener2 = new ListenerImpl(enhancedStore, namesTranslator);

    AbstractOid cityOID = oidMap.get("city");

    assertEquals(0, listener1.getEvents().size());
    assertEquals(0, listener2.getEvents().size());

    enhancedStore.registerListener(pc.toPathName("/root/city"), listener1);
    enhancedStore.registerListener(pc.toPathName("/root/city"), listener2);
    enhancedStore.registerListener(pc.toPathName("/root/forest"), listener1);
    enhancedStore.registerListener(pc.toPathName("/root/forest"), listener2);

    enhancedStore.addSubobject(t, cityOID, generateRandomAtomic());
    assertEquals(2, listener1.getEvents().size());
    assertEquals(2, listener2.getEvents().size());

    enhancedStore.unregisterListener(listener1);

    enhancedStore.addSubobject(t, cityOID, generateRandomAtomic());
    assertEquals(2, listener1.getEvents().size());
    assertEquals(4, listener2.getEvents().size());
    
    t.rollback();
  }

  /**
   * Tests behavior of READ_UNCOMMITED transaction behavior
   * when moving object
   *
   * @throws Exception
   */
  @Test(timeout=10000)
  @DirtiesContext
  public void testReadUncommitedAfterMoveObject() throws Exception {
    Transaction t1 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

    // move kowalski to forest
    List<Integer> path = pc.toPathName("/root/city/inhabitants");
    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    enhancedStore.registerListener(path, listener);
    AbstractOid kowalskiOID = oidMap.get("kowalski");
    AbstractOid newParentOID = oidMap.get("forest_inhabitants");
    enhancedStore.moveObject(t1, kowalskiOID, newParentOID);
    
    // check where is kowalski from t2 (should see effects of t1)
    assertEquals(newParentOID, enhancedStore.getParentOID(t2, kowalskiOID));

    t2.commit();
    t1.commit();
  }

  /**
   * Tests behavior of READ_COMMITED transaction behavior
   * when moving object
   *
   * @throws Exception
   */
  @Test(timeout=10000)
  @DirtiesContext
  public void testReadCommitedAfterMoveObject() throws Exception {
    Transaction t1 = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    Transaction t2 = transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);

    // move kowalski to forest
    List<Integer> path = pc.toPathName("/root/city/inhabitants");
    ListenerImpl listener = new ListenerImpl(enhancedStore, namesTranslator);
    enhancedStore.registerListener(path, listener);
    AbstractOid kowalskiOID = oidMap.get("kowalski");
    AbstractOid newParentOID = oidMap.get("forest_inhabitants");
    enhancedStore.moveObject(t1, kowalskiOID, newParentOID);

    t1.commit();
    
    // check where is kowalski from t2 (should see effects of t1)
    assertEquals(newParentOID, enhancedStore.getParentOID(t2, kowalskiOID));

    t2.commit();
  }
}
