/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;

import com.google.common.collect.ImmutableList;

import pl.edu.mimuw.jloxim.lock_mgrs.api.LockTypeEnum;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.PathNameProvidingStoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.PathNamesModificationListener;
import pl.edu.mimuw.jloxim.stores.as0.PathNamesObservingStoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0WithLogicalLocksSupport;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 * 
 * @author mlenart
 * @version $Id: PathNamesObservingAndProvidingStoreAS0Impl.java 2524 2011-10-13 21:37:55Z ptab $
 */
public class PathNamesObservingAndProvidingStoreAS0Impl
    implements PathNamesObservingStoreAS0, PathNameProvidingStoreAS0 {

  private final static Logger logger = Logger.getLogger(PathNamesObservingAndProvidingStoreAS0Impl.class);
  /**
   * backing store
   */
  private StoreAS0WithLogicalLocksSupport backing_store;
  /**
   * map of registered listeners
   */
  private Map<List<Integer>, Set<PathNamesModificationListener>> listenerMap
      = new HashMap<List<Integer>, Set<PathNamesModificationListener>>();
  /**
   * protects listener map from r/w conflicts
   */
  protected final ReentrantReadWriteLock listenerLock = new ReentrantReadWriteLock(true);

  public void setBackingStore(StoreAS0WithLogicalLocksSupport store) {
    this.backing_store = store;
  }

  public synchronized void registerListener(List<Integer> path, PathNamesModificationListener listener) {
    listenerLock.writeLock().lock();
    try {

      Set<PathNamesModificationListener> listeners = listenerMap.get(path);
      if (listeners == null)
        listeners = new LinkedHashSet<PathNamesModificationListener>();
      listeners.add(listener);
      listenerMap.put(path, listeners);
    }
    finally {
      listenerLock.writeLock().unlock();
    }
  }

  public synchronized void unregisterListener(PathNamesModificationListener listener) {
    listenerLock.writeLock().lock();
    try {

      for (Set<PathNamesModificationListener> listeners : listenerMap.values())
        listeners.remove(listener);
    }
    finally {
      listenerLock.writeLock().unlock();
    }
  }

  public synchronized void unregisterListeners(List<Integer> path) {
    listenerLock.writeLock().lock();
    try {
      listenerMap.get(path).clear();
    }
    finally {
      listenerLock.writeLock().unlock();
    }
  }

  public synchronized void unregisterAllListeners() {
    listenerLock.writeLock().lock();
    try {
      listenerMap.clear();
    }
    finally {
      listenerLock.writeLock().unlock();
    }
  }

  public String getStoreId() {
    return backing_store.getStoreId();
  }

  public AbstractOid getSuperRootOid() {
    listenerLock.readLock().lock();
    try {
      return backing_store.getSuperRootOid();
    } finally {
      listenerLock.readLock().unlock();
    }
  }

  @Override
  public AbstractOid getConfigRootOid() {
    listenerLock.readLock().lock();
    try {
      return backing_store.getConfigRootOid();
    } finally {
      listenerLock.readLock().unlock();
    }
  }

  public AbstractOid getParentOID(Transaction t, AbstractOid oid) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getParentOID(t, oid);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap(Transaction t, AbstractOid OID) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getSubobjectOIDsMap(t, OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public ClosableIterator<AbstractOid> getSubobjectOIDs(Transaction t, AbstractOid OID) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getSubobjectOIDs(t, OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public ClosableIterator<AbstractOid> getSubobjectOIDsByNameOID(Transaction t, AbstractOid OID, int nameID) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getSubobjectOIDsByNameOID(t, OID, nameID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getRootsMap(Transaction t) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getRootsMap(t);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public ClosableIterator<AbstractOid> getRoots(Transaction t) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getRoots(t);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public ClosableIterator<AbstractOid> getRootsByName(Transaction t, int name_id) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getRootsByName(t, name_id);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public AS0ObjectRO getObjectByOID(Transaction t, AbstractOid OID) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getObjectByOID(t, OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void setAtomicObjectValue(Transaction t, AbstractOid OID, AtomicValue value) throws StoreException {
    logger.debug("will set atomic: " + OID.toReadableString());
    listenerLock.readLock().lock();
    try {
      getLogicalLock(t, OID, LockTypeEnum.PROTECTED_WRITE);
      lockInterestingDescendantsAndSelf(t, OID, LockTypeEnum.PROTECTED_WRITE);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.beforeAtomicValSet(t, getPathNameForObject(t, OID), OID, value);

      backing_store.setAtomicObjectValue(t, OID, value);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.afterAtomicValSet(t, getPathNameForObject(t, OID), OID, value);
    }
    finally {
      listenerLock.readLock().unlock();
    }
    logger.debug("done set atomic: " + OID.toReadableString());
  }

  public void setNewPointerObjectDestination(Transaction t, AbstractOid OID, AbstractOid destOID) throws StoreException {
    logger.debug("will set pointer: " + OID.toReadableString());
    listenerLock.readLock().lock();

    try {
      getLogicalLock(t, OID, LockTypeEnum.PROTECTED_WRITE);
      lockInterestingDescendantsAndSelf(t, OID, LockTypeEnum.PROTECTED_WRITE);

//      fireBeforeRemoveOnDescendants(t, OID);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.beforePointerDestSet(t, getPathNameForObject(t, OID), OID, destOID);

      backing_store.setNewPointerObjectDestination(t, OID, destOID);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.afterPointerDestSet(t, getPathNameForObject(t, OID), OID, destOID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
    logger.debug("done set pointer: " + OID.toReadableString());
  }

  public void setNewComplexObjectValue(Transaction t, AbstractOid OID, Collection<AS0ObjectEditable> subobjects) throws StoreException {
    logger.debug("will set complex: " + OID.toReadableString());
    listenerLock.readLock().lock();

    try {
      getLogicalLock(t, OID, LockTypeEnum.PROTECTED_WRITE);
      lockInterestingDescendantsAndSelf(t, OID, LockTypeEnum.PROTECTED_WRITE);

//      fireBeforeRemoveOnDescendants(t, OID);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.beforeSetComplexObjectValue(t, getPathNameForObject(t, OID), OID, subobjects);

      backing_store.setNewComplexObjectValue(t, OID, subobjects);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.afterSetComplexObjectValue(t, getPathNameForObject(t, OID), OID, subobjects);
    }
    finally {
      listenerLock.readLock().unlock();
    }
    logger.debug("done set complex: " + OID.toReadableString());
  }

  public AbstractOid addSubobject(Transaction t, AbstractOid parent_OID, AS0ObjectEditable object) throws StoreException {
    logger.debug("will add subobject: " + parent_OID.toReadableString());
    if (logger.isDebugEnabled()) {
      logger.debug("PARENT path: "+getPathNameForObject(t, parent_OID));
    }
    listenerLock.readLock().lock();

    try {
      getLogicalLock(t, parent_OID, LockTypeEnum.PROTECTED_READ);

      for (PathNamesModificationListener listener : getListenersFor(t, parent_OID))
        listener.beforeAddSubobject(t, getPathNameForObject(t, parent_OID), parent_OID, object);

      AbstractOid oid=backing_store.addSubobject(t, parent_OID, object);

      for (PathNamesModificationListener listener : getListenersFor(t, parent_OID))
        listener.afterAddSubobject(t, getPathNameForObject(t, parent_OID), parent_OID, object);

      return oid;
    }
    finally {
      listenerLock.readLock().unlock();
      if (logger.isDebugEnabled()){
          logger.debug("done add subobject to: " + parent_OID.toReadableString());
      }
    }
  }

  public void removeObject(Transaction t, AbstractOid OID) throws StoreException {
    logger.debug("will remove: " + OID.toReadableString());

    listenerLock.readLock().lock();
    try {
      getLogicalLock(t, OID, LockTypeEnum.PROTECTED_WRITE);
      lockInterestingDescendantsAndSelf(t, OID, LockTypeEnum.PROTECTED_WRITE);

      for (PathNamesModificationListener listener : getListenersFor(t, OID))
        listener.beforeRemoveObject(t, getPathNameForObject(t, OID), OID);

      backing_store.removeObject(t, OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }

    logger.debug("done remove: " + OID.toReadableString());
  }

  public void removeObjects(Transaction t, AbstractOid[] OIDs) throws StoreException {
    for (AbstractOid oid : OIDs)
      removeObject(t, oid);
  }

  public void moveObject(Transaction t, AbstractOid OID, AbstractOid new_parent_oid) throws StoreException {
    listenerLock.readLock().lock();
    logger.debug("will move: " + OID.toReadableString());
    try {
      AbstractOid[] oidsToLockW = {OID, new_parent_oid};
      getLogicalLocks(t, oidsToLockW, LockTypeEnum.PROTECTED_WRITE);
      lockInterestingDescendantsAndSelf(t, OID, LockTypeEnum.PROTECTED_READ);

      // TODO [mlenart] czy na pewno trzeba przegladac wszystkie sciezki??
      List<Integer> oldPath = getPathNameForObject(t, OID);
      List<Integer> newParentPath = getPathNameForObject(t, new_parent_oid);

      Set<PathNamesModificationListener> listenersOldPath = getListenersFor(t, OID);
      Set<PathNamesModificationListener> listenersNewPath = getListenersFor(t, new_parent_oid);

      Set<PathNamesModificationListener> listenersToNotify = new LinkedHashSet<PathNamesModificationListener>();
      listenersToNotify.addAll(listenersOldPath);
      listenersToNotify.addAll(listenersNewPath);

      for (PathNamesModificationListener listener : listenersToNotify)
        listener.beforeMoveObject(t, oldPath, OID, newParentPath, new_parent_oid);

      backing_store.moveObject(t, OID, new_parent_oid);

      for (PathNamesModificationListener listener : listenersToNotify)
        listener.afterMoveObject(t, oldPath, OID, newParentPath, new_parent_oid);
    }
    finally {
      listenerLock.readLock().unlock();
    }
    logger.debug("done move: " + OID.toReadableString());
  }

  public ClosableIterator<AbstractOid> getReferrers(Transaction t, AbstractOid OID) throws StoreException {
    listenerLock.readLock().lock();
    try {
      return backing_store.getReferrers(t, OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void prefetchObject(AbstractOid OID) {
    listenerLock.readLock().lock();
    try {
      backing_store.prefetchObject(OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void prefetchObjects(AbstractOid[] OIDs) {
    listenerLock.readLock().lock();
    try {
      backing_store.prefetchObjects(OIDs);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void prefetchDeepObject(AbstractOid OID) {
    listenerLock.readLock().lock();
    try {
      backing_store.prefetchDeepObject(OID);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void prefetchDeepObjects(AbstractOid[] OIDs) {
    listenerLock.readLock().lock();
    try {
      backing_store.prefetchDeepObjects(OIDs);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void prefetchSubobjectsByParentIDandName(AbstractOid parentId, int nameId) {
    listenerLock.readLock().lock();
    try {
      backing_store.prefetchSubobjectsByParentIDandName(parentId, nameId);
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  // TODO [mlenart] wydajniejsze (jesli chodzi o operacje dyskowe) wyszukiwanie odpowiednich listenerow
  private Set<PathNamesModificationListener> getListenersFor(Transaction t, AbstractOid oid)
      throws StoreException {
    Set<PathNamesModificationListener> res =
        listenerMap.get(getPathNameForObject(t, oid));
    if (res == null)
      res = new HashSet<PathNamesModificationListener>();
    return res;
  }

  public List<Integer> getPathNameForObject(Transaction t, AbstractOid oid)
      throws StoreException {
    listenerLock.readLock().lock();
    final AbstractOid superRoot = getSuperRootOid();
    try {
      getLogicalLock(t, oid, LockTypeEnum.PROTECTED_READ);

      LinkedList<Integer> res = new LinkedList<Integer>();
      AbstractOid currOid = oid;
      if (oid.equals(getConfigRootOid())) {
        return ImmutableList.of();
      }
      while (!superRoot.equals(currOid)) {
        AS0ObjectRO object = backing_store.getObjectByOID(t, currOid);
        res.addFirst(object.getNameId());
        currOid = object.getParentOID();
      }
      return res;
    }
    finally {
      listenerLock.readLock().unlock();
    }
  }

  public void getLogicalLock(Transaction t, AbstractOid OID, LockTypeEnum type)
      throws StoreException {
    backing_store.getLogicalLock(t, OID, type);
  }

  public void getLogicalLocks(Transaction t, AbstractOid[] OIDs, LockTypeEnum type) throws StoreException {
    backing_store.getLogicalLocks(t, OIDs, type);
  }

  private void lockInterestingDescendantsAndSelf(
      Transaction t,
      AbstractOid OID,
      LockTypeEnum type)
      throws InterruptedStoreOperationException {

    getLogicalLock(t, OID, type);

    ClosableIterator<AbstractOid> it = getSubobjectOIDs(t, OID);
    try {
      while (it.hasNext()) {
        AbstractOid currOID = it.next();
        lockInterestingDescendantsAndSelf(t, currOID, type);
      }
    }
    finally {
      it.close();
    }
  }
}
