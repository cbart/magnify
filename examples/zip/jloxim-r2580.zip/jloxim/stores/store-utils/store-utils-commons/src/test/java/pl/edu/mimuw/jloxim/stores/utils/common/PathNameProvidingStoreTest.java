/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;
import org.springframework.test.annotation.DirtiesContext;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

/**
 * Tests of PathNameProvidingStore
 *
 * //TODO [mlenart] co robić z READ_UNCOMMITED??
 * 
 * @author mlenart
 * @version $Id: PathNameProvidingStoreTest.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class PathNameProvidingStoreTest extends AbstractStoreUtilsCommonsTest {

  protected final static int CONCURRENT_THREADS_NUM = 16;

  /**
   * Tests if store.getPathName() really returns correct path name
   * on single thread
   * @throws Exception
   */
  @Test(timeout=10000)
  @DirtiesContext
  public void testBasicGetPathName() throws Exception {
    logger.info("Starting testBasicGetPathName");
    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);

    assertEquals(pc.toString(enhancedStore.getPathNameForObject(t, enhancedStore.getSuperRootOid())),
        "/");

    AbstractOid oid = oidMap.get("root");
    assertEquals("/root",
        pc.toString(enhancedStore.getPathNameForObject(t, oid)));

    oid = oidMap.get("kowalski");
    assertEquals("/root/city/inhabitants/person",
        pc.toString(enhancedStore.getPathNameForObject(t, oid)));

    oid = oidMap.get("kowalski_name");
    assertEquals("/root/city/inhabitants/person/name",
        pc.toString(enhancedStore.getPathNameForObject(t, oid)));

    t.commit();
    logger.info("Done testBasicGetPathName");
  }

  private void doTestGetPathName(final TransactionIsolationLevel isolationLevel)
      throws Exception {
    logger.info("Starting doTestGetPathName");

    // init write thread
    RememberExceptionThread writeThread = new RememberExceptionThread("WRITE THREAD") {

      @Override
      public void runWithException() throws Exception {
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.SERIALIZABLE);
        logger.debug("transactionId="+t.getTransactionId());
        try {
          AbstractOid kowalskiOid = oidMap.get("kowalski");
          AbstractOid nowhereOid = oidMap.get("nowhere");
          AbstractOid cityInhabitantsOid = oidMap.get("city_inhabitants");
          AbstractOid forestInhabitantsOid = oidMap.get("forest_inhabitants");

          enhancedStore.moveObject(t, kowalskiOid, forestInhabitantsOid);
          enhancedStore.moveObject(t, cityInhabitantsOid, nowhereOid);
        }
        finally {
          t.commit();
          logger.debug("write thread done");
        }
      }
    };

    // init read threads
    List<RememberExceptionThread> readThreads = new LinkedList<RememberExceptionThread>();
    for (int i = 0; i < CONCURRENT_THREADS_NUM; i++)
      readThreads.add(new RememberExceptionThread("READ THREAD-"+i) {

        @Override
        public void runWithException() throws Exception {
          Transaction t = transactionManager.newTransaction(isolationLevel);
          try {
            AbstractOid kowalskiOid = oidMap.get("kowalski");
            List<Integer> path = enhancedStore.getPathNameForObject(t, kowalskiOid);
            String pathString = pc.toString(path);
            String[] sensiblePathStrings = {
              "/root/city/inhabitants/person",
              "/root/forest/inhabitants/person"
            };
            assertTrue(Arrays.asList(sensiblePathStrings).contains(pathString));
          }
          finally {
            t.rollback();
            logger.info("read thread done");
          }
        }
      });

    // start threads
    writeThread.start();
    for (Thread t : readThreads)
      t.start();

    // join threads
    for (Thread t : readThreads)
      t.join();
    writeThread.join();

    // check for errors
    boolean failed = false;

    for (RememberExceptionThread t : readThreads)
      if (!t.isSuccessful()) {
        failed = true;
        logger.error("Read thread failed!", t.getThrownException());
      }
    if (!writeThread.isSuccessful()) {
      failed = true;
      logger.error("Write thread failed!", writeThread.getThrownException());
    }

    assertFalse(failed);
  }

  /**
   * Tests if store.getPathName() is atomic
   * when transaction isolation level == READ_UNCOMMITED
   * @throws Exception
   */
  @Test(timeout=10000)
  @DirtiesContext
  public void testConcurrentGetPathName_READ_UNCOMMITED() throws Exception {
    doTestGetPathName(TransactionIsolationLevel.READ_UNCOMMITED);
  }

  /**
   * Tests if store.getPathName() is atomic
   * when transaction isolation level != READ_UNCOMMITED
   * @throws Exception
   */
  @Test(timeout=10000)
  @DirtiesContext
  public void testConcurrentGetPathName() throws Exception {
    doTestGetPathName(TransactionIsolationLevel.READ_COMMITED);
    doTestGetPathName(TransactionIsolationLevel.REPETABLE_READS);
    doTestGetPathName(TransactionIsolationLevel.SERIALIZABLE);
  }
}
