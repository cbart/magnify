/**
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 * 
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * 
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 * Builder of AS0 objects.
 *
 * @author mlenart
 * @version $Id: AS0ObjectsBuilder.java 2066 2010-09-17 16:24:55Z ptab $
 */
public class AS0ObjectsBuilder {
  private final static AtomicValueFactory avf = new AtomicValueFactoryImpl();
  private final static AS0ObjectsFactory aof = new AS0ObjectsFactoryImpl();
  private final Map<String, AS0ObjectRO> labelsMap =
      new HashMap<String, AS0ObjectRO>();
  private final NamesTranslator nt;

  public AS0ObjectsBuilder(NamesTranslator nt) {
    this.nt = nt;
  }

  public AS0AtomicObjectEditable atomic(String name, Object value) {
    return aof.newAtomicObject(nt.getOrRegisterName(name), avf.newAtomicValue(value));
  }
  
  public AS0AtomicObjectEditable atomic(String name, String oidLabel, Object value) {
    AS0AtomicObjectEditable res = atomic(name, value);
    labelsMap.put(oidLabel, res);
    return res;
  }

  public AS0ComplexObjectEditable complex(String name, AS0ObjectEditable... subobjects) {
    return aof.newComplexObject(nt.getOrRegisterName(name), Arrays.asList(subobjects));
  }

  public AS0ComplexObjectEditable complex(String name, String oidLabel, AS0ObjectEditable... subobjects) {
    AS0ComplexObjectEditable res = complex(name, subobjects);
    labelsMap.put(oidLabel, res);
    return res;
  }

  public AbstractOid getOIDByLabel(String oidLabel) {
    return labelsMap.get(oidLabel).getOID();
  }
}
