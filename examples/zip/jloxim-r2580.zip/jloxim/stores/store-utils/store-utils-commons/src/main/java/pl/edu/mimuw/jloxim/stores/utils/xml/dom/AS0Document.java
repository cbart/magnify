/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * This class represents store or its fragment as XML document.
 * Since all nodes of document have reference to this object in
 * <code>ownerDocument</code> filed, it holds all the stuff necessary
 * for making operations on underling store (transaction, names translator etc.)
 *
 * @author Pawel Mantur
 */
public class AS0Document extends AS0Node implements Document {

    private final Logger logger = Logger.getLogger(AS0Document.class);
    private StoreAS0 store;
    private NamesTranslator nt;
    private AS0ObjectsFactory objectsFactory;
    private AtomicValueFactory atomicValFacory;
//    private TransactionManager transactionManager;
    private Transaction transaction;

    public StoreAS0 getStore() {
        return store;
    }

    public NamesTranslator getNamesTranslator() {
        return nt;
    }

    public void setNamesTranslator(NamesTranslator nt) {
        this.nt = nt;
    }

    public void setObjectsFactory(AS0ObjectsFactory factory) {
        this.objectsFactory = factory;
    }

    public AS0ObjectsFactory getObjectsFactory() {
        return objectsFactory;
    }

    public AtomicValueFactory getAtomicValueFactory() {
        return atomicValFacory;
    }

    public void setAtomicValueFactory(AtomicValueFactory factory) {
        this.atomicValFacory = factory;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction t) {
        this.transaction = t;
    }
    /**
     * Root element of the document.
     * If document was create from store, it is the superroot.
     * If document was created from object, it is that object.
     */
    private Element documentElement;
    public boolean readOnly;
    private DocumentType doctype;
    private DOMImplementation implementation;

    /**
     * Creates XML document wrapping StoreAS0.
     * @param store
     */
    public AS0Document(StoreAS0 store, boolean readOnly, DOMImplementation implementation, Transaction transaction) {
        this.documentElement = new AS0Element(LongOid.ZERO, this);
        this.store = store;
        this.ownerDocument = this;
        this.readOnly = readOnly;
        this.implementation = implementation;
        this.doctype = null;
        this.transaction = transaction;
    }

    /**
     * Creates XML document with its root node set to given object
     * @param object Object being used as a document's root node
     * @param store underlying store
     */
    public AS0Document(AS0ObjectRO object, StoreAS0 store, boolean readOnly, DOMImplementation implementation, Transaction transaction) {
        this.documentElement = new AS0Element(object.getOID(), this);
        this.store = store;
        this.ownerDocument = this;
        this.readOnly = readOnly;
        this.implementation = implementation;
        this.doctype = null;
        this.transaction = transaction;
    }

    /**
     * Creates virtual document (no underlying store)
     * @param name
     * @param readOnly
     * @param implementation
     */
    public AS0Document(Element docElement, boolean readOnly, DOMImplementation implementation, Transaction transaction) {
        this.documentElement = docElement;
        adoptNode(docElement);
        this.store = null;
        this.ownerDocument = this;
        this.readOnly = readOnly;
        this.implementation = implementation;
        this.doctype = null;
        this.transaction = transaction;
    }

    public DocumentType getDoctype() {
        return doctype;
    }

    public DOMImplementation getImplementation() {
        return implementation;
    }

    public Element getDocumentElement() {
        return documentElement;
    }

    public Element createElement(String tagName) throws DOMException {
        if (tagName == null)
            throw new DOMException(DOMException.INVALID_CHARACTER_ERR, "tag name cannor be null");
        return new AS0Element(tagName, this);
    }

    public DocumentFragment createDocumentFragment() {
        return new AS0DocumentFragment();
    }

    public Text createTextNode(String data) {
        return new AS0Text(data);
    }

    public Comment createComment(String data) {
        return new AS0Comment(data);
    }

    public CDATASection createCDATASection(String data) throws DOMException {
        //return new AS0CDATASection();
        return null;
    }

    public ProcessingInstruction createProcessingInstruction(String target, String data) throws DOMException {
        //return new AS0ProcessingInstruction();
        return null;
    }

    public Attr createAttribute(String name) throws DOMException {
        return new AS0Attr(name, "", this);
    }

    public EntityReference createEntityReference(String name) throws DOMException {
        return null;
    }

    public NodeList getElementsByTagName(String tagname) {
        AS0NodeList list = new AS0NodeList();

        logger.debug("getElementsByTagName");

        try {
            int nameID = getDocNamesTranslator().getNameIdByName(tagname);
            DOMUtils.getDescendantsByName(getDocStore(), this.transaction, new LongOid(0L), nameID, this, list);
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }

        return list;
    }

    public Node importNode(Node importedNode, boolean deep) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Element createElementNS(String namespaceURI, String qualifiedName) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Attr createAttributeNS(String namespaceURI, String qualifiedName) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public NodeList getElementsByTagNameNS(String namespaceURI, String localName) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Element getElementById(String elementId) {

        try {
            AS0ObjectRO obj = getStore().getObjectByOID(this.transaction, DOMUtils.castStringToJLoximOID(elementId));
            if (obj != null) {
                return new AS0Element(obj.getOID(), this);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public String getInputEncoding() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getXmlEncoding() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean getXmlStandalone() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setXmlStandalone(boolean xmlStandalone) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getXmlVersion() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setXmlVersion(String xmlVersion) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean getStrictErrorChecking() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setStrictErrorChecking(boolean strictErrorChecking) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getDocumentURI() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setDocumentURI(String documentURI) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Node adoptNode(Node source) throws DOMException {
        if (source instanceof Document || source instanceof DocumentFragment)
            throw new DOMException(DOMException.NOT_SUPPORTED_ERR, ErrorMsg.NOT_SUPPORTED_ERR);

        if (!(source instanceof AS0Node))
            return null; // node comes from different implementation

        AS0Node node = (AS0Node) source;
        node.ownerDocument = this;
        adoptNodesTree(node);

        return source;
    }

    private void adoptNodesTree(AS0Node parent) {

        NodeList children = parent.getChildNodes();
        if (children != null) {
            for (int i = 0; i < children.getLength(); i++) {
                AS0Node c = (AS0Node) children.item(i);
                c.ownerDocument = parent.ownerDocument;
                adoptNodesTree(c);
            }
        }

        NamedNodeMap attr = parent.getAttributes();
        if (attr != null) {
            for (int i = 0; i < attr.getLength(); i++) {
                AS0Node c = (AS0Node) attr.item(i);
                c.ownerDocument = parent.ownerDocument;
                adoptNodesTree(c);
            }
        }
    }

    public DOMConfiguration getDomConfig() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void normalizeDocument() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Node renameNode(Node n, String namespaceURI, String qualifiedName) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean hasChildNodes() {
        return documentElement.hasChildNodes();
    }

    @Override
    public String getNodeName() {
        return "#document";
    }

    public short getNodeType() {
        return Node.DOCUMENT_NODE;
    }

    @Override
    public Node getFirstChild() {
        return this.documentElement;
    }

    @Override
    public Node getLastChild() {
        return this.documentElement;
    }

    @Override
    public NodeList getChildNodes() {
        AS0NodeList children = new AS0NodeList();
        children.AddNode(this.documentElement);
        return children;
    }

    @Override
    /**
     * If deep == false we create a document with the same underlying store
     * as original one
     * If deep == true we create deep virtual with no underlying store
     */
    public Node cloneNode(boolean deep) {
        if (!deep)
            return new AS0Document(store, readOnly, implementation, transaction);
        else {
            Element docElement = (Element) this.documentElement.cloneNode(true);
            return new AS0Document(docElement, this.readOnly, this.implementation, transaction);
        }
    }
}
