/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;

/**
 *
 * @author Pawel Mantur
 */
public class AS0DOMImplementation implements DOMImplementation {

    public DocumentType createDocumentType(String qualifiedName, String publicId, String systemId) throws DOMException {
        return null;
    }

    public Document createDocument(String namespaceURI, String qualifiedName, DocumentType doctype) throws DOMException {
        // TODO: maybe we should create a new (empty) store here with a given name?
        return null;
    }

    /**
     * Additional method introduced for JLoXiM - creates a document that wraps provided store.
     * Document will be in read only mode. Modifications of store through DOM won't be allowed.
     * @param store
     * @param nt - NamesTranslator
     * @param tm - TransactionManager
     * @return
     */
    public Document createAS0DocumentRO(StoreAS0 store, NamesTranslator nt, Transaction t) {
        AS0Document doc = new AS0Document(store, true, this, t);
        doc.setNamesTranslator(nt);
        return doc;
    }

    /**
     * Additional method introduced for JLoXiM - creates a document that wraps provided store.
     * Document will be in read-write mode. Modifications of store through DOM will be allowed.
     * @param store
     * @param nt - NamesTranslator
     * @param tm - TransactionManager
     * @param avf - AtomicValueFactory
     * @param of - AS0ObjectsFactory
     * @return
     */
    public Document createAS0DocumentEditable(StoreAS0 store, NamesTranslator nt, Transaction t, AtomicValueFactory avf, AS0ObjectsFactory of) {
        AS0Document doc = new AS0Document(store, false, this, t);
        doc.setNamesTranslator(nt);
        doc.setAtomicValueFactory(avf);
        doc.setObjectsFactory(of);        
        return doc;
    }

    // JLoXiM DOM imlementation supports only core features
    public boolean hasFeature(String feature, String version) {
        if (feature.toLowerCase().compareTo("core") == 0) {
            if (version != null && version.length()>0) {
                if (version.compareTo("1.0") == 0 || version.compareTo("2.0") == 0)
                    return true;
                else
                    return false;
            } else
                return true;
        } else
            return false;
    }

    // we do not implement any features (just core)
    public Object getFeature(String feature, String version) {
        if (feature.toLowerCase().compareTo("core") == 0) {
            if (version != null && version.length()>0) {
                if (version.compareTo("1.0") == 0 || version.compareTo("2.0") == 0)
                    return this;
                else
                    return null;
            } else
                return this;
        } else
            return null;
    }
}
