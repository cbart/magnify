/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.apache.log4j.Logger;
import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.UserDataHandler;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;

/**
 *
 * @author Pawel Mantur
 */
public abstract class AS0Node implements Node {

    protected AS0Document ownerDocument;
    protected Node parent;
    protected String namespaceUri;

    protected NamesTranslator getDocNamesTranslator() {
        return ownerDocument.getNamesTranslator();
    }

    protected StoreAS0 getDocStore() {
        return ownerDocument.getStore();
    }

    protected AS0ObjectsFactory getDocAS0ObjectsFactory() {
        return ownerDocument.getObjectsFactory();
    }

    protected AtomicValueFactory getDocAtomicValueFactory() {
        return ownerDocument.getAtomicValueFactory();
    }

    @SuppressWarnings("unused")
  private Logger logger = Logger.getLogger(AS0Node.class);

    // ========================================================================
    protected boolean isReadOnly() {
        return ownerDocument.readOnly;
    }

    public String getNodeName() {
        return "";
    }

    public String getNodeValue() throws DOMException {
        return null;
    }

    public void setNodeValue(String nodeValue) throws DOMException {
        // no effect, overriden if necessary
    }

    // overriden if necessary
    public Node getParentNode() {
        return null;
    }

    // overriden in Element and Document
    public NodeList getChildNodes() {
        return new AS0NodeList();
    }

    // overriden in Element and Document
    public Node getFirstChild() {
        return null;
    }

    // overriden in Element and Document
    public Node getLastChild() {
        return null;
    }

    // overriden in Element and Text
    public Node getPreviousSibling() {
        return null;
    }

    // overriden in Element and Text
    public Node getNextSibling() {
        return null;
    }

    // overriden in Element
    public NamedNodeMap getAttributes() {
        return null;
    }

    public org.w3c.dom.Document getOwnerDocument() {
        return this.ownerDocument;
    }

    public Node insertBefore(Node newChild, Node refChild) throws DOMException {

        /**
         *  Store does not guarantee preserving order of child objects,
         *  so this method acts just like <code>appendChild</code>
         */
        return appendChild(newChild);
    }

    public Node replaceChild(Node newChild, Node oldChild) throws DOMException {

        Node removed = removeChild(oldChild);
        if (removed == null)
            throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);

        try {
            appendChild(newChild);
        } catch (DOMException e) {
            // rollback changes
            appendChild(removed);
            throw e;
        }

        return removed;
    }

    // overriden by Element, other nodes (Text, Attr) doesn't have any children
    public Node removeChild(Node oldChild) throws DOMException {
        throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);
    }

    // overriden by Element
    public Node appendChild(Node newChild) throws DOMException {
        throw new DOMException(DOMException.HIERARCHY_REQUEST_ERR, ErrorMsg.HIERARCHY_REQUEST_ERR);
    }

    // overriden by Element
    public boolean hasChildNodes() {
        return false;
    }

    // overriden by subclasses
    public abstract Node cloneNode(boolean deep);

    protected void copyValuesOnClone(AS0Node n) {
        n.ownerDocument = this.ownerDocument;
        n.namespaceUri = this.namespaceUri;
        n.parent = null;
    }

    // level 3
    public void normalize() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isSupported(String feature, String version) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getNamespaceURI() {
        return this.namespaceUri;
    }

    public String getPrefix() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPrefix(String prefix) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // overriden
    public String getLocalName() {
        return null;
    }

    // overriden
    public boolean hasAttributes() {
        return false;
    }

    // level 3
    public String getBaseURI() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public short compareDocumentPosition(Node other) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public String getTextContent() throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public void setTextContent(String textContent) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public boolean isSameNode(Node other) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public String lookupPrefix(String namespaceURI) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public boolean isDefaultNamespace(String namespaceURI) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public String lookupNamespaceURI(String prefix) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public boolean isEqualNode(Node arg) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public Object getFeature(String feature, String version) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public Object setUserData(String key, Object data, UserDataHandler handler) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public Object getUserData(String key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
