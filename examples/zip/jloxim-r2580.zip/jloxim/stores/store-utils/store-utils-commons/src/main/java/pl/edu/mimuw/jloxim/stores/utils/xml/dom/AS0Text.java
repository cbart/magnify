/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 *
 * @author Pawel Mantur
 */
public class AS0Text extends AS0CharacterData implements Text {

    public AS0Text() {
        super.textData = "";
    }

    public AS0Text(String innerText) {
        super.textData = innerText;
    }

    public Text splitText(int offset) throws DOMException {
        throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
    }

    public boolean isElementContentWhitespace() {
        return isEmptyTextData();
    }

    private boolean isEmptyTextData() {
    return (textData==null) || (textData.length()==0);
  }

  public String getWholeText() {
        return textData;
    }

    public Text replaceWholeText(String content) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public short getNodeType() {
        return Node.TEXT_NODE;
    }

    @Override
    public String getNodeValue() throws DOMException {
        return textData;
    }

    @Override
    public void setNodeValue(String nodeValue) throws DOMException {
        throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
    }

    @Override
    public Node getPreviousSibling() {
        Node p = this.getParentNode();
        if (p != null) {
            NodeList siblings = p.getChildNodes();
            for (int i = 0; i < siblings.getLength(); i++)
                if (i > 0 && siblings.item(i) == this)
                    return siblings.item(i - 1);
            return null;
        }
        return null;
    }

    @Override
    public Node getNextSibling() {
        Node p = this.getParentNode();
        if (p != null) {
            NodeList siblings = p.getChildNodes();
            for (int i = 0; i < siblings.getLength(); i++)
                if (i < siblings.getLength() - 1 && siblings.item(i) == this)
                    return siblings.item(i + 1);
            return null;
        }
        return null;
    }

    @Override
    public Node cloneNode(boolean deep) {
        AS0Text res = new AS0Text(getWholeText());
        copyValuesOnClone(res);
        return res;
    }
}
