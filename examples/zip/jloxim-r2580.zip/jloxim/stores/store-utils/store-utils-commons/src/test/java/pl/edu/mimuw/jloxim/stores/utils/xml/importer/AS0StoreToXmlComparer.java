/*
 *  Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 *  and the project's contributors (see changelog).
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under
 *  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 *  either express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.importer;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.utils.common.AS0StoreContentLogger;
import pl.edu.mimuw.jloxim.stores.utils.xml.dom.Consts;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 * Utility class helpful to test XML importer. *
 *
 * @author Pawel Mantur
 */
public class AS0StoreToXmlComparer {

    private Logger logger = Logger.getLogger(AS0StoreContentLogger.class);
    Transaction t;
    StoreAS0 store;
    NamesTranslator nt;

    public NamesTranslator getNamesTranslator() {
        return this.nt;
    }

    public void setNamesTranslator(NamesTranslator namesTranslator) {
        this.nt = namesTranslator;
    }

    public StoreAS0 getStoreAS0() {
        return store;
    }

    public void setStoreAS0(StoreAS0 storeAS0) {
        this.store = storeAS0;
    }

    public Transaction getTransaction() {
        return t;
    }

    public void setTransaction(Transaction transcation) {
        this.t = transcation;
    }

    public AS0StoreToXmlComparer(Transaction t, StoreAS0 store, NamesTranslator nt) {
        this.t = t;
        this.store = store;
        this.nt = nt;
    }

    /**
     * Compares store to Document element with general structure. Document is expected to have
     * documentElement representing superrrot, and it's children are supposed to represent
     * store roots.
     * @param doc
     * @param store
     * @param checkNames
     * @return
     */
    public boolean CompareElementsStructureGeneral(Document doc, StoreAS0 store, boolean checkNames) {
      try {
        ClosableIterator<AbstractOid> iter = null;
        try {
          iter = store.getRoots(t);
          int elementCount = 0;
          while (iter.hasNext()) {
         	elementCount++;
        	iter.next();
          }
          if (elementCount != doc.getChildNodes().getLength()) {
            logger.error(String.format("Store has %1$d roots, whereas documentelement has %2$d children", elementCount, doc.getChildNodes().getLength()));
            return false;
          }
        } finally {
        	if (iter != null) iter.close();
        }
        try {
          iter = store.getRoots(t);
          boolean result;
          int i = 0;
          while (iter.hasNext()) {
            Element elt = (Element) doc.getDocumentElement().getChildNodes().item(i);
              AbstractOid id = iter.next();
            allOIDs.add(id);
            AS0ObjectRO obj = store.getObjectByOID(t, id);
  
            if (obj instanceof AS0ComplexObjectRO)
                result = checkComplexObject(elt, (AS0ComplexObjectRO) obj, checkNames, false);
            else if (obj instanceof AS0AtomicObjectRO)
                result = checkAtomicObject(elt, (AS0AtomicObjectRO) obj, checkNames, false);
            else
                result = checkPointerObject(elt, (AS0PointerObjectRO) obj, checkNames);
  
            if (!result)
                return false;
          }
        } finally {
          if (iter != null) iter.close();
        }
        return checkReferencedOIDsPresence();
      } catch (StoreException e) {
          logger.error("store exception:" + e.getMessage());
          return false;
      }
    }

    /**
     * Compares StoreAS0 with given XML file reporting some of obvious errors.
     * Method uses DOM so it's not recommended to use it with big files.
     * @return <code>true</code> if no errors were found
     */
    public boolean CompareElementsStructure(Document xmlDoc, StoreAS0 store, boolean checkNames) {
        try {
          ClosableIterator<AbstractOid> iter = store.getRoots(t);
          try {
            int elementCount = 0;
            while (iter.hasNext()) {
            	elementCount++;
            	iter.next();
            }

            if (elementCount != 1) {
                logger.error("Store imported from proper xml is expected to have exactly one root");
                return false;
            }
          } finally {
            iter.close();
          }
          try {
            iter = store.getRoots(t);
            boolean result;
            AbstractOid id = iter.next();
            iter.close();
            allOIDs.add(id);
            AS0ObjectRO obj = store.getObjectByOID(t, id);

            if (obj instanceof AS0ComplexObjectRO)
                result = checkComplexObject(xmlDoc.getDocumentElement(), (AS0ComplexObjectRO) obj, checkNames, true);
            else if (obj instanceof AS0AtomicObjectRO)
                result = checkAtomicObject(xmlDoc.getDocumentElement(), (AS0AtomicObjectRO) obj, checkNames, true);
            else
                result = checkPointerObject(xmlDoc.getDocumentElement(), (AS0PointerObjectRO) obj, checkNames);

            if (!result)
                return false;

            return checkReferencedOIDsPresence();
          } finally {
            iter.close(); 
          }
        } catch (StoreException e) {
            logger.error("store exception:" + e.getMessage());
            return false;
        }
    }

    private boolean checkComplexObject(Element elt, AS0ComplexObjectRO obj, boolean checkNames, boolean checkTypeAttr) {

        try {

            if (!checkNames(elt, obj, checkNames))
                return false;

            ClosableIterator<AbstractOid> i = obj.iterator();
            List<AbstractOid> childOIDs = new LinkedList<AbstractOid>();
            NodeList allChildren = elt.getChildNodes();

            // removing children that are not elements because they were not imported by XmlImporter
            List<Element> children = new LinkedList<Element>();
            for (int k = 0; k < allChildren.getLength(); k++)
                if (allChildren.item(k) instanceof Element)
                    children.add((Element) allChildren.item(k));

            while (i.hasNext())
                childOIDs.add(i.next());
            i.close();

            if (childOIDs.size() != children.size()) {
                logger.error(String.format("Children objects count mismatch: expected %1$s found %2$s", children.size(), childOIDs.size()));
                return false;
            }

            // PM: I assume that objects were getting ascending oids when adding to store
            Collections.sort(childOIDs);

            int index = 0;
            boolean result;

            for (AbstractOid id : childOIDs) {

                Element child = children.get(index++);
                AS0ObjectRO childObj = store.getObjectByOID(t, id);
                allOIDs.add(id);

                if (childObj instanceof AS0ComplexObjectRO)
                    result = checkComplexObject(child, (AS0ComplexObjectRO) childObj, checkNames, checkTypeAttr);
                else if (childObj instanceof AS0PointerObjectRO)
                    result = checkPointerObject(child, (AS0PointerObjectRO) childObj, checkNames);
                else
                    result = checkAtomicObject(child, (AS0AtomicObjectRO) childObj, checkNames, checkTypeAttr);

                if (!result)
                    return false;
            }

            return true;

        } catch (StoreException e) {
            logger.error("store exception in complex object validation: " + e.getMessage());
            return false;
        } catch (ModelException e) {
            logger.error("model exception in complex object validation: " + e.getMessage());
            return false;
        }

    }
    List<AbstractOid> referencedOIDs = new LinkedList<AbstractOid>();
    List<AbstractOid> allOIDs = new LinkedList<AbstractOid>();

    private boolean checkPointerObject(Element elt, AS0PointerObjectRO obj, boolean checkNames) {

        if (!checkNames(elt, obj, checkNames))
            return false;

        // TODO probably it would be better to support only attributes from loxim namespace

        if (!elt.hasAttribute(Consts.loximRefAttr) && !elt.hasAttributeNS(Consts.loximNamespace, Consts.loximRefAttr)) {
            logger.error("Found pointer object but corresponding xml element doesn't have ref attribute");
            return false;
        }

        Long destinationID = Long.decode(elt.getAttribute(Consts.loximRefAttr));
        if (destinationID == null)
            destinationID = Long.decode(elt.getAttributeNS(Consts.loximNamespace, Consts.loximRefAttr));

        if (destinationID == null) {
            logger.error("Found pointer object but ref attribute doesn't have proper value in xml");
            return false;
        }

        // at the end we check if all the referenced OIDs are present in the store
        referencedOIDs.add(obj.getDestinationOID());

        return true;
    }

    private boolean checkAtomicObject(Element elt, AS0AtomicObjectRO obj, boolean checkNames, boolean checkTypeAttr) {

        if (!checkNames(elt, obj, checkNames))
            return false;

        if (checkTypeAttr && !elt.hasAttribute("type")) {
            logger.error("Found atomic object but corresponding xml element doesn't have type attribute");
            return false;
        }

        Object value = obj.getValue();

        if (value == null) {
            logger.error("Value of Atomic object is null");
            return false;
        }

        return true;
    }

    private boolean checkNames(Node node, AS0ObjectRO obj, boolean checkNames) {

        if (checkNames)
            try {
                String name = nt.getNameByNameId(obj.getNameId());
                if (node.getNodeName().compareTo(name) != 0) {
                    logger.error(String.format("Names mismatch: expected %1$s found %2$s", node.getNodeName(), name));
                    return false;
                }
            } catch (NameTranslatorException e) {
                logger.error("names translator error: " + e.getMessage());
                return false;
            }

        return true;
    }

    private boolean checkReferencedOIDsPresence() {
        for (AbstractOid refOID : referencedOIDs)
            if (!allOIDs.contains(refOID)) {
                logger.error("Referenced OID not present in store");
                return false;

            }
        return true;
    }
}
