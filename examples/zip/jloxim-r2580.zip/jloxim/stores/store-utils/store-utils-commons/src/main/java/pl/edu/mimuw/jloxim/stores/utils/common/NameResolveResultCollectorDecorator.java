/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import pl.edu.mimuw.jloxim.model.as0.api.ResultCollector;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;

/**
 * This collector translates all binders to 'resolved' format.
 * 
 * <p>{@link #adoptResultset(AS0Resultset)} guaranties that all names in binders are resolved
 * (both ways) in returned as0resultset.</p>
 * 
 * <p>All binders created using the {@link #getFinalAs0ResultsetFactory()} will also 
 * fully resolved</p> 
 * 
 * @author ptab@mimuw.edu.pl
 */
public class NameResolveResultCollectorDecorator implements ResultCollector{
  private final ResultCollector backingResultCollector;
  private final AS0ResultsetNameIdResolveRewriteTransformer transformer;
  private final AS0ResultsetFactory finalResultsetFactory;

  public NameResolveResultCollectorDecorator(ResultCollector backingResultCollector,
      NamesTranslator namesTranslator) {
    this.backingResultCollector = backingResultCollector;
//    this.transformer = new AS0ResultsetNameIdResolveTransformer();
    this.transformer = new AS0ResultsetNameIdResolveRewriteTransformer(backingResultCollector.getFinalAs0ResultsetFactory());
    transformer.setNamesTranslator(namesTranslator);
    finalResultsetFactory = new ResultsetFactoryNameIdResolvingDecorator(
        backingResultCollector.getFinalAs0ResultsetFactory(),
        namesTranslator);
  }
  
  public AS0Resultset adoptResultset(AS0Resultset resultset) {
    return transformer.process(backingResultCollector.adoptResultset(resultset));
  }

  public AS0ResultsetFactory getFinalAs0ResultsetFactory() {
    return finalResultsetFactory;
  }

  public void provideQueryResponse(AS0Resultset result) {
    backingResultCollector.provideQueryResponse(result); 
  }

  public void reportWarning(String message, Integer warningId,
      Object componentReporting) {
    backingResultCollector.reportWarning(message, warningId, componentReporting);
  }

  public void setPercentCompleted(double completion) {
    backingResultCollector.setPercentCompleted(completion); 
  }
  
}
