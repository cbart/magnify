/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.TypeInfo;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.api.exceptions.JLoximException;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

/**
 * 2 types of elements exist:
 * - stored (they have corresponding object in store identified by underlyingObjectOID)
 * - virtual (underlyingObjectOID == null, such elements are created by document.createElement method
 *   and are not added to the document tree; their children and attributes are also not stored)
 * @author Pawel Mantur
 */
public class AS0Element extends AS0Node implements Element {
    private Logger logger = Logger.getLogger(AS0Element.class);

    protected AbstractOid underlyingObjectOID;
    private AS0NamedNodeMap attributes;
    private AS0NodeList children;
    private String tagName;


    public AS0Element(AbstractOid underlayingObjectOID, AS0Document owner) {
        this.underlyingObjectOID = underlayingObjectOID;
        this.ownerDocument = owner;
        this.attributes = new AS0NamedNodeMap(owner);
        this.children = new AS0NodeList();
    }

    public AS0Element(String tagName, AS0Document owner) {
        this.underlyingObjectOID = null;
        this.tagName = tagName;
        this.ownerDocument = owner;
        this.attributes = new AS0NamedNodeMap(owner);
        this.children = new AS0NodeList();
    }

    public String getTagName() {

        if (underlyingObjectOID == null)
            return this.tagName;

        if (isSuperRoot())
            return getDocStore().getStoreId();

        logger.debug("getTagName");

        try {
            AS0ObjectRO object = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
            return getDocNamesTranslator().getNameByNameId(object.getNameId());
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    public String getAttribute(String attrName) {
        Attr res = this.getAttributeNode(attrName);
        if (res == null)
            return "";
        return res.getValue();
    }

    public Attr getAttributeNode(String name) {

        if (name == null)
            return null;

        if (underlyingObjectOID == null) {
            return (Attr) attributes.getNamedItem(name);
        }

        logger.debug("getAttributeNode");

        try {

            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + name);
            ClosableIterator<AbstractOid> iter = null;

            if (isSuperRoot()) {
                iter = getDocStore().getRootsByName(ownerDocument.getTransaction(), nameID);
            } else {
                iter = getDocStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);
            }

            while (iter.hasNext()) {
                AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                if (attr instanceof AS0AtomicObjectRO) {
                    String value = ((AS0AtomicObjectRO) attr).getValue().getValue().toString();
                    iter.close();
                    return new AS0Attr(name, value, this);
                }
            }

            iter.close();
            return null;

        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    private boolean isSuperRoot() {
      return getDocStore().getSuperRootOid().equals(underlyingObjectOID);
    }

    public String getAttributeNS(String namespaceURI, String localName) throws DOMException {

        Attr res = getAttributeNodeNS(namespaceURI, localName);
        if (res == null)
            return "";
        return res.getValue();
    }

    public Attr getAttributeNodeNS(String namespaceURI, String localName) throws DOMException {

        if (namespaceURI == null || namespaceURI.length()==0)
            return this.getAttributeNode(localName);

        if (namespaceURI.compareToIgnoreCase(Consts.loximNamespace) == 0) {

            if (underlyingObjectOID != null) {

                if (DOMUtils.isIdAttribute(localName))
                    return new AS0Attr(localName, underlyingObjectOID.toReadableString(), ownerDocument);

                if (DOMUtils.isRefAttribute(localName) && !isSuperRoot()) {

                    logger.debug("getAttributeNodeNS");

                    try {
                        AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
                        if (obj instanceof AS0PointerObjectRO) {
                            AbstractOid val = ((AS0PointerObjectRO) obj).getDestinationOID();
                            return new AS0Attr(localName, val.toReadableString(), ownerDocument);
                        } else
                            return null;
                    } catch (JLoximException e) {
                        throw new JLoximDOMException(e);
                    }
                }
            } else {

                // there is no loxim:id attribute but there can be loxim:ref attribute
                if (DOMUtils.isRefAttribute(localName))
                    return (Attr) attributes.getNamedItemNS(namespaceURI, localName);
            }
        }

        // we do not support other namespaces
        return null;
    }

    public void setAttribute(String name, String value) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (underlyingObjectOID == null) {
            Node attr = attributes.getNamedItem(name);
            if (attr == null) {
                attr = new AS0Attr(name, value, this);
                attributes.setNamedItem(attr);
            } else {
                attr.setNodeValue(value);
            }
            return;
        }

        logger.debug("setAttribute");

        try {

            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + name);
            ClosableIterator<AbstractOid> iter = ownerDocument.getStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);
            AtomicValue sv = getDocAtomicValueFactory().newAtomicValue(value);

            // try to find and update
            while (iter.hasNext()) {
                AbstractOid id = iter.next();
                AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), id);
                if (attr instanceof AS0AtomicObjectRO) {
                    getDocStore().setAtomicObjectValue(ownerDocument.getTransaction(), id, sv);
                    iter.close();
                    return;
                }
            }
            iter.close();

            // add new
            AS0AtomicObjectEditable newAttr = getDocAS0ObjectsFactory().newAtomicObject(nameID, sv);
            getDocStore().addSubobject(ownerDocument.getTransaction(), underlyingObjectOID, newAttr);

        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    public Attr setAttributeNode(Attr newAttr) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (newAttr.getOwnerDocument() != this.ownerDocument)
            throw new DOMException(DOMException.WRONG_DOCUMENT_ERR, ErrorMsg.WRONG_DOCUMENT_ERR);

        if (newAttr.getOwnerElement() != null && newAttr.getOwnerElement() != this)
            throw new DOMException(DOMException.INUSE_ATTRIBUTE_ERR, ErrorMsg.INUSE_ATTRIBUTE_ERR);

        Attr previous = null;
        AS0Attr na = null;

        if (newAttr instanceof AS0Attr)
            na = (AS0Attr) newAttr;
        else
            throw new DOMException(DOMException.WRONG_DOCUMENT_ERR, ErrorMsg.WRONG_DOCUMENT_ERR);

        if (underlyingObjectOID == null) {
            previous = (Attr) attributes.setNamedItem(newAttr);
        } else {

            logger.debug("setAttributeNode");

            try {

                int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + newAttr.getName());
                ClosableIterator<AbstractOid> iter = ownerDocument.getStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);
                AtomicValue sv = getDocAtomicValueFactory().newAtomicValue(newAttr.getValue());

                // try to find and update
                while (iter.hasNext()) {
                    AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                    if (attr instanceof AS0AtomicObjectRO) {
                        AS0AtomicObjectEditable atomicObj = (AS0AtomicObjectEditable) attr;
                        String value = atomicObj.getValue().getValue().toString();
                        previous = new AS0Attr(newAttr.getName(), value, this);
                        atomicObj.setValue(sv);
                        iter.close();
                        return previous;
                    }
                }
                iter.close();

                // add new
                AS0AtomicObjectEditable newStoreAttr = getDocAS0ObjectsFactory().newAtomicObject(nameID, sv);
                getDocStore().addSubobject(ownerDocument.getTransaction(), underlyingObjectOID, newStoreAttr);


            } catch (JLoximException e) {
                throw new JLoximDOMException(e);
            }
        }

        na.ownerElement = this;
        return previous;

    }

    public void setAttributeNS(String namespaceURI, String qualifiedName, String value) throws DOMException {
        Attr newAttr = new AS0Attr(qualifiedName, value, namespaceURI, ownerDocument);
        this.setAttributeNodeNS(newAttr);
    }

    public Attr setAttributeNodeNS(Attr newAttr) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if ((newAttr.getNamespaceURI() == null || newAttr.getNamespaceURI().length()==0) && !newAttr.getName().contains(":")) {
            return this.setAttributeNode(newAttr);
        }

        if (newAttr.getNamespaceURI().compareToIgnoreCase(Consts.loximNamespace) == 0 && newAttr.getName().startsWith(Consts.loximNamespacePrefix) && newAttr.getName().replaceFirst(Consts.loximNamespacePrefix, "").equalsIgnoreCase("ref")) {

            if (underlyingObjectOID == null) {
                return (Attr) attributes.setNamedItemNS(newAttr);
            } else {

                logger.debug("setAttributeNodeNS");

                try {

                    AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);

                    if (obj instanceof AS0PointerObjectEditable) {
                        String oldVal = ((AS0PointerObjectEditable) obj).getDestinationOID().toReadableString();
                        Attr previous = new AS0Attr(newAttr.getName(), oldVal, newAttr.getNamespaceURI(), ownerDocument);
                        getDocStore().setNewPointerObjectDestination(ownerDocument.getTransaction(), underlyingObjectOID, new LongOid(Long.valueOf(newAttr.getValue())));
                        return previous;
                    } else {
                        throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
                    }

                } catch (StoreException e) {
                    throw new JLoximDOMException(e);
                }
            }
        } else {
            // we do not support other namespaces
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }
    }

    public void removeAttribute(String name) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (underlyingObjectOID == null) {
            attributes.removeNamedItem(name);
            return;
        }

        logger.debug("removeAttribute");


        try {

            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + name);
            ClosableIterator<AbstractOid> iter = ownerDocument.getStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);

            // remove all
            while (iter.hasNext()) {
                AbstractOid id = iter.next();
                AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), id);
                if (attr instanceof AS0AtomicObjectRO)
                    getDocStore().removeObject(ownerDocument.getTransaction(), id);
            }
            iter.close();


        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    public Attr removeAttributeNode(Attr oldAttr) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (oldAttr.getOwnerDocument() != this.ownerDocument)
            throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);

        if (oldAttr.getOwnerElement() != null && oldAttr.getOwnerElement() != this)
            throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);

        if (underlyingObjectOID == null)
            return (Attr) attributes.removeNamedItem(oldAttr.getName());

        logger.debug("removeAttributeNode");


        try {

            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + oldAttr.getName());
            ClosableIterator<AbstractOid> iter = ownerDocument.getStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);

            Attr res = null;

            // remove all
            while (iter.hasNext()) {
                AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                if (attr instanceof AS0AtomicObjectRO) {
                    if (res == null)
                        res = new AS0Attr(oldAttr.getName(), ((AS0AtomicObjectRO) attr).getValue().getValue().toString(), ownerDocument);
                    getDocStore().removeObject(ownerDocument.getTransaction(), iter.next());
                }
            }
            iter.close();

            return res;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    public void removeAttributeNS(String namespaceURI, String localName) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if ((namespaceURI == null || namespaceURI.length()==0)) {
            this.removeAttribute(localName);
            return;
        }

        if (namespaceURI.compareToIgnoreCase(Consts.loximNamespace) == 0 && localName.equalsIgnoreCase("ref")) {

            if (underlyingObjectOID == null) {
                attributes.removeNamedItem(localName);
            } else {
                throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
            }
        }
    }

    public NodeList getElementsByTagName(String name) {
        AS0NodeList list = new AS0NodeList();

        logger.debug("getElementsByTagName");


        try {
            int nameID = getDocNamesTranslator().getNameIdByName(name);
            DOMUtils.getDescendantsByName(getDocStore(), ownerDocument.getTransaction(), underlyingObjectOID, nameID, this.ownerDocument, list);
        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }

        return list;
    }

    public NodeList getElementsByTagNameNS(String namespaceURI, String localName) throws DOMException {

        if (namespaceURI == null || namespaceURI.length()==0)
            return getElementsByTagName(localName);

        //if (namespaceURI.compareToIgnoreCase(Consts.loximNamespace) == 0) {
        //    // for now there are no elements belonging to jloxim namespace, only attributes 'id' and 'ref' are present
        //}

        // empty list - no support for other namspaces
        return new AS0NodeList();
    }

    public boolean hasAttribute(String name) {

        if (name == null || name.length()==0)
            return false;

        if (underlyingObjectOID == null)
            return attributes.getNamedItem(name) != null;

        logger.debug("hasAttribute");

        try {

            int nameID = getDocNamesTranslator().getOrRegisterName(Consts.attrPrefix + name);
            ClosableIterator<AbstractOid> iter = ownerDocument.getStore().getSubobjectOIDsByNameOID(ownerDocument.getTransaction(), underlyingObjectOID, nameID);

            while (iter.hasNext()) {
                AS0ObjectRO attr = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                if (attr instanceof AS0AtomicObjectRO) {
                    iter.close();

                    return true;
                }
            }
            iter.close();

            return false;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }

    }

    public boolean hasAttributeNS(String namespaceURI, String localName) throws DOMException {

        if (namespaceURI == null || namespaceURI.length()==0)
            return this.hasAttribute(localName);

        if (underlyingObjectOID == null)
            return attributes.getNamedItemNS(namespaceURI, localName) != null;

        if (namespaceURI.compareToIgnoreCase(Consts.loximNamespace) == 0 && DOMUtils.isIdAttribute(localName))
            return true;

        if (namespaceURI.compareToIgnoreCase(Consts.loximNamespace) == 0 && DOMUtils.isRefAttribute(localName)) {

            logger.debug("hasAttributeNS");

            try {
                AS0ObjectRO res = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);

                return res instanceof AS0PointerObjectRO;
            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }
        }

        return false;
    }

    // level 3
    public TypeInfo getSchemaTypeInfo() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public void setIdAttribute(String name, boolean isId) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public void setIdAttributeNS(String namespaceURI, String localName, boolean isId) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // level 3
    public void setIdAttributeNode(Attr idAttr, boolean isId) throws DOMException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public NamedNodeMap getAttributes() {

        if (this.underlyingObjectOID == null)
            return this.attributes;

        logger.debug("getAttributes");

        try {
            AS0NamedNodeMap res = new AS0NamedNodeMap(this.ownerDocument);
            ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
            while (iter.hasNext()) {
                AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                if (obj instanceof AS0AtomicObjectRO) {
                    String name = getDocNamesTranslator().getNameByNameId(obj.getNameId());
                    if (name.startsWith(Consts.attrPrefix)) {
                        Node node = new AS0Attr(name.substring(1), ((AS0AtomicObjectRO) obj).getValue().getValue().toString(), ownerDocument);
                        res.internalSet(node);
                    }
                }
            }
            iter.close();

            return res;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    private Text getTextNodeForAtomicObject(AS0AtomicObjectRO atomicObj) {
        return new AS0Text(atomicObj.getValue().getValue().toString());
    }

    private boolean isChildAttribute(AbstractOid id, Transaction t) {
        try {
            AS0ObjectRO child = getDocStore().getObjectByOID(t, id);
            if (child instanceof AS0AtomicObjectRO) {
                String name = getDocNamesTranslator().getNameByNameId(child.getNameId());
                if (name.startsWith(Consts.attrPrefix))
                    return true;
            }
            return false;
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    private NodeList getChildNodes(ClosableIterator<AbstractOid> iter, Transaction t) {
        AS0NodeList res = new AS0NodeList();
        while (iter.hasNext()) {
            AbstractOid id = iter.next();
            if (isChildAttribute(id, t))
                continue;
            res.AddNode(new AS0Element(id, this.ownerDocument));
        }
        iter.close();
        return res;
    }

    @Override
    public NodeList getChildNodes() {

        if (underlyingObjectOID != null) {

            logger.debug("getChildNodes");


            try {
                if (isSuperRoot()) {
                    ClosableIterator<AbstractOid> iter = getDocStore().getRoots(ownerDocument.getTransaction());
                    return getChildNodes(iter, ownerDocument.getTransaction());
                } else {

                    AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);

                    if (obj instanceof AS0AtomicObjectRO) {
                        AS0NodeList res = new AS0NodeList();
                        res.AddNode(getTextNodeForAtomicObject((AS0AtomicObjectRO) obj));

                        return res;
                    } else if (obj instanceof AS0ComplexObjectRO) {
                        ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
                        return getChildNodes(iter, ownerDocument.getTransaction());
                    }


                    return new AS0NodeList();
                }

            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }

        } else
            return children;
    }

    private Node getFirstChild(Transaction t, ClosableIterator<AbstractOid> iter) {
        while (iter.hasNext()) {
            AbstractOid id = iter.next();
            if (isChildAttribute(id, t))
                continue;
            iter.close();
            return new AS0Element(id, this.ownerDocument);
        }
        iter.close();
        return null;
    }

    @Override
    public Node getFirstChild() {

        if (underlyingObjectOID != null) {
            logger.debug("getFirstChild");
            try {
                if (isSuperRoot()) {
                    ClosableIterator<AbstractOid> iter = getDocStore().getRoots(ownerDocument.getTransaction());
                    Node res = getFirstChild(ownerDocument.getTransaction(), iter);

                    return res;
                } else {
                    AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
                    if (obj instanceof AS0AtomicObjectRO) {

                        return getTextNodeForAtomicObject((AS0AtomicObjectRO) obj);
                    } else if (obj instanceof AS0ComplexObjectRO) {
                        ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
                        Node res = getFirstChild(ownerDocument.getTransaction(), iter);

                        return res;
                    }


                    return null;
                }

            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }

        } else if (children.getLength() > 0)
            return children.item(0);
        else
            return null;
    }

    private Node getLastChild(Transaction t, ClosableIterator<AbstractOid> iter) {
        LinkedList<AbstractOid> c = new LinkedList<AbstractOid>();
        while (iter.hasNext()) {
            c.addFirst(iter.next());
        }
        iter.close();

        for (AbstractOid id : c) {
            if (isChildAttribute(id, t))
                continue;
            return new AS0Element(id, this.ownerDocument);
        }
        return null;
    }

    @Override
    public Node getLastChild() {

        if (underlyingObjectOID != null) {

            logger.debug("getLastChild");


            try {

                if (isSuperRoot()) {
                    ClosableIterator<AbstractOid> iter = getDocStore().getRoots(ownerDocument.getTransaction());
                    return getLastChild(ownerDocument.getTransaction(), iter);
                } else {
                    AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
                    if (obj instanceof AS0AtomicObjectRO) {

                        return getTextNodeForAtomicObject((AS0AtomicObjectRO) obj);
                    } else if (obj instanceof AS0ComplexObjectRO) {
                        ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
                        return getLastChild(ownerDocument.getTransaction(), iter);
                    }


                    return null;
                }

            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }

        } else if (children.getLength() > 0)
            return children.item(children.getLength() - 1);
        else
            return null;
    }

    @Override
    public Node getPreviousSibling() {

        // special case for super root
        if (this.isSuperRoot())
            return null;

        logger.debug("getPreviousSibling");


        try {

            StoreAS0 store = getDocStore();
            AbstractOid parentOID = store.getParentOID(ownerDocument.getTransaction(), this.underlyingObjectOID);
            ClosableIterator<AbstractOid> siblings = store.getSubobjectOIDs(ownerDocument.getTransaction(), parentOID);

            List<AbstractOid> oids = new LinkedList<AbstractOid>();
            while (siblings.hasNext()) {
                AbstractOid id = siblings.next();
                if (isChildAttribute(id, ownerDocument.getTransaction()))
                    continue;
                oids.add(id);
            }
            siblings.close();


            Collections.sort(oids);

            int thisNdx = oids.indexOf(this.underlyingObjectOID);
            if (thisNdx == 0)
                return null;

            return new AS0Element(oids.get(thisNdx - 1), this.ownerDocument);

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    @Override
    public Node getNextSibling() {

        // specia lcase for super root
        if (this.isSuperRoot())
            return null;

        logger.debug("getNextSibling");


        try {

            StoreAS0 store = getDocStore();
            AbstractOid parentOID = store.getParentOID(ownerDocument.getTransaction(), this.underlyingObjectOID);
            ClosableIterator<AbstractOid> siblings = store.getSubobjectOIDs(ownerDocument.getTransaction(), parentOID);

            List<AbstractOid> oids = new LinkedList<AbstractOid>();
            while (siblings.hasNext()) {
                AbstractOid id = siblings.next();
                if (isChildAttribute(id, ownerDocument.getTransaction()))
                    continue;
                oids.add(id);
            }
            siblings.close();


            Collections.sort(oids);

            int thisNdx = oids.indexOf(this.underlyingObjectOID);
            if (thisNdx == oids.size() - 1) {
                return null;
            }

            return new AS0Element(oids.get(thisNdx + 1), this.ownerDocument);

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    @Override
    public boolean hasAttributes() {

        if (this.underlyingObjectOID == null)
            return this.attributes.getLength() > 0;

        logger.debug("hasAttributes");


        try {

            ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
            while (iter.hasNext()) {
                AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), iter.next());
                if (obj instanceof AS0AtomicObjectRO) {
                    String name = getDocNamesTranslator().getNameByNameId(obj.getNameId());
                    if (name.startsWith(Consts.attrPrefix)) {
                        iter.close();

                        return true;
                    }
                }
            }
            iter.close();

            return false;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }

    }

    @Override
    public String getLocalName() {
        return getTagName();
    }

    @Override
    public String getNodeName() {
        return getTagName();
    }

    private boolean hasChildNodes(Transaction t, ClosableIterator<AbstractOid> iter) throws TransactionException {
        boolean res = false;
        while (iter.hasNext()) {
            AbstractOid id = iter.next();
            if (isChildAttribute(id, t))
                continue;
            res = true;
            break;
        }
        iter.close();
        return res;
    }

    @Override
    public boolean hasChildNodes() {

        if (underlyingObjectOID != null) {

            logger.debug("hasChildNodes");


            try {

                if (isSuperRoot()) {

                    ClosableIterator<AbstractOid> iter = getDocStore().getRoots(ownerDocument.getTransaction());
                    return hasChildNodes(ownerDocument.getTransaction(), iter);

                } else {

                    AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
                    if (obj instanceof AS0ComplexObjectRO) {
                        ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
                        return hasChildNodes(ownerDocument.getTransaction(), iter);
                    } else {

                        return obj instanceof AS0AtomicObjectRO; // text node is a child node
                    }
                }

            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }

        } else
            return children.getLength() > 0;
    }

    @Override
    public Node getParentNode() {

        if (underlyingObjectOID != null) {

            if (isSuperRoot())
                return null;

            logger.debug("getParentNode");


            try {
                AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);
                AbstractOid parentOID = obj.getParentOID();

                return new AS0Element(parentOID, ownerDocument);

            } catch (JLoximException e) {

                throw new JLoximDOMException(e);
            }
        } else {
            return this.parent;
        }
    }

    public short getNodeType() {
        return Node.ELEMENT_NODE;
    }

    private boolean isAncestor(AbstractOid id, AbstractOid idToSearch) {
        logger.debug("isAncestor");
        try {
            AbstractOid currentId = id;
            AbstractOid superRootOid = getDocStore().getSuperRootOid();
            while (true) {
                if (idToSearch.compareTo(currentId) == 0) {
                    return true;
                }
                if (superRootOid.equals(currentId)) {
                    return false;
                }
                AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), id);
                AbstractOid parentOID = obj.getParentOID();
                currentId = parentOID;
            }

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    private boolean isNodeAncestor(Node n, Node nodeToSearch) {

        Node currentNode = n;

        while (true) {
            if (currentNode == nodeToSearch)
                return true;
            if (currentNode.getParentNode() == null)
                return false;
            currentNode = currentNode.getParentNode();
        }
    }

    @Override
    public Node appendChild(Node newChild) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (newChild instanceof AS0DocumentFragment) {
            // TODO
        }

        if (!(newChild instanceof AS0Node))
            throw new DOMException(DOMException.WRONG_DOCUMENT_ERR, ErrorMsg.WRONG_DOCUMENT_ERR);

        if (newChild instanceof AS0Element) {
            AS0Element eltToInsert = (AS0Element) newChild;

            if (this.underlyingObjectOID == null) {
                if (eltToInsert.underlyingObjectOID != null) {
                    // we do not allow to append stored elements to virtual elements
                    throw new DOMException(DOMException.HIERARCHY_REQUEST_ERR, ErrorMsg.HIERARCHY_REQUEST_ERR);
                } else {
                    // appending virtual element to virtual element

                    if (isNodeAncestor(this, newChild))
                        throw new DOMException(DOMException.HIERARCHY_REQUEST_ERR, ErrorMsg.HIERARCHY_REQUEST_ERR);

                    Node newChildParent = newChild.getParentNode();
                    if (newChildParent != null)
                        newChildParent.removeChild(newChild);

                    eltToInsert.parent = this;
                    this.children.AddNode(newChild);
                    return eltToInsert;
                }
            } else {
                if (eltToInsert.underlyingObjectOID != null) {
                    // appending store element to store element (moving an element)

                    if (isAncestor(underlyingObjectOID, eltToInsert.underlyingObjectOID))
                        throw new DOMException(DOMException.HIERARCHY_REQUEST_ERR, ErrorMsg.HIERARCHY_REQUEST_ERR);

                    logger.debug("appendChild");

                    try {

                        getDocStore().moveObject(ownerDocument.getTransaction(), eltToInsert.underlyingObjectOID, this.underlyingObjectOID);

                        return new AS0Element(eltToInsert.underlyingObjectOID, ownerDocument);
                    } catch (JLoximException e) {

                        throw new JLoximDOMException(e);
                    }

                } else {
                    // appending virtual element to store element
                    return this.appendVirtualChild(eltToInsert);
                }
            }

        } else if (newChild instanceof Text) {
            if (this.underlyingObjectOID == null) {
                if (newChild.getParentNode() != null)
                    newChild.getParentNode().removeChild(newChild);
                this.children.AddNode(newChild);
                return newChild;
            } else
                throw new DOMException(DOMException.HIERARCHY_REQUEST_ERR, ErrorMsg.HIERARCHY_REQUEST_ERR);
        } else if (newChild instanceof Attr) {
            this.setAttributeNode((Attr) newChild);
            return newChild;
        } else
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
    }

    private AS0ObjectEditable toStoreObject() {
        AS0ObjectEditable res = this.toPointerObject();
        if (res != null)
            return res;

        res = this.toAtomicObject();
        if (res != null)
            return res;

        return this.toComplexObject();
    }

    private boolean hasLoximRefAttribute() {
        return this.attributes.getNamedItemNS(Consts.loximNamespace, "ref") != null;
    }

    private AS0ObjectEditable toComplexObject() {

        if (this.hasLoximRefAttribute())
            return null;

        List<AS0ObjectEditable> objChildren = new LinkedList<AS0ObjectEditable>();

        // add children
        for (int i = 0; i < this.children.getLength(); i++) {
            Node n = this.children.item(i);
            if (!(n instanceof AS0Element))
                return null;
            else
                objChildren.add(((AS0Element) n).toStoreObject());
        }

        // add attributes
        for (int i = 0; i < this.attributes.getLength(); i++) {
            AS0Attr attr = (AS0Attr) attributes.item(i);
            objChildren.add(attr.toAtomicObject());
        }

        try {
            int nameID = getDocNamesTranslator().getOrRegisterName(this.getTagName());
            AS0ComplexObjectEditable comlex = getDocAS0ObjectsFactory().newComplexObject(nameID, objChildren);
            return comlex;
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    private AS0ObjectEditable toPointerObject() {
        if (this.children.getLength() > 0)
            return null;
        if (this.attributes.getLength() != 1)
            return null;

        Node refAttr = this.attributes.getNamedItemNS(Consts.loximNamespace, "ref");
        if (refAttr == null)
            return null;

        try {
            int nameID = getDocNamesTranslator().getOrRegisterName(this.getTagName());
            Long destinationOid = Long.parseLong(refAttr.getNodeValue());
            AS0PointerObjectEditable pointer = getDocAS0ObjectsFactory().newPointerObject(nameID, new LongOid(destinationOid));
            return pointer;
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    private AS0ObjectEditable toAtomicObject() {

        if (this.hasLoximRefAttribute())
            return null;

        if (this.children.getLength() == 0)
            return null;

        String concatenatedText = "";

        for (int i = 0; i < this.children.getLength(); i++) {
            Node n = this.children.item(i);
            if (n instanceof Text)
                concatenatedText += n.getNodeValue();
            else
                return null;
        }

        try {

            int nameId = getDocNamesTranslator().getOrRegisterName(this.getTagName());
            AtomicValue value = getDocAtomicValueFactory().newAtomicValue(concatenatedText);
            AS0AtomicObjectEditable atomic = getDocAS0ObjectsFactory().newAtomicObject(nameId, value);
            return atomic;
        } catch (JLoximException e) {
            throw new JLoximDOMException(e);
        }
    }

    protected Node appendVirtualChild(AS0Element elt) {
        // all subtree of elt will be also appended

        // elt cannot be already in the store
        if (elt.underlyingObjectOID != null)
            throw new JLoximDOMException("appendVirtualChild - child is not virtual");

        if (this.underlyingObjectOID == null)
            throw new JLoximDOMException("appendVirtualChild - parent is not stored");

        AS0ObjectEditable newObj = elt.toStoreObject();
        if (newObj == null)
            throw new JLoximDOMException("element cannot be converted to any store object");

        logger.debug("appendVirtualChild");


        try {

            getDocStore().addSubobject(ownerDocument.getTransaction(), this.underlyingObjectOID, newObj);
            // TODO set underlyingObjectOID for elt


            return new AS0Element(newObj.getOID(), ownerDocument);

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    @Override
    public Node removeChild(Node oldChild) throws DOMException {

        if (isReadOnly())
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);

        if (underlyingObjectOID == null) {
            Node removed = this.children.RemoveNode(oldChild);
            if (removed == null)
                throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);
            return removed;
        }

        if (!(oldChild instanceof AS0Element)) {
            // we can remove only other elements, we do not allow to remove text node (if
            // if this is an atomic object) or others
            throw new DOMException(DOMException.NO_MODIFICATION_ALLOWED_ERR, ErrorMsg.NO_MODIFICATION_ALLOWED_ERR);
        }

        AS0Element oldElement = (AS0Element) oldChild;
        if (oldElement.underlyingObjectOID == null) {
            Node removed = this.children.RemoveNode(oldChild);
            if (removed == null)
                throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);
            return removed;
        }

        logger.debug("removeChild");


        try {


            // check if oldnode is our child
            ClosableIterator<AbstractOid> iter = getDocStore().getSubobjectOIDs(ownerDocument.getTransaction(), underlyingObjectOID);
            boolean oldNodePresent = false;
            while (iter.hasNext())
                if (iter.next().compareTo(oldElement.underlyingObjectOID) == 0) {
                    oldNodePresent = true;
                    break;
                }
            iter.close();

            if (!oldNodePresent) {
                throw new DOMException(DOMException.NOT_FOUND_ERR, ErrorMsg.NOT_FOUND_ERR);
            }

            Node removed = new AS0Element(oldElement.underlyingObjectOID, ownerDocument).toVirtualNode(null);
            getDocStore().removeObject(ownerDocument.getTransaction(), oldElement.underlyingObjectOID);


            return removed;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    /**
     * Produces virtual node from current stored node
     * @param parent notice: ita can be null
     * @return
     */
    private Node toVirtualNode(Node parentNode) {

        if (this.underlyingObjectOID == null)
            return this;

        logger.debug("toVirtualNode");


        try {

            AS0Element res = new AS0Element(getTagName(), ownerDocument);

            if (isSuperRoot())
            {
                NodeList roots = this.getChildNodes();
                for (int i = 0; i < roots.getLength(); i++)
                    res.children.AddNode(((AS0Element)roots.item(i)).toVirtualNode(res));


                return res;
            }

            AS0ObjectRO obj = getDocStore().getObjectByOID(ownerDocument.getTransaction(), underlyingObjectOID);

            if (obj instanceof AS0PointerObjectRO) {
                res.parent = parentNode;
                res.namespaceUri = this.namespaceUri;
                AS0Attr refAttr = new AS0Attr(Consts.loximNamespacePrefix + "ref", ((AS0PointerObjectRO) obj).getDestinationOID().toReadableString(), ownerDocument);
                refAttr.namespaceUri = Consts.loximNamespace;
                refAttr.parent = res;
                res.attributes.internalSet(refAttr);

            } else if (obj instanceof AS0AtomicObjectRO) {
                res.parent = parentNode;
                res.namespaceUri = this.namespaceUri;
                AS0Text text = new AS0Text(((AS0AtomicObjectRO) obj).getValue().getValue().toString());
                text.parent = res;
                text.ownerDocument = this.ownerDocument;
                res.children.AddNode(text);

            } else if (obj instanceof AS0ComplexObjectRO) {
                res.parent = parentNode;
                res.namespaceUri = this.namespaceUri;
                res.attributes = (AS0NamedNodeMap) this.getAttributes();
                NodeList childrenList = this.getChildNodes();
                for (int i = 0; i < childrenList.getLength(); i++) {
                    Node c = childrenList.item(i);
                    if (c instanceof AS0Element)
                        res.children.AddNode(((AS0Element) c).toVirtualNode(res));
                    else
                        res.children.AddNode(c);
                }

            } else {

                throw new JLoximDOMException("unknown store object type");
            }


            return res;

        } catch (JLoximException e) {

            throw new JLoximDOMException(e);
        }
    }

    @Override
    public Node cloneNode(boolean deep) {
        if (deep)
            return this.toVirtualNode(null);

        AS0Element res = new AS0Element(getTagName(), ownerDocument);
        copyValuesOnClone(res);
        return res;
    }
}
