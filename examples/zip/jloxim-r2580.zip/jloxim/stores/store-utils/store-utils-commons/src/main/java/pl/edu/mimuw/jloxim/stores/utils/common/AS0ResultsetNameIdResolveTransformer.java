/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.common;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinderExtTemp;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.process.AbstractRecursiveAs0ResultsetTranslator;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;


/**
 * Rebuilds given {@link AS0Resultset} tree and replaces all found {@link AS0ResultsetBinder} (internal - integer representation of name)
 * into {@link AS0ResultsetBinderExt} representation (string representation of names).   
 *   
 * @author ptab
 *
 */
public class AS0ResultsetNameIdResolveTransformer extends AbstractRecursiveAs0ResultsetTranslator {
  //private final static Logger logger=Logger.getLogger(AS0ResultsetNameTranslatorToExternalTransformer.class);
  private NamesTranslator namesTranslator;
  
  @Override
  protected AS0Resultset processTyped(AS0ResultsetBinder r) {
    process(r.getValue()); //Don't need to rebuild the r. Recursive process quearantee to not change the structure
     if (!r.hasName()){
       r.setName(namesTranslator.getNameByNameId(r.getNameId()));
     }
     if (r instanceof AS0ResultsetBinderExtTemp){
       AS0ResultsetBinderExtTemp rt = (AS0ResultsetBinderExtTemp)r;
       if (!rt.isInitialized()) {
         rt.initNameIdAs(namesTranslator.getOrRegisterName(rt.getName()));
       }
     }
     return r;
  }
  
  public NamesTranslator getNamesTranslator() {
    return namesTranslator;
  }
  
  public void setNamesTranslator(NamesTranslator namesTranslator) {
    this.namesTranslator = namesTranslator;
  }
  

}
