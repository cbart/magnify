/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.utils.common;

import static org.junit.Assert.assertFalse;

import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransBufferspaceManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.utils.xml.importer.XmlImporter;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 *
 * @author mlenart
 * @version $Id: AbstractStoreUtilsCommonsTest.java 2430 2011-08-08 23:06:08Z mlenart $
 */
@ContextConfiguration(locations = {"classpath:/PathStoreUtilsSpringContext.xml"})
public abstract class AbstractStoreUtilsCommonsTest extends AbstractJUnit4SpringContextTests {

  protected final static String STORE_CONTENT = "/utils_commons_test.xml";
  
  @Autowired
  protected TransactionManager transactionManager;
  @Autowired
  protected PathNamesObservingAndProvidingStoreAS0Impl enhancedStore;
  @Autowired
  protected NamesTranslator namesTranslator;
  @Autowired
  XmlImporter xmlImporter;
  @Autowired
  protected AS0ObjectsFactory as0ObjectsFactory;
  @Autowired
  protected AtomicValueFactory atomicValueFactory;
  PathConverter pc;
  Map<String, AbstractOid> oidMap;

  @BeforeClass
  public static void setUpClass() throws Exception {
  }

  @AfterClass
  public static void tearDownClass() throws Exception {
  }

  @Before
  @DirtiesContext
  public void setUp() throws Exception {
    assertFalse(enhancedStore == null);
    assertFalse(namesTranslator == null);

    Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
    xmlImporter.setTransation(t);
    xmlImporter.importXmlFile(AbstractStoreUtilsCommonsTest.class.getResourceAsStream(STORE_CONTENT));
    t.commit();

    oidMap = xmlImporter.getXmlIdToOidMap();
    pc = new PathConverter(namesTranslator);
  }

  @After
  public void tearDown() {
  }
}
