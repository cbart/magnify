/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.utils.xml.sax;

import java.util.Collection;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

//TODO: PRzemyśleć/konfigurować zachowanie wobec namespaceów.
//TODO: Przemyśleć obsługę namespaceów
public class JLoximSAXLoaderHandler extends DefaultHandler {
  private static final Logger logger = Logger.getLogger(JLoximSAXLoaderHandler.class);

  // ========================================================================

  private NamesTranslator namesTranslator;
  private StoreAS0 storeAS0;
  private Transaction transation;
  private AS0ObjectsFactory as0objectFactory;
  private AtomicValueFactory atomicValueFactory;
  
  private boolean saveProcessingInstruction=false;
  private boolean saveComments=false;

  public NamesTranslator getNamesTranslator() {
    return namesTranslator;
  }

  public void setNamesTranslator(NamesTranslator namesTranslator) {
    this.namesTranslator = namesTranslator;
  }

  public StoreAS0 getStoreAS0() {
    return storeAS0;
  }

  public void setStoreAS0(StoreAS0 storeAS0) {
    this.storeAS0 = storeAS0;
  }

  public Transaction getTransation() {
    return transation;
  }

  public void setTransation(Transaction transcation) {
    this.transation = transcation;
  }

  public AS0ObjectsFactory getAs0objectFactory() {
    return as0objectFactory;
  }

  public void setAs0objectFactory(AS0ObjectsFactory as0objectFactory) {
    this.as0objectFactory = as0objectFactory;
  }

  public AtomicValueFactory getAtomicValueFactory() {
    return atomicValueFactory;
  }

  public void setAtomicValueFactory(AtomicValueFactory atomicValueFactory) {
    this.atomicValueFactory = atomicValueFactory;
  }
  
  public void setSaveComments(boolean saveComments) {
    this.saveComments = saveComments;
  }
  
  public boolean getSaveComments(){
    return saveComments;
  }
  
  public void setSaveProcessingInstruction(boolean saveProcessingInstruction) {
    this.saveProcessingInstruction = saveProcessingInstruction;
  }
  
  public boolean getSaveProcessingInstruction() {
    return saveProcessingInstruction;
  }

  // ========================================================================

  private StringBuilder lastContent;
  private LinkedList<AS0ComplexObjectEditable> startedElements = new LinkedList<AS0ComplexObjectEditable>();
  private String waitingElementName;

  public void flushContentInNewItem() throws SAXException
  {

//        DOMSource ds = new DOMSource();
//        javax.xml.transform.stax.StAXSource ss;
        

    try{
      if (lastContent!=null && lastContent.length()>0)
      {
        String s=lastContent.toString().trim();
        if (s.length()>0)
        {
          getStoreAS0().addSubobject(
              transation,
              getCurrentOid(),
              as0objectFactory.newAtomicObject(nameId_Text,
                  getAtomicValueFactory().newAtomicValue(lastContent.toString())));
        }
        lastContent=null;
      }
    }catch (StoreException e) {
       throw new SAXException(e);
    }
  }  

  private int nameId_Text;
  //TODO: Fix support for comments
//  private int nameId_Comment;
  private int nameId_Target;
  private int nameId_Data;
  private int nameId_ProcessingInstruction;

  @Override
  public void startDocument() throws SAXException {
    logger.debug("startDocument()");
    lastContent = null;
    
    try {
      nameId_Text=namesTranslator.getOrRegisterName( "#text");
//      nameId_Comment=namesTranslator.getOrRegisterName( "#comment");
      nameId_ProcessingInstruction=namesTranslator.getOrRegisterName("#processingInstruction");
      
      nameId_Target=namesTranslator.getOrRegisterName("target");
      nameId_Data=namesTranslator.getOrRegisterName("data");
    } catch (NameTranslatorException e) {
      throw new SAXException(e);
    }
  }

  @Override
  public void startElement(String uri, String localName, String name,
      Attributes attributes) throws SAXException {
    try {
      makeCurrentComplex();
      flushContentInNewItem();
      String objectName = generateObjectName(uri, localName, name);
      logger.debug("startElement(" + uri + ", " + localName + ", " + name
          + ", " + attributes + "); as0name=" + objectName);
      // startedElements.addLast(objectName);
      waitingElementName = objectName;

      if (attributes.getLength() > 0) {
        AbstractOid parent_OID = makeCurrentComplex();
        for (int i = 0; i < attributes.getLength(); i++) {
          logger.debug(" - adding attribute "
              + attributes.getQName(i) + "="
              + attributes.getValue(i));
          int name_id = namesTranslator.getOrRegisterName("@" + attributes.getQName(i));
          getStoreAS0().addSubobject(
              transation,
              parent_OID,
              as0objectFactory.newAtomicObject(name_id,
                  getAtomicValueFactory().newAtomicValue(
                      attributes.getValue(i))));
        }
      }
    } catch (NameTranslatorException e) {
      throw new SAXException(e);
    } catch (StoreException e) {
      throw new SAXException(e);
    }
  }

  private AbstractOid makeCurrentComplex() throws NameTranslatorException,
      StoreException {
    if (waitingElementName != null) {
      AS0ComplexObjectEditable object = as0objectFactory
          .newEmptyComplexObject(namesTranslator.getOrRegisterName(waitingElementName));
      getStoreAS0().addSubobject(transation, getCurrentOid(), object);
      startedElements.addLast(object);
      waitingElementName = null;
      return object.getOID();
    } else {
      return getCurrentOid();
    }
  }

  private AbstractOid getCurrentOid() {
    try {
      return startedElements.getLast().getOID();
    } catch (NoSuchElementException e) {
      return new LongOid(0L);// SUPER_ROOT
    }
  }

  private String generateObjectName(String uri, String localName, String name) {
    if (logger.isTraceEnabled()){
      logger.trace("generateObjectName("+uri+", "+localName+", "+name+") called");
    }
    return name;
  }

  @Override
  public void ignorableWhitespace(char[] ch, int start, int length)
      throws SAXException {
    // Ignoring
  }

  @Override
  public void characters(char[] ch, int start, int length)
      throws SAXException {
    String content = new String(ch, start, length);
    logger.debug("Characters: |" + content + "|");
    if (lastContent == null) {
      lastContent = new StringBuilder();
    }
    lastContent.append(content);
  }

  @Override
  public void endElement(String uri, String localName, String name)
      throws SAXException {
    logger.debug("endElement(" + uri + ", " + localName + ", " + name + ");");
    try {
      if (waitingElementName == null) {
        flushContentInNewItem();
        startedElements.removeLast();
      } else {
        AS0AtomicObjectEditable object;
        object = as0objectFactory.newAtomicObject(namesTranslator.getOrRegisterName(waitingElementName),
            atomicValueFactory.newAtomicValue(lastContent
                .toString()));
        getStoreAS0().addSubobject(transation, getCurrentOid(), object);
        lastContent = null;
        waitingElementName = null;
      }
    } catch (NameTranslatorException e) {
      throw new SAXException(e);
    } catch (StoreException e) {
      throw new SAXException(e);
    }
  }

  @Override
  public void endDocument() throws SAXException {
    logger.debug("endDocument();");
    super.endDocument();
  }

  @Override
  public void processingInstruction(String target, String data)
      throws SAXException {
    logger.debug("processingInstruction: target="+target+" data="+data);
    if (saveProcessingInstruction){
      try {
        AbstractOid parent_OID=makeCurrentComplex();
        flushContentInNewItem();
    
        getStoreAS0().addSubobject(
                transation,
                parent_OID,
                createProcessingInstructionObject(target, data));
      } catch (NameTranslatorException e) {
        throw new SAXException(e);
      } catch (StoreException e) {
        throw new SAXException(e);
      }

    }
  }
  
  

  private AS0ObjectEditable createProcessingInstructionObject(String target, String data) throws NameTranslatorException {
    Collection<AS0ObjectEditable> childs=new LinkedList<AS0ObjectEditable>();
    childs.add(as0objectFactory.newAtomicObject(nameId_Target, atomicValueFactory.newAtomicValue(target)));
    childs.add(as0objectFactory.newAtomicObject(nameId_Data, atomicValueFactory.newAtomicValue(data)));    
    return as0objectFactory.newComplexObject(nameId_ProcessingInstruction, childs);
  }
  
}

  

