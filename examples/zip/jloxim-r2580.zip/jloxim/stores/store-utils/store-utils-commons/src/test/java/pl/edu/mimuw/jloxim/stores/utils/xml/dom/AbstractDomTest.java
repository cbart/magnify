/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.xml.dom;

import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import junit.framework.Assert;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.w3c.dom.Document;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.utils.common.AS0StoreContentLogger;
import pl.edu.mimuw.jloxim.stores.utils.xml.importer.XmlImporter;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

@ContextConfiguration(locations = {"classpath:/XmlImporterTest_spring.xml"})
public abstract class AbstractDomTest extends AbstractJUnit4SpringContextTests {

    @Autowired
    NamesTranslator namesTranslator;
    @Autowired
    StoreAS0 store;
    @Autowired
    XmlImporter xmlImporter;
    @Autowired
    TransactionManager transactionManager;
    @Autowired
    AS0StoreContentLogger storeContentLogger;
    @Autowired
    XmlImporter importer;
    AtomicValueFactory atomicValueFactory = new AtomicValueFactoryImpl();
    AS0ObjectsFactory objectsFactory = new AS0ObjectsFactoryImpl();

    protected void writeStoreToXmlChackTransactionNumber(StoreAS0 st, OutputStream output) throws Exception {
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
        writeStoreToXml(st, output);
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }

    protected void writeStoreToXml(StoreAS0 st, OutputStream output) throws Exception {
        StreamSource ss = new StreamSource(DOMTest.class.getResourceAsStream("/identicalTransform.xsl"));
        AS0DOMImplementation impl = new AS0DOMImplementation();
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        Document doc = impl.createAS0DocumentRO(st, namesTranslator, t);
        DOMSource ds = new DOMSource(doc);
        TransformerFactory tfactory = TransformerFactory.newInstance();
        Transformer transformer = tfactory.newTransformer(ss);
        transformer.transform(ds, new StreamResult(output));
        t.commit();
    }

    protected void clearStore() throws Exception {
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        ClosableIterator<AbstractOid> iter = store.getRoots(t);
        List<AbstractOid> roots = new LinkedList<AbstractOid>();
        while (iter.hasNext())
            roots.add(iter.next());
        iter.close();
        store.removeObjects(t, roots.toArray(new AbstractOid[0]));
        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }

    protected void createStoreFromXml(StoreAS0 s, NamesTranslator nt, String src) throws Exception {
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
        Transaction t = transactionManager.newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
        importer.setStoreAS0(s);
        importer.setTransation(t);
        importer.setNamesTranslator(nt);
        importer.importXmlFile(XmlImporter.class.getResourceAsStream(src));
        t.commit();
        Assert.assertEquals(0, transactionManager.getAllActiveTransactions().size());
    }
}
