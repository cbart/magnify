/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.utils.trans_btree;

import java.util.Comparator;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

import java.util.Map;

/**
 * @author kadamczyk
 * @version $Id: TransBtree.java 2505 2011-09-26 06:05:41Z kadamczyk $
 */
public interface TransBtree<KEY, VALUE> {

    /**
     * Sets the object used to convert the keys from source type to TransBtreeValue type and back.
     *
     * @param keyBinding
     */
    public void setKeyBinding(TransBtreeValueBinding<KEY> keyBinding);

    /**
     * Sets the object used to convert the values from source type to TransBtreeValue type and back. 
     * 
     * @param valueBinding
     */
    public void setValueBinding(TransBtreeValueBinding<VALUE> valueBinding);

    /**
     * Sets key Comparator
     * 
     * @param keyComparator
     */
    public void setKeyComparator(Comparator<TransBtreeValue> keyComparator);

    /**
     * 
     * @param pageId
     */
    public void setRootPageId(int pageId);

    /**
     * Returns iterator over all objects.
     * 
     * @param transaction
     * @return iterator over objects
     */
    public ClosableIterator<? extends Map.Entry<KEY, VALUE>> iterator(Transaction transaction);

    /**
     * Returns an iterator pointing to the first element 
     * which does not compare less than given key.
     * 
     * @param transaction
     * @param key
     * @return iterator over all objects pointing to the first element greater 
     *         than or equal to given key
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
    public ClosableIterator<? extends Map.Entry<KEY, VALUE>> find(Transaction transaction, KEY key) throws TransBtreeException;

    /**
     * Returns object by given key.
     * 
     * @param transaction
     * @param key
     * @return value for a given key or null
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public VALUE get(Transaction transaction, KEY key) throws TransBtreeException;

    /**
     * Adds object
     * 
     * @param transaction
     * @param key
     * @param value
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public void put(Transaction transaction, KEY key, VALUE value) throws TransBtreeException;
    
    /**
     * Removes given object.
     * 
     * @param transaction
     * @param key
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public void remove(Transaction transaction, KEY key) throws TransBtreeException;

    /**
     * Returns true if tree contains no objects.
     *
     * @param transaction
     * @return
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public boolean isEmpty(Transaction transaction) throws TransBtreeException;

    /**
     * Removes all objects
     * 
     * @param transaction
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public void clear(Transaction transaction) throws TransBtreeException;

    /**
     * Removes tree from bufferspace (all pages).
     * 
     * @param transaction
     * @throws TransBtreeException
     * @throws InterruptedOperationTransBtreeException if transaction was deadlocked
     *     on resource with another process and has been chosen as the deadlock victim
     */
  public void drop(Transaction transaction) throws TransBtreeException;

}
