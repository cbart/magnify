/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.impl.ro.AS0PointerObjectROImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ComplexObjectEditableImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.AbstractPrePostAs0StoreTest;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.NewObjectEvent;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.ObjectRemoveEvent;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.ObjectTypeOrValueChangeEvent;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ReferrerIndexTest extends AbstractPrePostAs0StoreTest {

	@Test
	public void testNewObjectEvent() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    LongOid oid = new LongOid(12);
		LongOid parentOid = new LongOid(11);
		LongOid destinationOid = new LongOid(19);
		AS0ObjectRO object = new AS0PointerObjectROImpl(oid, 22, parentOid, destinationOid);
		getEventBus().publish(new NewObjectEvent(t, object, 0));
		Assert.assertEquals(Arrays.asList(oid), getReferrerIndex().getReferrers(t, destinationOid));
    t.commit();
	}

	@Test
	public void testNewObject_multipleEvents() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int num = 1000;
    LongOid[] oids = new LongOid[num];
    for (int i = 0; i < num; i++) {
    	oids[i] = new LongOid(100 + i);
    }
		LongOid parentOid = new LongOid(11);
		LongOid destinationOid = new LongOid(19);
		List<LongOid> list = Arrays.asList(oids);
		for (LongOid oid : list) {
			AS0ObjectRO object = new AS0PointerObjectROImpl(oid, 22, parentOid, destinationOid);
			getEventBus().publish(new NewObjectEvent(t, object, 0));
		}
		Assert.assertEquals(list, getReferrerIndex().getReferrers(t, destinationOid));
    t.commit();
	}

	@Test
	public void testNewObjectAndRemoveObjectEvents() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    LongOid oid = new LongOid(12);
		LongOid parentOid = new LongOid(11);
		LongOid destinationOid = new LongOid(19);
		AS0ObjectRO object = new AS0PointerObjectROImpl(oid, 22, parentOid, destinationOid);
		getEventBus().publish(new NewObjectEvent(t, object, 0));
		getEventBus().publish(new ObjectRemoveEvent(t, object));
		Assert.assertEquals(Collections.<LongOid>emptyList(), getReferrerIndex().getReferrers(t, destinationOid));
    t.commit();
	}

	@Test
	public void testObjectTypeChangedEvent() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    LongOid oid = new LongOid(12);
    LongOid oid2 = new LongOid(13);
		LongOid parentOid = new LongOid(11);
		LongOid destinationOid = new LongOid(19);
		AS0ComplexObjectEditable complex = new AS0ComplexObjectEditableImpl(oid, 22, parentOid);
		AS0PointerObjectRO pointer = new AS0PointerObjectROImpl(oid2, 22, parentOid, destinationOid);
		getEventBus().publish(new NewObjectEvent(t, complex, 0));
		Assert.assertEquals(Collections.<LongOid>emptyList(), getReferrerIndex().getReferrers(t, destinationOid));
		getEventBus().publish(new ObjectTypeOrValueChangeEvent(t,complex, pointer));
		Assert.assertEquals(Arrays.asList(oid2), getReferrerIndex().getReferrers(t, destinationOid));
    t.commit();
	}
}
