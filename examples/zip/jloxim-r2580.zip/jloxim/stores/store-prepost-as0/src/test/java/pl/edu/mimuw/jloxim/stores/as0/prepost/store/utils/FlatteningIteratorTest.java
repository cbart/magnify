/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.stores.as0.prepost.store.iterators.FlatteningIterator;

public class FlatteningIteratorTest {

  @Test
	public void test_normal() {
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		lists.add(Arrays.asList(new Integer[] {1, 2}));
		lists.add(Arrays.asList(new Integer[] {3}));
		lists.add(Arrays.asList(new Integer[] {4, 5}));
		FlatteningIterator<List<Integer>, Integer> iterator =
			new FlatteningIterator<List<Integer>, Integer>(lists);

		for (int i = 1; i <= 5; i++) {
			Assert.assertTrue(iterator.hasNext());
			Assert.assertEquals((Integer) i, iterator.next());
		}
		Assert.assertFalse(iterator.hasNext());
	}

  @Test
	public void test_emptyCollections() {
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Arrays.asList(new Integer[] {1}));
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Arrays.asList(new Integer[] {2}));
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		lists.add(Collections.<Integer>emptyList());
		FlatteningIterator<List<Integer>, Integer> iterator =
			new FlatteningIterator<List<Integer>, Integer>(lists);

		Assert.assertTrue(iterator.hasNext());
		Assert.assertEquals((Integer)1, iterator.next());
		Assert.assertTrue(iterator.hasNext());
		Assert.assertEquals((Integer)2, iterator.next());
		Assert.assertFalse(iterator.hasNext());
	}

  @Test(expected = NoSuchElementException.class)
	public void test_exceptionExpected() {
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		lists.add(Arrays.asList(new Integer[] {1}));
		FlatteningIterator<List<Integer>, Integer> iterator =
			new FlatteningIterator<List<Integer>, Integer>(lists);

		Assert.assertTrue(iterator.hasNext());
		Assert.assertEquals((Integer)1, iterator.next());
		Assert.assertFalse(iterator.hasNext());
		iterator.next();
	}

}
