/*
 * Copyright 2011 Faculty of Mathematics Informatics and Mechanics at the University of Warsaw.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store;

import pl.edu.mimuw.jloxim.stores.tests.StoreAs0CmpPerfTest;
import org.apache.log4j.Logger;
import org.junit.After;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;

/**
 *
 * @author kadamczyk
 * @version $Id: PrePostAs0StoreCmpPerfTest.java 2488 2011-09-21 23:07:47Z mlenart $
 */
public class PrePostAs0StoreCmpPerfTest extends StoreAs0CmpPerfTest {
           
    @SuppressWarnings("unused")
    private static final Logger logger = Logger.getLogger(PrePostAs0StoreCmpPerfTest.class);
    
    private AbstractApplicationContext applicationContext;

    private AS0ObjectsFactory as0ObjectsFactory = new AS0ObjectsFactoryImpl();
    private AtomicValueFactory atomicValueFactory = new AtomicValueFactoryImpl();
    
    protected synchronized ApplicationContext getApplicationContext() {
        if (applicationContext == null) {
            applicationContext = new ClassPathXmlApplicationContext("/StorePrePostAs0SpringTest-context.xml");
        }
        return applicationContext;
    }

    @After
    @Override
    public void clearApplicationContext() {
        if (applicationContext != null) {
            applicationContext.close();
            applicationContext = null;
        }
    }

    @Override
    public StoreAS0 getStore() {
        return getApplicationContext().getBean("store", StoreAS0.class);
    }
 
    @Override
    public TransactionManager getTM() {
        return getApplicationContext().getBean("transactionManager", TransactionManager.class);
    }

    
    @Override
    public AS0ObjectsFactory getAS0ObjectsFactory() {
        return as0ObjectsFactory;
    }

    @Override
    public AtomicValueFactory getAtomicValueFactory() {
        return atomicValueFactory;
    }

}
