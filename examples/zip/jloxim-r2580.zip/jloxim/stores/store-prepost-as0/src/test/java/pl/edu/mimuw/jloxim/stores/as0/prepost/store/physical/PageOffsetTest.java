/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical;

import java.util.List;

import junit.framework.Assert;

import org.junit.Ignore;
import org.junit.Test;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.AbstractPrePostAs0StoreTest;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.IndexAwarePageId;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.PageBasedPageOffset;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

@Ignore
public class PageOffsetTest extends AbstractPrePostAs0StoreTest {

	@Test
	public void initialState() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    Integer pageId = getPageOffset().getPageFromIndex(t, 0);
    Assert.assertNotNull(pageId);
    Assert.assertEquals((Integer) 0, getPageOffset().getIndexFromPage(t, pageId));
    checkSection(t, pageId, new int[] {pageId}, 0);
    Assert.assertNull(getPageOffset().getNextPage(t, pageId));
    t.commit();
	}

	@Test
	public void add() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    getPageOffset().addNewPage(t, pageId, 10);
    getPageOffset().addNewPage(t, 10, 12);
    getPageOffset().addNewPage(t, pageId, 8);
    getPageOffset().addNewPage(t, 10, 11);
    getPageOffset().addNewPage(t, 8, 9);
    getPageOffset().addNewPage(t, pageId, 7);
    int[] expected = new int[] {pageId, 7, 8, 9, 10, 11, 12};
    for (int i = 0; i < expected.length; i++) {
    	Assert.assertEquals((Integer) expected[i], getPageOffset().getPageFromIndex(t, i));
    	Assert.assertEquals((Integer) i, getPageOffset().getIndexFromPage(t, expected[i]));
    }

    checkSection(t, pageId, expected, 0);

    t.commit();
	}

	@Test
	public void addAndRemove() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    getPageOffset().addNewPage(t, pageId, 10);
    getPageOffset().addNewPage(t, 10, 12);
    getPageOffset().removePage(t, 10);
    getPageOffset().addNewPage(t, 12, 14);
    getPageOffset().addNewPage(t, 14, 16);
    getPageOffset().removePage(t, 14);
    int[] expected = new int[] {pageId, 12, 16};
    for (int i = 0; i < expected.length; i++) {
    	Assert.assertEquals((Integer) expected[i], getPageOffset().getPageFromIndex(t, i));
    	Assert.assertEquals((Integer) i, getPageOffset().getIndexFromPage(t, expected[i]));
    }

    checkSection(t, pageId, expected, 0);
    t.commit();
	}

	@Test
	public void sections() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    getPageOffset().addNewPage(t, pageId, 11);
    for (int i = 12; i < 50; i++) {
    	getPageOffset().addNewPage(t, i - 1, i);
    }

    checkSection(t, 11, new int[] {11, 12, 13}, 1);
    checkSection(t, 17, new int[] {17, 18, 19, 20, 21}, 7);
    checkSection(t, 29, new int[] {29, 30, 31, 32, 33, 34}, 19);
    checkSection(t, 43, new int[] {43, 44, 45}, 33);
    t.commit();
	}

	@Test
	public void bigTest() {

    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    for (int i = 1000; i >= 10; i-= 10) {
    	getPageOffset().addNewPage(t, pageId, i);
    }
    for (int i = 0; i < 9; i++) {
    	for (int j = 10 + i; j <= 1000 + i; j += 10) {
    		getPageOffset().addNewPage(t, j, j + 1);
    	}
    }

    for (int i = 15; i <= 995; i+= 10) {
    	checkSection(t, i, new int[] {i, i + 1, i + 2, i + 3, i + 4, i + 5, i + 6, i + 7, i + 8, i + 9}, i - 9);
    }

    for (int i = 1; i <= 9; i += 2) {
    	for (int j = 10 + i; j <= 1000 + i; j += 10) {
    		getPageOffset().removePage(t, j);
    	}
    }

    for (int i = 10; i <= 1000; i+= 10) {
    	checkSection(t, i, new int[] {i, i + 2, i + 4, i + 6, i + 8}, (i - 10) / 2 + 1);
    }

    t.commit();
	}

	@Test
	public void bigAddTest() {

    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    int num = 20;
    getPageOffset().addNewPage(t, pageId, 10);
    for (int i = 11; i <= num; i++) {
    	getPageOffset().addNewPage(t, i - 1, i);
    }

    int expected[] = new int[num - 8];
    expected[0] = pageId;
    for (int i = 10; i <= num; i++) {
    	expected[i - 9] = i;
    }

    checkSection(t, pageId, expected, 0);

    t.commit();
	}

	@Test
	public void notFound() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    Assert.assertNull(getPageOffset().getIndexFromPage(t, pageId + 1));
    Assert.assertNull(getPageOffset().getPageFromIndex(t,1));
    Assert.assertNull(getPageOffset().getFollowingPages(t, pageId + 1, 1));
    Assert.assertNull(getPageOffset().getFollowingIndexAwarePages(t, pageId + 1, 1));
    t.commit();
	}

	@Test
	public void remove() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    for (int i = 20; i >= 10; i--) {
    	getPageOffset().addNewPage(t, pageId, i);
    }
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    for (int i = 11; i <= 19; i += 2) {
    	getPageOffset().removePage(t, i);
    }
    checkSection(t, pageId, new int[] {pageId, 10, 12, 14, 16, 18, 20}, 0);
    t.commit();
	}

	@Test
	public void bigRemove_forceMerging() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    int pageId = getPageOffset().getPageFromIndex(t, 0);
    for (int i = 3000; i >= 10; i--) {
    	getPageOffset().addNewPage(t, pageId, i);
    }
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    for (int i = 3000; i >= 10; i--) {
    	if (i % 1000 != 0) {
    		getPageOffset().removePage(t, i);
    	}
    }
    checkSection(t, pageId, new int[] {pageId, 1000, 2000, 3000}, 0);
    if (getPageOffset() instanceof PageBasedPageOffset) {
    	Assert.assertTrue(((PageBasedPageOffset) getPageOffset()).getMergeCount() > 0);
    }
    t.commit();
	}

	private void checkSection(Transaction t, int pageId, int[] expectedIds, int indexStart) {
    List<Integer> list = getPageOffset().getFollowingPages(t, pageId, expectedIds.length);

    Assert.assertEquals(expectedIds.length, list.size());
    for (int i = 0; i < expectedIds.length; i++) {
      Assert.assertEquals((Integer) expectedIds[i], list.get(i));
    }

    List<IndexAwarePageId> list2 = getPageOffset().getFollowingIndexAwarePages(t, pageId, expectedIds.length);
    Assert.assertEquals(expectedIds.length, list2.size());
    for (int i = 0; i < expectedIds.length; i++) {
      Assert.assertEquals(expectedIds[i], list2.get(i).getPageId());
	    Assert.assertEquals(indexStart + i, list2.get(i).getIndex());
	    Assert.assertEquals((Integer)(indexStart + i), getPageOffset().getIndexFromPage(t, expectedIds[i]));
    }

    for (int i = 0; i < expectedIds.length - 1; i++) {
    	Assert.assertEquals((Integer) expectedIds[i + 1], getPageOffset().getNextPage(t, expectedIds[i]));
    }

    ClosableIterator<Integer> iterator = getPageOffset().getStructuralPageIdIterator(t, indexStart);
    for (int i = 0; i < expectedIds.length - 1; i++) {
    	Assert.assertEquals((Integer) expectedIds[i], iterator.next());
    }
    iterator.close();
	}
}
