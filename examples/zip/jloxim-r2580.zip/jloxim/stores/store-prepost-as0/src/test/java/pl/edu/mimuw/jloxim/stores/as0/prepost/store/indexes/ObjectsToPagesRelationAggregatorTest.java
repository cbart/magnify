/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.IndexAwarePageId;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils.ObjectsToPagesRelationAggregator;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils.ObjectsToPagesRelationAggregator.ResultElement;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ObjectsToPagesRelationAggregatorTest {

	@Test
	public void simpleScenario() {
		ObjectsToPagesRelationAggregator aggregator =
			new ObjectsToPagesRelationAggregator();
		IndexAwarePageId[] pages = new IndexAwarePageId[] {
				new IndexAwarePageId(0, 1),
				new IndexAwarePageId(1, 3),
				new IndexAwarePageId(2, 6),
				new IndexAwarePageId(3, 12),
				new IndexAwarePageId(4, 18),
				new IndexAwarePageId(5, 22),
				new IndexAwarePageId(6, 29),
				new IndexAwarePageId(7, 31)
		};
		LongOid[] oids = new LongOid[] {
				new LongOid(0), new LongOid(1), new LongOid(2),
				new LongOid(3), new LongOid(4), new LongOid(5),
		};

		aggregator.add(oids[0], Arrays.asList(new IndexAwarePageId[] {
				pages[0], pages[1]
		}));
		aggregator.add(oids[1], Arrays.asList(new IndexAwarePageId[] {
				pages[1]
		}));
		aggregator.add(oids[2], Arrays.asList(new IndexAwarePageId[] {
				pages[1], pages[2]
		}));
		aggregator.add(oids[3], Arrays.asList(new IndexAwarePageId[] {
				pages[4]
		}));
		aggregator.add(oids[4], Arrays.asList(new IndexAwarePageId[] {
				pages[6]
		}));
		aggregator.add(oids[5], Arrays.asList(new IndexAwarePageId[] {
				pages[7]
		}));
		List<ResultElement> result = aggregator.extractResult();
		Assert.assertEquals(4, result.size());
		Set<LongOid> expectedOids = new HashSet<LongOid>();
		expectedOids.addAll(Arrays.asList(oids));
		for (ResultElement element : result) {
			List<LongOid> elementOids = element.getOids();
			for (LongOid oid : elementOids) {
				Assert.assertTrue(expectedOids.remove(oid));
			}
			if (elementOids.contains(oids[0])) {
				Assert.assertEquals(3, elementOids.size());
				Assert.assertEquals(3, element.getPageIds().size());
				Assert.assertTrue(elementOids.contains(oids[1]));
				Assert.assertTrue(elementOids.contains(oids[2]));
				Assert.assertTrue(element.getPageIds().contains(pages[0].getPageId()));
				Assert.assertTrue(element.getPageIds().contains(pages[1].getPageId()));
				Assert.assertTrue(element.getPageIds().contains(pages[2].getPageId()));
			} else {
				Assert.assertEquals(1, elementOids.size());
				Assert.assertEquals(1, element.getPageIds().size());
				if (elementOids.contains(oids[3])) {
					Assert.assertTrue(element.getPageIds().contains(pages[4].getPageId()));
				} else if (elementOids.contains(oids[4])) {
					Assert.assertTrue(element.getPageIds().contains(pages[6].getPageId()));
				} else if (elementOids.contains(oids[5])) {
					Assert.assertTrue(element.getPageIds().contains(pages[7].getPageId()));
				}
			}
		}
		Assert.assertTrue(expectedOids.isEmpty());
	}

	@Test
	public void add_order1() {
		ObjectsToPagesRelationAggregator aggregator =
			new ObjectsToPagesRelationAggregator();
		IndexAwarePageId[] pages = new IndexAwarePageId[] {
				new IndexAwarePageId(0, 7),
				new IndexAwarePageId(1, 18),
				new IndexAwarePageId(2, 1),
				new IndexAwarePageId(3, 12),
				new IndexAwarePageId(4, 22),
		};
		LongOid[] oids = new LongOid[] {
				new LongOid(0), new LongOid(1)
		};
		aggregator.add(oids[0], Arrays.asList(new IndexAwarePageId[] {
				pages[0], pages[1], pages[2]
		}));
		aggregator.add(oids[1], Arrays.asList(new IndexAwarePageId[] {
				pages[2], pages[3], pages[4]
		}));
		List<ResultElement> result = aggregator.extractResult();
		Assert.assertEquals(1, result.size());
		ResultElement element = result.get(0);
		Assert.assertEquals(2, element.getOids().size());
		Assert.assertEquals(5, element.getPageIds().size());
		Assert.assertTrue(element.getOids().contains(oids[0]));
		Assert.assertTrue(element.getOids().contains(oids[1]));
		Assert.assertTrue(element.getPageIds().contains(pages[0].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[1].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[2].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[3].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[4].getPageId()));
	}

	@Test
	public void add_order2() {
		ObjectsToPagesRelationAggregator aggregator =
			new ObjectsToPagesRelationAggregator();
		IndexAwarePageId[] pages = new IndexAwarePageId[] {
				new IndexAwarePageId(0, 7),
				new IndexAwarePageId(1, 18),
				new IndexAwarePageId(2, 1),
				new IndexAwarePageId(3, 12),
				new IndexAwarePageId(4, 22),
		};
		LongOid[] oids = new LongOid[] {
				new LongOid(0), new LongOid(1)
		};
		aggregator.add(oids[1], Arrays.asList(new IndexAwarePageId[] {
				pages[2], pages[3], pages[4]
		}));
		aggregator.add(oids[0], Arrays.asList(new IndexAwarePageId[] {
				pages[0], pages[1], pages[2]
		}));
		List<ResultElement> result = aggregator.extractResult();
		Assert.assertEquals(1, result.size());
		ResultElement element = result.get(0);
		Assert.assertEquals(2, element.getOids().size());
		Assert.assertEquals(5, element.getPageIds().size());
		Assert.assertTrue(element.getOids().contains(oids[0]));
		Assert.assertTrue(element.getOids().contains(oids[1]));
		Assert.assertTrue(element.getPageIds().contains(pages[0].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[1].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[2].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[3].getPageId()));
		Assert.assertTrue(element.getPageIds().contains(pages[4].getPageId()));
	}
}
