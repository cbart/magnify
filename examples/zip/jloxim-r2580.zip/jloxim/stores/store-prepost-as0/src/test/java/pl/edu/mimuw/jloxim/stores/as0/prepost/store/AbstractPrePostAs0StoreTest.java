/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store;

import org.junit.After;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.EventBus;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.oidpage.OidPageIndex;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.parent.ParentIndex;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.referrer.ReferrerIndex;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.merging.MergingManager;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.DataReader;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.PageOffset;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils.StoreConstants;
import pl.edu.mimuw.jloxim.stores.as0.stream.StreamStoreAS0;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.NodeManager;

public abstract class AbstractPrePostAs0StoreTest {

	private AbstractApplicationContext context;

	public synchronized ApplicationContext getContext() {
		if (context == null) {
			context = new ClassPathXmlApplicationContext("/StorePrePostAs0SpringTest-context.xml");
		}
		return context;
	}

	public StoreAS0 getStore() {
		return (StoreAS0) getContext().getBean("store", StoreAS0.class);
	}

	public StreamStoreAS0 getStreamStore() {
		return (StreamStoreAS0) getContext().getBean("store", StreamStoreAS0.class);
	}

	public TransactionManager getTM() {
		return (TransactionManager) getContext()
		    .getBean("transactionManager", TransactionManager.class);
	}

	public AS0ObjectsFactory getAS0ObjectsFactory() {
		return new pl.edu.mimuw.jloxim.model.as0.impl.rw.AS0ObjectsFactoryImpl();
	}

	public AtomicValueFactory getAtomicValueFactory() {
		return new AtomicValueFactoryImpl();
	}

	@After
	public void cleanContext() {
		if (context != null)
			context.close();
	}

  public PageOffset getPageOffset() {
  	return (PageOffset) getContext().getBean(PageOffset.class);
  }

  public ParentIndex getParentIndex() {
  	return (ParentIndex) getContext().getBean(ParentIndex.class);
  }

  public ReferrerIndex getReferrerIndex() {
  	return (ReferrerIndex) getContext().getBean(ReferrerIndex.class);
  }

  public OidPageIndex getOidPageIndex() {
  	return (OidPageIndex) getContext().getBean(OidPageIndex.class);
  }

  public EventBus getEventBus() {
  	return (EventBus) getContext().getBean(EventBus.class);
  }

  public StoreConstants getConstants() {
  	return (StoreConstants) getContext().getBean(StoreConstants.class);
  }

  public NodeManager getNodeManager() {
  	return (NodeManager) getContext().getBean(NodeManager.class);
  }

	public MergingManager getMergingManager() {
		return (MergingManager) getContext().getBean(MergingManager.class);
	}

  public void iterateAll(DataReader.ObjectCommand command) {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
		iterateAll(t, command);
		t.commit();
  }

  public void iterateAll(Transaction t, DataReader.ObjectCommand command) {
  	Integer pageId;
  	int i = 0;
  	while ((pageId = getPageOffset().getPageFromIndex(t, i++)) != null) {
			getDataReader().iterateAll(t, pageId, command);

  	}
  }

	private DataReader getDataReader() {
		return (DataReader) getContext().getBean(DataReader.class);
	}

	protected void fullPagesDebug(String message) {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_UNCOMMITED);
  	Integer pageId;
  	int i = 0;
  	while ((pageId = getPageOffset().getPageFromIndex(t, i++)) != null) {
  		getDataReader().debug(t, pageId);
		}
		t.commit();
	}
}
