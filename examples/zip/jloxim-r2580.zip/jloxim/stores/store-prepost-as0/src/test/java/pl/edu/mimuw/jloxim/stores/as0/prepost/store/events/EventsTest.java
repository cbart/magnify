/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.events;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.AbstractPrePostAs0StoreTest;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class EventsTest extends AbstractPrePostAs0StoreTest {

  @SuppressWarnings("unused")
  private Logger logger=Logger.getLogger(EventsTest.class);

	private RegisteringSubscriber subscriber;

  public EventBus getEventBus() {
  	return (EventBus) getContext().getBean(EventBus.class);
  }

  @Before
	public void init() {
		subscriber = new RegisteringSubscriber();
		getEventBus().subscribe((NewObjectEvent.Subscriber)subscriber);
		getEventBus().subscribe((ObjectRemoveEvent.Subscriber)subscriber);
		getEventBus().subscribe((ObjectMoveEvent.Subscriber)subscriber);
		getEventBus().subscribe((ObjectTypeOrValueChangeEvent.Subscriber)subscriber);
	}

  @SuppressWarnings("unchecked")
  @Test
  public void newObjectEventTest_simple() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory()
        .newComplexObject(22, Collections.EMPTY_LIST);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    List<NewObjectEvent> newObjectEvents = subscriber.getNewObjectEvents();
    Assert.assertEquals(1, newObjectEvents.size());
    NewObjectEvent event = newObjectEvents.get(0);
    Assert.assertEquals(((LongOid)getStore().getSuperRootOid()).getValue(), event.getParentOid());
    Assert.assertEquals(((LongOid)complex.getOID()).getValue(), event.getOid());
  }

  @Test
  public void newObjectEventTest_complex() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable obj1 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable obj2 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(true));
    AS0ObjectEditable obj3 = getAS0ObjectsFactory().newPointerObject(22,
    		new LongOid(15L));
    AS0ObjectEditable obj4 = getAS0ObjectsFactory() .newEmptyComplexObject(22);
    List<AS0ObjectEditable> subobjects = Arrays.asList(new AS0ObjectEditable[] {obj1, obj2, obj3, obj4});
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory().newComplexObject(22,
    		subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    List<NewObjectEvent> newObjectEvents = subscriber.getNewObjectEvents();
    Assert.assertEquals(5, newObjectEvents.size());
    Set<Long> expectedOids = new HashSet<Long>();
    for (AS0ObjectRO obj : new AS0ObjectRO[] {complex, obj1, obj2, obj3, obj4}) {
    	expectedOids.add(((LongOid)obj.getOID()).getValue());
    }
    long complexOid = ((LongOid)complex.getOID()).getValue();
    for (NewObjectEvent event : newObjectEvents) {
    	Assert.assertTrue(expectedOids.remove(event.getOid()));
    	if (event.getOid() == complexOid) {
    		Assert.assertEquals(((LongOid)getStore().getSuperRootOid()).getValue(),
    				event.getParentOid());
    	} else {
    		Assert.assertEquals(complexOid, event.getParentOid());
    	}
    }
  }

  @Test
  public void removeObjectEventTest_simple() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory().newEmptyComplexObject(22);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().removeObject(t, complex.getOID());
    t.commit();
    List<ObjectRemoveEvent> objectRemoveEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(1, objectRemoveEvents.size());
    ObjectRemoveEvent event = objectRemoveEvents.get(0);
    Assert.assertEquals(((LongOid)complex.getOID()).getValue(), event.getOid());
  }

  @Test
  public void removeObjectEventTest_complex() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable obj1 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable obj2 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(true));
    AS0ObjectEditable obj3 = getAS0ObjectsFactory().newPointerObject(22,
    		new LongOid(15L));
    AS0ObjectEditable obj4 = getAS0ObjectsFactory().newEmptyComplexObject(22);
    List<AS0ObjectEditable> subobjects = Arrays.asList(new AS0ObjectEditable[] {obj1, obj2, obj3, obj4});
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory().newComplexObject(22,
    		subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().removeObject(t, complex.getOID());
    t.commit();
    List<ObjectRemoveEvent> objectRemoveEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(5, objectRemoveEvents.size());
    Set<Long> expectedOids = new HashSet<Long>();
    for (AS0ObjectRO obj : new AS0ObjectRO[] {complex, obj1, obj2, obj3, obj4}) {
    	expectedOids.add(((LongOid)obj.getOID()).getValue());
    }
    for (ObjectRemoveEvent event : objectRemoveEvents) {
    	Assert.assertTrue(expectedOids.remove(event.getOid()));
    }
  }

  @Test
  public void removeObjectEventTest_multiple() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable obj1 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable obj2 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(true));
    AS0ObjectEditable obj3 = getAS0ObjectsFactory().newPointerObject(22,
    		new LongOid(15L));
    AS0ObjectEditable obj4 = getAS0ObjectsFactory() .newEmptyComplexObject(22);
    List<AS0ObjectEditable> subobjects = Arrays.asList(new AS0ObjectEditable[] {obj1, obj2, obj3, obj4});
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory().newComplexObject(22,
    		subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().removeObjects(t, new AbstractOid[] {
    		obj1.getOID(), obj4.getOID(), obj3.getOID(), obj2.getOID()});
    t.commit();
    List<ObjectRemoveEvent> objectRemoveEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(4, objectRemoveEvents.size());
    Set<Long> expectedOids = new HashSet<Long>();
    for (AS0ObjectRO obj : new AS0ObjectRO[] {obj1, obj2, obj3, obj4}) {
    	expectedOids.add(((LongOid)obj.getOID()).getValue());
    }
    for (ObjectRemoveEvent event : objectRemoveEvents) {
    	Assert.assertTrue(expectedOids.remove(event.getOid()));
    }
  }

  @Test
  public void removeObjectEventTest_multipleAndOverlapping() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable obj1 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable obj2 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(true));
    AS0ObjectEditable obj3 = getAS0ObjectsFactory().newPointerObject(22,
    		new LongOid(15L));
    AS0ObjectEditable obj4 = getAS0ObjectsFactory() .newEmptyComplexObject(22);
    List<AS0ObjectEditable> subobjects = Arrays.asList(new AS0ObjectEditable[] {obj1, obj2, obj3, obj4});
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory().newComplexObject(22,
    		subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().removeObjects(t, new AbstractOid[] {
    		obj1.getOID(), obj4.getOID(), complex.getOID(), obj3.getOID(), obj2.getOID()});
    t.commit();
    List<ObjectRemoveEvent> objectRemoveEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(5, objectRemoveEvents.size());
    Set<Long> expectedOids = new HashSet<Long>();
    for (AS0ObjectRO obj : new AS0ObjectRO[] {complex, obj1, obj2, obj3, obj4}) {
    	expectedOids.add(((LongOid)obj.getOID()).getValue());
    }
    for (ObjectRemoveEvent event : objectRemoveEvents) {
    	Assert.assertTrue(expectedOids.remove(event.getOid()));
    }
  }

  @Test
  public void moveObjectEventTest_simple() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable ab = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable a = getAS0ObjectsFactory().newComplexObject(11, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().moveObject(t, ab.getOID(), getStore().getSuperRootOid());
    t.commit();
    Assert.assertTrue(subscriber.getObjectRemoveEvents().isEmpty());
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectTypeChangedEvents().isEmpty());
    List<ObjectMoveEvent> objectMoveEvents = subscriber.getObjectMoveEvents();
    Assert.assertEquals(1, objectMoveEvents.size());
    ObjectMoveEvent event = objectMoveEvents.get(0);
    Assert.assertEquals(((LongOid) ab.getOID()).getValue(), event.getOid());
    Assert.assertEquals(((LongOid) getStore().getSuperRootOid()).getValue(), event.getNewParentOid());
  }

  @Test
  public void moveObjectEventTest_complex() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable abcd = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable abc = getAS0ObjectsFactory().newComplexObject(11, Collections.singleton(abcd));
    AS0ObjectEditable abe = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue("lol"));
    AS0ObjectEditable ab = getAS0ObjectsFactory().newComplexObject(11, Arrays.asList(abc, abe));
    AS0ObjectEditable a = getAS0ObjectsFactory().newComplexObject(11, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().moveObject(t, ab.getOID(), getStore().getSuperRootOid());
    t.commit();
    Assert.assertTrue(subscriber.getObjectRemoveEvents().isEmpty());
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectTypeChangedEvents().isEmpty());
    List<ObjectMoveEvent> objectMoveEvents = subscriber.getObjectMoveEvents();
    Assert.assertEquals(1, objectMoveEvents.size());
    ObjectMoveEvent event = objectMoveEvents.get(0);
    Assert.assertEquals(((LongOid) ab.getOID()).getValue(), event.getOid());
    Assert.assertEquals(((LongOid) getStore().getSuperRootOid()).getValue(), event.getNewParentOid());
  }

  @Test
  public void setAtomicObjectValueEventTest_basic() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable a = getAS0ObjectsFactory().newEmptyComplexObject(22);
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AtomicValue value = getAtomicValueFactory().newAtomicValue("lol");
		getStore().setAtomicObjectValue(t, a.getOID(), value);
    t.commit();
    Assert.assertTrue(subscriber.getObjectRemoveEvents().isEmpty());
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());
    List<ObjectTypeOrValueChangeEvent> events = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, events.size());
    ObjectTypeOrValueChangeEvent event = events.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0AtomicObjectRO);
    Assert.assertEquals(22, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());
    Assert.assertEquals(value, ((AS0AtomicObjectRO)event.getNewObject()).getValue());
  }

  @Test
  public void setAtomicObjectValueEventTest_subobjectsRemoveEvents() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable abcd = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable abc = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(abcd));
    AS0ObjectEditable abe = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue("lol"));
    AS0ObjectEditable ab = getAS0ObjectsFactory().newComplexObject(22, Arrays.asList(abc, abe));
    AS0ObjectEditable a = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AtomicValue value = getAtomicValueFactory().newAtomicValue("lol");
		getStore().setAtomicObjectValue(t, a.getOID(), value);
    t.commit();
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());

    List<ObjectTypeOrValueChangeEvent> typeChangeEvents = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, typeChangeEvents.size());
    ObjectTypeOrValueChangeEvent event = typeChangeEvents.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0AtomicObjectRO);
    Assert.assertEquals(22, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());
    Assert.assertEquals(value, ((AS0AtomicObjectRO)event.getNewObject()).getValue());

    List<ObjectRemoveEvent> removeEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(4, removeEvents.size());
    List<AbstractOid> oids = new ArrayList<AbstractOid>();
    oids.addAll(Arrays.asList(abcd.getOID(), abc.getOID(), abe.getOID(), ab.getOID()));
    for (ObjectRemoveEvent e : removeEvents) {
    	Assert.assertTrue(oids.remove(e.getObject().getOID()));
    }
  }

  @Test
  public void setNewPointerObjectDestination_basic() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable a = getAS0ObjectsFactory().newEmptyComplexObject(11);
    AS0ObjectEditable b = getAS0ObjectsFactory().newEmptyComplexObject(22);
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    getStore().addSubobject(t, getStore().getSuperRootOid(), b);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		getStore().setNewPointerObjectDestination(t, a.getOID(), b.getOID());
    t.commit();
    Assert.assertTrue(subscriber.getObjectRemoveEvents().isEmpty());
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());
    List<ObjectTypeOrValueChangeEvent> events = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, events.size());
    ObjectTypeOrValueChangeEvent event = events.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(11, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0PointerObjectRO);
    Assert.assertEquals(11, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());
    Assert.assertEquals(b.getOID(), ((AS0PointerObjectRO)event.getNewObject()).getDestinationOID());
  }

  @Test
  public void setNewPointerObjectDestination_subobjectsRemoveEvents() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable abcd = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable abc = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(abcd));
    AS0ObjectEditable abe = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue("lol"));
    AS0ObjectEditable ab = getAS0ObjectsFactory().newComplexObject(22, Arrays.asList(abc, abe));
    AS0ObjectEditable a = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(ab));
    AS0ObjectEditable x = getAS0ObjectsFactory().newEmptyComplexObject(22);
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    getStore().addSubobject(t, getStore().getSuperRootOid(), x);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		getStore().setNewPointerObjectDestination(t, a.getOID(), x.getOID());
    t.commit();
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());

    List<ObjectTypeOrValueChangeEvent> typeChangeEvents = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, typeChangeEvents.size());
    ObjectTypeOrValueChangeEvent event = typeChangeEvents.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0PointerObjectRO);
    Assert.assertEquals(22, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());
    Assert.assertEquals(x.getOID(), ((AS0PointerObjectRO)event.getNewObject()).getDestinationOID());

    List<ObjectRemoveEvent> removeEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(4, removeEvents.size());
    List<AbstractOid> oids = new ArrayList<AbstractOid>();
    oids.addAll(Arrays.asList(abcd.getOID(), abc.getOID(), abe.getOID(), ab.getOID()));
    for (ObjectRemoveEvent e : removeEvents) {
    	Assert.assertTrue(oids.remove(e.getObject().getOID()));
    }
  }

  @Test
  public void setNewComplexObjectValueEventTest_basic() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable a = getAS0ObjectsFactory().newAtomicObject(22,
    		getAtomicValueFactory().newAtomicValue("lol"));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		getStore().setNewComplexObjectValue(t, a.getOID(), Collections.<AS0ObjectEditable>emptyList());
    t.commit();
    Assert.assertTrue(subscriber.getObjectRemoveEvents().isEmpty());
    Assert.assertTrue(subscriber.getNewObjectEvents().isEmpty());
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());
    List<ObjectTypeOrValueChangeEvent> events = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, events.size());
    ObjectTypeOrValueChangeEvent event = events.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0AtomicObjectRO);
    Assert.assertEquals(22, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());
  }

  @Test
  public void setNewComplexObjectValueEventTest_complex() {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable abc1 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17));
    AS0ObjectEditable ab1 = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(abc1));
    AS0ObjectEditable a = getAS0ObjectsFactory().newComplexObject(22, Collections.singleton(ab1));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    t.commit();
    subscriber.clear();
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable abc2 = getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue("lol"));
    AS0ObjectEditable ab2 = getAS0ObjectsFactory().newComplexObject(22, Arrays.asList(abc2));
		getStore().setNewComplexObjectValue(t, a.getOID(), Collections.singleton(ab2));
    t.commit();
    Assert.assertTrue(subscriber.getObjectMoveEvents().isEmpty());
    List<ObjectTypeOrValueChangeEvent> events = subscriber.getObjectTypeChangedEvents();
    Assert.assertEquals(1, events.size());
    ObjectTypeOrValueChangeEvent event = events.get(0);

    Assert.assertTrue(event.getOldObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getOldObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getOldObject().getOID());

    Assert.assertTrue(event.getNewObject() instanceof AS0ComplexObjectRO);
    Assert.assertEquals(22, event.getNewObject().getNameId());
    Assert.assertEquals(a.getOID(), event.getNewObject().getOID());

    List<ObjectRemoveEvent> removeEvents = subscriber.getObjectRemoveEvents();
    Assert.assertEquals(2, removeEvents.size());
    List<AbstractOid> oids = new ArrayList<AbstractOid>();
    oids.addAll(Arrays.asList(ab1.getOID(), abc1.getOID()));
    for (ObjectRemoveEvent e : removeEvents) {
    	Assert.assertTrue(oids.remove(e.getObject().getOID()));
    }

    List<NewObjectEvent> newObjEvents = subscriber.getNewObjectEvents();
    Assert.assertEquals(2, removeEvents.size());
    oids = new ArrayList<AbstractOid>();
    oids.addAll(Arrays.asList(ab2.getOID(), abc2.getOID()));
    for (NewObjectEvent e : newObjEvents) {
    	Assert.assertTrue(oids.remove(new LongOid(e.getOid())));
    }
	}
}
