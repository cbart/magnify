/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.tables;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.impl.ro.AS0AtomicObjectROImpl;
import pl.edu.mimuw.jloxim.model.as0.impl.values.IntegerAtomicValueImpl;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.AbstractPrePostAs0StoreTest;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.datasections.ListBasedPageSizeDataSection;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.datasections.PageSizeDataSection;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.datasections.SectionNode;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.objects.As0ComplexObjectROImpl;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.PathSplitter;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils.ObjectLocation;

public class PathSplitterTest extends AbstractPrePostAs0StoreTest {

	// Applies only to path vectors!
	private static final Comparator<List<Integer>> PATH_VECTOR_COMPARATOR = new Comparator<List<Integer>>() {
		@Override
    public int compare(List<Integer> o1, List<Integer> o2) {
	    return o1.get(0).compareTo(o2.get(0));
    }
	};

	private static abstract class WritableNodeMock implements SectionNode {

		private int level;
		private AS0ObjectRO object;

		public WritableNodeMock(int level, AS0ObjectRO object) {
			this.level = level;
			this.object = object;
    }

		@Override
    public int getLevel() {
	    return level;
    }

		@Override
    public AS0ObjectRO getObject() {
	    return object;
    }

		@Override
    public int getSize() {
	    return 1;
    }

		@Override
    public ObjectLocation getOriginalObjectLocation() {
	    return null;
    }

		@Override
    public SectionNode getParentNode() {
	    return null;
    }

		@Override
		public boolean isEmptyTuplesNode() {
		  return false;
		}
	}

	private static class WritableNodeMockComplex extends WritableNodeMock {
		public WritableNodeMockComplex(int level, final int nameId) {
			super(level, new As0ComplexObjectROImpl(nameId, null, null));
    }
	}

	private static class WritableNodeMockAtomic extends WritableNodeMock {
		public WritableNodeMockAtomic(int level, final int nameId) {
			super(level, new AS0AtomicObjectROImpl(null, nameId, null, new IntegerAtomicValueImpl(29)));
    }
	}

	public PathSplitter getPathSplitter() {
		return (PathSplitter) getContext().getBean(PathSplitter.class);
	}

	@Test
	public void splitPathsTest_empty() {
		List<SectionNode> nodeList = Collections.emptyList();
		PageSizeDataSection emptySegment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(emptySegment);
		Assert.assertTrue(splitPaths.isEmpty());
	}

  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_simple1() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(0, 12),
				(SectionNode) new WritableNodeMockComplex(1, 19),
				(SectionNode) new WritableNodeMockComplex(1, 19));
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(Arrays.asList(0), Arrays.asList(1, 2)));
	}

  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_simple2() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(0, 0),  // 0
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 1
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 2
				(SectionNode) new WritableNodeMockComplex(2, 22), // 3
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 4
				(SectionNode) new WritableNodeMockComplex(1, 11), // 5
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 6
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 7
				(SectionNode) new WritableNodeMockComplex(2, 22), // 8
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 9
				(SectionNode) new WritableNodeMockComplex(2, 2)); // 10
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(
						Arrays.asList(0),
						Arrays.asList(1, 6),
						Arrays.asList(5),
						Arrays.asList(2, 7, 10),
						Arrays.asList(3, 8),
						Arrays.asList(4, 9)));
	}

  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_sameNamesOnDifferentPaths() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(0, 1),  // 0
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 1
				(SectionNode) new WritableNodeMockComplex(2, 1),  // 2
				(SectionNode) new WritableNodeMockComplex(2, 1),  // 3
				(SectionNode) new WritableNodeMockComplex(3, 1),  // 4
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 5
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 6
				(SectionNode) new WritableNodeMockComplex(2, 1),  // 7
				(SectionNode) new WritableNodeMockComplex(2, 1),  // 8
				(SectionNode) new WritableNodeMockComplex(3, 1),  // 9
				(SectionNode) new WritableNodeMockComplex(2, 1)); // 10
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(
						Arrays.asList(0),
						Arrays.asList(1, 5, 6),
						Arrays.asList(2, 3, 7, 8, 10),
						Arrays.asList(4, 9)));
	}

  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_absentRootSimple() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 0
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 1
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 2
				(SectionNode) new WritableNodeMockComplex(2, 2)); // 3
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(
						Arrays.asList(0),
						Arrays.asList(1, 3),
						Arrays.asList(2)));
	}


  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_absentRootComplex() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 0
				(SectionNode) new WritableNodeMockComplex(2, 22), // 1
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 2
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 3
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 4
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 5
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 6
				(SectionNode) new WritableNodeMockComplex(1, 1),  // 7
				(SectionNode) new WritableNodeMockComplex(2, 22), // 8
				(SectionNode) new WritableNodeMockComplex(3, 3),  // 9
				(SectionNode) new WritableNodeMockComplex(2, 2),  // 10
				(SectionNode) new WritableNodeMockComplex(3, 3)); // 11
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(
						Arrays.asList(0),
						Arrays.asList(1),
						Arrays.asList(2),
						Arrays.asList(3, 7),
						Arrays.asList(4, 10),
						Arrays.asList(5, 6, 11),
						Arrays.asList(8),
						Arrays.asList(9)));
	}

  @Test
	@SuppressWarnings("unchecked")
	public void splitPathsTest_differentTypeSameName() {
		List<SectionNode> nodeList = Arrays.asList(
				(SectionNode) new WritableNodeMockComplex(1, 1), // 0
				(SectionNode) new WritableNodeMockComplex(2, 2), // 1
				(SectionNode) new WritableNodeMockAtomic(2, 2),  // 2
				(SectionNode) new WritableNodeMockComplex(1, 1), // 3
				(SectionNode) new WritableNodeMockComplex(2, 2), // 4
				(SectionNode) new WritableNodeMockAtomic(2, 2)); // 5
		PageSizeDataSection segment = new ListBasedPageSizeDataSection(nodeList);
		List<List<Integer>> splitPaths = getPathSplitter().splitPaths(segment);
		assertPathVectorsEquals(splitPaths,
				Arrays.asList(
						Arrays.asList(0, 3),
						Arrays.asList(1, 4),
						Arrays.asList(2, 5)));
	}

	// Utility method + its tests

  @Test
	@SuppressWarnings("unchecked")
	public void equalityUtilityTest_simple() {
		List<List<Integer>> list1 = Arrays.asList(Arrays.asList(1), Arrays.asList(2));
		List<List<Integer>> list2 = Arrays.asList(Arrays.asList(1), Arrays.asList(2));
		assertPathVectorsEquals(list1, list2);
	}

  @Test
	@SuppressWarnings("unchecked")
	public void equalityUtilityTest() {
		List<List<Integer>> list1 = Arrays.asList(Arrays.asList(1, 3), Arrays.asList(2, 4), Arrays.asList(0, 5));
		List<List<Integer>> list2 = Arrays.asList(Arrays.asList(0, 5), Arrays.asList(2, 4), Arrays.asList(1, 3));
		assertPathVectorsEquals(list1, list2);
	}

  @Test(expected = AssertionFailedError.class)
	@SuppressWarnings("unchecked")
	public void equalityUtilityTest_failed() {
		List<List<Integer>> list1 = Arrays.asList(Arrays.asList(1), Arrays.asList(2, 3));
		List<List<Integer>> list2 = Arrays.asList(Arrays.asList(1, 3), Arrays.asList(2));
		assertPathVectorsEquals(list1, list2);
	}

	private void assertPathVectorsEquals(List<List<Integer>> pv1, List<List<Integer>> pv2) {
		Collections.sort(pv1, PATH_VECTOR_COMPARATOR);
		Collections.sort(pv2, PATH_VECTOR_COMPARATOR);

		Assert.assertEquals(pv1, pv2);
	}
}
