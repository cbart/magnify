/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.events;

import java.util.ArrayList;
import java.util.List;

public class RegisteringSubscriber implements NewObjectEvent.Subscriber,
		ObjectRemoveEvent.Subscriber, ObjectTypeOrValueChangeEvent.Subscriber,
		ObjectMoveEvent.Subscriber {

	private List<NewObjectEvent> newObjectEvents = new ArrayList<NewObjectEvent>();
	private List<ObjectRemoveEvent> objectRemoveEvents = new ArrayList<ObjectRemoveEvent>();
	private List<ObjectTypeOrValueChangeEvent> objectTypeChangedEvents = new ArrayList<ObjectTypeOrValueChangeEvent>();
	private List<ObjectMoveEvent> objectMoveEvents = new ArrayList<ObjectMoveEvent>();

	@Override
  public void onNewObject(NewObjectEvent event) {
	  newObjectEvents.add(event);
  }

	@Override
  public void onObjectRemove(ObjectRemoveEvent event) {
	  objectRemoveEvents.add(event);
  }

	@Override
  public void onObjectTypeOrValueChange(ObjectTypeOrValueChangeEvent event) {
		objectTypeChangedEvents.add(event);
  }

	@Override
  public void onObjectMove(ObjectMoveEvent event) {
	  objectMoveEvents.add(event);
  }

	public List<NewObjectEvent> getNewObjectEvents() {
  	return newObjectEvents;
  }

	public List<ObjectRemoveEvent> getObjectRemoveEvents() {
  	return objectRemoveEvents;
  }

	public List<ObjectTypeOrValueChangeEvent> getObjectTypeChangedEvents() {
  	return objectTypeChangedEvents;
  }

	public List<ObjectMoveEvent> getObjectMoveEvents() {
  	return objectMoveEvents;
  }

	public void clear() {
		newObjectEvents.clear();
		objectRemoveEvents.clear();
		objectTypeChangedEvents.clear();
		objectMoveEvents.clear();
	}
}
