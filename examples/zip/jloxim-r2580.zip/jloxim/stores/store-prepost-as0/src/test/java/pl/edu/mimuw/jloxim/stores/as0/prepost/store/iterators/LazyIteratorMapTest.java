/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.iterators;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.AbstractPrePostAs0StoreTest;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

public class LazyIteratorMapTest extends AbstractPrePostAs0StoreTest {

	@Test
	public void multipleNames() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		int num = 100;
		int names = 13;
		Map<Integer, List<AbstractOid>> map = new HashMap<Integer, List<AbstractOid>>();
		for (int i = 0; i < names; i++) {
			map.put(i, new ArrayList<AbstractOid>());
		}

		for (int i = 0; i < num; i++) {
			int name = i % names;
			AS0ComplexObjectEditable newEmptyComplexObject = getAS0ObjectsFactory().newEmptyComplexObject(name);
			getStore().addSubobject(t, getStore().getSuperRootOid(), newEmptyComplexObject);
			map.get(name).add(newEmptyComplexObject.getOID());
		}
		Map<Integer, ClosableIterator<AbstractOid>> rootsMap = getStore().getRootsMap(t);

		for (int i = 0; i < names / 2; i++) {
			ClosableIterator<AbstractOid> it = rootsMap.get(i);
			while (it.hasNext()) {
				Assert.assertTrue(map.get(i).remove(it.next()));
			}
			Assert.assertTrue(map.get(i).isEmpty());
		}

		Assert.assertFalse(rootsMap.isEmpty());
		Assert.assertEquals(names, rootsMap.size());

		for (int i = 0; i < names; i++) {
		  Assert.assertTrue(rootsMap.containsKey(i));
		}

		for (int i = names; i < names + 5; i++) {
		  Assert.assertFalse(rootsMap.containsKey(i));
		  Assert.assertNull(rootsMap.get(i));
		}

		for (int i = names / 2; i < names; i++) {
			ClosableIterator<AbstractOid> it = rootsMap.get(i);
			while (it.hasNext()) {
				Assert.assertTrue(map.get(i).remove(it.next()));
			}
			Assert.assertTrue(map.get(i).isEmpty());
		}
		t.commit();
	}

	@Test
	public void initialState() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		Map<Integer, ClosableIterator<AbstractOid>> rootsMap = getStore().getRootsMap(t);

		Assert.assertEquals(0, rootsMap.size());
		Assert.assertTrue(rootsMap.isEmpty());
		Assert.assertTrue(rootsMap.keySet().isEmpty());
		Assert.assertTrue(rootsMap.entrySet().isEmpty());
		Assert.assertNull(rootsMap.get(0));
		Assert.assertNull(rootsMap.get(1));
		Assert.assertNull(rootsMap.get(2));

		t.commit();
	}
}
