/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

public class PrePostAs0StoreSpecificTests extends AbstractPrePostAs0StoreTest {

  @Test
	public void testAddGetRemoveMultipageAtomicTextObject() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

		// create 20 long strings
		int num = 20;
		List<String> strings = new ArrayList<String>();
		for (int i = 0; i < num; i++) {
			StringBuilder builder = new StringBuilder();
			for (int j = 0; j < i + 300; j++) {
				builder.append(" Prepost test " + i);
			}
			strings.add(builder.toString());
		}

		// Add Strings as atomic objects
		for (String s : strings) {
			AS0AtomicObjectEditable newObject = getAS0ObjectsFactory().newAtomicObject(21,
					getAtomicValueFactory().newAtomicValue(s));
			getStore().addSubobject(t, getStore().getSuperRootOid(), newObject);
		}

		List<AbstractOid> toRemove = new ArrayList<AbstractOid>();

		Set<String> set = new HashSet<String>();
		Set<String> set2 = new HashSet<String>();
		set.addAll(strings);

		ClosableIterator<AbstractOid> subobjectOIDs =
			getStore().getSubobjectOIDs(t, getStore().getSuperRootOid());
		// Check all objects were added properly
		while (subobjectOIDs.hasNext()) {
			AbstractOid oid = subobjectOIDs.next();

			AS0ObjectRO o = getStore().getObjectByOID(t, oid);

			Assert.assertTrue(o instanceof AS0AtomicObjectRO);

			AS0AtomicObjectRO ao = (AS0AtomicObjectRO) o;

			Assert.assertTrue(ao.getNameId() == 21);
			Assert.assertTrue(((LongOid) ao.getOID()).getValue() == ((LongOid) oid).getValue());
			Assert.assertTrue(((LongOid) ao.getParentOID()).getValue() == 0);
			Assert.assertTrue(ao.getValue() instanceof TextAtomicValue);
			String value = ((TextAtomicValue)ao.getValue()).getValue();
			// mark 3/4 of all objects as to be removed
			if (strings.indexOf(value) % 4 < 3) {
				toRemove.add(oid);
			} else {
				set2.add(value);
			}
			Assert.assertTrue(set.remove(value));
		}
		Assert.assertTrue(set.isEmpty());

		// remove 3/4 of all objects
		for (AbstractOid oid : toRemove) {
			getStore().removeObject(t, oid);
		}

		subobjectOIDs = getStore().getSubobjectOIDs(t, getStore().getSuperRootOid());
		// check that only remaining 1/4 objects are still there
		while (subobjectOIDs.hasNext()) {
			AbstractOid oid = subobjectOIDs.next();

			AS0ObjectRO o = getStore().getObjectByOID(t, oid);

			Assert.assertTrue(o instanceof AS0AtomicObjectRO);

			AS0AtomicObjectRO ao = (AS0AtomicObjectRO) o;

			Assert.assertTrue(ao.getNameId() == 21);
			Assert.assertTrue(((LongOid) ao.getOID()).getValue() == ((LongOid) oid).getValue());
			Assert.assertTrue(((LongOid) ao.getParentOID()).getValue() == 0);
			Assert.assertTrue(ao.getValue() instanceof TextAtomicValue);
			String value = ((TextAtomicValue)ao.getValue()).getValue();
			Assert.assertTrue(set2.remove(value));
		}
		Assert.assertTrue(set2.isEmpty());
		t.commit();
	}

  @Test
	public void mixedTextAndBinaryObjects() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

		List<AbstractOid> texts = new ArrayList<AbstractOid>();
		List<AbstractOid> binaries = new ArrayList<AbstractOid>();
		for (int i = 0; i < 100; i++) {
			AtomicValue value = i % 2 == 0
			    ? getAtomicValueFactory().newAtomicValue("jloxim " + i)
			    : getAtomicValueFactory().newAtomicValue(new byte[] {(byte) i, (byte) i, (byte) i, (byte) i});
			AS0AtomicObjectEditable newObject = getAS0ObjectsFactory().newAtomicObject(21, value);
			getStore().addSubobject(t, getStore().getSuperRootOid(), newObject);
			(i % 2 == 0 ? texts : binaries).add(newObject.getOID());
		}

		t.commit();
		t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		int longOid = 0;
		for (AbstractOid oid : texts) {
			AS0AtomicObjectRO object = (AS0AtomicObjectRO) getStore().getObjectByOID(t, oid);
			TextAtomicValue value = (TextAtomicValue) object.getValue();
			Assert.assertEquals("jloxim " + longOid, value.getValue());
			longOid += 2;
		}
		longOid = 1;
		for (AbstractOid oid : binaries) {
			AS0AtomicObjectRO object = (AS0AtomicObjectRO) getStore().getObjectByOID(t, oid);
			BinaryAtomicValue value = (BinaryAtomicValue) object.getValue();
			byte[] bytes = value.getValue();
			Assert.assertEquals(4, bytes.length);
			for (int i = 0; i < 4; i++) {
				Assert.assertEquals((byte) longOid, bytes[i]);
			}
			longOid += 2;
		}
		t.commit();
	}


  @Test
	public void testAddAndGetAtomicBinaryObject() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
		int length = 5000;
		byte[] bytes = new byte[length];
		for (int i = 0; i < length; i++) {
			bytes[i] = (byte)(i % 133 + i % 79);
		}
		AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(21,
				getAtomicValueFactory().newAtomicValue(bytes));
		getStore().addSubobject(t, getStore().getSuperRootOid(), object);
		AS0ObjectRO objectByOID = getStore().getObjectByOID(t, object.getOID());

		BinaryAtomicValue val = (BinaryAtomicValue)((AS0AtomicObjectRO)objectByOID).getValue();
		byte[] bytes2 = val.getValue();

		Assert.assertEquals(length, bytes2.length);
		for (int i = 0; i < length; i++) {
			Assert.assertEquals(bytes[i], bytes2[i]);
		}

		t.commit();
	}

  @Test
	public void testAddGetMultipleTextObjects() {
		Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

		int numOfComplex = 100;
		char lastLetter = 'h';

		List<AbstractOid> addedComplexObjects = new ArrayList<AbstractOid>();
		Set<Character> chars = new HashSet<Character>();
		// create 100 complex objects as subobjects of super root
		for (int i = 0; i <= numOfComplex; i++) {
			AS0ComplexObjectEditable co = getAS0ObjectsFactory().newEmptyComplexObject(i);
			getStore().addSubobject(t, getStore().getSuperRootOid(), co);
			addedComplexObjects.add(co.getOID());
		}

		// add "name+letter" to all complex objects
		// first, add a to each one, then b, etc.
		// this one is for forcing a lot of page splitting, object shifting etc.
		for (char c = 'a'; c < lastLetter; c++) {
			chars.add(c);
			for (int i = 0; i < addedComplexObjects.size(); i++) {
				AS0AtomicObjectEditable obj = getAS0ObjectsFactory().newAtomicObject(1000,
						getAtomicValueFactory().newAtomicValue("" + i + c));
				getStore().addSubobject(t, addedComplexObjects.get(i), obj);
			}
		}
		t.commit();
		t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

		ClosableIterator<AbstractOid> complexObjs =
			getStore().getSubobjectOIDs(t, getStore().getSuperRootOid());

		// for each complex object check that it contains all expected subobjects
		while (complexObjs.hasNext()) {
			AbstractOid oid = complexObjs.next();
			Assert.assertTrue(addedComplexObjects.remove(oid));

			AS0ObjectRO co = getStore().getObjectByOID(t, oid);
			int name = co.getNameId();

			Set<Character> localChars = new HashSet<Character>();
			localChars.addAll(chars);

			ClosableIterator<AbstractOid> textObjs =
				getStore().getSubobjectOIDs(t, oid);

			while (textObjs.hasNext()) {
				AbstractOid textOid = textObjs.next();
				AS0ObjectRO textObj = getStore().getObjectByOID(t, textOid);

				Assert.assertTrue(textObj instanceof AS0AtomicObjectRO);

				AtomicValue val = ((AS0AtomicObjectRO) textObj).getValue();

				Assert.assertTrue(val instanceof TextAtomicValue);

				String s = ((TextAtomicValue) val).getValue();

				Assert.assertTrue(s.length() > 0);

				char lastChar = s.charAt(s.length() - 1);

				Assert.assertTrue(localChars.remove(lastChar));

				String nameStr = s.substring(0, s.length() - 1);
				int nameFromStr = Integer.parseInt(nameStr);

				Assert.assertEquals(name, nameFromStr);
			}

			Assert.assertTrue(localChars.isEmpty());
		}

		Assert.assertTrue(addedComplexObjects.isEmpty());

		t.commit();
  }

  @Test
  public void testPageMerging() throws InterruptedException {

    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

    List<AbstractOid> oidsToRemove = new ArrayList<AbstractOid>();
    Set<AbstractOid> oidsToKeep = new HashSet<AbstractOid>();
    for (int i = 0; i < 1000; i++) {
    	AS0ComplexObjectEditable object = getAS0ObjectsFactory().newEmptyComplexObject(20);
    	getStore().addSubobject(t, getStore().getSuperRootOid(), object);
    	if (i % 20 == 0) {
    		oidsToKeep.add(object.getOID());
    	} else {
    		oidsToRemove.add(object.getOID());
    	}
    }
    int pageCount = getPageOffset().getPageCount(t);
    t.commit();


    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    getStore().removeObjects(t, oidsToRemove.toArray(new AbstractOid[0]));
    t.commit();

    Thread.sleep(3000);

    // For reasonably small page sizes it should work well,
    // but note it might fail someday if tested with huge page size.
    t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    Assert.assertTrue(getPageOffset().getPageCount(t) + "<=" + pageCount,
        getPageOffset().getPageCount(t) <= pageCount);
    ClosableIterator<AbstractOid> subobjectOIDs =
    	getStore().getSubobjectOIDs(t, getStore().getSuperRootOid());
    while(subobjectOIDs.hasNext()) {
    	Assert.assertTrue(oidsToKeep.remove(subobjectOIDs.next()));
    }
    Assert.assertTrue(oidsToKeep.isEmpty());
    t.commit();
  }

  //@Test
  public void concurrentWritingTest() throws Throwable {
  	List<RememberExceptionThread> threads = new ArrayList<RememberExceptionThread>();
  	// btree fails
  	int threadsNum = 1;
  	final int objsPerThread = 50;
  	for (int i = 0; i < threadsNum; i++) {
  		final int name = i;
  		threads.add( new RememberExceptionThread("Thread " + name) {
	      @Override
	      public void runWithException() throws TransactionManagerException,
	          StoreException, TransactionException {
	        TransactionManager tm = getTM();
	        Transaction t = tm
	            .newTransaction(TransactionIsolationLevel.READ_COMMITED);
        	System.out.println("T" + name + ", starts");
	        try{
	        	AbstractOid parentOid = getStore().getSuperRootOid();
	          for (int i = 0; i < objsPerThread; i++) {
	          	AS0ComplexObjectEditable object =
	          		  getAS0ObjectsFactory().newEmptyComplexObject(name);
	            getStore().addSubobject(t, parentOid, object);
	          	System.out.println("T" + name + ", adds " + i + " oid=" + ((LongOid) object.getOID()).getValue());
	            parentOid = object.getOID();
	            Thread.yield();
	          }
	        }finally{
          	System.out.println("T" + name + ", commits");
	          t.commit();
	        }
	      }
	    });
  	}
  	for (Thread t : threads) {
  		t.start();
  	}
  	for (Thread t : threads) {
  		t.join();
  	}
  	for (RememberExceptionThread t : threads) {
      if (!t.isSuccessful()) {
      	t.getName();
        throw t.getThrownException();
      }
  	}
  }
}
