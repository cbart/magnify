/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils;

import java.nio.ByteBuffer;

import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValue;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.entry.TransBtreeValueBinding;

public class LongValueBinding implements TransBtreeValueBinding<Long> {

  @Override
  public void objectToRawValue(Long object, TransBtreeValue entry) {
    byte[] byteArray = new byte[8];
    ByteBuffer data = ByteBuffer.wrap(byteArray);
    data.putLong(0, object == null ? 0 : object);
    entry.setData(byteArray, 0, byteArray.length);
  }

  @Override
  public Long rawValueToObject(TransBtreeValue entry) {
    ByteBuffer data = ByteBuffer.wrap(entry.getData());
	  return data.getLong(0);
  }
}
