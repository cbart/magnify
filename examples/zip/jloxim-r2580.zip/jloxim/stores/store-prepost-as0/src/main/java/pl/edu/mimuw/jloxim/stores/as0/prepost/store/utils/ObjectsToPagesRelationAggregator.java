/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.IndexAwarePageId;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ObjectsToPagesRelationAggregator {

	boolean aggregated = false;

	public static class ResultElement {
		private List<LongOid> oids;
		private List<Integer> pageIds;

		public ResultElement(List<LongOid> oids, List<Integer> pageIds) {
	    super();
	    this.oids = oids;
	    this.pageIds = pageIds;
    }

		public List<LongOid> getOids() {
    	return oids;
    }

		public List<Integer> getPageIds() {
    	return pageIds;
    }
	}

	private static class OidPageListPair implements Comparable<OidPageListPair>{
		public LongOid oid;
		public List<IndexAwarePageId> pages;

		public OidPageListPair(LongOid oid, List<IndexAwarePageId> pages) {
	    super();
	    this.oid = oid;
	    this.pages = pages;
    }

		@Override
    public int compareTo(OidPageListPair o) {
	    return pages.get(0).getIndex() - o.pages.get(0).getIndex();
    }
	}

	private List<OidPageListPair> pairs = new ArrayList<OidPageListPair>();

	public void add(LongOid oid, List<IndexAwarePageId> pages) {
		if (!pages.isEmpty()) {
			pairs.add(new OidPageListPair(oid, pages));
		}
	}

	public List<ResultElement> extractResult() {
		if (aggregated) {
			throw new IllegalStateException("Result can be extracted only once");
		}
		aggregated = true;

		Collections.sort(pairs);

		SortedMap<IndexAwarePageId, List<LongOid>> pageToOids =
			new TreeMap<IndexAwarePageId, List<LongOid>>();

		for (OidPageListPair pair : pairs) {
			LongOid oid = pair.oid;
			List<IndexAwarePageId> pages = pair.pages;
			Iterator<IndexAwarePageId> iterator = pages.iterator();

			IndexAwarePageId firstPage = iterator.next();
			List<LongOid> list = pageToOids.get(firstPage);
			if (list == null) {
				list = new ArrayList<LongOid>();
				list.add(oid);
				pageToOids.put(firstPage, list);
			} else {
				list.add(oid);
			}

			while (iterator.hasNext()) {
				IndexAwarePageId page = iterator.next();
				List<LongOid> list2 = pageToOids.get(page);
				if (list2 != list) {
					if (list2 != null) {
						list.addAll(list2);
					}
					pageToOids.put(page, list);
				}
			}
		}

		List<ResultElement> results = new ArrayList<ResultElement>();
		List<Integer> pages = new ArrayList<Integer>();
		List<LongOid> previousOids = null;
		for (Entry<IndexAwarePageId, List<LongOid>> entry : pageToOids.entrySet()) {
			if (previousOids != null && previousOids != entry.getValue()) {
				results.add(new ResultElement(previousOids, pages));
				pages = new ArrayList<Integer>();
			}
			pages.add(entry.getKey().getPageId());
			previousOids = entry.getValue();
		}
		results.add(new ResultElement(previousOids, pages));
		return results;
	}
}
