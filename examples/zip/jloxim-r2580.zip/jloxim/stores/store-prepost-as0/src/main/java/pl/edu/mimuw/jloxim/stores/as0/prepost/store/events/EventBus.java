/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.events;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class EventBus {

  private List<NewObjectEvent.Subscriber> newObjectEventSubscribers = new ArrayList<NewObjectEvent.Subscriber>();
  private List<ObjectPageShiftEvent.Subscriber> objectPageShiftEventSubscribers = new ArrayList<ObjectPageShiftEvent.Subscriber>();
  private List<ObjectRemoveEvent.Subscriber> objectRemoveEventSubscribers = new ArrayList<ObjectRemoveEvent.Subscriber>();
  private List<ObjectTypeOrValueChangeEvent.Subscriber> newPointerEventSubscribers = new ArrayList<ObjectTypeOrValueChangeEvent.Subscriber>();
  private List<ObjectMoveEvent.Subscriber> objectMoveEventSubscribers = new ArrayList<ObjectMoveEvent.Subscriber>();

  public void publish(NewObjectEvent event) {
    for (NewObjectEvent.Subscriber subscriber : newObjectEventSubscribers) {
      subscriber.onNewObject(event);
    }
  }

  public void publish(ObjectPageShiftEvent event) {
    for (ObjectPageShiftEvent.Subscriber subscriber : objectPageShiftEventSubscribers) {
      subscriber.onObjectPageShift(event);
    }
  }

  public void publish(ObjectRemoveEvent event) {
  	for (ObjectRemoveEvent.Subscriber subscriber : objectRemoveEventSubscribers) {
  		subscriber.onObjectRemove(event);
  	}
  }

  public void publish(ObjectTypeOrValueChangeEvent event) {
  	for (ObjectTypeOrValueChangeEvent.Subscriber subscriber : newPointerEventSubscribers) {
  		subscriber.onObjectTypeOrValueChange(event);
  	}
  }

  public void publish(ObjectMoveEvent event) {
  	for (ObjectMoveEvent.Subscriber subscriber : objectMoveEventSubscribers) {
  		subscriber.onObjectMove(event);
  	}
  }

  public void subscribe(NewObjectEvent.Subscriber subscriber) {
    newObjectEventSubscribers.add(subscriber);
  }

  public void subscribe(ObjectPageShiftEvent.Subscriber subscriber) {
    objectPageShiftEventSubscribers.add(subscriber);
  }

  public void subscribe(ObjectRemoveEvent.Subscriber subscriber) {
    objectRemoveEventSubscribers.add(subscriber);
  }

  public void subscribe(ObjectTypeOrValueChangeEvent.Subscriber subscriber) {
    newPointerEventSubscribers.add(subscriber);
  }

  public void subscribe(ObjectMoveEvent.Subscriber subscriber) {
  	objectMoveEventSubscribers.add(subscriber);
  }
}
