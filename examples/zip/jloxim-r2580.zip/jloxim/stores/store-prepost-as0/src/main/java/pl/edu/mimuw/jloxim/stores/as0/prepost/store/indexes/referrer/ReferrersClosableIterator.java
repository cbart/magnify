/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.referrer;

import java.util.Map;
import java.util.NoSuchElementException;

import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ReferrersClosableIterator implements ClosableIterator<LongOid> {

	private ClosableIterator<? extends Map.Entry<ReferrerIndexKey, ReferrerIndexValue>> realIterator;
	LongOid oId;
	private LongOid nextReferrerOid;
	private boolean end;

	public ReferrersClosableIterator(
	    ClosableIterator<? extends Map.Entry<ReferrerIndexKey, ReferrerIndexValue>> realIterator,
	    LongOid oId) {
		this.realIterator = realIterator;
		this.oId = oId;
		this.end = false;
	}

	public void close() {
		realIterator.close();
	}

	public boolean hasNext() {
		if (end == true) {
			return false;
		}

		if (nextReferrerOid != null)
			return true;

		if (realIterator.hasNext()) {
			Map.Entry<ReferrerIndexKey, ReferrerIndexValue> value = realIterator.next();
			if (value.getKey().getOid().compareTo(oId) == 0) {
				nextReferrerOid = value.getKey().getReferrerOid();
				return true;
			}
		}

		end = true;
		return false;
	}

	public LongOid next() {
		if (hasNext()) {
			LongOid ret = nextReferrerOid;
			nextReferrerOid = null;
			return ret;
		}
		throw new NoSuchElementException("The cursor have no more items.");
	}

	public void remove() {
		realIterator.remove();
	}
}
