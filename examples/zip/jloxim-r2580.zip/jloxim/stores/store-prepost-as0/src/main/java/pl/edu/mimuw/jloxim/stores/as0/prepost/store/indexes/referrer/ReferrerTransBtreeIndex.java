/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.referrer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;

import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.TransBtree;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.NodeManager;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.basic.node.RootNode;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.TransBtreeException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ReferrerTransBtreeIndex extends AbstractReferrerIndex {

	@Autowired private NodeManager nodeManager;
  private TransBtree<ReferrerIndexKey, ReferrerIndexValue> index;

	public TransBtree<ReferrerIndexKey, ReferrerIndexValue> getIndex() {
  	return index;
  }

	public void setIndex(TransBtree<ReferrerIndexKey, ReferrerIndexValue> index) {
  	this.index = index;
  }

  @Override
  protected List<AbstractOid> get(Transaction t, LongOid oid) {
    try {
      ReferrerIndexKey key = new ReferrerIndexKey(oid, new LongOid(0));
      ClosableIterator<? extends Entry<ReferrerIndexKey, ReferrerIndexValue>> it1 = index.find(t, key);
      ReferrersClosableIterator it2 = new ReferrersClosableIterator(it1, oid);
      List<AbstractOid> list = new ArrayList<AbstractOid>();
      try {
        while (it2.hasNext()) {
          list.add(it2.next());
        }
      } finally {
        it2.close();
      }
      return list;
    } catch (InterruptedOperationTransBtreeException ex) {
      throw new InterruptedStoreOperationException("prepost", ex);
    } catch (TransBtreeException ex) {
      throw new StoreException("prepost", ex);
    }
  }

  @Override
  protected void put(Transaction t, LongOid oid, LongOid destination) {
    ReferrerIndexKey key = new ReferrerIndexKey(destination, oid);
    try {
      index.put(t, key, ReferrerIndexValue.EMPTY);
    } catch (InterruptedOperationTransBtreeException ex) {
      throw new InterruptedStoreOperationException("prepost", ex);
    } catch (TransBtreeException ex) {
      throw new StoreException("prepost", ex);
    }
  }

	@Override
  protected void remove(Transaction t, LongOid oid, LongOid destination) {
    ReferrerIndexKey referrerIndexKey = new ReferrerIndexKey(destination, oid);
    try {
      index.remove(t, referrerIndexKey);
    } catch (InterruptedOperationTransBtreeException ex) {
      throw new InterruptedStoreOperationException("prepost", ex);
    } catch (TransBtreeException ex) {
      throw new StoreException("prepost", ex);
    }
  }
        
  @Override
  public void init(Transaction t) {
    RootNode referrerIndexRootNode = nodeManager.newRootNode(t);
    referrerIndexRootNode.write();
    index.setRootPageId(referrerIndexRootNode.getId());
  }
}
