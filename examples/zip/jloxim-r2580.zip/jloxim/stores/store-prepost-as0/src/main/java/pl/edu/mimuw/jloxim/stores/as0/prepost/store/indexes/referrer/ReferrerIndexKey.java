/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.referrer;

import java.nio.ByteBuffer;

import pl.edu.mimuw.jloxim.utils.api.SerializableIntoBuffer;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class ReferrerIndexKey implements SerializableIntoBuffer, Comparable<ReferrerIndexKey> {

	private LongOid oId;
	private LongOid referrerOid;

	public ReferrerIndexKey(LongOid oId, LongOid referrerOid) {
		this.oId = oId;
		this.referrerOid = referrerOid;
	}

	public ReferrerIndexKey() {
		oId = new LongOid(0L);
		referrerOid = new LongOid(0L);
	}

	public LongOid getOid() {
		return oId;
	}

	public void setoId(LongOid oId) {
		this.oId = oId;
	}

	public LongOid getReferrerOid() {
		return referrerOid;
	}

	public void setReferrerOid(LongOid referrerOid) {
		this.referrerOid = referrerOid;
	}

	@Override
	public int serializeInto(ByteBuffer data) {
		oId.serializeInto(data);
		referrerOid.serializeInto(data);
		return serializableLength();
	}

	@Override
	public int deserialize(ByteBuffer data) {
		oId.deserialize(data);
		referrerOid.deserialize(data);
		return serializableLength();
	}

	@Override
	public int serializableLength() {
		return oId.serializableLength() + referrerOid.serializableLength();
	}

	@Override
	public int compareTo(ReferrerIndexKey key) {
		int ret = this.oId.compareTo(key.oId);
		if (ret != 0)
			return ret;

		return this.referrerOid.compareTo(key.referrerOid);
	}

	@Override
	public String toString() {
		return "oId:" + oId + " referrerOid:" + referrerOid;
	}

}
