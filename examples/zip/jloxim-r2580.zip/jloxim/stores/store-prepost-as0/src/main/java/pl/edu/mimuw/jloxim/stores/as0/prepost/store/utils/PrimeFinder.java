/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils;

import java.util.ArrayList;
import java.util.List;

public class PrimeFinder {

	private int border = 1;
	private List<Integer> primes = new ArrayList<Integer>();

	public int findBiggestPrimeLessOrEqTo(int x) {
		if (x <= 1) {
			throw new IllegalArgumentException();
		}
		initTo(x);
		for (int i = x;; i--) {
			if (checkPrime(i)) {
				return i;
			}
		}
	}

	private boolean checkPrime(int x) {
		for (int p : primes) {
			if (p * p > x) {
				return true;
			} else {
				if (x % p == 0) {
					return false;
				}
			}
		}
		return true;
	}

	private void initTo(int x) {
		int newBorder = (int) Math.sqrt(x);
		for (int i = border + 1; i <= newBorder; i++) {
			if (checkPrime(i)) {
				primes.add(i);
			}
		}
		border = newBorder;
	}
}
