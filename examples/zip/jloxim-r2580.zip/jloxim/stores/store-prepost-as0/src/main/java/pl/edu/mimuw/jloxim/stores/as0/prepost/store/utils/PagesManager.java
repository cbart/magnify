/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.BufferUsePurpose;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransBufferspace;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransBufferspaceManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionBufferPage;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionInterruptedException;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.stores.utils.trans_btree.exceptions.InterruptedOperationTransBtreeException;

public class PagesManager {
	private final static Logger logger = Logger.getLogger(PagesManager.class);

	private String bufferSpaceName;
	private TransBufferspaceManager transBufferspaceManager;

	private TransBufferspace transBufferspace;
	private TransactionBufferManager transactionBufferManager;

	public void init() {
		logger.info("init");
		assert bufferSpaceName != null;
		this.transBufferspace = transBufferspaceManager.getBufferspace(bufferSpaceName);
	}

	public String getBufferSpaceName() {
		return bufferSpaceName;
	}

	public void setBufferSpaceName(String bufferSpaceName) {
		this.bufferSpaceName = bufferSpaceName;
	}

	public TransBufferspaceManager getTransBufferspaceManager() {
		return transBufferspaceManager;
	}

	public void setTransBufferspaceManager(TransBufferspaceManager transBufferspaceManager) {
		this.transBufferspaceManager = transBufferspaceManager;
	}

	public TransBufferspace getTransBufferspace() {
		return transBufferspace;
	}

	public void setTransBufferspace(TransBufferspace transBufferspace) {
		this.transBufferspace = transBufferspace;
	}

	public TransactionBufferManager getTransactionBufferManager() {
		return transactionBufferManager;
	}

	public void setTransactionBufferManager(TransactionBufferManager transactionBufferManager) {
		this.transactionBufferManager = transactionBufferManager;
	}

	public TransactionBufferPage allocatePage(Transaction t) {          
          try {
            return transactionBufferManager.allocateBuffer(transBufferspace, t);
          } catch (TransactionInterruptedException ex) {
            throw new InterruptedStoreOperationException("prepost", ex);
          } catch (TransactionException ex) {
            throw new StoreException("prepost", ex);
          }
	}

	public TransactionBufferPage getPage(Transaction t, int pageID, BufferUsePurpose usePurpose) {
          try {
	    return transactionBufferManager.getBuffer(transBufferspace, t, pageID, usePurpose);
          } catch (TransactionInterruptedException ex) {
            throw new InterruptedStoreOperationException("prepost", ex);
          } catch (TransactionException ex) {
            throw new StoreException("prepost", ex);
          }
	}

	public int getPageBodySize() {
		return transBufferspace.getTransBufferspaceMetadata().getPageBodySize();
	}
}
