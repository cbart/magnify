/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.indexes.referrer;

import java.util.Collections;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.EventBus;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.NewObjectEvent;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.ObjectRemoveEvent;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.events.ObjectTypeOrValueChangeEvent;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public abstract class AbstractReferrerIndex implements ReferrerIndex {

  @Autowired private EventBus eventBus;

  @PostConstruct
  public void init() {
		eventBus.subscribe((NewObjectEvent.Subscriber) this);
		eventBus.subscribe((ObjectTypeOrValueChangeEvent.Subscriber) this);
		eventBus.subscribe((ObjectRemoveEvent.Subscriber) this);
  }

	@Override
  public List<AbstractOid> getReferrers(Transaction t, LongOid oid) {
		List<AbstractOid> list  = get(t, oid);
		return list == null ? Collections.<AbstractOid>emptyList() : list;
  }

	@Override
  public void onObjectTypeOrValueChange(ObjectTypeOrValueChangeEvent event) {
		if (event.getOldObject() instanceof AS0PointerObjectRO) {
			AS0PointerObjectRO pointer = (AS0PointerObjectRO) event.getOldObject();
			remove(event.getTransaction(), (LongOid) pointer.getOID(),
					(LongOid) pointer.getDestinationOID());
		}
		if (event.getNewObject() instanceof AS0PointerObjectRO) {
			AS0PointerObjectRO pointer = (AS0PointerObjectRO) event.getNewObject();
			put(event.getTransaction(), (LongOid) pointer.getOID(),
					(LongOid) pointer.getDestinationOID());
		}
  }

	@Override
  public void onNewObject(NewObjectEvent event) {
		if (event.getObject() instanceof AS0PointerObjectRO) {
			AS0PointerObjectRO pointer = (AS0PointerObjectRO) event.getObject();
			put(event.getTransaction(), (LongOid) pointer.getOID(),
					(LongOid) pointer.getDestinationOID());
		}
  }

	@Override
  public void onObjectRemove(ObjectRemoveEvent event) {
		if (event.getObject() instanceof AS0PointerObjectRO) {
			AS0PointerObjectRO pointer = (AS0PointerObjectRO) event.getObject();
			remove(event.getTransaction(), (LongOid) pointer.getOID(), (LongOid) pointer.getDestinationOID());
		}
  }

	protected abstract void remove(Transaction t, LongOid oid, LongOid destination);
	protected abstract void put(Transaction t, LongOid oid, LongOid destination);
	protected abstract List<AbstractOid> get(Transaction t, LongOid oid);
}
