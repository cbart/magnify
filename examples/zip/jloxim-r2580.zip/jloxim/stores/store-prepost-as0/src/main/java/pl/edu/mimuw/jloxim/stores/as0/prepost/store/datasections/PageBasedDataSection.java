/**
 * Copyright 2011 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.as0.prepost.store.datasections;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.nodestructure.EmptyTuplesNode;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.nodestructure.InternalNode;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.objects.ObjectType;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.LogicalPage;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.StructuralPage;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.physical.ValuesPage;
import pl.edu.mimuw.jloxim.stores.as0.prepost.store.utils.ObjectLocation;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public class PageBasedDataSection implements PageSizeDataSection, RandomAccessDataSection, DataSectionWithOrigin {

	private StructuralPage sPage;
	private ValuesPage vPage;
	private int size;
	private List<SectionNode> lazyList;
	private int filledTuplesCount;
	private LogicalPage pages;

  public PageBasedDataSection(LogicalPage pages) {
  	this.pages = pages;
	  this.sPage = pages.getStructuralPage();
	  this.vPage = pages.getValuesPage();
	  int unusedTuplesCount = sPage.getUnusedTuplesCount();
	  this.filledTuplesCount = sPage.getFilledTuplesCount();
	  this.size =  filledTuplesCount + (unusedTuplesCount > 0 ? 1 : 0);
	  this.lazyList = Arrays.asList(new SectionNode[size]);
  }

	public StructuralPage getSPage() {
  	return sPage;
  }

	public ValuesPage getVPage() {
  	return vPage;
  }

	public AS0ObjectRO getObject(int offset, LongOid parentOid) {
    if (sPage.getLevelAt(offset) == StructuralPage.NULL_LEVEL_VALUE) {
      return null;
    }
    byte typeIndex = vPage.getTypeAt(offset);
    ObjectType type = ObjectType.getTypeFromIndex(typeIndex);
    return type.parse(pages, offset, parentOid);
  }

	@Override
  public SectionNode get(int index) {
	  initElement(index);
	  return lazyList.get(index);
  }

	@Override
  public int size() {
	  return size;
  }

	@Override
  public Iterator<SectionNode> iterator() {
	  return new Iterator<SectionNode>() {
	  	int index = 0;

			@Override
      public boolean hasNext() {
	      return index < size;
      }

			@Override
      public SectionNode next() {
				if (hasNext()) {
					return get(index++);
				} else {
					throw new NoSuchElementException();
				}
      }

			@Override
      public void remove() {
				throw new UnsupportedOperationException();
      }
		};
  }

	@Override
  public int getFilledTuplesCount() {
	  return filledTuplesCount;
  }

	private void initElement(int index) {
		if (lazyList.get(index) == null) {
			SectionNode sectionNode;
			if (index < filledTuplesCount) {
				sectionNode = new InternalNode(
						sPage.getLevelAt(index), getObject(index, null), sPage.getSizeAt(index),
						new ObjectLocation(sPage.getPageId(), index));
			} else {
				sectionNode = new EmptyTuplesNode(null, sPage.getSizeAt(index));
			}
			lazyList.set(index, sectionNode);
		}
	}

	@Override
  public List<Integer> getOriginPageIds() {
	  return Arrays.asList(sPage.getPageId());
  }
}
