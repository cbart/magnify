/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import junit.framework.Assert;

import org.junit.Test;

public class BoolAtomicValueImplTest {
  @Test
  public void constructorTest()
  {
    BoolAtomicValueImpl x = new BoolAtomicValueImpl(true);
    Assert.assertEquals(x.getValue().toString(), "true");
    Assert.assertTrue(x.getValue()==true);
    
    BoolAtomicValueImpl y = new BoolAtomicValueImpl(false);
    Assert.assertEquals(y.getValue().toString(), "false");
    Assert.assertTrue(y.getValue()==false);
    
    Assert.assertEquals(x instanceof BoolAtomicValueImpl, true);
    Assert.assertEquals(x.hashCode(), 1262);

  }

  @Test
  public void compareBoolTest(){
    BoolAtomicValueImpl x = new BoolAtomicValueImpl(true);
    BoolAtomicValueImpl y = new BoolAtomicValueImpl(false);
    BoolAtomicValueImpl z = new BoolAtomicValueImpl(true);
    BoolAtomicValueImpl a = new BoolAtomicValueImpl(false);

    Assert.assertEquals(x, z);
    Assert.assertEquals(y, a);
    Assert.assertEquals(x.toString(), z.toString());
    Assert.assertTrue(x.compareTo(x)==0);
    Assert.assertTrue(x.compareTo(z)==0);
    Assert.assertTrue(x.compareTo(a)==1);
    Assert.assertTrue(y.compareTo(z)==-1);
  }
  
  @Test
  public void compareNumberTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(7754.99);
    IntegerAtomicValueImpl j = new IntegerAtomicValueImpl(8545);
    LongAtomicValueImpl k = new LongAtomicValueImpl(567764);
    BoolAtomicValueImpl x = new BoolAtomicValueImpl(true);
    try{
      Assert.assertTrue(x.compareTo(i)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare BooleanAtomicValue with DoubleAtomicValueImpl.", ex.getMessage());
    }
    try{
      Assert.assertTrue(x.compareTo(j)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare BooleanAtomicValue with IntegerAtomicValueImpl.", ex.getMessage());
    }
    try{
      Assert.assertTrue(x.compareTo(k)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare BooleanAtomicValue with LongAtomicValueImpl.", ex.getMessage());
    }
  }
  
  @Test
  public void nullCompareTest(){
    BoolAtomicValueImpl x = new BoolAtomicValueImpl(true);
    try{
      Assert.assertTrue(x.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare BooleanAtomicValue with null.", ex.getMessage());
    }
  }
}
