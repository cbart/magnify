/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import junit.framework.Assert;
import junit.framework.AssertionFailedError;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;

public class IntegerAtomicValueImplTest {
  @Test
  public void constructorTest()
  {
    IntegerAtomicValueImpl i = new IntegerAtomicValueImpl(1);
    Assert.assertEquals(i.getValue().toString(), "1");
    Assert.assertTrue(i.getValue()==1);
    
    Assert.assertEquals(i instanceof IntegerAtomicValueImpl, true);
    Assert.assertEquals(i instanceof IntegerAtomicValue, true);
    Assert.assertEquals(i instanceof LongAtomicValue, false);
    Assert.assertEquals(i instanceof DoubleAtomicValue, false);
    Assert.assertEquals(i.hashCode(), 32);

  }

  @Test
  public void compareIntTest(){
    IntegerAtomicValueImpl i = new IntegerAtomicValueImpl(1);
    IntegerAtomicValueImpl j = new IntegerAtomicValueImpl(1);
    IntegerAtomicValueImpl k = new IntegerAtomicValueImpl(2);
    IntegerAtomicValueImpl l = new IntegerAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertEquals(i.toString(), j.toString());
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
  }

  @Test
  public void compareLongTest(){
    LongAtomicValueImpl i = new LongAtomicValueImpl(1);
    IntegerAtomicValueImpl j = new IntegerAtomicValueImpl(1);
    IntegerAtomicValueImpl k = new IntegerAtomicValueImpl(2);
    IntegerAtomicValueImpl l = new IntegerAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
  }


  @Test
  public void compareDoubleTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(1.0);
    IntegerAtomicValueImpl j = new IntegerAtomicValueImpl(1);
    IntegerAtomicValueImpl k = new IntegerAtomicValueImpl(2);
    IntegerAtomicValueImpl l = new IntegerAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
    
    try{
      Assert.assertEquals(i, k);
      Assert.fail();
    }
    catch (AssertionFailedError ex)
    {
      return;
    }
  }
  
  @Test
  public void nullCompareTest(){
    IntegerAtomicValueImpl x = new IntegerAtomicValueImpl(12345);
    try{
      Assert.assertTrue(x.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare IntegerAtomicValue with null.", ex.getMessage());
    }
  }
}
