/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;

import org.junit.Test;


public class TextAtomicValueImplTest {
    
    
  @Test
  public void constructorTest()
  {
    TextAtomicValueImpl i = new TextAtomicValueImpl("ala");
    Assert.assertEquals(i.getValue().toString(), "ala");
    Assert.assertTrue(i.getValue()=="ala");
    
    Assert.assertEquals(i instanceof TextAtomicValueImpl, true);
    Assert.assertEquals(i instanceof TextAtomicValueImpl, true);
    Assert.assertEquals(i.hashCode(), 96693);
  }
  
  @Test
  public void compareStringTest(){
    TextAtomicValueImpl i = new TextAtomicValueImpl("ala");
    TextAtomicValueImpl j = new TextAtomicValueImpl("ala");
    TextAtomicValueImpl k = new TextAtomicValueImpl("ca");
    TextAtomicValueImpl l = new TextAtomicValueImpl("a");
    
    Assert.assertEquals(i, j);
    Assert.assertEquals(i.toString(), j.toString());
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)<0);
    Assert.assertTrue(i.compareTo(l)>0);
  }
  
  @Test
  public void compareString2Test(){
    TextAtomicValueImpl i = new TextAtomicValueImpl("ala");
    TextAtomicValueImpl j = new TextAtomicValueImpl("ala");
    TextAtomicValueImpl k = new TextAtomicValueImpl("ca");
    
    Assert.assertEquals(i, j);
    try{
    Assert.assertEquals(i, k);
    Assert.fail();
    }
    catch (AssertionFailedError ex)
    {
      return;
    }
  }
  
  @Test
  public void compareIntegerTest(){
    TextAtomicValueImpl i = new TextAtomicValueImpl("ala");
    TextAtomicValueImpl j = new TextAtomicValueImpl("ala");
    IntegerAtomicValueImpl k = new IntegerAtomicValueImpl(9);
    Assert.assertEquals(i, j);
    try{
    Assert.assertEquals(i, k);
    Assert.fail();
    }
    catch (AssertionFailedError ex)
    {
      return;
    }
  }
  
  @Test
  public void compareDoubleTest(){
    TextAtomicValueImpl i = new TextAtomicValueImpl("texxtttttt..............");
    TextAtomicValueImpl j = new TextAtomicValueImpl("texxtttttt..............");
    DoubleAtomicValueImpl k = new DoubleAtomicValueImpl(1.0);
    Assert.assertEquals(i, j);
    Assert.assertTrue(i.equals(i)==true);
    Assert.assertTrue(i.equals(j)==true);
    Assert.assertTrue(i.equals(k)==false);
    try{
    Assert.assertEquals(i, k);
    Assert.fail();
    }
    catch (AssertionFailedError ex)
    {
      return;
    }
  }
  @Test
  public void nullCompareTest(){
    TextAtomicValueImpl x = new TextAtomicValueImpl("test");
    try{
      Assert.assertTrue(x.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare TextAtomicValue with null.", ex.getMessage());
    }
  }
}
