/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;

public class LongAtomicValueImplTest {

  @Test
  public void constructorTest()
  {
    LongAtomicValueImpl i = new LongAtomicValueImpl(1);
    Assert.assertEquals(i.getValue().toString(), "1");
    Assert.assertTrue(i.getValue()==1);
    
    Assert.assertEquals(i instanceof LongAtomicValueImpl, true);
    Assert.assertEquals(i instanceof LongAtomicValueImpl, true);
    Assert.assertEquals(i instanceof IntegerAtomicValue, false);
    Assert.assertEquals(i instanceof DoubleAtomicValue, false);
    Assert.assertEquals(i.hashCode(), 32);

  }

  @Test
  public void compareLongTest(){
    LongAtomicValueImpl i = new LongAtomicValueImpl(1);
    LongAtomicValueImpl j = new LongAtomicValueImpl(1);
    LongAtomicValueImpl k = new LongAtomicValueImpl(2);
    LongAtomicValueImpl l = new LongAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertEquals(i.toString(), j.toString());
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
  }
  
  @Test
  public void txtCompareTest(){
    LongAtomicValueImpl i = new LongAtomicValueImpl(45764356);
    TextAtomicValueImpl txt = new TextAtomicValueImpl("test");
    try{
      Assert.assertTrue(i.compareTo(txt)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare LongAtomicValue with TextAtomicValue.", ex.getMessage());
    }
  }
  
  @Test
  public void nullCompareTest(){
    LongAtomicValueImpl x = new LongAtomicValueImpl(123456);
    try{
      Assert.assertTrue(x.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare LongAtomicValue with null.", ex.getMessage());
    }
  }
}
