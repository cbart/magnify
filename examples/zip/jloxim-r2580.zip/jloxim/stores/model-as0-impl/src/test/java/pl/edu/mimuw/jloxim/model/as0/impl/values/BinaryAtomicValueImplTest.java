/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import java.util.Arrays;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;


public class BinaryAtomicValueImplTest {
  @Test
  public void constructorTest()
  {
    byte[] buf=new byte[10];
    for (int i=0;i<10;i++){
      buf[i]= 1;
    }
    
    BinaryAtomicValueImpl i = new BinaryAtomicValueImpl(buf);
    BinaryAtomicValueImpl j = new BinaryAtomicValueImpl(buf);
    Assert.assertTrue(Arrays.equals(i.getValue(), buf));
    
    Assert.assertEquals(i, j);
    Assert.assertEquals(i instanceof BinaryAtomicValue, true);

  }

  @Test
  public void compareTest(){
    //medium 1100
    byte[] buf= new byte[4];
    buf[0]= 1; buf[1]= 1; buf[2]= 0; buf[3]= 0;
    //medium 1100
    byte[] buf2= new byte[4];
    buf2[0]= 1; buf2[1]= 1; buf2[2]= 0; buf2[3]= 0;

    //minimum  1000
    byte[] buf3= new byte[4];
    buf3[0]= 1; buf3[1]= 0; buf3[2]= 0; buf3[3]= 0;
    
    //max 1111
    byte[] buf4=new byte[4];
    buf4[0]= 1; buf4[1]= 1; buf4[2]= 1; buf4[3]= 1;
    
    BinaryAtomicValueImpl i = new BinaryAtomicValueImpl(buf);
    BinaryAtomicValueImpl j = new BinaryAtomicValueImpl(buf2);
    BinaryAtomicValueImpl k = new BinaryAtomicValueImpl(buf3);
    BinaryAtomicValueImpl l = new BinaryAtomicValueImpl(buf4);
    
    Assert.assertTrue(i.compareTo(i)== 0);
    Assert.assertTrue(i.compareTo(j)==  0);
    //max > min
    Assert.assertTrue(l.compareTo(k)==  1);
    //max > medium
    Assert.assertTrue(l.compareTo(i)==  1);
    //medium > min
    Assert.assertTrue(j.compareTo(k)==  1);
    //medium < max
    Assert.assertTrue(j.compareTo(l)==  -1);
  }
  
  @Test
  public void compareLengthTest(){

    byte[] buf= new byte[10];
    byte[] buf2= new byte[6];
    byte[] buf3=new byte[1];

    
    BinaryAtomicValueImpl i = new BinaryAtomicValueImpl(buf);
    BinaryAtomicValueImpl j = new BinaryAtomicValueImpl(buf2);
    BinaryAtomicValueImpl k = new BinaryAtomicValueImpl(buf3);

    
    Assert.assertTrue(i.compareTo(j)== 1);
    Assert.assertTrue(i.compareTo(k)== 1);
    
    Assert.assertTrue(j.compareTo(k)== 1);
    Assert.assertTrue(j.compareTo(i)== -1);
    
    Assert.assertTrue(k.compareTo(i)== -1);
    Assert.assertTrue(k.compareTo(j)== -1);
  }
  
  @Test
  public void nullCompareTest(){
    byte[] buf=new byte[10];
    for (int i=0;i<10;i++){
      buf[i]= 1;
    }
    
    BinaryAtomicValueImpl b = new BinaryAtomicValueImpl(buf);
    try{
      Assert.assertTrue(b.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare BinaryAtomicValue with null.", ex.getMessage());
    }
  }
  
  
  public void assertCompare(byte[] a1, byte[] a2, int expectedValue){
    BinaryAtomicValueImpl ba1=new BinaryAtomicValueImpl(a1);
    BinaryAtomicValueImpl ba2=new BinaryAtomicValueImpl(a2);
    Assert.assertEquals("Expected "+new String(a1)+(expectedValue<0?'<':(expectedValue>0?'>':'='))+new String(a2), expectedValue, ba1.compareTo(ba2));
    Assert.assertEquals("Expected "+new String(a1)+(expectedValue<0?'>':(expectedValue>0?'<':'='))+new String(a2), -expectedValue, ba2.compareTo(ba1));
  }
  
  @Test
  public void compareTests(){
    assertCompare("abc".getBytes(), "abc".getBytes(), 0);
    assertCompare("ab".getBytes(), "abc".getBytes(), -1);
  }
  
  @Test
  public void toStringShortTest(){
    Assert.assertEquals("(binary)'abc'", new BinaryAtomicValueImpl("abc".getBytes()).toString());
  }
  
  @Test
  public void toStringLongTest(){
    Assert.assertEquals("(binary)'abced123xy...'", new BinaryAtomicValueImpl("abced123xyzble".getBytes()).toString());
  }
}
