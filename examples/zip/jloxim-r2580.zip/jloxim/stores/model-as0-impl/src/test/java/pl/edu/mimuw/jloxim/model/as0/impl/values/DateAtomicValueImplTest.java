/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import java.util.GregorianCalendar;

import junit.framework.Assert;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;

public class DateAtomicValueImplTest {

  @Test
  public void constructorTest()
  {
    DateAtomicValueImpl d = new DateAtomicValueImpl();
    Assert.assertTrue(d.getValue()==null);
    Assert.assertEquals(d instanceof DateAtomicValue, true);
    Assert.assertEquals(d.hashCode(), 31);
    
    GregorianCalendar calendar = new GregorianCalendar(2009, 5, 5, 12, 00, 0);
    DateAtomicValueImpl date = new DateAtomicValueImpl(calendar);
    Assert.assertEquals(date.getValue().getTime(), calendar.getTime());
    Assert.assertEquals(date instanceof DateAtomicValue, true);
  }

  @Test
  public void compareIntTest(){
    GregorianCalendar calendar = new GregorianCalendar(2009, 5, 5, 12, 00, 0);
    DateAtomicValueImpl date = new DateAtomicValueImpl(calendar);
    GregorianCalendar calendar2 = new GregorianCalendar(2009, 3, 6, 12, 00, 0);
    DateAtomicValueImpl date2 = new DateAtomicValueImpl(calendar2);
    GregorianCalendar calendar3 = new GregorianCalendar(2010, 9, 5, 9, 00, 0);
    DateAtomicValueImpl date3 = new DateAtomicValueImpl(calendar3);
    GregorianCalendar calendar4 = new GregorianCalendar(2010, 9, 5, 9, 00, 0);
    DateAtomicValueImpl date4 = new DateAtomicValueImpl(calendar4);
    
    Assert.assertEquals(date, date);
    Assert.assertEquals(calendar, date.getValue());
    Assert.assertTrue(date.compareTo(date)==0);
    Assert.assertTrue(date.compareTo(date2)==1);
    Assert.assertTrue(date.compareTo(date3)==-1);
    Assert.assertTrue(date3.compareTo(date4)==0);
    Assert.assertTrue(date != date4);
    Assert.assertEquals(date3, date4);
  }
  
  @Test
  public void txtCompareTest(){
    GregorianCalendar calendar = new GregorianCalendar(2009, 5, 5, 12, 00, 0);
    DateAtomicValueImpl date = new DateAtomicValueImpl(calendar);
    TextAtomicValueImpl txt = new TextAtomicValueImpl("test");
    try{
      Assert.assertTrue(date.compareTo(txt)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare DateAtomicValue with TextAtomicValueImpl.", ex.getMessage());
    }
  }
  
  @Test
  public void nullCompareTest(){
    GregorianCalendar calendar = new GregorianCalendar(2009, 5, 5, 12, 00, 0);
    DateAtomicValueImpl date = new DateAtomicValueImpl(calendar);
    try{
      Assert.assertTrue(date.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare DateAtomicValue with null.", ex.getMessage());
    }
  }
}

