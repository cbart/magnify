/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.impl.values.AtomicValueFactoryImpl;

/**
 * 
 * @author ptab
 *
 */
public class ResultsetComparatorTest {
  private AtomicValueFactory avf=new AtomicValueFactoryImpl();
  private AS0ResultsetFactory resultsetFactory=new AS0ResultsetFactoryImpl();

  @Test
  public void testEqualsString() {
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
  }
  
  @Test
  public void testEqualsString2() {
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), resultsetFactory.createAtomic(avf.newAtomicValue("123")));  
  }
  
  @Test
  public void testEqualsNumbers1() {
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue(-4)), resultsetFactory.createAtomic(avf.newAtomicValue(4000)));  
  }
  
  @Test
  public void testEqualsNumbers2() {
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue(-4)), resultsetFactory.createAtomic(avf.newAtomicValue(-4.0)));  
  }
  
  @Test
  public void testEqualsNumbers3() {
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue(5)), resultsetFactory.createAtomic(avf.newAtomicValue(5)));  
  }
  
  @Test
  public void testEqualsNumbers4() {
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue(123)), resultsetFactory.createAtomic(avf.newAtomicValue(123)));  
  }
  
  @Test
  public void testEqualsEmptyBag() {
    assertResultsEquals(AS0ResultsetBagImpl.EMPTY_BAG_READ_ONLY, AS0ResultsetBagImpl.EMPTY_BAG_READ_ONLY);  
  }
  
  @Test
  public void testEqualsEmptyBag2() {
    AS0ResultsetBag b=resultsetFactory.createAtomic(avf.newAtomicValue("Napis")).wrapAsBag();
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b);  
  }
  
  @Test
  public void testEqualsEmptyBag3() {
    AS0ResultsetBag.Builder b=resultsetFactory.createBagBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b.build());  
  }

  @Test
  public void testEqualsEmptyStruct() {
    assertResultsEquals(new AS0ResultsetStructImpl(), new AS0ResultsetStructImpl());  
  }
  
  @Test
  public void testEqualsEmptyStruct2() {
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b.build());  
  }
  
  @Test
  public void testEqualsEmptyStruct3() {
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b.build());  
  }
  
  @Test
  public void testEqualsEmptySequence() {
    assertResultsEquals(new AS0ResultsetSequenceImpl(), new AS0ResultsetSequenceImpl());  
  }
  
  @Test
  public void testEqualsEmptySequence2() {
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b.build());  
  }
  
  @Test
  public void testEqualsEmptySequence3() {
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsNotEquals(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")), b.build());  
  }
  
  @Test
  public void testEqualsEmptySequence4() {
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    assertResultsEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsMixSequence() {
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    assertResultsNotEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsSequence() {
    Date date=new Date();
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetSequence.Builder c = resultsetFactory.createSequenceBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    
    assertResultsEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsSequenceN() {
    Date date=new Date();
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetSequence.Builder c = resultsetFactory.createSequenceBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    
    assertResultsNotEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsSequenceN2() {
    Date date=new Date();
    AS0ResultsetSequence.Builder b = resultsetFactory.createSequenceBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetSequence.Builder c = resultsetFactory.createSequenceBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));    
    
    assertResultsNotEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsBagN2() {
    Date date=new Date();
    AS0ResultsetBag.Builder b = resultsetFactory.createBagBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetBag.Builder c = resultsetFactory.createBagBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));    
    
    assertResultsEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsStructN2() {
    Date date=new Date();
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createBinder(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)), 16));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createBinder(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)), 16));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));    
    
    assertResultsEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsStructN2min() {
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createBinder(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)), 16));
    
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createBinder(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)), 16));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));    
    
    assertResultsEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsStructN3() {
    Date date=new Date();
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));    
    
    assertResultsNotEquals(c.build(), b.build());  
  }
  
  @Test
  public void testEqualsStructN4() {
    Date date=new Date();
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));
    
    AS0ResultsetStruct.Builder c = resultsetFactory.createStructBuilder();
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(2.0)));
    c.add(resultsetFactory.createAtomic(avf.newAtomicValue(date)));    
    
    assertResultsNotEquals(b.build(), c.build());  
  }
  

  private void assertResultsEquals(
      AS0Resultset a1,
      AS0Resultset a2) {
    try {
      assertTrue("Expected equals resultset:"+a1+"="+a2, a1.equalsUsingInternal(a2));
    } catch (ModelException e) {
      throw new RuntimeException(e);
    }
    
  }
  
  private void assertResultsNotEquals(
      AS0Resultset a1,
      AS0Resultset a2) {
    try{
      assertFalse("Expected not equals resultset:"+a1+"!="+a2, a1.equalsUsingInternal(a2));
    }catch (ModelException e) {
      throw new RuntimeException(e);
    }
    
  }
  
  @Test
  public void compareTwoBags(){
    AS0ResultsetBag.Builder a=resultsetFactory.createBagBuilder();
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue(2549.21)));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue(2549.21)));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue(2549.21)));
    
    AS0ResultsetBag.Builder b=resultsetFactory.createBagBuilder();
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(549.21)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(2549.21)));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue(1549.21)));
    
    assertResultsNotEquals(a.build(), b.build());
  }
  
  @Test
  public void testEqualsDifferentNumberOfItems() {
    AS0ResultsetStruct.Builder a=resultsetFactory.createStructBuilder();
    AS0ResultsetStruct.Builder b=resultsetFactory.createStructBuilder();
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    assertResultsNotEquals(a.build(), b.build());  
  }
  
  @Test
  public void testEqualsDifferentNumberOfItems2() {
    AS0ResultsetStruct.Builder a = resultsetFactory.createStructBuilder();
    AS0ResultsetStruct.Builder b = resultsetFactory.createStructBuilder();
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    a.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    b.add(resultsetFactory.createAtomic(avf.newAtomicValue("Napis2")));
    assertResultsEquals(a.build(), b.build());  
  }

}
