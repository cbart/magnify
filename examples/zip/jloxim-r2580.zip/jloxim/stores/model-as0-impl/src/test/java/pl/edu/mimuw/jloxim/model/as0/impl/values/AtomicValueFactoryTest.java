/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;

public abstract class AtomicValueFactoryTest {
  
  abstract protected AtomicValueFactory getAtomicValueFactory();
  
  @Test
  public void testNewAtomicValueByteArray() throws UnsupportedEncodingException {
    String testText=new String("asdząśęśćđŋŧ¶łś"+'\0'+"abc123456");
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertArrayEquals(testText.getBytes("UTF-8"), atomicValueFactory.newAtomicValue(testText.getBytes("UTF-8")).getValue());
  }

  @Test
  public void testNewAtomicValueInputStream() throws IOException {
    String testText=new String("asdząśęśćđŋŧ¶łś"+'\0'+"abc123456");
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertArrayEquals(testText.getBytes("UTF-8"), atomicValueFactory.newAtomicValue(new ByteArrayInputStream(testText.getBytes("UTF-8"))).getValue());
  }

  @Test
  public void testNewAtomicValueBoolean() {
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(true, atomicValueFactory.newAtomicValue(true).getValue());
    assertEquals(false, atomicValueFactory.newAtomicValue(false).getValue());
  }

  @Test
  public void testNewAtomicValueCalendar() {
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    Date d=new Date();
    Calendar c=Calendar.getInstance();
    c.setTime(d);
    assertEquals(c, atomicValueFactory.newAtomicValue(c).getValue());
  }

  @Test
  public void testNewAtomicValueDate() {
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    Date d=new Date();
    Calendar c=Calendar.getInstance();
    c.setTime(d);
    assertEquals(c, atomicValueFactory.newAtomicValue(d).getValue());
  }

  @Test
  public void testNewAtomicValueInt() {
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(0, (long)atomicValueFactory.newAtomicValue(0).getValue());
    assertEquals(5, (long)atomicValueFactory.newAtomicValue(5).getValue());
    assertEquals(Integer.MAX_VALUE, (long)atomicValueFactory.newAtomicValue(Integer.MAX_VALUE).getValue());
    assertEquals(Integer.MIN_VALUE, (long)atomicValueFactory.newAtomicValue(Integer.MIN_VALUE).getValue());
  }

  @Test
  public void testNewAtomicValueDouble() {
    double PRECISION=0.0000000000000000000000000000000000001;
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(0.0, atomicValueFactory.newAtomicValue(0.0).getValue(), PRECISION);
    assertEquals(23412897.23423423, atomicValueFactory.newAtomicValue(23412897.23423423).getValue(), PRECISION);
    assertEquals(-23412897.23423423, atomicValueFactory.newAtomicValue(-23412897.23423423).getValue(), PRECISION);
    assertEquals(23412894457.245543423423, atomicValueFactory.newAtomicValue(23412894457.245543423423).getValue(), PRECISION);
    assertEquals(-23412855597.23423452453, atomicValueFactory.newAtomicValue(-23412855597.23423452453).getValue(), PRECISION);
  }

  @Test
  public void testNewAtomicValueLong() {
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals((long)0, (long)atomicValueFactory.newAtomicValue((long)0).getValue());
    assertEquals((long)5, (long)atomicValueFactory.newAtomicValue((long)5).getValue());
    assertEquals((long)Integer.MAX_VALUE, (long)atomicValueFactory.newAtomicValue((long)Integer.MAX_VALUE).getValue());
    assertEquals((long)Integer.MIN_VALUE, (long)atomicValueFactory.newAtomicValue((long)Integer.MIN_VALUE).getValue());
    assertEquals((long)Long.MAX_VALUE, (long)atomicValueFactory.newAtomicValue((long)Long.MAX_VALUE).getValue());
    assertEquals((long)Long.MIN_VALUE, (long)atomicValueFactory.newAtomicValue((long)Long.MIN_VALUE).getValue());
  }

  @Test
  public void testNewAtomicValueString() {
    String testText=new String("asdząśęśćđŋŧ¶łś"+'\0'+"abc123456");
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(testText, atomicValueFactory.newAtomicValue(testText).getValue());
  }

  @Test
  public void testNewAtomicValueReader() throws IOException {
    String testText=new String("asdząśęśćđŋŧ¶łśabc123456");
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(testText, atomicValueFactory.newAtomicValue(new StringReader(testText)).getValue());
  }
  
  @Test
  public void testNewAtomicValueReader2() throws IOException {
    String testText=new String("asdząśęśćđŋŧ¶łś"+'\0'+"abc123456");
    AtomicValueFactory atomicValueFactory=getAtomicValueFactory();
    assertEquals(testText, atomicValueFactory.newAtomicValue(new StringReader(testText)).getValue());
  }

}
