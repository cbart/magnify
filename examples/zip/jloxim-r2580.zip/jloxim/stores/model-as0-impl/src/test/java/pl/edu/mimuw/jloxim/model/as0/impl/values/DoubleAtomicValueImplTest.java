/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;
import java.util.GregorianCalendar;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;

import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;

public class DoubleAtomicValueImplTest {
  @Test
  public void constructorTest()
  {
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(1);
    Assert.assertEquals(i.getValue().toString(), "1.0");
    Assert.assertTrue(i.getValue()==1.0);
    
    Assert.assertEquals(i instanceof IntegerAtomicValue, false);
    Assert.assertEquals(i instanceof LongAtomicValue, false);
    Assert.assertEquals(i instanceof DoubleAtomicValue, true);
    Assert.assertEquals(i.hashCode(), 1072693279);

  }

  @Test
  public void compareDoubleTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(1.0);
    DoubleAtomicValueImpl j = new DoubleAtomicValueImpl(1.0);
    DoubleAtomicValueImpl k = new DoubleAtomicValueImpl(2.0);
    DoubleAtomicValueImpl l = new DoubleAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
    
    try{
      Assert.assertEquals(i, k);
      Assert.fail();
    }
    catch (AssertionFailedError ex)
    {
      return;
    }
  }
  
  @Test
  public void compareIntTest(){
    IntegerAtomicValueImpl i = new IntegerAtomicValueImpl(1);
    DoubleAtomicValueImpl j = new DoubleAtomicValueImpl(1.0);
    DoubleAtomicValueImpl k = new DoubleAtomicValueImpl(2.0);
    DoubleAtomicValueImpl l = new DoubleAtomicValueImpl(0);
    DoubleAtomicValueImpl m = new DoubleAtomicValueImpl(2);
    
    Assert.assertEquals(i, j);
    Assert.assertEquals(k.toString(), m.toString());
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
  }

  @Test
  public void compareLongTest(){
    LongAtomicValueImpl i = new LongAtomicValueImpl(1);
    DoubleAtomicValueImpl j = new DoubleAtomicValueImpl(1.0);
    DoubleAtomicValueImpl k = new DoubleAtomicValueImpl(2.0);
    DoubleAtomicValueImpl l = new DoubleAtomicValueImpl(0);
    
    Assert.assertEquals(i, j);
    Assert.assertTrue(i.compareTo(i)==0);
    Assert.assertTrue(i.compareTo(j)==0);
    Assert.assertTrue(i.compareTo(k)==-1);
    Assert.assertTrue(i.compareTo(l)==1);
  }
  
  @Test
  public void txtCompareTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(99.99);
    TextAtomicValueImpl txt = new TextAtomicValueImpl("test");
    try{
      Assert.assertTrue(i.compareTo(txt)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare DoubleAtomicValue with TextAtomicValue.", ex.getMessage());
    }
  }
  
  @Test
  public void dateCompareTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(99.99);
    GregorianCalendar calendar = new GregorianCalendar(2009, 5, 5, 12, 00, 0);
    DateAtomicValueImpl date = new DateAtomicValueImpl(calendar);
    try{
      Assert.assertTrue(i.compareTo(date)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare DoubleAtomicValue with DateAtomicValue.", ex.getMessage());
    }
  }
  
  @Test
  public void nullCompareTest(){
    DoubleAtomicValueImpl i = new DoubleAtomicValueImpl(99.99);
    try{
      Assert.assertTrue(i.compareTo(null)!=0);
    }
    catch (ClassCastException ex)
    {
      Assert.assertEquals("Could not compare DoubleAtomicValue with null.", ex.getMessage());
    }
  }
}
