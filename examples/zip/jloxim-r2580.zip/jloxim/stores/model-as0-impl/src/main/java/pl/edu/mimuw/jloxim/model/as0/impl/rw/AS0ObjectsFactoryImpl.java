/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.rw;

import java.util.Collection;
import java.util.LinkedHashSet;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

public class AS0ObjectsFactoryImpl implements AS0ObjectsFactory {

  public AS0AtomicObjectEditable newAtomicObject(int name_id, AtomicValue s) {
    return new AS0AtomicObjectEditableImpl(null, name_id, null, s);
  }

  public AS0ComplexObjectEditable newEmptyComplexObject(int name_id) {
    return new AS0ComplexObjectEditableImpl(null, name_id, null);
  }

  public AS0PointerObjectEditable newPointerObject(int name_id, AbstractOid destination_oid) {
    return new AS0PointerObjectEditableImpl(null, name_id, null, destination_oid);
  }

  public AS0ComplexObjectEditable newComplexObject(int name_id,
      Collection<? extends AS0ObjectEditable> object) {
    return new AS0ComplexObjectEditableImpl(null, name_id, null, new LinkedHashSet<AS0ObjectEditable>(object));
  }

}
