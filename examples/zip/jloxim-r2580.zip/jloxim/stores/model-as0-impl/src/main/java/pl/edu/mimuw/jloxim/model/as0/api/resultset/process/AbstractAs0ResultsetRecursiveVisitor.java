/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset.process;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;

public abstract class AbstractAs0ResultsetRecursiveVisitor<T extends AS0Resultset> {
  
  public T process(AS0Resultset r) {
    if (r instanceof AS0ResultsetAtomic){
      return processTyped((AS0ResultsetAtomic)r);
    }else if (r instanceof AS0ResultsetSequence){
      return processTyped((AS0ResultsetSequence)r);
    }else if (r instanceof AS0ResultsetBag){
      return processTyped((AS0ResultsetBag)r);
    }else if (r instanceof AS0ResultsetStruct){
      return processTyped((AS0ResultsetStruct)r);
    }else if (r instanceof AS0ResultsetBinder){
      return processTyped((AS0ResultsetBinder)r);
    }if (r instanceof AS0ResultsetRef){
      return processTyped((AS0ResultsetRef)r);
    }
    throw new IllegalArgumentException("Unknown type process method:"+r.getClass().getCanonicalName());
  }

  protected abstract T processTyped(AS0ResultsetRef r);

  protected abstract T processTyped(AS0ResultsetBinder r);

  protected abstract T processTyped(AS0ResultsetStruct r);   

  protected abstract T processTyped(AS0ResultsetBag r);

  protected abstract T processTyped(AS0ResultsetSequence r);

  protected abstract T processTyped(AS0ResultsetAtomic r);
  
  /**
   * Returns true if all processed items where returned identical
   * 
   * @param r
   * @param collector
   * @return
   */
  protected boolean processCollection(AS0ResultsetCollection r, AS0ResultsetCollection.Builder collector){
    boolean identical=true;
    for (AS0Resultset item:r){
      T processed=process(item);
      identical = identical && (processed==item);
      collector.add(processed);
    }
    return identical;
  }
}
