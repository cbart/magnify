/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import java.util.Arrays;
import java.util.Iterator;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection;

import com.google.common.collect.ImmutableMultiset;

/**
 * @author ptab@mimuw.edu.pl
 */
public class AS0ResultsetBagImpl extends AbstractAS0Resultset implements AS0ResultsetBag {
  private static final long serialVersionUID = 1L;

  public static final AS0ResultsetBag EMPTY_BAG_READ_ONLY = new AS0ResultsetBagImpl();
  
  private ImmutableMultiset<AS0Resultset> bag;
  
  protected AS0ResultsetBagImpl() {  
    bag = ImmutableMultiset.of();
  }
  
  protected AS0ResultsetBagImpl(ImmutableMultiset<AS0Resultset> bag) {  
    this.bag = bag;
  }
  
  public Iterator<AS0Resultset> iterator() {
    return bag.iterator();
  }
  
  public int size() {
    return bag.size();
  }
      
  @Override
  public String toString() {
    StringBuilder sb=new StringBuilder("bag(");
    boolean not_first=false;
    for (AS0Resultset i:this)
    {
      if (not_first){
        sb.append(", ");
      }
      sb.append(i.toString());
      not_first=true;
    }
    sb.append(")");
    return sb.toString();
  }

  public boolean contains(AS0Resultset r) {
    return bag.contains(r);
  }

  public AS0ResultsetBag wrapAsBag() {
    return this;
  }
  
  /**The builder is not thread-safe because of changed field*/
  static class Builder implements AS0ResultsetCollection.Builder {
    private ImmutableMultiset.Builder<AS0Resultset> builder = ImmutableMultiset.builder();
    private boolean changed = false;

    protected void realAddToBuilder(AS0Resultset r){
      builder.add(r);
      changed = true;
    }
    
    public Builder add(AS0Resultset r) {
      if (r instanceof AS0ResultsetBag){        
        for (AS0Resultset b : (AS0ResultsetBag)r){
          realAddToBuilder(b);
        }
      } else {
        realAddToBuilder(r);
      }
      return this;
    }
       
    public Builder addAll(Iterable<AS0Resultset> rs) {
      for (AS0Resultset r : rs){
        add(r);        
      }
      return this;
    }

    /** The method is not thread safe*/
    public boolean addAllCheckChanges(Iterable<AS0Resultset> rs) {
      changed = false;
      addAll(rs);
      return changed;
    }

    public AS0Resultset build() {      
      ImmutableMultiset<AS0Resultset> r = builder.build();
      if (r.size() == 0){
        return EMPTY_BAG_READ_ONLY;
      } else if (r.size() == 1){
        return r.iterator().next();
      } else {
        return realBuild(r);
      }
    }

    protected AS0Resultset realBuild(ImmutableMultiset<AS0Resultset> r) {
      return new AS0ResultsetBagImpl(r);
    }
  }
  
  @Override
  protected long calcExternalHash() {
    if (bag.size() == 1)
      return bag.iterator().next().hashCodeExternal();
    long[] hashes = new long[bag.size()];
    int i = 0;
    for (AS0Resultset r : bag){
      hashes[i++] = r.hashCodeExternal();
    }
    Arrays.sort(hashes);
    return combineHashCodes(2645, combineHashes(hashes));
  }
  
  @Override
  protected long calcInternalHash() {
    if (bag.size() == 1)
      return bag.iterator().next().hashCodeInternal();
    long[] hashes = new long[bag.size()];
    int i = 0;
    for (AS0Resultset r : bag){
      hashes[i++] = r.hashCodeInternal();
    }
    Arrays.sort(hashes);
    return combineHashCodes(2645, combineHashes(hashes));
  }
  
  public boolean isEmpty() {
    return size()==0;
  }
 
}
