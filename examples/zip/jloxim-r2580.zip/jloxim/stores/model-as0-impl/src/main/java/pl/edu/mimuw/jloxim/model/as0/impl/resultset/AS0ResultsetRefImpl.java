/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

/**
 * @author rp234370
 */
public class AS0ResultsetRefImpl extends AbstractAS0Resultset implements AS0ResultsetRef {

  private static final long serialVersionUID = 1L;
  
  private AbstractOid refOID;
  private boolean automaticDereferentionBlocked = false;
  
  AS0ResultsetRefImpl(AbstractOid oid) {
    refOID=oid;
  }
  
  public AbstractOid getRefOID() {
    return refOID;
  }
  
  public boolean isAutomaticDereferentionBlocked() {
    return automaticDereferentionBlocked;
  }
  
  public void blockAutomaticDereferention() {
    automaticDereferentionBlocked = true;
  }
  
  @Override
  public String toString() {
    return "(refoid)"+getRefOID().toReadableString();
  }
  
  public AS0ResultsetBag wrapAsBag() {
      return new AS0ResultsetBagSingleton(this);
  }
  
  @Override
  protected long calcExternalHash() {
    return getRefOID().longHashCode()*221;
  }
  
  @Override
  protected long calcInternalHash() {
    return getRefOID().longHashCode()*221;
  }

}
