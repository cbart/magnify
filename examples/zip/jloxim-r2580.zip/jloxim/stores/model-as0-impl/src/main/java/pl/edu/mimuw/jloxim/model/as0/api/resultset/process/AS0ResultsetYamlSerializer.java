/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset.process;

import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Iterator;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BooleanAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;

public class AS0ResultsetYamlSerializer extends AbstractAs0ResultsetRecursiveVisitor<AS0Resultset>{
  
  private PrintWriter writer;
  private int level=0;
  private StringBuffer levelPrefix;
  
  public void serialize(AS0Resultset r){
    level=0;
    levelPrefix=new StringBuffer("");
    process(r);
  }
    
  @Override
  protected AS0Resultset processTyped(AS0ResultsetAtomic r) {
    AtomicValue av=r.getValue();
    if (av instanceof BinaryAtomicValue){
      writer.println("!!binary UNIMPLEMENTED");
//      !!binary |
//       R0lGODlhDAAMAIQAAP//9/X
//       17unp5WZmZgAAAOfn515eXv
//       Pz7Y6OjuDg4J+fn5OTk6enp
//       56enmleECcgggoBADs=

    }else if (av instanceof BooleanAtomicValue){
      writer.print("!!bool "+av.getValue());
    }else  if (av instanceof DateAtomicValue){
      writer.print("!!date "+date2yaml(((DateAtomicValue)av).getValue()));
    }else if (av instanceof DoubleAtomicValue){
      writer.print("!!float "+av.getValue());
    }else if (av instanceof IntegerAtomicValue){
      writer.print("!!int "+av.getValue());
    }else if (av instanceof LongAtomicValue){
      writer.print("!!int "+av.getValue());
    }else if (av instanceof TextAtomicValue){
      writer.print(escape2yaml(((TextAtomicValue)av).getValue()));
    }else{
      writer.print("!!"+r.getValue().getClass().getCanonicalName());
    }
    return null;
  }
  
  @Override
  protected AS0Resultset processTyped(AS0ResultsetRef r) {
    writer.print("!!ref "+r.getRefOID());
    return null;
  }
  
  @Override
  protected AS0Resultset processTyped(AS0ResultsetBag r) {
    writeCollection("bag", r);
    return null;
  }
  
  @Override
  protected AS0Resultset processTyped(AS0ResultsetSequence r) {
    writeCollection("seq", r);
    return null;
  }
  
  @Override
  protected AS0Resultset processTyped(AS0ResultsetStruct r) {
    writeCollection("struct", r);
    return null;
  }
    
  @Override
  protected AS0Resultset processTyped(AS0ResultsetBinder r) {
    if (r.hasName()){
      writer.print(r.getName()+": ");
    } else {
      writer.print("!int_binder!"+r.getNameId()+": "); 
    }    
    return process(r.getValue());
  }
  
  //==========================================================
  
  private void writeCollection(String type, AS0ResultsetCollection r) {
    writer.println("!!"+type);
    try{
      levelPrefix.append("  ");
      level++;
      Iterator<AS0Resultset> iter=r.iterator();
      while(iter.hasNext()){
        AS0Resultset item=iter.next();
        writer.print(levelPrefix);
        writer.print(" - ");
        process(item);
        if (iter.hasNext()){
          writer.println();
        }
      }      
    }finally{
      level--;
      levelPrefix.setLength(levelPrefix.length()-2);
    }  
  }

  private String escape2yaml(String value) {
    return '"'+value.replace("\n", "\\n").replace("\r", "\\r").replace("\"", "\\\"")+'"';
  }

//  ThreadLocal<Formatter> dateFormater=new ThreadLocal<Formatter>(){
//    protected Formatter initialValue() {
//      Formatter. ("%04d-%02d-%02dt%02d:%02d:%02d.%02d%c%02d:%02d");
//    };
//  }
  
  String date2yaml(Calendar c) {
    int timezone=(c.getTimeZone().getRawOffset()/60000);
    return String.format("%04d-%02d-%02dt%02d:%02d:%02d.%02d%c%02d:%02d",
      c.get(Calendar.YEAR),
      c.get(Calendar.MONTH),
      c.get(Calendar.DAY_OF_MONTH),
      c.get(Calendar.HOUR_OF_DAY),
      c.get(Calendar.MINUTE),
      c.get(Calendar.SECOND),
      c.get(Calendar.MILLISECOND)/10,      
      timezone<0?'-':'+',
      Math.abs(timezone)/60,
      Math.abs(timezone)%60);
  }

  public PrintWriter getWriter() {
    return writer;
  }
  
  public void setWriter(PrintWriter writer) {
    this.writer = writer;
  }
  
}
