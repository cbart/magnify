/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.model.as0.impl.rw;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

public class AS0ComplexObjectEditableImpl extends AS0ObjectEditableImpl
    implements AS0ComplexObjectEditable {

  private Set<AS0ObjectEditable> subobjects;

  public AS0ComplexObjectEditableImpl(AbstractOid oid, int name_id, AbstractOid parent) {
    super(oid, name_id, parent);
    subobjects=new LinkedHashSet<AS0ObjectEditable>();
  }

  public AS0ComplexObjectEditableImpl(AbstractOid oid, int name_id, AbstractOid parent, Set<AS0ObjectEditable> s)
  {
    super(oid, name_id, parent);
    subobjects=s;
  }

  public Set<AS0ObjectEditable> getSubobjects() {
    return subobjects;
  }


  public ClosableIterator<AbstractOid> getIteratorBySubobjectNameId(int name_id) throws ModelException {
    Set<AS0ObjectEditable> subset=new LinkedHashSet<AS0ObjectEditable>();
    for (AS0ObjectEditable e:subobjects)
    {
      if (e.getNameId()==name_id)
        subset.add(e);
    }
    return new GetOidIterator(subset);
  }

  public ClosableIterator<AbstractOid> iterator() throws ModelException {
    return new GetOidIterator(subobjects);
  }

  static class GetOidIterator implements ClosableIterator<AbstractOid>
  {
    private long availableItemsCnt;
    private Iterator<AS0ObjectEditable> realIterator;

    public GetOidIterator(Collection<AS0ObjectEditable> c) {
      availableItemsCnt=c.size();
      realIterator=c.iterator();
    }

    public void close() {
      //TODO: ignoring- no real cursor
    }

    public boolean hasNext() {
      return realIterator.hasNext();
    }

    public AbstractOid next() {
      AS0ObjectEditable object=realIterator.next();
      availableItemsCnt--;
      return object.getOID();
    }

    public void remove() {
      throw new UnsupportedOperationException("remove in the iterator");
    }

    public long availableItemsCnt() {
      return availableItemsCnt;
    }
  }

  public Map<Integer, ClosableIterator<AbstractOid>> getSubobjectOIDsMap()
      throws ModelException {
// XXX Can be done more effective
    Map<Integer, LinkedList<AS0ObjectEditable>> mapa=new LinkedHashMap<Integer, LinkedList<AS0ObjectEditable>>();
    for (AS0ObjectEditable o:subobjects){
      LinkedList<AS0ObjectEditable> dstList=mapa.get(o.getNameId());
      if (dstList==null){
        dstList=new LinkedList<AS0ObjectEditable>();
        mapa.put(o.getNameId(), dstList);
      }
      dstList.add(o);
    }
    Map<Integer, ClosableIterator<AbstractOid>> res=
      new HashMap<Integer, ClosableIterator<AbstractOid>>();
    for (Map.Entry<Integer, LinkedList<AS0ObjectEditable>> e:mapa.entrySet()){
      res.put(e.getKey(), new GetOidIterator(e.getValue()));
    }

    return res;
  }

  @Override
  public String toString() {
    return "complex("+super.toString()+"):"+subobjects.toString();
  }


}
