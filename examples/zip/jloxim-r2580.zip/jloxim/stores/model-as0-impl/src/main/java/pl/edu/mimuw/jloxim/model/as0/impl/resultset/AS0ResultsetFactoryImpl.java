/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import javax.annotation.Nullable;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinderExtTemp;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetMethod;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection.Builder;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;

import com.google.common.base.Function;

public class AS0ResultsetFactoryImpl implements AS0ResultsetFactory{

  public AS0ResultsetAtomic createAtomic(AtomicValue value) {
    return new AS0ResultsetAtomicImpl(value);
  }

  public Builder createBagBuilder() {
    return new AS0ResultsetBagImpl.Builder();
  }

  public Builder createSequenceBuilder() {
    return new AS0ResultsetSequenceImpl.Builder();
  }

  public Builder createStructBuilder() {
    return new AS0ResultsetStructImpl.Builder();
  }

  public AS0ResultsetRef createRef(AbstractOid oid) {
    return new AS0ResultsetRefImpl(oid);
  }

  public AS0ResultsetBinder createBinder(AS0Resultset value, Integer nameId) {
    return new AS0ResultsetBinderImpl(value, nameId);
  }

  public AS0ResultsetBinder createBinder(AS0Resultset value, Integer nameId, @Nullable String name) {
    return new AS0ResultsetBinderImpl(value, nameId, name);    
  }

  public AS0ResultsetBinderExtTemp createBinder(AS0Resultset value, String name) {
    return new AS0ResultsetBinderImpl(value, name);
  }
  
  public AS0ResultsetMethod createMethod(
      Function<AS0Resultset[], AS0Resultset> method) {
    return new Function2AS0ResultsetMethodAdapter(method);
  }

  public Builder createBagOrSequenceBuilderAsOrigin(AS0ResultsetBag origin) {
    if (origin instanceof AS0ResultsetSequence){
      return new AS0ResultsetSequenceImpl.Builder();
    } else {
      return new AS0ResultsetBagImpl.Builder();
    }
  }
}
