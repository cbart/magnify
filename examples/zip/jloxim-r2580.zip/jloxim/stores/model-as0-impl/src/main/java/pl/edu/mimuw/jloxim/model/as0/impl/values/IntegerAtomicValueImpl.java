/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BooleanAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;

public class IntegerAtomicValueImpl implements IntegerAtomicValue, Comparable<AtomicValue> {
  private static final long serialVersionUID = 1L;
  private int value;
  
  public IntegerAtomicValueImpl(int v){value=v;}; 
  
  public Integer getValue() {
    return value;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + value;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    
    if ((getClass() != obj.getClass())
       &&(!(obj instanceof IntegerAtomicValue))  
         &&(!(obj instanceof DoubleAtomicValue)))
    {
        return false;
    }
    
    if (obj instanceof LongAtomicValue)  {
      LongAtomicValue other = (LongAtomicValue) obj;
      if (value != other.getValue())
        return false;
    }
    
    if (obj instanceof IntegerAtomicValue)  {
      IntegerAtomicValue other2 = (IntegerAtomicValue) obj;
      if (value != other2.getValue())
        return false;
    }
    
    if (obj instanceof DoubleAtomicValue)  {
      DoubleAtomicValue other3 = (DoubleAtomicValue) obj;
      if (value != other3.getValue())
        return false;
    }
    return true;  
  }

  public int compareTo(AtomicValue atom) {
    if (atom == null)
      throw new ClassCastException("Could not compare IntegerAtomicValue with null.");
    if (atom instanceof DateAtomicValue)
      throw new ClassCastException("Could not compare IntegerAtomicValue with DateAtomicValue.");
    if (atom instanceof TextAtomicValue)
      throw new ClassCastException("Could not compare IntegerAtomicValue with TextAtomicValue.");
    if (atom instanceof BooleanAtomicValue)
      throw new ClassCastException("Could not compare IntegerAtomicValue with BooleanAtomicValue.");
    if (atom instanceof BinaryAtomicValue)
      throw new ClassCastException("Could not compare IntegerAtomicValue with BinaryAtomicValue.");

    Object atomValue = atom.getValue();
    Integer thisValue = value; 
    
    if (atom instanceof IntegerAtomicValue){
      //No problem with compare
      return thisValue.compareTo((Integer) atomValue);
    }
      
    if (atom instanceof DoubleAtomicValue){
      if (value > ((Double) atomValue))
        return 1;
      if (value == ((Double) atomValue))
        return 0;
      if (value < ((Double) atomValue)) 
        return -1;
    }
    
    if (atom instanceof LongAtomicValue){
      if (value > ((Long) atomValue))
        return 1;
      if (value == ((Long) atomValue))
        return 0;
      if (value < ((Long) atomValue)) 
        return -1;
    }
    throw new ClassCastException("Could not compare IntegerAtomicValue with " + atom.getClass().getSimpleName() +".");
  }
  
  @Override
  public String toString() {
    return "(int)"+value;
  }
}
