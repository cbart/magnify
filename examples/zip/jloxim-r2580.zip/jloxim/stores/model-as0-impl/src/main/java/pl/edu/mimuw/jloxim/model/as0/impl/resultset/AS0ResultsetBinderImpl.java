/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import javax.annotation.Nullable;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinderExtTemp;

public class AS0ResultsetBinderImpl extends AbstractAS0Resultset implements AS0ResultsetBinder, AS0ResultsetBinderExtTemp {
  private static final long serialVersionUID = 1L;
  
  private boolean initialized = false;
  private String name = null;
  private int nameId = 0;
  private final AS0Resultset value;
  
  AS0ResultsetBinderImpl(AS0Resultset value, int nameId) {
    this.value = value;
    this.nameId = nameId;
    this.initialized = true;
  }
  
  AS0ResultsetBinderImpl(AS0Resultset value, int nameId, @Nullable String name){
    this(value, nameId);
    this.name = name;
  }
  
  public AS0ResultsetBinderImpl(AS0Resultset value, String name) {
    this.value = value; 
    this.name = name;
    this.initialized = false;
  }

  public int getNameId() {
    if (!initialized){
      throw new IllegalStateException("Cannot get nameId of uninitialized binder");
    }
    return nameId;
  }

  public AS0Resultset getValue() {
    return value;
  }

  public AS0ResultsetBag wrapAsBag() {
    return new AS0ResultsetBagSingleton(this);
  }

  public String getName() {
    if (name == null) {
      throw new IllegalStateException("Name (as string) has not been resolved for the binder");
    }
    return name;
  }

  public boolean hasName() {
    return name != null;
  }

  public void initNameIdAs(int nameId) {
    if (initialized){
      throw new IllegalStateException("The binder has been already initialized");
    } else {
      this.nameId = nameId;
      initialized = true;
    }    
  }

  public boolean isInitialized() {
    return initialized;
  }
  
  public void setName(String newName) {
    this.name = newName; 
  }

  @Override
  protected long calcExternalHash() {
    return combineHashCodes(getName().hashCode(), value.hashCodeExternal());
  }
  
  @Override
  protected long calcInternalHash() {
    return combineHashCodes(getNameId(), value.hashCodeInternal());
  }

  @Override
  public String toString() {
    final StringBuilder sb = new StringBuilder();
    String key = name != null ? name : String.valueOf(nameId);
    sb.append(key).append("->").append(value);
    return sb.toString();
  }
}
