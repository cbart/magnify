/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.resultset;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetCollection;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;

import com.google.common.collect.ImmutableMultiset;

/**
 * @author rp234370
 */
public class AS0ResultsetStructImpl extends AbstractAS0Resultset implements AS0ResultsetStruct {

  private static final long serialVersionUID = 1L;
  
  //TODO(ptab): Empty struct should be not allowed
  public static final AS0ResultsetStruct EMPTY_STRUCT = new AS0ResultsetStructImpl();
  private static final AS0ResultsetFactory RESULTSET_FACTORY = new AS0ResultsetFactoryImpl();
  
  private ImmutableMultiset<AS0Resultset> struct;
  
  protected AS0ResultsetStructImpl() { 
    struct = ImmutableMultiset.of();
  }
  
  protected AS0ResultsetStructImpl(ImmutableMultiset<AS0Resultset> struct) {  
    this.struct = struct;
  }
  
  public Iterator<AS0Resultset> iterator() {
    return struct.iterator();
  }
  
  public int size() {
    return struct.size();
  }
      
  @Override
  public String toString() {
    StringBuilder sb=new StringBuilder("struct(");
    boolean not_first=false;
    for (AS0Resultset i:this)
    {
      if (not_first){
        sb.append(", ");
      }
      sb.append(i.toString());
      not_first=true;
    }
    sb.append(")");
    return sb.toString();
  }

  public boolean contains(AS0Resultset r) {
    return struct.contains(r);
  }

  public AS0ResultsetBag wrapAsBag() {
    return new AS0ResultsetBagSingleton(this);
  }
  
  public static class Builder implements AS0ResultsetCollection.Builder {
    private final ImmutableMultiset.Builder<AS0Resultset> simple = new ImmutableMultiset.Builder<AS0Resultset>(); 
    private final LinkedList<AS0ResultsetBag> bags = new LinkedList<AS0ResultsetBag>();

    public Builder add(AS0Resultset r) {
      if (r instanceof AS0ResultsetBag) {
        bags.add((AS0ResultsetBag)r);
      }else if (r instanceof AS0ResultsetStruct) {
        simple.addAll((AS0ResultsetStruct)r);
      } else {
        simple.add(r);
      }
      return this;
    }
        
    public Builder addAll(Iterable<AS0Resultset> it) {
      for (AS0Resultset r:it){
        add(r);
      }
      return this;
    }

    public boolean addAllCheckChanges(Iterable<AS0Resultset> it) {
      addAll(it);
      return true;
    }

    public AS0Resultset build() {
      ImmutableMultiset<AS0Resultset> s=simple.build();      
      if (s.isEmpty() && bags.isEmpty()) {        
        return AS0ResultsetStructImpl.EMPTY_STRUCT;
      } else if (s.isEmpty()){
         return cartesianBagProduct();
      } else if (bags.isEmpty()){
        return new AS0ResultsetStructImpl(s);
      } else {
        bags.add(new AS0ResultsetStructImpl(s).wrapAsBag());
        return cartesianBagProduct();
      }
    }
        

    //  TODO(ptab): Implement as lazy AS0StructGenerator
    private AS0Resultset cartesianBagProduct() {
      AS0ResultsetBag.Builder builder = RESULTSET_FACTORY.createBagBuilder();               
      genCartesianProduct(0, bags, new LinkedList<AS0Resultset>(), builder);
      return builder.build();
    }

    private void genCartesianProduct(int index, LinkedList<AS0ResultsetBag> queriesResults, 
        LinkedList<AS0Resultset> structList, AS0ResultsetBag.Builder resultBag)
    {
      if (index >= queriesResults.size()){
        resultBag.add(new Builder().addAll(structList).build());
      } else {
        AS0ResultsetBag resultsetCollection = queriesResults.get(index); 
        Iterator<AS0Resultset> myIter = resultsetCollection.iterator();   
        while(myIter.hasNext()) {
          AS0Resultset res = myIter.next();
          
          int elems;
          if (res instanceof AS0ResultsetStruct) {
            for (AS0Resultset s:(AS0ResultsetStruct)res){
              structList.add(s);
            }         
            elems = ((AS0ResultsetStruct)res).size();
          } else {
            structList.addLast(res);
            elems = 1;
          }     
          genCartesianProduct(index + 1, queriesResults, structList, resultBag);
          
          for (int i = 0; i < elems; i++)
            structList.removeLast();      
        }
      }
    }
     
  }  
 
  @Override
  protected long calcExternalHash() {
    if (struct.size() == 1)
      return struct.iterator().next().hashCodeExternal();
    long[] hashes = new long[struct.size()];
    int i = 0;
    for (AS0Resultset r : struct){
      hashes[i++] = r.hashCodeExternal();
    }
    Arrays.sort(hashes);
    return combineHashCodes(2647, combineHashes(hashes));
  }
  
  @Override
  protected long calcInternalHash() {
    if (struct.size() == 1)
      return struct.iterator().next().hashCodeInternal();
    long[] hashes = new long[struct.size()];
    int i = 0;
    for (AS0Resultset r : struct){
      hashes[i++] = r.hashCodeInternal();
    }
    Arrays.sort(hashes);
    return combineHashCodes(2647, combineHashes(hashes));
  }

  public boolean isEmpty() {
    return size() == 0;
  }
  
}
