/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */
package pl.edu.mimuw.jloxim.model.as0.api.resultset.process;

import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0Resultset;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetAtomic;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinder;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBinderExtTemp;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetFactory;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetRef;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetSequence;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetStruct;
import pl.edu.mimuw.jloxim.model.as0.impl.resultset.AS0ResultsetFactoryImpl;

public class AbstractRecursiveAs0ResultsetTranslator  extends AbstractAs0ResultsetRecursiveVisitor<AS0Resultset> implements AS0ResultsetTransformer{

  protected AS0ResultsetFactory resultsetFactory=new AS0ResultsetFactoryImpl();
  
  public AS0Resultset transform(AS0Resultset r) {
    return process(r);
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetRef r) {
    return r;
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetBinder r) {
    AS0Resultset r1=process(r.getValue());
    //TODO(ptab): Change == into equals ?
    if ( r1 == r.getValue() ){
      return r;
    } else if ( (r instanceof AS0ResultsetBinderExtTemp)
        && (!((AS0ResultsetBinderExtTemp) r).isInitialized())){
      return resultsetFactory.createBinder(r1, r.getName());
    }else{
      if (r.hasName()){
        return resultsetFactory.createBinder(r1, r.getNameId(), r.getName());
      } else {
        return resultsetFactory.createBinder(r1, r.getNameId());
      }
    }
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetStruct r) {
    AS0ResultsetStruct.Builder res = resultsetFactory.createStructBuilder();
    if (processCollection(r, res)) return r;
    else return res.build();
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetBag r) {
    AS0ResultsetBag.Builder res = resultsetFactory.createBagBuilder();
    if (processCollection(r, res)) return r;
    else return res.build();
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetSequence r) {
    AS0ResultsetSequence.Builder res=resultsetFactory.createSequenceBuilder();
    if (processCollection(r, res)) return r;
    else return res.build();  
  }

  @Override
  protected AS0Resultset processTyped(AS0ResultsetAtomic r) {
    return r;
  }
}
