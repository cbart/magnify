/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;

import java.io.Reader;
import java.io.StringReader;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;

public class TextAtomicValueImpl implements TextAtomicValue, Comparable<AtomicValue> {
  private static final long serialVersionUID = 1L;
  private String value;
  
  public TextAtomicValueImpl() {value=null;}
  public TextAtomicValueImpl(String v){value=v;};
  
  public Reader getStringReader() {
    return new StringReader(value);
  }

  public String getValue() {
    return value;
  }
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((value == null) ? 0 : value.hashCode());
    return result;
  }
  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    TextAtomicValueImpl other = (TextAtomicValueImpl) obj;
    if (value == null) {
      if (other.value != null)
        return false;
    } else if (!value.equals(other.value))
      return false;
    return true;
  }
  
  @Override
  public String toString() {
    return value;
  }
  
  public int compareTo(AtomicValue atom) {
    if (atom == null)
      throw new ClassCastException("Could not compare TextAtomicValue with null.");
    if (!(atom instanceof TextAtomicValue))
      throw new ClassCastException("Could not compare TextAtomicValue with " + atom.getClass() +".");  
    return value.compareTo((String) atom.getValue());
  }
}
