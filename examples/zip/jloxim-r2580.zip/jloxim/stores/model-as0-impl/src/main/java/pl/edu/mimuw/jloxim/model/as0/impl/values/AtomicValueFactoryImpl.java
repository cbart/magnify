/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.model.as0.impl.values;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Date;

import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.BinaryAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.BooleanAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DateAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.DoubleAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.IntegerAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.LongAtomicValue;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;

public class AtomicValueFactoryImpl implements AtomicValueFactory {

  public BinaryAtomicValue newAtomicValue(byte[] b) {
    return new BinaryAtomicValueImpl(b);
  }

  public BinaryAtomicValue newAtomicValue(InputStream is) throws IOException {
    return new BinaryAtomicValueImpl(readWholeStream(is));
  }

  private byte[] readWholeStream(InputStream is) throws IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    int res = 0;
    byte[] buf = new byte[4096];
    while ((res = is.read(buf)) > 0) {
      baos.write(buf, 0, res);
    }
    return baos.toByteArray();
  }

  public BooleanAtomicValue newAtomicValue(boolean b) {
    return b ? BoolAtomicValueImpl.TRUE : BoolAtomicValueImpl.FALSE;
  }

  public DateAtomicValue newAtomicValue(Calendar d) {
    return new DateAtomicValueImpl(d);
  }

  public DateAtomicValue newAtomicValue(Date d) {
    return new DateAtomicValueImpl(d);
  }

  public IntegerAtomicValue newAtomicValue(int value) {
    return new IntegerAtomicValueImpl(value);
  }

  public DoubleAtomicValue newAtomicValue(double d) {
    return new DoubleAtomicValueImpl(d);
  }

  public LongAtomicValue newAtomicValue(long value) {
    return new LongAtomicValueImpl(value);
  }

  public TextAtomicValue newAtomicValue(String value) {
    return new TextAtomicValueImpl(value);
  }

  public TextAtomicValue newAtomicValue(Reader src) throws IOException {
    return new TextAtomicValueImpl(readWhole(src));
  }

  private String readWhole(Reader src) throws IOException {

    StringWriter sw = new StringWriter();
    char[] buffer = new char[4096];
    int res;
    while ((res = src.read(buffer)) >= 0) {
      sw.write(buffer, 0, res);
    }
    return sw.getBuffer().toString();
  }

  public AtomicValue newAtomicValue(Object o) {
    if (o instanceof byte[]){
      return newAtomicValue((byte[]) o);
    } else if (o instanceof Boolean){
      return newAtomicValue(((Boolean) o).booleanValue());
    } else if (o instanceof Calendar){
      return newAtomicValue((Calendar) o);
    } else if (o instanceof Date){
      return newAtomicValue((Date) o);
    } else if (o instanceof Integer){
      return newAtomicValue(((Integer) o).intValue());
    } else if (o instanceof Double){
      return newAtomicValue(((Double) o).doubleValue());
    } else if (o instanceof Long){
      return newAtomicValue(((Long) o).longValue());
    } else if (o instanceof String){
      return newAtomicValue((String) o);
    }
    throw new IllegalArgumentException("Atomic type expected");
  }
}
