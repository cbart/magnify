/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.tests;

import java.util.Random;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;

public abstract class StoreAs0PTest {
  private static final Logger log=Logger.getLogger(StoreAs0PTest.class);
  private static final int STEP_SEC=10;

  public abstract StoreAS0 getStore();

  public abstract TransactionManager getTM();

  public abstract AS0ObjectsFactory getAS0ObjectsFactory();

  public abstract AtomicValueFactory getAtomicValueFactory();

//  @Test
//  public void getStoreTest() {
//    Assert.assertNotNull(getStore());
//    Assert.assertNotNull(getStore().getStoreId());
//  }
//
//  @Test
//  public void getTransactionManagerTest() {
//    Assert.assertNotNull(getTM());
//  }

  @Test
  public void performanceTest1() throws InterruptedException
  {
    log.info("Starting performance test");
    
    // initialize 
    ///*
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    for (int i=0; i<100000; ++i) {      
      AS0ObjectsFactory factory=getAS0ObjectsFactory();
      AtomicValueFactory afactory=getAtomicValueFactory();
      AS0ObjectEditable ob = factory.newAtomicObject((int)(i%1000), afactory.newAtomicValue(i));
      getStore().addSubobject(t, getStore().getSuperRootOid(), ob);
    }    
    t.commit();
    //*/
    
    for (int i=0; i<0; i++)
      runCreatorThread(i);
    
    for (int i=0; i<3; i++)
      runRandomReaderThread(i);
    
    Thread.sleep(10000000);
  }

//  private void runRemoverThreads() {
//    // TODO Auto-generated method stub
//    
//  }

  private void runRandomReaderThread(int id) {
    Thread t=new RandomReaderThread("Random Reader"+id);
    t.start();
  }

  private void runCreatorThread(int id) {
    Thread t=new CreatorThread("Creator "+id);
    t.start();
  }
  
  class CreatorThread extends Thread{
    
    public CreatorThread(String name) {
      super(name);
    }
    
    @Override
    public void run() {
      log.info("Running creator");
      long lastTicker=getTicker();
      long lastState=0;
      long state=0;
      StoreAS0 store=getStore();
      LongOid lastOid = (LongOid)getStore().getSuperRootOid();
      TransactionManager tm=getTM();
      Transaction t;
      try {
        t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      AS0ObjectsFactory factory=getAS0ObjectsFactory();
      AtomicValueFactory afactory=getAtomicValueFactory();
      while(true){
        long newTicker=getTicker();
        if (newTicker>lastTicker)
        {
          log.error(String.format("%s done: %10d in %3d sec. Rate: %f. LastOid:%8d", getName(), state-lastState, (newTicker-lastTicker)*STEP_SEC, (double)(((double)state-lastState)/(((double)newTicker-lastTicker)*(double)STEP_SEC)), lastOid.getValue()));
          lastState=state;
          lastTicker=newTicker;
        }
        state++;
        if (state%100 == 0)
        {
          t.commit();
          t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        }
        try {
          AS0ObjectEditable ob=factory.newAtomicObject((int)(state%1000), afactory.newAtomicValue(state));
          store.addSubobject(t, getStore().getSuperRootOid(), ob);
          lastOid=(LongOid) ob.getOID();
        } catch (InterruptedStoreOperationException e) {
          log.info(e);
          t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        } catch (StoreException e) {
          log.error(e);
        }
      }
      } catch (TransactionManagerException e1) {
        log.fatal(e1);
      } catch (TransactionException e) {
        log.fatal(e);
      }
    }
    
    public long getTicker()
    {
      return System.currentTimeMillis()/(1000*STEP_SEC);
    }
  }
  
  class RandomReaderThread extends Thread{
    
    public RandomReaderThread(String name) {
      super(name);
    }
    
    @Override
    public void run() {
      log.info("Running creator");
      long lastTicker=getTicker();
      long lastState=0;
      long state=0;
      StoreAS0 store=getStore();
      TransactionManager tm=getTM();
      Random r=new Random();
      long missed=0;
      Transaction t;
      try {
        t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      AS0ObjectsFactory factory=getAS0ObjectsFactory();
      Assert.assertNotNull(factory);
      AtomicValueFactory afactory=getAtomicValueFactory();
      Assert.assertNotNull(afactory);
      while(true){
        long newTicker=getTicker();
        if (newTicker>lastTicker)
        {
          log.error(String.format("%s done: %10d=%5d s+%5df in %3d sec. Rate: %f", getName(), state-lastState, state-lastState-missed, missed, (newTicker-lastTicker)*STEP_SEC, (double)(((double)state-lastState)/(((double)newTicker-lastTicker)*STEP_SEC))));
          lastState=state;
          lastTicker=newTicker;
          missed=0;
        }
        state++;
        if (state%100 == 0)
        {
          t.commit();
          t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        }
        try {
          store.getObjectByOID(t, new LongOid(r.nextInt()%1000000));
        } catch (InterruptedStoreOperationException e) {
          log.info(e);
          t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
        } catch (StoreException e) {
          missed++;
        }
      }
      } catch (TransactionManagerException e1) {
        log.fatal(e1);
      } catch (TransactionException e) {
        log.fatal(e);
      }      
    }
    
    public long getTicker()
    {
      return System.currentTimeMillis()/(1000*STEP_SEC);
    }
  }
  
}
