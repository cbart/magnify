/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package pl.edu.mimuw.jloxim.stores.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ModelException;
import pl.edu.mimuw.jloxim.model.as0.api.resultset.AS0ResultsetBag;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0AtomicObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0PointerObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.model.as0.api.values.TextAtomicValue;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionException;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.exceptions.TransactionManagerException;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.stores.exceptions.InterruptedStoreOperationException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundStoreException;
import pl.edu.mimuw.jloxim.stores.exceptions.StoreException;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;
import pl.edu.mimuw.jloxim.utils.impl.LongOid;
import pl.edu.mimuw.jloxim.utils.impl.RememberExceptionThread;

public abstract class StoreAs0Test {
  private Logger logger = Logger.getLogger(StoreAs0Test.class);

  public abstract StoreAS0 getStore();

  public abstract TransactionManager getTM();

  public abstract AS0ObjectsFactory getAS0ObjectsFactory();

  public abstract AtomicValueFactory getAtomicValueFactory();

  @Test
  public void getStoreTest() {
    Assert.assertNotNull(getStore());
    Assert.assertNotNull(getStore().getStoreId());
  }

  @Test
  public void getTransactionManagerTest() {
    Assert.assertNotNull(getTM());
  }

  @Test(/*expected = ObjectNotFoundStoreException.class*/)
  public void getSuperRoot() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    try {
      AS0ObjectRO result = getStore().getObjectByOID(t, getStore().getSuperRootOid());
      ClosableIterator<AbstractOid> iterator = ((AS0ComplexObjectRO)result).iterator();  
      try {
        Assert.assertFalse(iterator.hasNext());
      } finally {
        iterator.close();
      }
    } finally {
      t.commit();
    }
  }

  @Test
  public void addSubobjects() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
        .newAtomicObject(22,
            getAtomicValueFactory().newAtomicValue(true));
    getStore().addSubobject(t, getStore().getSuperRootOid(), atomicObject);
    Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());

    ClosableIterator<AbstractOid> iter = getStore().getRoots(t);
    Assert.assertTrue(iter.hasNext());
    Assert.assertEquals(atomicObject.getOID(), iter.next());
    Assert.assertFalse(iter.hasNext());
    iter.close();

    t.commit();
  }

  @Test
  public void getRootsOnEmpty() throws TransactionManagerException,
  TransactionException, StoreException {
    Transaction t=getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    ClosableIterator<AbstractOid> it=getStore().getRoots(t);
    Assert.assertNotNull(it);
    it.close();
    t.rollback();
  }

  @Test
  public void getRoots() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AbstractOid> oids = new HashSet<AbstractOid>();
    final int COUNT=100;
    for (int i = 0; i < COUNT; i++) {
      AS0ComplexObjectEditable complexObject = getAS0ObjectsFactory()
          .newEmptyComplexObject(22);
      getStore().addSubobject(t, getStore().getSuperRootOid(), complexObject);
      Assert.assertTrue(complexObject.getOID()!= getStore().getSuperRootOid());
      oids.add(complexObject.getOID());

      AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
          .newAtomicObject(22,
              getAtomicValueFactory().newAtomicValue(true));
      getStore().addSubobject(t, complexObject.getOID(), atomicObject);
      Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());
    }

    ClosableIterator<AbstractOid> iter = getStore().getRoots(t);
    for (int i = 0; i < COUNT; i++) {
      Assert.assertTrue(iter.hasNext());
      AbstractOid value = iter.next();
      Assert.assertTrue(oids.contains(value));
      Assert.assertTrue(oids.remove(value));
    }
    Assert.assertFalse(iter.hasNext());
    Assert.assertTrue(oids.isEmpty());

    iter.close();
    t.commit();
  }

  @Test
  public void getRootsByName() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AbstractOid> oids = new HashSet<AbstractOid>();
    for (int i = 0; i < 1000; i++) {
      AS0ComplexObjectEditable complexObject = getAS0ObjectsFactory()
          .newEmptyComplexObject(100 + (i % 3));
      getStore().addSubobject(t, getStore().getSuperRootOid(), complexObject);
      Assert.assertTrue(complexObject.getOID()!= getStore().getSuperRootOid());
      oids.add(complexObject.getOID());

      AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
          .newAtomicObject(200 + (i % 3),
              getAtomicValueFactory().newAtomicValue(true));
      getStore().addSubobject(t, complexObject.getOID(), atomicObject);
      Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());
    }

    ClosableIterator<AbstractOid> iter = getStore().getRootsByName(t,
        100);
    for (int i = 0; i < 334; i++) {
      logger.info(i);
      Assert.assertTrue(iter.hasNext());
      AbstractOid value = iter.next();
      Assert.assertTrue(oids.contains(value));
      Assert.assertTrue(oids.remove(value));
    }
    Assert.assertFalse(iter.hasNext());
    Assert.assertFalse(oids.isEmpty());
    iter.close();

    iter = getStore().getRootsByName(t, 101);
    for (int i = 0; i < 333; i++) {
      Assert.assertTrue(iter.hasNext());
      AbstractOid value = iter.next();
      Assert.assertTrue(oids.contains(value));
      Assert.assertTrue(oids.remove(value));
    }
    Assert.assertFalse(iter.hasNext());
    Assert.assertFalse(oids.isEmpty());
    iter.close();

    iter = getStore().getRootsByName(t, 102);
    for (int i = 0; i < 333; i++) {
      Assert.assertTrue(iter.hasNext());
      AbstractOid value = iter.next();
      Assert.assertTrue(oids.contains(value));
      Assert.assertTrue(oids.remove(value));
    }
    Assert.assertFalse(iter.hasNext());
    Assert.assertTrue(oids.isEmpty());
    iter.close();

    iter = getStore().getRootsByName(t, 201);
    Assert.assertFalse(iter.hasNext());
    iter.close();

    t.commit();
  }

  @Test
  public void getRootsOnEmptyDB() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    ClosableIterator<AbstractOid> iter = getStore().getRootsByName(t, 100);
    Assert.assertFalse(iter.hasNext());
    iter.close();

    t.commit();
  }

  @Test()
  public void getObjectByOidRoot() throws TransactionManagerException,
      TransactionException, StoreException, ModelException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    try {
      Set<AbstractOid> oids = new HashSet<AbstractOid>();
      for (int i = 0; i < 1000; i++) {
        AS0ComplexObjectEditable complexObject = getAS0ObjectsFactory()
            .newEmptyComplexObject(22);
        getStore().addSubobject(t, getStore().getSuperRootOid(), complexObject);
        Assert.assertTrue(complexObject.getOID()!= getStore().getSuperRootOid());
        oids.add(complexObject.getOID());

        AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
            .newAtomicObject(22, getAtomicValueFactory().newAtomicValue(true));
        getStore().addSubobject(t, complexObject.getOID(), atomicObject);
        Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());
      }

      AS0ComplexObjectRO object = (AS0ComplexObjectRO)
          getStore().getObjectByOID(t, getStore().getSuperRootOid());
      Assert.assertNotNull(object);
      ClosableIterator<AbstractOid> iter = object.iterator();
      try {
        for (int i = 0; i < 1000; ++i) {
          Assert.assertTrue(iter.hasNext());
          AS0ComplexObjectRO complex = (AS0ComplexObjectRO)getStore().getObjectByOID(t, iter.next());
          Assert.assertEquals(22, complex.getNameId());
        }
      } finally {
        iter.close();
      }
    } finally {
      t.rollback();
    }
  }

  @Test
  public void getComplexObjectByOid() throws TransactionManagerException,
      TransactionException, StoreException, ModelException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AbstractOid> oids = new HashSet<AbstractOid>();
    Set<AbstractOid> oids_sub = new HashSet<AbstractOid>();
    for (int i = 0; i < 1000; i++) {
      AS0ComplexObjectEditable complexObject = getAS0ObjectsFactory()
          .newEmptyComplexObject(22);
      getStore().addSubobject(t, getStore().getSuperRootOid(), complexObject);
      Assert.assertTrue(complexObject.getOID()!= getStore().getSuperRootOid());
      oids.add(complexObject.getOID());

      AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
          .newAtomicObject(22,
              getAtomicValueFactory().newAtomicValue(true));
      getStore().addSubobject(t, complexObject.getOID(), atomicObject);
      Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());
      oids_sub.add(atomicObject.getOID());
    }

    for (AbstractOid oid : oids) {
      AS0ObjectRO object = getStore().getObjectByOID(t, oid);
      Assert.assertEquals(getStore().getSuperRootOid(), object.getParentOID());
      Assert.assertEquals(oid, object.getOID());
      ClosableIterator<AbstractOid> iter = ((AS0ComplexObjectRO) object)
          .iterator();
       AbstractOid child = iter.next();

      AS0AtomicObjectRO childObject = (AS0AtomicObjectRO) getStore()
          .getObjectByOID(t, child);
      Assert.assertNotNull(childObject);
      Assert.assertEquals(child, childObject.getOID());
      Assert.assertEquals(oid, childObject.getParentOID());

      Assert.assertTrue(oids_sub.contains(child));
      oids_sub.remove(child);

      Assert.assertFalse(iter.hasNext());
      iter.close();
    }
    t.commit();
  }

  @Test
  public void addSubobjectsPointer() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0PointerObjectEditable obj = getAS0ObjectsFactory().newPointerObject(
        23, new LongOid(56L));
    getStore().addSubobject(t, getStore().getSuperRootOid(), obj);
    Assert.assertNotNull(obj.getOID());
    Assert.assertEquals(getStore().getSuperRootOid(), obj.getParentOID());
    AS0ObjectRO r = getStore().getObjectByOID(t, obj.getOID());
    Assert.assertTrue(r instanceof AS0PointerObjectRO);
    Assert.assertEquals(new LongOid(56L), ((AS0PointerObjectRO) r).getDestinationOID());
    t.commit();
    Transaction t2 = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    r = getStore().getObjectByOID(t2, obj.getOID());
    Assert.assertTrue(r instanceof AS0PointerObjectRO);
    Assert.assertEquals(new LongOid(56L), ((AS0PointerObjectRO) r).getDestinationOID());
    t2.commit();
  }

  @Test(expected = ObjectNotFoundStoreException.class)
  public void addSubobjectsPointerRollback()
      throws TransactionManagerException, TransactionException,
      StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0PointerObjectEditable obj = getAS0ObjectsFactory().newPointerObject(
        23, new LongOid(56L));
    getStore().addSubobject(t, getStore().getSuperRootOid(), obj);
    Assert.assertNotNull(obj.getOID());
    Assert.assertEquals(getStore().getSuperRootOid(), obj.getParentOID());
    AS0ObjectRO r = getStore().getObjectByOID(t, obj.getOID());
    Assert.assertTrue(r instanceof AS0PointerObjectRO);
    Assert.assertEquals(new LongOid(56L), ((AS0PointerObjectRO) r).getDestinationOID());
    t.rollback();
    Transaction t2 = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    try {
      r=getStore().getObjectByOID(t2, obj.getOID());
      Assert.assertNotNull(r);
    } finally {
      t2.rollback();
    }
  }

  @Test
  public void addSubobjectsComplexEmpty() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AS0ObjectEditable> subobjects = new LinkedHashSet<AS0ObjectEditable>();
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory()
        .newComplexObject(22, subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
  }

  @Test
  public void addSubobjectsComplex() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AS0ObjectEditable> subobjects = new LinkedHashSet<AS0ObjectEditable>();
    subobjects.add(getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(17)));
    subobjects.add(getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue("abceęąść")));
    subobjects.add(getAS0ObjectsFactory().newAtomicObject(22,
        getAtomicValueFactory().newAtomicValue(new Date())));
    subobjects.add(getAS0ObjectsFactory().newPointerObject(22, new LongOid(15L)));
    AS0ComplexObjectEditable complex = getAS0ObjectsFactory()
        .newComplexObject(22, subobjects);
    getStore().addSubobject(t, getStore().getSuperRootOid(), complex);
    t.commit();
  }

  @Test
  public void addSubobjects1000x() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_UNCOMMITED);
    Random r = new Random();
    AS0ObjectEditable object = getAS0ObjectsFactory().newAtomicObject(
        r.nextInt(), getAtomicValueFactory().newAtomicValue(true));
    StoreAS0 store = getStore();

    List<AbstractOid> oids=new ArrayList<AbstractOid>();
    oids.add(getStore().getSuperRootOid());
    for (int i=0; i<100; i++)
    {
      AS0ComplexObjectEditable complex=getAS0ObjectsFactory().newComplexObject(r.nextInt(), new HashSet<AS0ObjectEditable>());
      int random=r.nextInt(oids.size());
      AbstractOid parent_oid=oids.get(random);
      store.addSubobject(t, parent_oid, complex);
      oids.add(complex.getOID());
      Assert.assertNotNull("addSubobject method expected to set OID in the added object.", complex.getOID());
    }

    for (int i = 0; i < 1000; i++) {
      store.addSubobject(t, oids.get(r.nextInt(oids.size())), object);
    }
    t.commit();
  }

  @Test
  public void getSubobjectOIDsMapTest() throws TransactionManagerException,
      StoreException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    Set<AbstractOid> oids = new HashSet<AbstractOid>();
    for (int i = 0; i < 1000; i++) {
      AS0ComplexObjectEditable complexObject = getAS0ObjectsFactory()
          .newEmptyComplexObject(100 + (i % 5));
      getStore().addSubobject(t, getStore().getSuperRootOid(), complexObject);
      Assert.assertTrue(complexObject.getOID()!= getStore().getSuperRootOid());
      oids.add(complexObject.getOID());

      AS0AtomicObjectEditable atomicObject = getAS0ObjectsFactory()
          .newAtomicObject(200 + (i % 5),
              getAtomicValueFactory().newAtomicValue(true));
      getStore().addSubobject(t, complexObject.getOID(), atomicObject);
      Assert.assertTrue(atomicObject.getOID()!= getStore().getSuperRootOid());
    }

    Map<Integer, ClosableIterator<AbstractOid>> iterators = getStore()
        .getSubobjectOIDsMap(t, getStore().getSuperRootOid());
    Assert.assertEquals(5, iterators.size());
    checkIterator(iterators.get(100));
    checkIterator(iterators.get(101));
    // checkIterator(iterators.get(102), 202);
    // Not used cursor should not cause problem on closing transaction
    checkIterator(iterators.get(103));
    checkIterator(iterators.get(104));

    t.commit();
  }

  @Test
  public void moveObjectTest() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ComplexObjectEditable abc = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));

    AS0ComplexObjectEditable xyz = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable xy = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xyz));
    AS0ComplexObjectEditable x = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xy));

    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    getStore().addSubobject(t, getStore().getSuperRootOid(), x);

    ClosableIterator<AbstractOid> iter;

    iter = getStore().getSubobjectOIDs(t, ab.getOID());
    emptyIteratorAndAssertItemsCount(1, iter);
    iter.close();

    /*
     * Starting state: <a><ab><abc/></ab></a> <x><xy><xyz/></xy><x>
     */
    getStore().moveObject(t, ab.getOID(), xy.getOID());

    /*
     * Expected state: <a><a/> <x><xy><xyz/><ab><abc/></ab></xy></x>
     */
    iter = getStore().getRoots(t);
    emptyIteratorAndAssertItemsCount(2, iter);
    iter.close();

    iter = getStore().getSubobjectOIDs(t, a.getOID());
    emptyIteratorAndAssertItemsCount(0, iter);
    iter.close();

    iter = getStore().getSubobjectOIDs(t, ab.getOID());
    emptyIteratorAndAssertItemsCount(1, iter);
    iter.close();

    iter = getStore().getSubobjectOIDs(t, x.getOID());
    emptyIteratorAndAssertItemsCount(1, iter);
    iter.close();

    iter = getStore().getSubobjectOIDs(t, xy.getOID());
    emptyIteratorAndAssertItemsCount(2, iter);
    iter.close();

                /* boundary cases */

                getStore().moveObject(t, ab.getOID(), getStore().getSuperRootOid());
                getStore().moveObject(t, ab.getOID(), getStore().getSuperRootOid());

    t.commit();
  }

  private <T> void emptyIteratorAndAssertItemsCount(int itemCount, Iterator<T> it) {
  	int count = 0;
  	while (it.hasNext()) {
  		count++;
  		it.next();
  	}
  	Assert.assertEquals(itemCount, count);
  }


        @Test(expected=StoreException.class)
        public void moveSuperRoot() {
                Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
                try {
                        AS0ComplexObjectEditable complex_object = getAS0ObjectsFactory().newEmptyComplexObject(1);
                        getStore().addSubobject(t, getStore().getSuperRootOid(), complex_object);
                        getStore().moveObject(t, getStore().getSuperRootOid(), complex_object.getOID());
                        logger.info(getStore().toString());
                }finally{
      t.rollback();
    }
        }


  private void checkIterator(ClosableIterator<AbstractOid> iter) {
    Assert.assertNotNull(iter);
    for (int i = 0; i < 200; i++) {
      Assert.assertTrue(iter.hasNext());
      AbstractOid value = iter.next();
      Assert.assertNotNull(value);
      logger.debug("-->value="+value);
      //logger.info("Exception catched ok:"+e.getMessage());
    }
    Assert.assertFalse(iter.hasNext());
    iter.close();
  }

  @Test
  public void getReferersTest() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ComplexObjectEditable abc = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));

    AS0ComplexObjectEditable xyz = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable xy = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xyz));
    AS0ComplexObjectEditable x = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xy));

    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    getStore().addSubobject(t, getStore().getSuperRootOid(), x);

    AS0PointerObjectEditable ref_to_xy = getAS0ObjectsFactory()
        .newPointerObject(15, xy.getOID());
    getStore().addSubobject(t, xyz.getOID(), ref_to_xy);

    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, xyz.getOID())).size());
    Assert.assertEquals(1,
        iterToSet(getStore().getReferrers(t, xy.getOID())).size());
    Assert.assertEquals(0, iterToSet(getStore().getReferrers(t, x.getOID()))
        .size());
    Assert.assertEquals(0, iterToSet(getStore().getReferrers(t, a.getOID()))
        .size());
    Assert.assertEquals(0,
        iterToSet(getStore().getReferrers(t, ab.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, abc.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_xy.getOID())).size());

    AS0PointerObjectEditable ref_to_a = getAS0ObjectsFactory()
        .newPointerObject(15, a.getOID());
    getStore().addSubobject(t, xyz.getOID(), ref_to_a);

    AS0PointerObjectEditable ref_to_xy2 = getAS0ObjectsFactory()
        .newPointerObject(15, xy.getOID());
    getStore().addSubobject(t, xyz.getOID(), ref_to_xy2);

    AS0PointerObjectEditable ref_to_ref_xy = getAS0ObjectsFactory()
        .newPointerObject(15, ref_to_xy.getOID());
    getStore().addSubobject(t, xyz.getOID(), ref_to_ref_xy);

    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, xyz.getOID())).size());
    Set<AbstractOid> iterset = iterToSet(getStore().getReferrers(t, xy.getOID()));
    Assert.assertEquals(2, iterset.size());
    Assert.assertTrue(iterset.contains(ref_to_xy.getOID()));
    Assert.assertTrue(iterset.contains(ref_to_xy2.getOID()));

    // Assert.assertEquals(, iterToSet(getStore().getReferrers(t,
    // xy.getOID())));
    Assert.assertEquals(0, iterToSet(getStore().getReferrers(t, x.getOID()))
        .size());
    iterset = iterToSet(getStore().getReferrers(t, a.getOID()));
    Assert.assertEquals(1, iterset.size());
    Assert.assertTrue(iterset.contains(ref_to_a.getOID()));
    Assert.assertEquals(0,
        iterToSet(getStore().getReferrers(t, ab.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, abc.getOID())).size());

    Assert.assertEquals(1, iterToSet(
        getStore().getReferrers(t, ref_to_xy.getOID())).size());
    iterset = iterToSet(getStore().getReferrers(t, ref_to_xy.getOID()));
    Assert.assertTrue(iterset.contains(ref_to_ref_xy.getOID()));

    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_a.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_xy2.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_ref_xy.getOID())).size());

    t.rollback();
  }

  private <T> Set<T> iterToSet(ClosableIterator<T> iter) {
    LinkedHashSet<T> ret = new LinkedHashSet<T>();
    while (iter.hasNext()) {
      ret.add(iter.next());
    }
    iter.close();
    return ret;
  }

  @Test
  public void removeObjectTestPointers() throws TransactionManagerException,
      StoreException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ComplexObjectEditable abc = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));

    getStore().addSubobject(t, getStore().getSuperRootOid(), ab);

    Set<AS0ObjectEditable> set = new HashSet<AS0ObjectEditable>();
    AS0PointerObjectEditable ref_to_ab = getAS0ObjectsFactory()
        .newPointerObject(165, ab.getOID());
    AS0PointerObjectEditable ref_to_abc = getAS0ObjectsFactory()
        .newPointerObject(166, abc.getOID());
    set.add(ref_to_ab);
    set.add(ref_to_abc);
    AS0ComplexObjectEditable xyz = getAS0ObjectsFactory().newComplexObject(
        15, set);
    AS0ComplexObjectEditable xy = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xyz));
    AS0ComplexObjectEditable x = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(xy));
    Assert.assertNotNull(x);
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    getStore().addSubobject(t, getStore().getSuperRootOid(), ref_to_ab);
    getStore().addSubobject(t, getStore().getSuperRootOid(), ref_to_abc);

    /* Removing reference - referenced object should not be changed */
    getStore().removeObject(t, ref_to_ab.getOID());
    try {
      getStore().getObjectByOID(t, ref_to_ab.getOID());
      Assert.fail("Exception expected");
    } catch (ObjectNotFoundStoreException e) {
      logger.info("Exception catched ok:"+e.getMessage());
    }

    Assert.assertEquals(ab.getOID(), getStore().getObjectByOID(t,
        ab.getOID()).getOID());
    Assert.assertEquals(0,
        iterToSet(getStore().getReferrers(t, ab.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_ab.getOID())).size());

    /*
     * Removing referenced object - reference should be removed
     * autmatically.
     */
    getStore().removeObject(t, ab.getOID());
    try {
      getStore().getObjectByOID(t, ab.getOID());
      Assert.fail("Exception expected");
    } catch (ObjectNotFoundStoreException e) {
      logger.info("Exception catched ok:"+e.getMessage());
    }
    try {
      getStore().getObjectByOID(t, ref_to_ab.getOID());
      Assert.fail("Exception expected");
    } catch (ObjectNotFoundStoreException e) {
      logger.info("Exception catched ok:"+e.getMessage());
    }
    Assert.assertEquals(0,
        iterToSet(getStore().getReferrers(t, ab.getOID())).size());
    Assert.assertEquals(0, iterToSet(
        getStore().getReferrers(t, ref_to_ab.getOID())).size());

    t.commit();
  }

  @Test
  public void removeObjectTestPointersChain()
      throws TransactionManagerException, StoreException,
      TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0ComplexObjectEditable abc = getAS0ObjectsFactory()
        .newEmptyComplexObject(14);
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));

    getStore().addSubobject(t, getStore().getSuperRootOid(), a);

    AS0PointerObjectEditable ref_to_ab = getAS0ObjectsFactory()
        .newPointerObject(165, ab.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), ref_to_ab);

    AS0PointerObjectEditable ref_to_ref_to_ab = getAS0ObjectsFactory()
        .newPointerObject(165, ref_to_ab.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), ref_to_ref_to_ab);

    AS0PointerObjectEditable ref_to_ref_to_ref_to_ab = getAS0ObjectsFactory()
        .newPointerObject(165, ref_to_ref_to_ab.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), ref_to_ref_to_ref_to_ab);

    getStore().removeObject(t, a.getOID());

    assertNotExist(t, a.getOID());
    assertNotExist(t, ab.getOID());
    assertNotExist(t, abc.getOID());

    assertNotExist(t, ref_to_ab.getOID());
    assertNotExist(t, ref_to_ref_to_ab.getOID());
    assertNotExist(t, ref_to_ref_to_ref_to_ab.getOID());

    t.rollback();
  }

  @Test(expected = StoreException.class)
  public void removeObjectSuperRoot() throws TransactionManagerException,
      StoreException, TransactionException {
    Transaction t = getTM().newTransaction(
    TransactionIsolationLevel.READ_COMMITED);
    try{
      getStore().removeObject(t, getStore().getSuperRootOid());
    }finally{
      t.rollback();
    }
  }

  private void assertNotExist(Transaction t, AbstractOid OID) throws StoreException {
    try {
      getStore().getObjectByOID(t, OID);
      Assert.fail("Expected exception");
    } catch (ObjectNotFoundStoreException e) {
      logger.info("Exception catched ok:"+e.getMessage());
    }
  }

  @Test
  public void setAtomicObjectValue() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ObjectEditable abc = getAS0ObjectsFactory().newAtomicObject(18,
        getAtomicValueFactory().newAtomicValue("dupa_dupa"));
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);

    getStore().setAtomicObjectValue(t, abc.getOID(),
        getAtomicValueFactory().newAtomicValue("ass ass"));

    Assert.assertEquals("ass ass",
        ((TextAtomicValue) ((AS0AtomicObjectRO) getStore()
            .getObjectByOID(t, abc.getOID())).getValue())
            .getValue());
    t.rollback();
  }

  @Test
  public void setAtomicObjectValueComplex() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ObjectEditable abc = getAS0ObjectsFactory().newAtomicObject(18,
        getAtomicValueFactory().newAtomicValue("dupa_dupa"));
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);

    getStore().setAtomicObjectValue(t, a.getOID(),
        getAtomicValueFactory().newAtomicValue("ass ass"));

    Assert.assertEquals("ass ass",
        ((TextAtomicValue) ((AS0AtomicObjectRO) getStore()
            .getObjectByOID(t, a.getOID())).getValue()).getValue());
    assertNotExist(t, ab.getOID());
    assertNotExist(t, abc.getOID());
    t.rollback();
  }

  @Test
  public void setNewPointerObjectDestination() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ObjectEditable abc = getAS0ObjectsFactory().newPointerObject(16, new LongOid(17L));
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);

    getStore().setNewPointerObjectDestination(t, abc.getOID(), new LongOid(18L));

    Assert.assertEquals(new LongOid(18L), ((AS0PointerObjectRO) getStore()
        .getObjectByOID(t, abc.getOID())).getDestinationOID());
    t.rollback();
  }

  @Test
  public void setNewPointerObjectDestinationComplex() throws StoreException,
      TransactionManagerException, TransactionException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);

    AS0ObjectEditable abc = getAS0ObjectsFactory().newPointerObject(16, new LongOid(17L));
    AS0ComplexObjectEditable ab = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(abc));
    AS0ComplexObjectEditable a = getAS0ObjectsFactory().newComplexObject(
        14, Collections.singleton(ab));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);

    getStore().setNewPointerObjectDestination(t, a.getOID(), new LongOid(18L));

    Assert.assertEquals(new LongOid(18L), ((AS0PointerObjectRO) getStore()
        .getObjectByOID(t, a.getOID())).getDestinationOID());
    assertNotExist(t, ab.getOID());
    assertNotExist(t, abc.getOID());
    t.rollback();
  }

  @Test
  public void setCyclicReferences() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable a = getAS0ObjectsFactory().newAtomicObject(10,
        getAtomicValueFactory().newAtomicValue(true));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    AS0PointerObjectEditable r_a = getAS0ObjectsFactory().newPointerObject(
        11, a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), r_a);
    AS0PointerObjectEditable rr_a = getAS0ObjectsFactory()
        .newPointerObject(11, r_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rr_a);
    AS0PointerObjectEditable rrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrr_a);
    AS0PointerObjectEditable rrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrr_a);
    AS0PointerObjectEditable rrrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrrr_a);
    AS0PointerObjectEditable rrrrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrrrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrrrr_a);
    getStore().setNewPointerObjectDestination(t, a.getOID(),
        rrrrrr_a.getOID());

    AS0PointerObjectRO ref;
    for (int i = 0; i < 1000; i++) // If its implemmented as stack - we can
                    // get overflow
    {
      ref = (AS0PointerObjectRO) getStore().getObjectByOID(t,
          rrrr_a.getDestinationOID());
      Assert.assertNotNull(ref);
    }

    t.commit();
  }

  @Test
  public void setCyclicReferencesRemove() throws TransactionManagerException,
      TransactionException, StoreException {
    Transaction t = getTM().newTransaction(
        TransactionIsolationLevel.READ_COMMITED);
    AS0ObjectEditable a = getAS0ObjectsFactory().newAtomicObject(10,
        getAtomicValueFactory().newAtomicValue(true));
    getStore().addSubobject(t, getStore().getSuperRootOid(), a);
    AS0PointerObjectEditable r_a = getAS0ObjectsFactory().newPointerObject(
        11, a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), r_a);
    AS0PointerObjectEditable rr_a = getAS0ObjectsFactory()
        .newPointerObject(11, r_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rr_a);
    AS0PointerObjectEditable rrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrr_a);
    AS0PointerObjectEditable rrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrr_a);
    AS0PointerObjectEditable rrrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrrr_a);
    AS0PointerObjectEditable rrrrrr_a = getAS0ObjectsFactory()
        .newPointerObject(11, rrrrr_a.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), rrrrrr_a);
    getStore().setNewPointerObjectDestination(t, a.getOID(),
        rrrrrr_a.getOID());

    getStore().removeObject(t, rrrr_a.getOID());

    assertNotExist(t, a.getOID());
    assertNotExist(t, r_a.getOID());
    assertNotExist(t, rr_a.getOID());
    assertNotExist(t, rrr_a.getOID());
    assertNotExist(t, rrrr_a.getOID());
    assertNotExist(t, rrrrr_a.getOID());
    assertNotExist(t, rrrrrr_a.getOID());

    t.commit();
  }

  @Test
  public void concurrentOperationsTest() throws Throwable {
    logger.info("concurrentOperationsTest started");
    RememberExceptionThread writer = new RememberExceptionThread() {
      @Override
      public void runWithException() throws TransactionManagerException,
          StoreException, TransactionException {
        TransactionManager tm = getTM();
        Transaction t = tm
            .newTransaction(TransactionIsolationLevel.READ_COMMITED);
        try{
          for (int i = 0; i < 1000; /*only successful*/) {
            try{
              getStore().addSubobject(t, getStore().getSuperRootOid(),
                  getAS0ObjectsFactory().newEmptyComplexObject(1));
              i++;
            } catch (InterruptedStoreOperationException e) {
              t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            }
          }
        }finally{
          t.rollback();
        }
      }
    };
    RememberExceptionThread reader = new RememberExceptionThread() {
      @Override
      public void runWithException() throws TransactionManagerException,
          StoreException, TransactionException {
        TransactionManager tm = getTM();
        Transaction t = tm
            .newTransaction(TransactionIsolationLevel.READ_COMMITED);
        try{
          for (int i = 0; i < 1000; ) {
            try {
              ClosableIterator<AbstractOid> it=getStore().getRoots(t);
              Assert.assertNotNull(it);              
              it.close();
              i++;
            } catch (InterruptedStoreOperationException e) {
              t = tm.newTransaction(TransactionIsolationLevel.READ_COMMITED);
            }
          }
        }finally{
          t.commit();
        }
      }
    };
    writer.start();
    reader.start();
    reader.join();
    writer.join();
    if (!reader.isSuccessful())
      throw reader.getThrownException();
    if (!writer.isSuccessful())
      throw writer.getThrownException();
  }

  /*References preserving tests in setValue methods*/

  @Test
  public void shouldPreserveReferencesAfterSets() throws TransactionManagerException, StoreException, TransactionException{
    logger.info("1----------------------------");
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

    AS0AtomicObjectEditable object=getAS0ObjectsFactory().newAtomicObject(2, getAtomicValueFactory().newAtomicValue("dwa"));
    getStore().addSubobject(t, getStore().getSuperRootOid(), object);
    getStore().toString();

    logger.info("2----------------------------");
    AS0PointerObjectEditable pointer=getAS0ObjectsFactory().newPointerObject(3, object.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), pointer);
    getStore().toString();
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    logger.info("3----------------------------");

    getStore().setAtomicObjectValue(t, object.getOID(), getAtomicValueFactory().newAtomicValue(true));
    getStore().toString();
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    logger.info("4----------------------------");


    getStore().setNewPointerObjectDestination(t, object.getOID(), pointer.getOID());
    getStore().toString();
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    assertEquals(getStore().getReferrers(t, pointer.getOID()), object.getOID());
    logger.info("5----------------------------");

    getStore().setAtomicObjectValue(t, object.getOID(), getAtomicValueFactory().newAtomicValue(false));
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    assertEquals(getStore().getReferrers(t, pointer.getOID()));
    getStore().toString();
    logger.info("6----------------------------");

    AS0ObjectEditable subobject1=getAS0ObjectsFactory().newAtomicObject(5, getAtomicValueFactory().newAtomicValue(3.14));
    AS0ObjectEditable subobject2=getAS0ObjectsFactory().newAtomicObject(5, getAtomicValueFactory().newAtomicValue(4.14));
    AS0ObjectEditable subobject3=getAS0ObjectsFactory().newComplexObject(5, Collections.<AS0ObjectEditable>emptySet());
    getStore().setNewComplexObjectValue(t, object.getOID(), Arrays.asList(subobject1, subobject2, subobject3));
    getStore().toString();
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    logger.info("7----------------------------");

    AS0PointerObjectEditable pointer2=getAS0ObjectsFactory().newPointerObject(3, subobject3.getOID());
    getStore().addSubobject(t, getStore().getSuperRootOid(), pointer2);
    getStore().toString();
    assertEquals(getStore().getReferrers(t, subobject3.getOID()), pointer2.getOID());
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    logger.info("8----------------------------");

    getStore().toString();
    getStore().setAtomicObjectValue(t, object.getOID(), getAtomicValueFactory().newAtomicValue(false));
    assertEquals(getStore().getReferrers(t, object.getOID()), pointer.getOID());
    assertEquals(getStore().getReferrers(t, pointer.getOID()));
    assertEquals(getStore().getReferrers(t, subobject3.getOID()));
    logger.info("9----------------------------");

                getStore().addSubobject(t, getStore().getSuperRootOid(), subobject3);
                getStore().moveObject(t, object.getOID(), subobject3.getOID());
                getStore().moveObject(t, object.getOID(), subobject3.getOID());
                getStore().moveObject(t, object.getOID(), getStore().getSuperRootOid());
                getStore().moveObject(t, object.getOID(), getStore().getSuperRootOid());
                getStore().toString();

    getStore().removeObject(t, object.getOID());
    assertEquals(getStore().getReferrers(t, object.getOID()));
    assertEquals(getStore().getReferrers(t, pointer.getOID()));
    assertEquals(getStore().getReferrers(t, subobject3.getOID()));
    logger.info("10----------------------------");

    t.commit();
  }


  /**
   * Checks if given iterator content is the same as given set of values
   * @param <T>
   * @param referers
   * @param expected
   */
  private <T> void assertEquals(ClosableIterator<T> referers, T... expected) {
      for (T exp:expected){
        Assert.assertEquals(exp, referers.next());
      }
      Assert.assertFalse("Iterator expected to be empty", referers.hasNext());
      referers.close();
  }


  @Test(expected=ObjectNotFoundStoreException.class)
  public void addSubobjectToNotExistingObject() throws TransactionManagerException, StoreException, TransactionException{
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    try{
      AS0ObjectEditable subobject=getAS0ObjectsFactory().newComplexObject(5, Collections.<AS0ObjectEditable>emptySet());
      getStore().addSubobject(t, new LongOid(1000), subobject);
    }finally{
      t.rollback();
    }
  }
      
    @Test(expected=ObjectNotFoundStoreException.class)
    public void setAtomicObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setAtomicObjectValue(t, newOid, getAtomicValueFactory().newAtomicValue(7));
      } finally {
        t.commit();
      }
    }
    
    @Test(expected=ObjectNotFoundStoreException.class)
    public void setNewComplexObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setNewComplexObjectValue(t, newOid, Collections.EMPTY_LIST);      
      } finally {
        t.commit();
      }
    }
    
    @Test(expected=ObjectNotFoundStoreException.class)
    public void setNewPointerObjectNotFound() {
      StoreAS0 store = getStore();        
      Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
      
      try {
        AS0AtomicObjectEditable object = getAS0ObjectsFactory().newAtomicObject(7, 
              getAtomicValueFactory().newAtomicValue(Calendar.getInstance()));
      
        AbstractOid newOid = store.addSubobject(t, store.getSuperRootOid(), object);
        store.removeObject(t, newOid);
      
        store.setNewPointerObjectDestination(t, newOid, store.getSuperRootOid());
      } finally {
        t.commit();
      }
    }
           

  @Test(expected=StoreException.class)
  public void addSubobjectToNotComplexObject() throws TransactionManagerException, StoreException, TransactionException{
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    try{
      AS0AtomicObjectEditable obj=getAS0ObjectsFactory().newAtomicObject(17, getAtomicValueFactory().newAtomicValue(true));
      getStore().addSubobject(t, getStore().getSuperRootOid(), obj);

      AS0ObjectEditable subobject=getAS0ObjectsFactory().newComplexObject(5, Collections.<AS0ObjectEditable>emptySet());
      getStore().addSubobject(t, obj.getOID(), subobject);
    }finally{
      t.rollback();
    }
  }


        @Test
        public void parentAfterSets() {
              Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);

              AS0ComplexObjectEditable complex_object = getAS0ObjectsFactory().newEmptyComplexObject(1);
              AS0ComplexObjectEditable complex_object2 = getAS0ObjectsFactory().newEmptyComplexObject(2);

              getStore().addSubobject(t, getStore().getSuperRootOid(), complex_object);
              getStore().addSubobject(t, complex_object.getOID(), complex_object2);

              getStore().setAtomicObjectValue(t, complex_object2.getOID(), getAtomicValueFactory().newAtomicValue(true));
              AS0ComplexObjectRO complex_objectRO = (AS0ComplexObjectRO) getStore().getObjectByOID(t, complex_object.getOID());
              ClosableIterator<AbstractOid> iter = complex_objectRO.iterator();

              AS0AtomicObjectRO atomic_object = (AS0AtomicObjectRO) getStore().getObjectByOID(t, iter.next());
              Assert.assertEquals( getAtomicValueFactory().newAtomicValue(true), atomic_object.getValue());
              Assert.assertFalse(iter.hasNext());

              iter.close();
              t.commit();
        }

        // Configuration area test

        @Test
        public void configAreaExists() {
          Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
          try {
            Assert.assertNotNull(getStore().getConfigRootOid());
            Assert.assertEquals(getStore().getSuperRootOid(),
                getStore().getParentOID(t, getStore().getConfigRootOid()));
          }finally {
            t.rollback();
          }
        }

        @Test(expected=StoreException.class)
        public void cannotRemoveConfigArea() {
          Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
          try {
            getStore().removeObject(t, getStore().getConfigRootOid());
          } finally {
            t.rollback();
          }
        }

        @Test
        public void addChildToConfigArea() {
          Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
          try {
            AS0AtomicObjectEditable obj1 =
              getAS0ObjectsFactory().newAtomicObject(7, getAtomicValueFactory().newAtomicValue("config1"));
            getStore().addSubobject(t, getStore().getConfigRootOid(), obj1);
            Assert.assertEquals(getStore().getConfigRootOid(),
                getStore().getParentOID(t, obj1.getOID()));
          } finally {
            t.rollback();
          }
        }
                
  @Test
  public void tryToCauseDeadlock() throws Throwable {     
    logger.error("tryToCauseDeadlock test started");
      
    final List<AbstractOid> oIds = new ArrayList<AbstractOid>();
      
    // init
    final int COUNT = 1000;
    Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
    try {
      for (int i=0; i<COUNT; ++i) {
        AS0AtomicObjectEditable obj = getAS0ObjectsFactory().newAtomicObject(i, getAtomicValueFactory().newAtomicValue("" + i));
        getStore().addSubobject(t, getStore().getSuperRootOid(), obj);
        oIds.add(obj.getOID());
      }
    } finally {
        t.commit();
    }
 
    RememberExceptionThread writerAscOrder = new RememberExceptionThread() {
      @Override
      public void runWithException() throws Exception {
        setName("writerAscOrder");
        logger.info("start");
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
        int i = -1;
        while(++i < COUNT) {
          try {
            TextAtomicValue newAtomicValue = getAtomicValueFactory().newAtomicValue("" + i+1);
            getStore().setAtomicObjectValue(t, oIds.get(i), newAtomicValue);
          } catch (InterruptedStoreOperationException ex) {
            logger.info("InterruptedStoreOperationException catched (expected) i=" + i);
            t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
            //i = -1;
          }
        }
        t.commit();
      }
    };
    
    RememberExceptionThread writerDescOrder = new RememberExceptionThread() {
      @Override
      public void runWithException() throws Exception {
        setName("writerDescOrder");
        logger.info("start");
        Transaction t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
        int i = COUNT;
        while(--i > 0) {
          try {
            TextAtomicValue newAtomicValue = getAtomicValueFactory().newAtomicValue("" + i+1);
            getStore().getObjectByOID(t, oIds.get(i));
            getStore().setAtomicObjectValue(t, oIds.get(i), newAtomicValue);
          } catch (InterruptedStoreOperationException ex) {
            logger.info("InterruptedStoreOperationException catched (expected) i=" + i);
            t = getTM().newTransaction(TransactionIsolationLevel.READ_COMMITED);
            //i = COUNT;
          }
        }
        t.commit();
      }
    };
    
    writerAscOrder.start();
    writerDescOrder.start();

    writerAscOrder.join();
    writerDescOrder.join();    
    if (!writerAscOrder.isSuccessful())
      throw writerAscOrder.getThrownException();
    if (!writerDescOrder.isSuccessful())
      throw writerDescOrder.getThrownException();        
  }

}
