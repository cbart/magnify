/*
 * Copyright 2011 Faculty of Mathematics Informatics and Mechanics at the University of Warsaw.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package pl.edu.mimuw.jloxim.stores.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import org.apache.log4j.Logger;
import org.junit.Test;
import pl.edu.mimuw.jloxim.model.as0.api.AS0ObjectsFactory;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ComplexObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.ro.AS0ObjectRO;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0AtomicObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0ComplexObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.rw.AS0PointerObjectEditable;
import pl.edu.mimuw.jloxim.model.as0.api.values.AtomicValueFactory;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.Transaction;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionIsolationLevel;
import pl.edu.mimuw.jloxim.physical_trans.trans_mgr.api.TransactionManager;
import pl.edu.mimuw.jloxim.stores.as0.StoreAS0;
import pl.edu.mimuw.jloxim.utils.api.AbstractOid;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

/**
 *
 * @author kadamczyk
 * @version $Id: StoreAs0CmpPerfTest.java 2496 2011-09-24 00:33:50Z kadamczyk $
 */
public abstract class StoreAs0CmpPerfTest {
  private static final Logger logger = Logger.getLogger(StoreAs0CmpPerfTest.class);
  Random rand = new Random(System.currentTimeMillis());

  public abstract void clearApplicationContext();
  
  public abstract StoreAS0 getStore(); 
  public abstract TransactionManager getTM();
    
  public abstract AS0ObjectsFactory getAS0ObjectsFactory();
  public abstract AtomicValueFactory getAtomicValueFactory();
  
  /*
   * 1. Dadawanie n małych obiektów atomowych o losowych wartościach typu liczby całkowitej i losowym identyfikatorze nazwy
   * 2. Dadawanie n obiektów atomowych o wartościach typu tekstowego o długości 1000 znaków.
   * 3. Tworzenie losowego drzewa obiektów typu złożonego poprzed stworzenie kolejno n obiektów złożonych o losowo wybranym ojcu w drzewie, dla każdego z nich tworzonych jest 100 pustych podobiektów typu złożonego.
   * 4. Tworzenie losowego drzewa składającego się z 2*n obiektów typu złożonego zawierającego dodatkowo n obiektów wzkaźnikowych referujących do losowo wybranego, jednego z poprzednio dodanych, obiektów w drzewie.
   * 5. Usuwanie n obiektów stworznych w metodą z testu pierwszego pojedynczo, jeden po drugim, w kolejności ich dodania lub losowo
   * 6. Usuwanie n obiektów stworznych w metodą z testu pierwszego podanych na raz
   * 7. Przeglądanie obiektów stworzonych metodą z testu pierwszego w kolejności ich dodawania lub losowej
   * 8. Przeglądanie w losowej kolejności obiektów złożonych z losowego drzewa obiektów stworzonego w teście 3, bez pobierania ich dzieci
   * 9. Przeglądanie w losowej kolejności obiektów złożonych z losowego drzewa obiektów stworzonego w teście 3 wraz z przeglądaniem dzieci każdego z obiektów
   */    
        
  public String createRandomString(int len) {        
    final String sample = "żą@łśźźćðę¶đ“”ŋŧ←ħńµ"
      + "j↓→ĸłóþzaqwsxcderfvbgtyhnjuikmlop \t\n\b\\";
    int i=0; 
    StringBuilder builder = new StringBuilder();
    while (i<len) {
      builder.append(sample).append(i);
      i += sample.length();
    }
                
    return builder.toString().substring(0, len);
  }
  
  private long opStartTime = 0;
  public void timerStart() {
      opStartTime = System.currentTimeMillis();
  }
  
  public void timerStop(String opName) {
      long timeTaken = System.currentTimeMillis() - opStartTime;
      logger.info(opName + " : " + timeTaken);
  }

  /**
   * Dadawanie n obiektów atomowych o losowych wartościach typu Integer 
   * i losowym identyfikatorze nazwy
   * 
   * @param n 
   * @param randName - if true create objects with random name identifier
   * @return object identifiers array with addition order
   */  
  public ArrayList<AbstractOid> createIntegerAtomicValue(int n, boolean randName) {
    AtomicValueFactory avf = getAtomicValueFactory();
    AS0ObjectsFactory aof = getAS0ObjectsFactory();
    StoreAS0 store = getStore(); 
    AbstractOid rootOid = store.getSuperRootOid();    
    
    ArrayList<AbstractOid> oIds = new ArrayList<AbstractOid>();
    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);        
    
    timerStart();
    for (int i=0; i<n; ++i) {
      AS0AtomicObjectEditable object = aof.newAtomicObject(
              (randName ? rand.nextInt() : 7), 
              avf.newAtomicValue(rand.nextInt()));
      oIds.add(store.addSubobject(t, rootOid, object));      
    }
    timerStop("createIntegerAtomicValue c" + n + " r" + randName);
    
    t.commit();    
    return oIds;
  }
  
  public void updateIntegerAtomicValue(int n, boolean randName) {
    AtomicValueFactory avf = getAtomicValueFactory();
    AS0ObjectsFactory aof = getAS0ObjectsFactory();
    StoreAS0 store = getStore(); 
        
    ArrayList<AbstractOid> oIds = createIntegerAtomicValue(n, true);    
    Collections.shuffle(oIds);
        
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);        
    
    timerStart();
    for (int i=0; i<n; ++i) {
      AS0AtomicObjectEditable object = aof.newAtomicObject(
              (randName ? rand.nextInt() : 13), 
              avf.newAtomicValue(rand.nextInt()));
      store.setAtomicObjectValue(t, oIds.get(i), avf.newAtomicValue(rand.nextInt()));
    }
    timerStop("updateIntegerAtomicValue c" + n + " r" + randName);
    
    t.commit();    
  }
  
  /**
   * Dadawanie n obiektów atomowych o wartościach typu tekstowego o długości 
   * size znaków.
   * 
   * @param n 
   * @param size - random string length
   * @param randName - if true create objects with random name identifier
   * @return object identifiers array with addition order
   */
  public ArrayList<AbstractOid> createStringAtomicValue(int count, int size, 
          boolean randomName) {
    AtomicValueFactory avf = getAtomicValueFactory();
    AS0ObjectsFactory aof = getAS0ObjectsFactory();
    StoreAS0 store = getStore(); 
    AbstractOid rootOid = store.getSuperRootOid();    
    
    ArrayList<AbstractOid> oIds = new ArrayList<AbstractOid>();
    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);        
    
    timerStart();
    for (int i=0; i<count; ++i) {
      AS0AtomicObjectEditable object = aof.newAtomicObject(
              (randomName ? rand.nextInt() : 7), 
        avf.newAtomicValue(createRandomString(size)));
      oIds.add(store.addSubobject(t, rootOid, object));
    }
    timerStop("createStringAtomicValueTest c" + count + " s" + size + 
            " r" + randomName);
    
    t.commit();    
    return oIds;
  } 
  
  /**
   * Remove all objects created by createIntegerAtomicValue, one by one.
   * 
   * @param n 
   */
  public void removeObjects(int n) {
    StoreAS0 store = getStore();    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);
        
    ArrayList<AbstractOid> oIds = createIntegerAtomicValue(n, true);
    
    timerStart();
    for (AbstractOid oId : oIds) {
        store.removeObject(t, oId);
    }
    timerStop("removeObjects n" +n);
    
    t.commit();
    
  }     

  /**
   * Remove all objects created by createIntegerAtomicValue, all at once.
   * 
   * @param n 
   */
  public void removeAllObjectsAtOnce(int n) {
    StoreAS0 store = getStore();    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);
        
    ArrayList<AbstractOid> oIds = createIntegerAtomicValue(n, true);
    
    int i=0;
    AbstractOid oIdsArray[] = new AbstractOid[oIds.size()];
    for (AbstractOid oid : oIds) {
        oIdsArray[i++] = oid;
    }
    
    timerStart();
    store.removeObjects(t, oIdsArray);
    timerStop("removeAllObjectsAtOnce n" +n);

    t.commit();
  } 
  
  /**
   * Create random complex object tree, and for each object 
   * 100 additional subobjects.
   * 
   * @param n
   * @param randName - if true create objects with random name identifier
   * @return object identifiers array with addition order (only main objects)
   */
  public ArrayList<AbstractOid> createComplexObjectTree(int n, boolean randName) {
    AtomicValueFactory avf = getAtomicValueFactory();
    AS0ObjectsFactory aof = getAS0ObjectsFactory();
    StoreAS0 store = getStore();        
    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);

    ArrayList<AbstractOid> oIds = new ArrayList<AbstractOid>();    
    ArrayList<AbstractOid> pIds = new ArrayList<AbstractOid>();
        
    timerStart();
    oIds.add(store.getSuperRootOid());
    for (int i=0; i<n; ++i) {
      AS0ComplexObjectEditable object = aof.newEmptyComplexObject(
              randName ? rand.nextInt() : 7);
      AbstractOid oId = store.addSubobject(t, 
              oIds.get(rand.nextInt(oIds.size())), object);
      pIds.add(oId);
      oIds.add(oId);
      for (int j=0; j<100; ++j) {
        oIds.add(store.addSubobject(t, oId, object));
      }
    }
    timerStop("createComplexObjectTree n" + n + " r" + randName);
    
    t.commit();    
    return pIds;
  }      
  
  public ArrayList<AbstractOid> createReferrerObjectGraph(int n, boolean randName) {
    AtomicValueFactory avf = getAtomicValueFactory();
    AS0ObjectsFactory aof = getAS0ObjectsFactory();
    StoreAS0 store = getStore();  
    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);

    ArrayList<AbstractOid> cIds = new ArrayList<AbstractOid>();
    ArrayList<AbstractOid> oIds = new ArrayList<AbstractOid>();    
        
    timerStart();
    
    cIds.add(store.getSuperRootOid());
    oIds.add(store.getSuperRootOid());
    for (int i=0; i<n; i+=3) {
      for (int j=0; j<2; ++j) {
        AS0ComplexObjectEditable complexObject = aof.newEmptyComplexObject(
                (randName ? rand.nextInt() : 7));
            
        cIds.add(store.addSubobject(t, cIds.get(rand.nextInt(cIds.size())), 
                complexObject));
        oIds.add(cIds.get(cIds.size()-1));
      }
      AS0PointerObjectEditable pointerObject = aof.newPointerObject(
              (randName ? rand.nextInt() : 7),
        oIds.get(rand.nextInt(oIds.size())));
            
      oIds.add(store.addSubobject(t, cIds.get(rand.nextInt(cIds.size())), 
              pointerObject));      
    }
    
    timerStop("createReferrerObjectGraph n" + n + " r" + randName);
    
    t.commit();
    
    oIds.remove(store.getSuperRootOid());
    return oIds;
  }   
  
  void searchAtomicObjects(int n, boolean randomOrder) {
    StoreAS0 store = getStore();    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);
    
    ArrayList<AbstractOid> oIds = createIntegerAtomicValue(n, true);
    
    if (randomOrder) {
        Collections.shuffle(oIds);
    }
    
    timerStart();
    
    for (AbstractOid oId : oIds) {
        store.getObjectByOID(t, oId);
    }
    timerStop("searchAtomicObjects n" + n + " r" + randomOrder);
    
    
    t.commit();    
  }
   
  void searchComplexObjects(int n, boolean randomOrder, boolean deep, 
          boolean prefetch) {
    StoreAS0 store = getStore();    
    Transaction t = getTM().newTransaction(
            TransactionIsolationLevel.READ_UNCOMMITED);
    
    ArrayList<AbstractOid> oIds = createComplexObjectTree(n, true);

    if (randomOrder) {
        Collections.shuffle(oIds);
    }
    
    timerStart();
    
    for (AbstractOid oId : oIds) {
      AS0ObjectRO object = store.getObjectByOID(t, oId);
      
      if (deep) {        
        if (prefetch)
          store.prefetchDeepObject(oId);
        
        if (object instanceof AS0ComplexObjectRO) {
          AS0ComplexObjectRO complexObject = (AS0ComplexObjectRO) object;
          ClosableIterator<AbstractOid> subobjects = complexObject.iterator();
          try {
            while (subobjects.hasNext()) {
              store.getObjectByOID(t, subobjects.next());
            }
          } finally {
            subobjects.close();
          }
        }
      }
        
    }    
    // stop tic
    timerStop("searchComplexObjects n" + n + " r" + randomOrder + " d" + deep 
            + " p" + prefetch);
    
    t.commit();
  }
  
  @Test
  public void comparePerformance() {
      
    final int testCases[] = {100};//, 500, 1000, 5000, 10000, 20000, 50000, 100000};
    final int longTestCases[] = {50};//, 100, 200, 400, 800, 1200};
    
    // warm-up
    createIntegerAtomicValue(100, true);
    clearApplicationContext();
      
    for (int i=0; i<testCases.length; ++i) {
      final int N = testCases[i];      
      logger.info("starts with n=" + N);
      
      createIntegerAtomicValue(N, true); 
      clearApplicationContext();
      
      updateIntegerAtomicValue(N, true);
      clearApplicationContext();
      
      createStringAtomicValue(N, 1000, true); 
      clearApplicationContext();
      
      removeObjects(N);
      clearApplicationContext();
      
      removeAllObjectsAtOnce(N); 
      clearApplicationContext();
      
      createReferrerObjectGraph(N, true); 
      clearApplicationContext();
      
      searchAtomicObjects(N, false /*randOrder*/); 
      clearApplicationContext();
      
      searchAtomicObjects(N, true /*randOrder*/); 
      clearApplicationContext();      
    }
        
    for (int i=0; i<longTestCases.length; ++i) {
      final int N = longTestCases[i];      
      logger.info("starts long tests with n=" + N);
            
      createComplexObjectTree(N, true); 
      clearApplicationContext();
      
      searchComplexObjects(N, true /*randOrder*/, false /*deep*/, false /*prefetch*/); 
      clearApplicationContext();
      
      searchComplexObjects(N, true /*randOrder*/, true /*deep*/, false /*prefetch*/); 
      clearApplicationContext();      
    }
  }

}
