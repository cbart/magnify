/**
 * Copyright 2008 Faculty of Mathematics, Informatics and Mechanics - University of Warsaw
 * and the project's contributors (see changelog). 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under 
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language governing permissions 
 * and limitations under the License. 
 */

package pl.edu.mimuw.jloxim.stores.tests;

import java.util.HashSet;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;

import pl.edu.mimuw.jloxim.stores.as0.NamesTranslator;
import pl.edu.mimuw.jloxim.stores.exceptions.NameTranslatorException;
import pl.edu.mimuw.jloxim.stores.exceptions.ObjectNotFoundNameTranslatorException;
import pl.edu.mimuw.jloxim.utils.api.ClosableIterator;

public abstract class NamesTranslatorTest {
  private Logger logger=Logger.getLogger(NamesTranslatorTest.class);
  
  public abstract NamesTranslator getNamesTranslator();

  @Test
  public void testGetOrRegisterName() throws NameTranslatorException{
    NamesTranslator namesTranslator=getNamesTranslator();
    for (int i = 0; i < 1000; i++)
      Assert.assertEquals(i, namesTranslator.getOrRegisterName("name_" + i));
    for (int i = 0; i < 1000; i++)
      Assert.assertEquals(i, namesTranslator.getOrRegisterName("name_" + i));
    for (int i = 0; i < 1000; i++)
      Assert.assertEquals(1000 + i, namesTranslator.getOrRegisterName("name2_" + i));
    for (int i = 0; i < 1000; i++)
      Assert.assertEquals(i, namesTranslator.getOrRegisterName("name_" + i));
  }

  @Test
  public void testGetAllEntriesEmpty() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    ClosableIterator<? extends Entry<Integer, String>> iter = namesTranslator.getAllEntries();
    try {
      Assert.assertNotNull("Iterator expected to be not null", iter);
      Assert.assertEquals("Iterator expected to be not empty", true, iter.hasNext());
      iter.next();
      Assert.assertEquals("Iterator expected to be empty", false, iter.hasNext());
    } finally {
      iter.close();
    }
  }

  @Test
  public void testGetAllEntries1item() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    int id = namesTranslator.getOrRegisterName("item");
    // namesTranslator.getOrRegisterName(null, "dupa2");
    ClosableIterator<? extends Entry<Integer, String>> iter = namesTranslator.getAllEntries();
    try {
      Assert.assertNotNull("Iterator expected to be not null", iter);
      Assert.assertEquals("Iterator expected to have two items", true, iter.hasNext());
      iter.next();
      Assert.assertEquals("Iterator expected to have two items", true, iter.hasNext());
      Entry<Integer, String> is = iter.next();
      Assert.assertTrue(Integer.valueOf(id) == is.getKey() || NamesTranslator.SUPERROOT == is.getKey());
      Assert.assertTrue("item".equals(is.getValue()) 
          || NamesTranslator.SUPERROOT_NAME.equals(is.getValue()));
      Assert.assertEquals("Iterator expected to be empty", false, iter
          .hasNext());
      try {
        iter.next();
        Assert.fail("NoSuchElementException expected");
      } catch (NoSuchElementException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    } finally {
      iter.close();
    }
  }

  @Test
  public void testGetAllEntriesBig() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    Set<String> names = new HashSet<String>();
    names.add("/");
    
    for (int i = 1000; i > 0; i--) {
      String s = String.format("%7d", i);
      namesTranslator.getOrRegisterName(s);
      namesTranslator.getOrRegisterName(s);
      names.add(s);
    }
    // namesTranslator.getOrRegisterName(null, "dupa2");
    ClosableIterator<? extends Entry<Integer, String>> iter = namesTranslator.getAllEntries();
    try {
      Assert.assertNotNull("Iterator expected to be not empty", iter);
      Assert.assertEquals("Iterator expected to have one item", true,
          iter.hasNext());

      while(iter.hasNext()) {
        Entry<Integer, String> is = iter.next();
        Assert.assertTrue(names.contains(is.getValue()));
        names.remove(is.getValue());
      }
      
      Assert.assertEquals(0, names.size());
      try {
        iter.next();
        Assert.fail("NoSuchElementException expected");
      } catch (NoSuchElementException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    } finally {
      iter.close();
    }
  }

  @Test
   public void testGetNameByNameIdEmpty() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    for (int i = 0; i < 100; i++) {
      try {
        namesTranslator.getNameByNameId(i);
        Assert.fail("ObjectNotFountNameTranslatorException expected");
      } catch (ObjectNotFoundNameTranslatorException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    }
   }
  
  @Test
  public void testGetNameByNameIdComposite() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    for (int i = 0; i < 100; i++) {
      try {
        namesTranslator.getNameIdByName( "name_" + i);
        Assert.fail("ObjectNotFountNameTranslatorException expected");
      } catch (ObjectNotFoundNameTranslatorException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    }
    for (int i = 0; i < 100; i += 2) {
      Assert.assertEquals("name_"+i, namesTranslator.getNameByNameId(namesTranslator.getOrRegisterName( "name_" + i)));
    }
    for (int i = 0; i < 100; i++) {
      try {
        Assert.assertEquals(i / 2, namesTranslator.getNameIdByName( "name_" + i));
        Assert.assertTrue(
            "ObjectNotFountNameTranslatorException expected",
            (i % 2) == 0);
      } catch (ObjectNotFoundNameTranslatorException e) {
        Assert.assertTrue(
            "ObjectNotFountNameTranslatorException not expected",
            (i % 2) != 0);
      }
      Assert.assertEquals("name_"+(i/2)*2, namesTranslator.getNameByNameId(i/2));
    }
  }
  
  

  @Test
  public void testGetNameIdByNameEmpty() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    for (int i = 0; i < 100; i++) {
      try {
        namesTranslator.getNameIdByName( "name_" + i);
        Assert.fail("ObjectNotFountNameTranslatorException expected");
      } catch (ObjectNotFoundNameTranslatorException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    }
  }

  @Test
  public void testGetNameIdByNameComposit() throws NameTranslatorException {
    NamesTranslator namesTranslator=getNamesTranslator();
    for (int i = 0; i < 100; i++) {
      try {
        namesTranslator.getNameIdByName("name_" + i);
        Assert.fail("ObjectNotFountNameTranslatorException expected");
      } catch (ObjectNotFoundNameTranslatorException e) {
        logger.info("Catched expected exception:"+e.getMessage());
      }
    }
    for (int i = 0; i < 100; i += 2) {
      namesTranslator.getOrRegisterName("name_" + i);
    }
    for (int i = 0; i < 100; i++) {
      try {
        Assert.assertEquals(i / 2, namesTranslator.getNameIdByName("name_" + i));
        Assert.assertTrue(
            "ObjectNotFountNameTranslatorException expected",
            (i % 2) == 0);
      } catch (ObjectNotFoundNameTranslatorException e) {
        Assert.assertTrue(
            "ObjectNotFountNameTranslatorException not expected",
            (i % 2) != 0);
      }
    }
  }

   @Test(expected=ObjectNotFoundNameTranslatorException.class)
   public void testRemoveNameNotFound() throws NameTranslatorException {
     NamesTranslator namesTranslator=getNamesTranslator();
     namesTranslator.removeName("xyz");
   }
   
   @Test
   public void testRemoveNameFunctional() throws NameTranslatorException {
     NamesTranslator namesTranslator=getNamesTranslator();
     int id=namesTranslator.getOrRegisterName("xyz");
     Assert.assertEquals(id, namesTranslator.getNameIdByName("xyz"));
     namesTranslator.removeName("xyz");
     try{
       namesTranslator.getNameIdByName( "xyz");
       Assert.fail("Exception expected");
     }catch (ObjectNotFoundNameTranslatorException e) {
       logger.info("Catched expected exception:"+e.getMessage());
    }
   }
   
   @Test
   public void testRemoveNameIdFunctional() throws NameTranslatorException {
     NamesTranslator namesTranslator=getNamesTranslator();
     int id=namesTranslator.getOrRegisterName("xyz");
     int id2=namesTranslator.getOrRegisterName("xyz2");
     Assert.assertEquals(id, namesTranslator.getNameIdByName("xyz"));
     namesTranslator.removeNameId(id);
     try{
       namesTranslator.getNameIdByName("xyz");
       Assert.fail("Exception expected");
     }catch (ObjectNotFoundNameTranslatorException e) {
       logger.info("Catched expected exception:"+e.getMessage()); 
    }
    Assert.assertEquals(id2, namesTranslator.getNameIdByName( "xyz2"));
   }
  
}
