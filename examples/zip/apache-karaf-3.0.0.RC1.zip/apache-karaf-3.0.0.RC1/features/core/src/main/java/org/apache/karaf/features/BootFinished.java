package org.apache.karaf.features;

/**
 * Marker interface for a service that announces when the karaf boot is finished
 */
public interface BootFinished {

}
